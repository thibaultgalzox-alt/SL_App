// Dessins des 14 titres achetables (onglet Permanent), dans la facture des objets
// de la boutique : objet plein, aplats francs, face a l'ombre plus sombre, reflet
// clair, ombre portee au sol. viewBox 0 0 100 100, sans fond (la tuile le porte).
var _TITRE_SVG={
// Invocateur de l'ombre : silhouette encapuchonnee, yeux violets, orbe d'ombre entre les mains
"Invocateur de l'ombre":'<ellipse cx="50" cy="90" rx="26" ry="4.5" fill="#000" opacity=".14"/>'
 +'<path d="M50 14 C33 14 26 30 26 46 L20 88 L80 88 L74 46 C74 30 67 14 50 14Z" fill="#3B2266"/>'
 +'<path d="M50 14 C67 14 74 30 74 46 L80 88 L58 88 C62 66 63 40 50 14Z" fill="#2A1750"/>'
 +'<path d="M50 24 C40 24 36 34 36 44 C36 52 42 56 50 56 C58 56 64 52 64 44 C64 34 60 24 50 24Z" fill="#120A24"/>'
 +'<ellipse cx="44" cy="43" rx="3.2" ry="2.2" fill="#C4A6FF"/><ellipse cx="56" cy="43" rx="3.2" ry="2.2" fill="#C4A6FF"/>'
 +'<circle cx="50" cy="72" r="10" fill="#7C3AED"/><circle cx="50" cy="72" r="6" fill="#B794FF"/><circle cx="47.5" cy="69.5" r="2.2" fill="#fff" opacity=".85"/>'
 +'<path d="M50 60 Q47 55 50 50 Q53 55 50 60Z" fill="#B794FF" opacity=".8"/>'
 +'<path d="M31 46 C31 34 37 22 46 17" fill="none" stroke="#6B4BA8" stroke-width="2" stroke-linecap="round" opacity=".7"/>',
// Briseur de limites : chaine d'acier brisee, eclat orange a la rupture
"Briseur de limites":'<ellipse cx="50" cy="88" rx="30" ry="4.5" fill="#000" opacity=".14"/>'
 +'<g transform="rotate(-28 50 52)">'
 +'<rect x="8" y="42" width="30" height="18" rx="9" fill="none" stroke="#5E6B78" stroke-width="7"/>'
 +'<rect x="8" y="42" width="30" height="18" rx="9" fill="none" stroke="#AEB9C4" stroke-width="3.2"/>'
 +'<rect x="62" y="42" width="30" height="18" rx="9" fill="none" stroke="#5E6B78" stroke-width="7"/>'
 +'<rect x="62" y="42" width="30" height="18" rx="9" fill="none" stroke="#AEB9C4" stroke-width="3.2"/>'
 +'<path d="M38 51 L44 47 M38 51 L43 56" stroke="#5E6B78" stroke-width="6" stroke-linecap="round"/>'
 +'<path d="M62 51 L56 46 M62 51 L57 56" stroke="#5E6B78" stroke-width="6" stroke-linecap="round"/></g>'
 +'<path d="M50 34 L54 46 L66 44 L56 52 L64 62 L52 57 L48 70 L45 57 L33 60 L42 51 L34 41 L46 46Z" fill="#FF8A3D"/>'
 +'<path d="M50 42 L52 48 L58 48 L53 52 L56 58 L50 55 L46 60 L46 54 L40 52 L46 49Z" fill="#FFD15C"/>',
// Fantome de la discipline : fantome souriant, bandeau rouge noue
"Fantôme de la discipline":'<ellipse cx="50" cy="90" rx="24" ry="4" fill="#000" opacity=".12"/>'
 +'<path d="M50 14 C33 14 24 27 24 44 L24 80 L31 74 L38 81 L45 74 L52 81 L59 74 L66 81 L76 74 L76 44 C76 27 67 14 50 14Z" fill="#EEF0FF"/>'
 +'<path d="M50 14 C67 14 76 27 76 44 L76 74 L66 81 L62 77 C68 60 68 32 50 14Z" fill="#CDD2F3"/>'
 +'<path d="M25 36 C40 32 60 32 75 36 L75 43 C60 39 40 39 25 43Z" fill="#E5383B"/>'
 +'<path d="M75 37 L88 31 L86 40Z M75 41 L87 46 L82 49Z" fill="#B8232A"/>'
 +'<ellipse cx="42" cy="52" rx="4" ry="5" fill="#2B2440"/><ellipse cx="58" cy="52" rx="4" ry="5" fill="#2B2440"/>'
 +'<circle cx="43.2" cy="50.4" r="1.4" fill="#fff"/><circle cx="59.2" cy="50.4" r="1.4" fill="#fff"/>'
 +'<path d="M45 62 Q50 66 55 62" fill="none" stroke="#2B2440" stroke-width="2.4" stroke-linecap="round"/>'
 +'<path d="M32 28 C36 21 42 18 48 17" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/>',
// L'Eternel : sablier dore, sable violet, symbole infini
"L'Éternel":'<ellipse cx="50" cy="91" rx="26" ry="4" fill="#000" opacity=".14"/>'
 +'<rect x="24" y="10" width="52" height="9" rx="4" fill="#E8A93A"/><rect x="24" y="80" width="52" height="9" rx="4" fill="#E8A93A"/>'
 +'<rect x="24" y="15" width="52" height="4" rx="2" fill="#B97A18"/><rect x="24" y="85" width="52" height="4" rx="2" fill="#B97A18"/>'
 +'<rect x="28" y="19" width="5" height="61" fill="#C98A22"/><rect x="67" y="19" width="5" height="61" fill="#C98A22"/>'
 +'<path d="M36 20 L64 20 C64 36 54 42 52 50 C54 58 64 64 64 80 L36 80 C36 64 46 58 48 50 C46 42 36 36 36 20Z" fill="#E9F2FF" opacity=".9"/>'
 +'<path d="M41 30 L59 30 C58 38 52 42 50 46 C48 42 42 38 41 30Z" fill="#8B5CF6"/>'
 +'<path d="M50 50 L50 66" stroke="#8B5CF6" stroke-width="2"/><path d="M38 79 C40 70 46 66 50 66 C54 66 60 70 62 79Z" fill="#7C3AED"/>'
 +'<path d="M40 22 C40 30 44 36 47 40" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".9"/>'
 +'<path d="M84 30 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2Z" fill="#FFD15C"/><path d="M14 60 l1.5 4 4 1.5 -4 1.5 -1.5 4 -1.5 -4 -4 -1.5 4 -1.5Z" fill="#C4A6FF"/>',
// Ascete : fleur de lotus sur l'eau
"Ascète":'<ellipse cx="50" cy="80" rx="36" ry="8" fill="#5BC3E8" opacity=".45"/>'
 +'<ellipse cx="50" cy="78" rx="30" ry="6" fill="#2E9E5B"/><ellipse cx="50" cy="76" rx="26" ry="4.5" fill="#46C27A"/>'
 +'<path d="M50 74 C30 72 18 60 16 48 C28 50 40 58 50 74Z" fill="#F28DB2"/>'
 +'<path d="M50 74 C70 72 82 60 84 48 C72 50 60 58 50 74Z" fill="#E0608F"/>'
 +'<path d="M50 74 C34 66 28 46 32 32 C42 40 48 56 50 74Z" fill="#F7A8C6"/>'
 +'<path d="M50 74 C66 66 72 46 68 32 C58 40 52 56 50 74Z" fill="#E8749E"/>'
 +'<path d="M50 74 C40 60 40 36 50 20 C60 36 60 60 50 74Z" fill="#FCC5DA"/>'
 +'<path d="M50 74 C56 60 58 40 50 20 C58 36 60 60 50 74Z" fill="#F29AB9"/>'
 +'<path d="M47 30 C45 40 45 52 47 62" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".8"/>'
 +'<circle cx="50" cy="66" r="4" fill="#FFD15C"/>',
// Gardien du silence : chouette aux grands yeux, bec clos
"Gardien du silence":'<ellipse cx="50" cy="90" rx="22" ry="4" fill="#000" opacity=".14"/>'
 +'<path d="M50 18 C30 18 22 34 22 52 C22 72 34 86 50 86 C66 86 78 72 78 52 C78 34 70 18 50 18Z" fill="#8A5A34"/>'
 +'<path d="M50 18 C70 18 78 34 78 52 C78 72 66 86 50 86 C62 74 66 44 50 18Z" fill="#6E4527"/>'
 +'<path d="M26 22 L34 32 L22 34Z M74 22 L66 32 L78 34Z" fill="#6E4527"/>'
 +'<path d="M50 56 C40 56 34 64 34 72 C34 80 42 84 50 84 C58 84 66 80 66 72 C66 64 60 56 50 56Z" fill="#E9CFA4"/>'
 +'<path d="M42 66 l3 3 M50 64 l3 3 M58 66 l3 3 M46 74 l3 3 M54 74 l3 3" stroke="#B98A58" stroke-width="1.8" stroke-linecap="round"/>'
 +'<circle cx="38" cy="44" r="12" fill="#F4E6C8"/><circle cx="62" cy="44" r="12" fill="#F4E6C8"/>'
 +'<circle cx="38" cy="44" r="7.5" fill="#FFC23A"/><circle cx="62" cy="44" r="7.5" fill="#FFC23A"/>'
 +'<circle cx="38" cy="44" r="4" fill="#1F1A14"/><circle cx="62" cy="44" r="4" fill="#1F1A14"/>'
 +'<circle cx="36.6" cy="42.6" r="1.5" fill="#fff"/><circle cx="60.6" cy="42.6" r="1.5" fill="#fff"/>'
 +'<path d="M46 52 L54 52 L50 60Z" fill="#E8A93A"/>',
// Maitre du temps : montre a gousset doree et sa chaine
"Maître du temps":'<ellipse cx="50" cy="90" rx="26" ry="4" fill="#000" opacity=".14"/>'
 +'<path d="M50 8 C40 8 34 12 30 18" fill="none" stroke="#C98A22" stroke-width="3" stroke-dasharray="4 3" stroke-linecap="round"/>'
 +'<rect x="45" y="12" width="10" height="9" rx="3" fill="#C98A22"/><circle cx="50" cy="11" r="4" fill="none" stroke="#E8A93A" stroke-width="3"/>'
 +'<circle cx="50" cy="54" r="32" fill="#B97A18"/><circle cx="50" cy="52" r="32" fill="#E8A93A"/>'
 +'<circle cx="50" cy="52" r="25" fill="#FFF8E8"/>'
 +'<g stroke="#5B4636" stroke-width="2.6" stroke-linecap="round"><path d="M50 30 V35"/><path d="M72 52 H67"/><path d="M50 74 V69"/><path d="M28 52 H33"/></g>'
 +'<path d="M50 52 L50 37" stroke="#1F1A14" stroke-width="3.2" stroke-linecap="round"/><path d="M50 52 L62 58" stroke="#E5383B" stroke-width="2.6" stroke-linecap="round"/>'
 +'<circle cx="50" cy="52" r="3" fill="#1F1A14"/>'
 +'<path d="M27 38 C31 30 38 25 46 23" fill="none" stroke="#FFE7A6" stroke-width="2.6" stroke-linecap="round"/>',
// Sentinelle : tour de guet de pierre, feu de veille au sommet
"Sentinelle":'<ellipse cx="50" cy="91" rx="26" ry="4" fill="#000" opacity=".14"/>'
 +'<path d="M50 6 C44 14 45 20 50 24 C55 20 56 14 50 6Z" fill="#FF8A3D"/><path d="M50 13 C47 18 48 21 50 23 C52 21 53 18 50 13Z" fill="#FFD15C"/>'
 +'<rect x="34" y="24" width="32" height="10" rx="2" fill="#8C7B6B"/>'
 +'<path d="M30 30 H70 V40 H30Z" fill="#A6927E"/><path d="M30 30 h7 v-5 h6 v5 h6 v-5 h6 v5 h6 v-5 h6 v5 h3 v10 H30Z" fill="#B8A48F"/>'
 +'<path d="M36 40 H64 L68 88 H32Z" fill="#B8A48F"/><path d="M52 40 H64 L68 88 H54Z" fill="#9C886F"/>'
 +'<g stroke="#8C7B6B" stroke-width="1.6"><path d="M35 52 H65 M34 64 H66 M33 76 H67 M44 40 V52 M56 52 V64 M42 64 V76 M58 76 V88"/></g>'
 +'<path d="M45 70 C45 64 55 64 55 70 V88 H45Z" fill="#4A3B2E"/><rect x="47" y="46" width="6" height="9" rx="3" fill="#FFC23A"/>',
// Forgeron d'habitudes : marteau sur l'enclume, etincelles
"Forgeron d'habitudes":'<ellipse cx="50" cy="90" rx="30" ry="4" fill="#000" opacity=".14"/>'
 +'<path d="M18 56 H82 C78 62 70 64 62 64 L60 72 H40 L38 64 C30 64 22 62 18 56Z" fill="#5E6B78"/>'
 +'<path d="M18 56 H82 L80 52 H22Z" fill="#AEB9C4"/><path d="M36 72 H64 L68 86 H32Z" fill="#4A5560"/>'
 +'<g transform="rotate(-35 54 36)"><rect x="51" y="30" width="6" height="40" rx="2" fill="#8A5A34"/><rect x="51" y="30" width="3" height="40" rx="1.5" fill="#A8744A"/>'
 +'<rect x="40" y="20" width="28" height="13" rx="3" fill="#5E6B78"/><rect x="40" y="20" width="28" height="5" rx="2" fill="#AEB9C4"/></g>'
 +'<path d="M30 46 l-6 -6 M34 42 l-2 -9 M26 50 l-9 -1" stroke="#FFB020" stroke-width="2.6" stroke-linecap="round"/>'
 +'<circle cx="38" cy="50" r="3" fill="#FFD15C"/>',
// Architecte de soi : compas de dessin sur un plan bleu
"Architecte de soi":'<ellipse cx="50" cy="90" rx="30" ry="4" fill="#000" opacity=".12"/>'
 +'<path d="M16 30 L76 22 L84 80 L24 88Z" fill="#1E5FD8"/><path d="M16 30 L76 22 L77 30 L17 38Z" fill="#3C7BEA"/>'
 +'<g stroke="#9CC2FF" stroke-width="1.2" opacity=".8"><path d="M26 46 L76 40 M27 58 L78 52 M29 70 L80 64 M40 34 L46 84 M58 32 L64 82"/></g>'
 +'<path d="M34 72 L58 68 L54 46 L36 49Z" fill="none" stroke="#fff" stroke-width="1.8" stroke-dasharray="3 2"/>'
 +'<path d="M54 14 L38 74" stroke="#5E6B78" stroke-width="5" stroke-linecap="round"/><path d="M54 14 L70 72" stroke="#5E6B78" stroke-width="5" stroke-linecap="round"/>'
 +'<path d="M54 14 L38 74" stroke="#C7D0D9" stroke-width="2" stroke-linecap="round"/><path d="M54 14 L70 72" stroke="#C7D0D9" stroke-width="2" stroke-linecap="round"/>'
 +'<path d="M43 52 L65 52" stroke="#E8A93A" stroke-width="3"/>'
 +'<circle cx="54" cy="14" r="6" fill="#E8A93A"/><circle cx="54" cy="14" r="2.4" fill="#fff"/>'
 +'<path d="M68 70 L72 80 L70 72Z" fill="#E5383B"/>',
// Porteur de flamme : torche au poing, grande flamme
"Porteur de flamme":'<ellipse cx="50" cy="91" rx="16" ry="3.5" fill="#000" opacity=".14"/>'
 +'<path d="M44 52 H56 L53 90 H47Z" fill="#8A5A34"/><path d="M50 52 H56 L53 90 H50Z" fill="#6E4527"/>'
 +'<rect x="40" y="46" width="20" height="9" rx="2" fill="#5E6B78"/><rect x="40" y="46" width="20" height="3.5" rx="1.5" fill="#AEB9C4"/>'
 +'<rect x="44" y="62" width="12" height="4" rx="1.5" fill="#4A5560"/>'
 +'<path d="M50 6 C36 20 32 32 36 40 C38 44 44 47 50 47 C56 47 62 44 64 40 C68 32 64 20 50 6Z" fill="#FF5A1F"/>'
 +'<path d="M50 16 C42 26 40 34 43 39 C45 43 55 43 57 39 C60 34 58 26 50 16Z" fill="#FF9A3D"/>'
 +'<path d="M50 26 C46 32 45 36 47 40 C48 42 52 42 53 40 C55 36 54 32 50 26Z" fill="#FFE07A"/>'
 +'<circle cx="64" cy="18" r="2" fill="#FFB020"/><circle cx="34" cy="24" r="1.6" fill="#FFB020"/>',
// Jour apres Jour : marches qui montent vers un soleil levant
"Jour après Jour":'<ellipse cx="50" cy="90" rx="34" ry="4" fill="#000" opacity=".12"/>'
 +'<circle cx="70" cy="30" r="14" fill="#FFC23A"/><circle cx="70" cy="30" r="9" fill="#FFE07A"/>'
 +'<g stroke="#FFB020" stroke-width="3" stroke-linecap="round"><path d="M70 9 V12 M88 20 L85 22 M91 33 H88 M52 20 L55 22"/></g>'
 +'<path d="M14 86 V74 H32 V62 H50 V50 H68 V86Z" fill="#13A05B"/>'
 +'<path d="M14 74 H32 V62 H50 V50 H68 V54 H54 V66 H36 V78 H14Z" fill="#3CC47C"/>'
 +'<path d="M68 50 H86 V86 H68Z" fill="#0B6B3C"/><path d="M68 50 H86 V54 H68Z" fill="#2E9E5B"/>'
 +'<circle cx="23" cy="69" r="2.6" fill="#fff"/><circle cx="41" cy="57" r="2.6" fill="#fff"/><circle cx="59" cy="45" r="2.6" fill="#fff"/><circle cx="77" cy="45" r="2.6" fill="#fff" opacity=".5"/>',
// Monarque : couronne d'or et ses gemmes sur un coussin
"Monarque":'<ellipse cx="50" cy="90" rx="32" ry="4" fill="#000" opacity=".14"/>'
 +'<path d="M14 76 C14 68 24 66 50 66 C76 66 86 68 86 76 C86 84 76 86 50 86 C24 86 14 84 14 76Z" fill="#7C3AED"/>'
 +'<path d="M14 76 C14 68 24 66 50 66 C76 66 86 68 86 76 C70 72 30 72 14 76Z" fill="#9F6BFF"/>'
 +'<path d="M22 66 L18 30 L36 46 L50 20 L64 46 L82 30 L78 66Z" fill="#E8A93A"/>'
 +'<path d="M50 20 L64 46 L82 30 L78 66 L56 66Z" fill="#C98A22"/>'
 +'<rect x="21" y="58" width="58" height="9" rx="3" fill="#B97A18"/>'
 +'<circle cx="18" cy="29" r="4" fill="#FFE07A"/><circle cx="50" cy="19" r="4.5" fill="#FFE07A"/><circle cx="82" cy="29" r="4" fill="#FFE07A"/>'
 +'<path d="M50 40 L55 48 L50 56 L45 48Z" fill="#E5383B"/><circle cx="33" cy="62.5" r="3" fill="#0B7CFF"/><circle cx="67" cy="62.5" r="3" fill="#13A05B"/>'
 +'<path d="M26 56 L23 36" stroke="#FFE7A6" stroke-width="2.4" stroke-linecap="round"/>',
// Legende vivante : couronne de laurier d'or autour d'une etoile
"Légende vivante":'<ellipse cx="50" cy="91" rx="26" ry="4" fill="#000" opacity=".14"/>'
 +'<path d="M50 86 C26 82 14 62 18 38" fill="none" stroke="#B97A18" stroke-width="3" stroke-linecap="round"/>'
 +'<path d="M50 86 C74 82 86 62 82 38" fill="none" stroke="#B97A18" stroke-width="3" stroke-linecap="round"/>'
 +[[22,44,-40],[20,56,-20],[24,68,0],[32,78,20],[78,44,40],[80,56,20],[76,68,0],[68,78,-20]].map(function(f){
   return '<ellipse cx="'+f[0]+'" cy="'+f[1]+'" rx="4.5" ry="9" transform="rotate('+f[2]+' '+f[0]+' '+f[1]+')" fill="'+(f[0]<50?'#E8A93A':'#C98A22')+'"/>';}).join('')
 +'<path d="M50 22 L57 38 L74 39 L61 50 L65 67 L50 58 L35 67 L39 50 L26 39 L43 38Z" fill="#8B5CF6"/>'
 +'<path d="M50 22 L57 38 L74 39 L61 50 L65 67 L50 58Z" fill="#6D3FE0"/>'
 +'<path d="M50 30 L53 39" stroke="#E4D6FF" stroke-width="2.4" stroke-linecap="round"/>'
 +'<path d="M84 18 l1.6 4 4 1.6 -4 1.6 -1.6 4 -1.6 -4 -4 -1.6 4 -1.6Z" fill="#FFD15C"/><path d="M16 20 l1.2 3 3 1.2 -3 1.2 -1.2 3 -1.2 -3 -3 -1.2 3 -1.2Z" fill="#FFD15C"/>'
};
