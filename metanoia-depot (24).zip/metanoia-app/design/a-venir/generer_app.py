# Fabrique design/a-venir/maquette-app/ : l APPLICATION REELLE (copie de www/)
# avec les maquettes de l onglet « A venir » injectees (variantes.js) et une
# amorce (amorce.js) qui pose un joueur au jour 24 sur Boutique > A venir.
#   python3 design/a-venir/generer_app.py   (depuis la racine du depot)
import os, shutil
R=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
W=os.path.join(R,'www'); D=os.path.join(R,'design','a-venir'); OUT=os.path.join(D,'maquette-app')
if os.path.isdir(OUT): shutil.rmtree(OUT)
shutil.copytree(W,OUT)
for f in ['variantes.js','amorce.js']: shutil.copy(os.path.join(D,f),OUT)
p=os.path.join(OUT,'index.html'); s=open(p,encoding='utf-8').read()
i=s.rindex('</body>')
s=s[:i]+'<script src="variantes.js"></script><script src="amorce.js"></script>\n'+s[i:]
open(p,'w',encoding='utf-8').write(s)
print('ok', sorted(os.listdir(OUT)))
