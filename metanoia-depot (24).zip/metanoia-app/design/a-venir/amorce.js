// Amorce de la maquette publiee : joueur fictif au jour 24, ecran Boutique > A venir.
(function(){
var css=document.createElement('style');css.textContent='#net-banner{display:none!important}.flash,.toast,#toast{display:none!important}';document.head.appendChild(css);
var n=0;
(function attendre(){
  if(!(typeof ST!=='undefined'&&typeof _obFinish==='function'&&typeof _shopTab==='function'&&window.AV)){if(n++<200)return setTimeout(attendre,100);return;}
  setTimeout(function(){
    try{
      if(!ST.onboarded){ST._ob={age:1,situation:1,sportLevel:1,physGoal:0,sportAccess:[0,2],collectifSport:'',collectifJours:[],mindLevel:0,screenHours:3,sleep:1,resistances:[1,2],prog:'Standard'};ST.myWhy='x';ST._tutoSeen=true;_obFinish();}
    }catch(e){}
    setTimeout(function(){
      document.querySelectorAll('.tuto-ui,#tuto-card,#tuto-ov,.tuto-overlay').forEach(function(x){x.remove();});
      if(!ST._avPose){ST.day=24;ST.points=20416;ST._avPose=1;}
      ST._tutoScreens=new Proxy({},{get:function(){return true}});window._isUnlocked=function(){return true};
      try{save();}catch(e){}
      nav('s-rewards');
      var b=document.querySelectorAll('#shop-tabs > *')[2];_shopTab('upcoming',b);
      AV.panneau();AV.maj();
    },1200);
  },600);
})();
})();
