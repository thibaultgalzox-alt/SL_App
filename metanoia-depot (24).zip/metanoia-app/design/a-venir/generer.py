# Fabrique design/a-venir/maquette/ : les templates de l onglet « A venir »,
# avec les VRAIES donnees des marchands (noms, objets, prix, figures SVG,
# icones d objets) extraites de www/index.html. Ne pas retoucher la maquette :
# modifier source.html puis relancer
#   python3 design/a-venir/generer.py   (depuis la racine du depot)
import os, shutil
R=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
W=os.path.join(R,'www'); D=os.path.join(R,'design','a-venir'); OUT=os.path.join(D,'maquette')
s=open(os.path.join(W,'index.html'),encoding='utf-8').read()

def bloc(debut, ouvre='{'):
    i=s.index(debut); j=s.index(ouvre,i); ferme={'{':'}','[':']'}[ouvre]
    k=j; n=0; q=None; esc=False
    while k<len(s):
        c=s[k]
        if q:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c==q: q=None
        elif c in '\'"`': q=c
        elif s.startswith('//',k) and s[k-1] not in ':\\':
            k=s.index('\n',k); continue
        elif c==ouvre: n+=1
        elif c==ferme:
            n-=1
            if n==0:
                fin=k+1
                if s[fin:fin+1]==';': fin+=1
                return s[i:fin]
        k+=1
    raise Exception('non ferme : '+debut)

CODE='\n'.join([bloc('var _MERCHANTS=[','['), bloc('var _MERCHANT_ITEMS={'),
  bloc('var _DAILY_POOL=[','['), bloc('var _FULL_SVG_ITEMS = {'), 'var _SVG_CACHE_ITEM={};',
  bloc('function _itemSVG(effect,rarity){'), bloc('function _merchantSvg(idx){')])
src=open(os.path.join(D,'source.html'),encoding='utf-8').read()
page=src.replace('/*DONNEES_APP*/',CODE.replace('</script>','<\\/script>'))
assert page.count('—')+page.count('–')==0, 'tiret long'
if os.path.isdir(OUT): shutil.rmtree(OUT)
os.makedirs(OUT); shutil.copytree(os.path.join(W,'fonts'),os.path.join(OUT,'fonts'))
shutil.copy(os.path.join(W,'fonts.css'),OUT)
open(os.path.join(OUT,'index.html'),'w',encoding='utf-8').write(page)
print('ok', len(page))
