// Maquettes de l onglet « A venir », injectees dans l APPLICATION REELLE.
// Tout vient du vrai code : _shopCycleInfo, _MERCHANTS, _merchantSvg,
// _openMerchantPage, styles et polices de l app. Rien n est recopie.
// Panneau de maquette : choix de la variante et du jour de jeu.
(function(){
'use strict';
// Couleurs vives par marchand : PROPOSITION (palette des menus de l app)
var VIF=['#13A05B','#0BA5A0','#FF5A1F','#0B7CFF','#E5383B','#7C3AED'];
var FONCE=['#0B6B3C','#06706C','#C23A0A','#0656B8','#A3191C','#5121B0'];
var N=6, SLOT=9, ACTIF=5, TOUR=N*SLOT;
var RAD=Math.PI/180;
function court(i){return _MERCHANTS[i].name.split(' ')[0];}
function esc(t){return String(t).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
var SANS={};
function sansAnim(i){ // figure figee (petites vignettes : aucune animation, comme la fiche d info de l app)
  if(!SANS[i]) SANS[i]=_merchantSvg(i).replace(/<(animate|animateTransform|animateMotion|set)\b[^>]*?(\/>|>[\s\S]*?<\/\1>)/g,'');
  return SANS[i];
}
function buste(i){ // tete et epaules, cadrees dans le vrai dessin
  return sansAnim(i).replace(/viewBox="[^"]*"/,'viewBox="48 14 104 104"').replace('<svg','<svg preserveAspectRatio="xMidYMid slice" style="width:100%;height:100%;display:block"');
}
function entier(i,anim){return (anim?_merchantSvg(i):sansAnim(i)).replace('<svg','<svg style="width:100%;height:100%;display:block;overflow:visible"');}
function etat(){
  var I=_shopCycleInfo(), d=ST.day||1, nx=(I.idx+1)%N;
  var vedette=I.active?I.idx:nx;
  return {I:I,d:d,vedette:vedette,
    phrase:I.active?('Au marché encore '+I.daysLeftActive+' jour'+(I.daysLeftActive>1?'s':'')):('Arrive dans '+I.daysUntilNext+' jour'+(I.daysUntilNext>1?'s':'')),
    pos:((d-1)%TOUR)/TOUR}; // 0..1 dans le tour complet (slot 0 = Enguerrand)
}
// dans combien de jours le marchand i arrive (0 s il est la)
function dans(i,E){var I=E.I;if(I.active&&I.idx===i)return 0;var k=((i-I.idx)%N+N)%N||N;return k*SLOT-(I.dayInCycle-1);}
function carte(inner,extra){return '<div style="background:#fff;border:1.5px solid rgba(21,18,26,.07);box-shadow:0 4px 0 rgba(21,18,26,.07),0 10px 24px -14px rgba(21,18,26,.25);border-radius:24px;'+(extra||'')+'">'+inner+'</div>';}
function legende(E,clair){
  var i=E.vedette;
  return '<div style="text-align:center;margin-top:18px">'
   +'<div style="font-family:Cinzel,serif;font-weight:700;font-size:21px;color:'+(clair?'#fff':'#15121A')+'">'+esc(_MERCHANTS[i].name)+'</div>'
   +'<div style="display:inline-block;margin-top:8px;padding:7px 16px;border-radius:30px;font:800 13px Sora;'
   +(clair?'background:rgba(255,255,255,.22);color:#fff':'background:'+VIF[i]+';color:#fff;box-shadow:0 4px 12px '+VIF[i]+'55')+'">'+E.phrase+'</div></div>';
}
function arc(cx,cy,r,a0,a1){ // angles en degres, 0 = haut, sens horaire
  var p0=[cx+r*Math.sin(a0*RAD),cy-r*Math.cos(a0*RAD)],p1=[cx+r*Math.sin(a1*RAD),cy-r*Math.cos(a1*RAD)];
  return 'M'+p0[0].toFixed(2)+' '+p0[1].toFixed(2)+' A'+r+' '+r+' 0 '+((a1-a0)>180?1:0)+' 1 '+p1[0].toFixed(2)+' '+p1[1].toFixed(2);
}
function rond(i,taille,bord,extra){
  return '<div onclick="_openMerchantPage('+i+')" style="width:'+taille+'px;height:'+taille+'px;border-radius:50%;overflow:hidden;cursor:pointer;'
   +'background:radial-gradient(circle at 50% 30%,#fff,'+VIF[i]+'33);box-shadow:0 0 0 '+bord+'px #fff,0 4px 12px rgba(21,18,26,.22);'+(extra||'')+'">'+buste(i)+'</div>';
}

var V={};
// 1. ANNEAU : un tour complet = un anneau epais, une couleur par marchand
V.anneau=function(E){
  var S=300,C=150,R=100,W=30,h='';
  for(var i=0;i<N;i++){var a=i*60;
    h+='<path d="'+arc(C,C,R,a+1.5,a+60*ACTIF/SLOT)+'" stroke="'+VIF[i]+'" stroke-width="'+W+'" fill="none" stroke-linecap="butt"/>';
    h+='<path d="'+arc(C,C,R,a+60*ACTIF/SLOT+1,a+58.5)+'" stroke="'+VIF[i]+'" stroke-opacity=".2" stroke-width="'+W+'" fill="none"/>';}
  var at=E.pos*360, bx=C+R*Math.sin(at*RAD), by=C-R*Math.cos(at*RAD);
  var tetes='';
  for(i=0;i<N;i++){var am=(i*60+60*ACTIF/SLOT/2)*RAD,x=(C+142*Math.sin(am))/S*100,y=(C-142*Math.cos(am))/S*100,g=i===E.vedette;
    tetes+='<div style="position:absolute;left:'+x+'%;top:'+y+'%;transform:translate(-50%,-50%)">'+rond(i,g?50:40,g?4:3,g?'box-shadow:0 0 0 4px #fff,0 0 0 7px '+VIF[i]+',0 6px 14px rgba(21,18,26,.25)':'')+'</div>';}
  return carte('<div style="position:relative;width:100%;max-width:300px;margin:0 auto;aspect-ratio:1">'
    +'<svg viewBox="0 0 '+S+' '+S+'" style="position:absolute;inset:0;width:100%;height:100%;overflow:visible">'+h
    +'</svg>'+tetes+'<div style="position:absolute;left:'+(bx/S*100)+'%;top:'+(by/S*100)+'%;width:26px;height:26px;transform:translate(-50%,-50%);border-radius:50%;background:#fff;border:4px solid #15121A;box-shadow:0 3px 8px rgba(0,0,0,.3)"></div>'
    +'<div onclick="_openMerchantPage('+E.vedette+')" style="position:absolute;left:50%;top:52%;transform:translate(-50%,-50%);width:34%;aspect-ratio:200/240;cursor:pointer">'+entier(E.vedette,true)+'</div></div>'
    +'<div style="height:16px"></div>'+legende(E),'padding:34px 26px 24px');
};
// 2. ROUE DE FORTUNE : parts epaisses, la roue tourne, la fleche montre aujourd hui
V.roue=function(E){
  var S=300,C=150,R=146,r0=36,h='',rot=-E.pos*360;
  function part(a0,a1,ri,re){var A=[a0,a1].map(function(a){return a*RAD;});
    return 'M'+(C+ri*Math.sin(A[0]))+' '+(C-ri*Math.cos(A[0]))+' L'+(C+re*Math.sin(A[0]))+' '+(C-re*Math.cos(A[0]))
      +' A'+re+' '+re+' 0 0 1 '+(C+re*Math.sin(A[1]))+' '+(C-re*Math.cos(A[1]))+' L'+(C+ri*Math.sin(A[1]))+' '+(C-ri*Math.cos(A[1]))+' A'+ri+' '+ri+' 0 0 0 '+(C+ri*Math.sin(A[0]))+' '+(C-ri*Math.cos(A[0]))+'Z';}
  for(var i=0;i<N;i++){var a=i*60,m=a+60*ACTIF/SLOT;
    h+='<path d="'+part(a,m,r0,R)+'" fill="'+VIF[i]+'" stroke="#fff" stroke-width="3"/>';
    h+='<path d="'+part(m,a+60,r0,R)+'" fill="'+VIF[i]+'" fill-opacity=".22" stroke="#fff" stroke-width="3"/>';}
  var tetes='';
  for(i=0;i<N;i++){var am=(i*60+60*ACTIF/SLOT/2)*RAD,x=(C+98*Math.sin(am))/S*100,y=(C-98*Math.cos(am))/S*100;
    tetes+='<div style="position:absolute;left:'+x+'%;top:'+y+'%;transform:translate(-50%,-50%) rotate('+(-rot)+'deg)">'+rond(i,56,3)+'</div>';}
  var I=E.I,n=I.active?I.daysLeftActive:I.daysUntilNext;
  return carte('<div style="position:relative;width:100%;max-width:310px;margin:0 auto;aspect-ratio:1">'
    +'<div style="position:absolute;inset:0;transform:rotate('+rot+'deg)"><svg viewBox="0 0 '+S+' '+S+'" style="position:absolute;inset:0;width:100%;height:100%">'+h+'</svg>'+tetes+'</div>'
    +'<svg viewBox="0 0 40 34" style="position:absolute;left:50%;top:-14px;width:40px;transform:translateX(-50%);filter:drop-shadow(0 3px 3px rgba(0,0,0,.25))"><path d="M4 2 H36 L20 32Z" fill="#15121A" stroke="#fff" stroke-width="3" stroke-linejoin="round"/></svg>'
    +'<div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:23%;aspect-ratio:1;border-radius:50%;background:#fff;box-shadow:0 4px 0 rgba(21,18,26,.1);display:flex;flex-direction:column;align-items:center;justify-content:center">'
    +'<div style="font:800 26px Sora;line-height:1;color:'+VIF[E.vedette]+'">'+n+'</div><div style="font:800 10px Sora;color:#75707F">JOUR'+(n>1?'S':'')+'</div></div></div>'
    +legende(E),'padding:30px 16px 24px');
};
// 3. ARCHE : le marchand du moment au sommet, les autres montent et descendent
V.arche=function(E){
  var v=E.vedette,f=FONCE[v],c=VIF[v],h='';
  var pl=[[-2,8,80],[-1,25,44],[0,50,22],[1,75,44],[2,92,80]]; // rang relatif, x %, y %
  var path='<svg viewBox="0 0 100 100" preserveAspectRatio="none" style="position:absolute;inset:0;width:100%;height:100%"><path d="M2 100 Q50 -38 98 100" fill="none" stroke="rgba(255,255,255,.35)" stroke-width=".7" stroke-dasharray="1.5 2.5" vector-effect="non-scaling-stroke"/></svg>';
  pl.forEach(function(p){var i=((v+p[0])%N+N)%N,g=p[0]===0,t=g?88:(Math.abs(p[0])===1?56:42);
    var lib=p[0]<0?(E.I.active?'':'') :(p[0]===0?'':dans(i,E)+' j');
    h+='<div style="position:absolute;left:'+p[1]+'%;top:'+p[2]+'%;transform:translate(-50%,-50%);text-align:center;opacity:'+(p[0]<0?.55:1)+'">'
      +rond(i,t,g?5:3,g?'box-shadow:0 0 0 5px #fff,0 0 0 10px '+c+'66,0 10px 30px rgba(0,0,0,.35)':'')
      +(lib?'<div style="margin-top:6px;font:800 12px Sora;color:#fff">'+lib+'</div>':'')+'</div>';});
  return '<div style="border-radius:24px;padding:22px 16px 24px;background:linear-gradient(150deg,'+c+','+f+');box-shadow:0 10px 26px -10px '+f+';overflow:hidden">'
    +'<div style="position:relative;height:220px">'+path+h+'</div>'+legende(E,true)+'</div>';
};
// 4. ANNEAU DU MOMENT : 9 crans autour du marchand (5 au marche, 4 de route)
V.cercle=function(E){
  var I=E.I,i=I.idx,c=VIF[i],f=FONCE[i],S=260,C=130,R=112,h='';
  // 5 segments, un par jour de marche, de gauche a droite dans le sens des aiguilles d une montre
  // (arc de -150 a +150 degres, ouvert en bas). Jour 1 : 5 blancs ; chaque jour, le plus a gauche
  // s eteint ; sur la route : tous gris.
  var blancs=I.active?(ACTIF-I.dayInCycle+1):0, pas=300/ACTIF;
  for(var k=0;k<ACTIF;k++){var a0=-150+k*pas+8,a1=-150+(k+1)*pas-8,on=k>=ACTIF-blancs;
    h+='<path d="'+arc(C,C,R,a0,a1)+'" fill="none" stroke-linecap="round" stroke-width="20" stroke="'+(on?'#fff':'rgba(40,28,40,.28)')+'"'
      +(on?' style="filter:drop-shadow(0 2px 6px rgba(0,0,0,.18))"':'')+'/>';}
  var suite='';
  for(var k2=1;k2<=5;k2++){var j=(i+k2)%N;suite+='<div style="text-align:center;flex:1">'+rond(j,46,3,'margin:0 auto')+'<div style="font:800 11px Sora;color:#3B3644;margin-top:7px;white-space:nowrap">'+dans(j,E)+' j</div></div>';}
  return '<div style="border-radius:24px;padding:24px 16px;background:linear-gradient(150deg,'+c+','+f+');box-shadow:0 10px 26px -10px '+f+'">'
    +'<div style="position:relative;width:78%;max-width:260px;margin:0 auto;aspect-ratio:1">'
    +'<svg viewBox="0 0 '+S+' '+S+'" style="position:absolute;inset:0;width:100%;height:100%;overflow:visible">'+h+'</svg>'
    +'<div onclick="_openMerchantPage('+i+')" style="position:absolute;left:50%;top:51%;transform:translate(-50%,-50%);width:50%;aspect-ratio:200/240;cursor:pointer'+(I.active?'':';opacity:.5;filter:grayscale(.6)')+'">'+entier(i,I.active)+'</div></div>'
    +'<div style="text-align:center;margin-top:14px"><div style="font-family:Cinzel,serif;font-weight:700;font-size:21px;color:#fff">'+esc(_MERCHANTS[i].name)+'</div>'
    +'<div style="display:inline-block;margin-top:8px;padding:7px 16px;border-radius:30px;font:800 13px Sora;background:rgba(255,255,255,.22);color:#fff">'
    +(I.active?'Au marché encore '+I.daysLeftActive+' jour'+(I.daysLeftActive>1?'s':''):'Reparti · '+esc(court(E.vedette))+' arrive dans '+I.daysUntilNext+' j')+'</div></div></div>'
    +carte('<div style="font:800 12px Sora;color:#75707F;margin-bottom:12px">Ensuite</div><div style="display:flex;gap:4px">'+suite+'</div>','padding:16px 12px;margin-top:14px');
};

var ORDRE=[['actuel','Actuel'],['anneau','1 Anneau'],['roue','2 Roue'],['arche','3 Arche'],['cercle','4 Cercle']];
var choix='anneau', ancien=null;
function rendre(){
  var t=document.getElementById('shop-tab-upcoming');if(!t)return;
  if(ancien===null)ancien=t.innerHTML;
  if(choix==='actuel'){if(!t.querySelector('#shop-upcoming-list'))t.innerHTML=ancien;_AV_orig();return;}
  t.innerHTML='<div style="padding-top:4px">'+V[choix](etat())+'</div>';
}
var _AV_orig=window._renderUpcoming;
window._renderUpcoming=rendre;
function panneau(){
  if(document.getElementById('av-pan'))return;
  var p=document.createElement('div');p.id='av-pan';
  p.style.cssText='position:fixed;left:8px;right:8px;top:calc(env(safe-area-inset-top,0px) + 6px);z-index:999999;background:rgba(21,18,26,.92);color:#fff;border-radius:16px;padding:8px;font:700 12px Sora;box-shadow:0 8px 24px rgba(0,0,0,.3)';
  p.innerHTML='<div style="display:flex;gap:4px;flex-wrap:wrap">'+ORDRE.map(function(o){return '<button data-v="'+o[0]+'" style="flex:1;min-height:36px;border:0;border-radius:10px;font:800 11.5px Sora;padding:0 6px">'+o[1]+'</button>';}).join('')+'</div>'
   +'<div style="display:flex;align-items:center;gap:8px;margin-top:6px"><button data-j="-1" style="width:44px;min-height:34px;border:0;border-radius:10px;font:800 16px Sora">-</button>'
   +'<div id="av-j" style="flex:1;text-align:center"></div><button data-j="1" style="width:44px;min-height:34px;border:0;border-radius:10px;font:800 16px Sora">+</button>'
   +'<button id="av-repli" style="min-height:34px;border:0;border-radius:10px;font:800 11px Sora;padding:0 10px">Masquer</button></div>';
  document.body.appendChild(p);
  p.onclick=function(e){var b=e.target.closest('button');if(!b)return;
    if(b.id==='av-repli'){p.style.display='none';var r=document.getElementById('av-rouvrir');r.style.display='block';return;}
    if(b.dataset.v)choix=b.dataset.v;
    if(b.dataset.j){ST.day=Math.max(1,(ST.day||1)+(+b.dataset.j));try{_renderMerchant();}catch(x){}}
    maj();};
  var r=document.createElement('button');r.id='av-rouvrir';r.textContent='Maquette';
  r.style.cssText='display:none;position:fixed;right:10px;top:calc(env(safe-area-inset-top,0px) + 8px);z-index:999999;border:0;border-radius:12px;background:#15121A;color:#fff;font:800 11px Sora;padding:9px 12px';
  r.onclick=function(){r.style.display='none';p.style.display='block';};document.body.appendChild(r);
}
function maj(){
  var I=_shopCycleInfo();
  document.getElementById('av-j').textContent='Jour '+ST.day+' · '+(I.active?court(I.idx)+' au marché':'route');
  document.querySelectorAll('#av-pan [data-v]').forEach(function(b){var on=b.dataset.v===choix;b.style.background=on?'#E0115F':'#3B3644';b.style.color='#fff';});
  document.querySelectorAll('#av-pan [data-j]').forEach(function(b){b.style.background='#3B3644';b.style.color='#fff';});
  rendre();
}
window.AV={rendre:rendre,choisir:function(v){choix=v;maj();},maj:maj,panneau:panneau,V:V};
})();
