// Maquettes de l onglet « Permanent » de la Boutique, injectees dans l APPLICATION REELLE.
// Catalogue, prix, dessins, descriptions et achats : le vrai code (_PERM_ITEM_EFFECTS,
// _permItemByEffect, _FULL_SVG_ITEMS, UTIL_R, SYM_R, _buyPermItem, buyRew,
// _permTitleTierByName). Seuls la mise en page et les regroupements sont proposes.
(function(){
'use strict';
// Regroupement par usage : PROPOSITION
var RAYONS=[
  {t:'Booste tes gains',c:'#FF5A1F',f:'#C23A0A',clair:'#FFEDE5',e:['double_xp','double_pts']},
  {t:'Vois avant les autres',c:'#7C3AED',f:'#5121B0',clair:'#F1EAFE',e:['preview_quests','watcher_shard']},
  {t:'Change le cours du jeu',c:'#0B7CFF',f:'#0656B8',clair:'#E6F1FF',e:['eclipse','void_key']},
  {t:'Protège ta série',c:'#13A05B',f:'#0B6B3C',clair:'#E4F6EC',bouclier:true},
  {t:'Titres à échanger',c:'#E0115F',f:'#9E0B43',clair:'#FDE7EF',titres:true}
];
var SHIELD=['shield_1','shield_3','shield_5'];
function esc(t){return String(t).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function dessin(eff){var raw=_FULL_SVG_ITEMS&&_FULL_SVG_ITEMS[eff];return raw?'<svg viewBox="0 0 100 100" width="100%" height="100%">'+_uniqSvgContent(raw)+'</svg>':'';}
function verrou(){return ST.integrity<50&&ST.day>=14;}
// Liste uniforme des objets d un rayon : {nom, desc, prix, svg, achat}
function objets(r){
  if(r.bouclier) return UTIL_R.map(function(u,i){return {nom:u.name,desc:u.desc,prix:u.cost,svg:dessin(SHIELD[i]),achat:'buyRew('+i+',\'util\')'};});
  if(r.titres){var own=ST.unlockedTitles||[];
    return SYM_R.map(function(x,i){return {x:x,i:i};}).filter(function(o){return own.indexOf(o.x.name.replace('Titre : ',''))<0;})
      .map(function(o){var nm=o.x.name.replace('Titre : ',''),t=_permTitleTierByName(nm);
        return {nom:nm,titre:true,tier:t,prix:o.x.cost,achat:'buyRew('+o.i+',\'sym\')',desc:'Titre '+t.label.toLowerCase()+' : il rejoint ta collection dans Identité.'};});}
  return r.e.map(function(e){var it=_permItemByEffect(e);return it?{nom:it.name,desc:it.desc,prix:it.orig||it.price,svg:dessin(e),achat:'_buyPermItem(\''+e+'\')'}:null;}).filter(Boolean);
}
function bouton(o,c,blanc){
  var pts=ST.points||0,ok=!verrou()&&pts>=o.prix,lib=verrou()?'Verrouillé':ok?(o.titre?'Échanger':'Acheter'):'Il manque '+(o.prix-pts);
  var st=blanc?(ok?'background:#fff;color:'+c+';box-shadow:0 3px 0 rgba(0,0,0,.18)':'background:rgba(255,255,255,.25);color:#fff')
             :(ok?'background:'+c+';color:#fff;box-shadow:0 3px 0 '+c+'88':'background:#EEEAE4;color:#9A93A0');
  return '<button '+(ok?'':'disabled ')+'onclick="event.stopPropagation();'+o.achat+'" style="border:0;border-radius:14px;padding:0 14px;min-height:42px;font:800 13px Sora,sans-serif;white-space:nowrap;'+st+'">'
    +'<span style="display:block;line-height:1.1">'+lib+'</span>'+(ok?'<span style="display:block;font-size:11px;opacity:.85;line-height:1.2">'+o.prix+' pts</span>':'')+'</button>';
}
function sigle(o,taille){ // medaille de titre : le vrai sigil de l app, a la couleur du palier
  return '<div style="width:'+taille+'px;height:'+taille+'px;flex:none;border-radius:50%;color:#fff;padding:'+(taille*.12)+'px;background:radial-gradient(circle at 35% 30%,'+o.tier.color+'cc,'+o.tier.color+');box-shadow:0 4px 0 rgba(0,0,0,.12)">'+o.tier.svg+'</div>';
}
function tete(r){
  return '<div style="display:flex;align-items:center;gap:10px;margin:22px 2px 12px"><span style="width:12px;height:12px;border-radius:4px;background:'+r.c+';box-shadow:0 0 0 4px '+r.c+'33"></span>'
    +'<span style="font:800 17px Sora,sans-serif;color:#15121A;letter-spacing:-.01em">'+r.t+'</span></div>';
}
var CARTE='background:#fff;border:1.5px solid rgba(21,18,26,.07);box-shadow:0 4px 0 rgba(21,18,26,.07),0 10px 24px -14px rgba(21,18,26,.25);border-radius:22px;';

var V={};
// 1. RAYONS : une ligne par objet, ce qu il fait lisible d un coup d oeil
V.rayons=function(){
  return RAYONS.map(function(r){var L=objets(r);if(!L.length)return '';
    return tete(r)+L.map(function(o){
      return '<div style="'+CARTE+'padding:12px;margin-bottom:10px;display:flex;gap:12px;align-items:center">'
        +(o.titre?sigle(o,58):'<div style="width:64px;height:64px;flex:none;border-radius:18px;background:'+r.clair+';padding:6px">'+o.svg+'</div>')
        +'<div style="flex:1"><div style="'+(o.titre?'font-family:Cinzel,serif;font-weight:700;font-size:15px':'font:800 15.5px Sora,sans-serif')+';color:#15121A;line-height:1.2">'+esc(o.nom)+'</div>'
        +(o.titre?'<div style="display:inline-block;margin-top:4px;font:800 10.5px Sora;color:#fff;background:'+o.tier.color+';padding:2px 8px;border-radius:20px">'+o.tier.label+'</div>'
                 :'<div style="font-size:12.5px;color:#3B3644;line-height:1.35;margin-top:3px">'+esc(o.desc)+'</div>')+'</div>'
        +bouton(o,r.c)+'</div>';}).join('');}).join('');
};
// 2. VITRINES : un panneau de couleur par usage, tuiles blanches en 2 colonnes
V.vitrines=function(){
  return RAYONS.map(function(r){var L=objets(r);if(!L.length)return '';
    return '<div style="margin-top:18px;border-radius:26px;padding:16px 12px 14px;background:linear-gradient(150deg,'+r.c+','+r.f+');box-shadow:0 10px 24px -12px '+r.f+'">'
      +'<div style="font:800 18px Sora,sans-serif;color:#fff;margin:0 4px 12px">'+r.t+'</div>'
      +'<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">'+L.map(function(o){
        return '<div style="background:#fff;border-radius:20px;padding:12px 10px;display:flex;flex-direction:column;align-items:center;text-align:center;box-shadow:0 4px 0 rgba(0,0,0,.12)">'
          +(o.titre?sigle(o,62):'<div style="width:78px;height:78px">'+o.svg+'</div>')
          +'<div style="'+(o.titre?'font-family:Cinzel,serif;font-weight:700;font-size:14px':'font:800 14px Sora,sans-serif')+';color:#15121A;margin-top:8px;line-height:1.2">'+esc(o.nom)+'</div>'
          +(o.titre?'<div style="font:800 10.5px Sora;color:'+o.tier.color+';margin-top:3px">'+o.tier.label+'</div>'
                   :'<div style="font-size:11.5px;color:#3B3644;line-height:1.3;margin-top:4px;flex:1">'+esc(o.desc)+'</div>')
          +'<div style="margin-top:10px;width:100%;display:flex;justify-content:center">'+bouton(o,r.c)+'</div></div>';}).join('')+'</div></div>';}).join('');
};
// 3. ETALS : une grande carte de couleur par objet, qui defile au doigt, rayon par rayon
V.etals=function(){
  return RAYONS.map(function(r){var L=objets(r);if(!L.length)return '';
    return tete(r)+'<div data-noswipe style="display:flex;gap:12px;overflow-x:auto;scroll-snap-type:x mandatory;padding:2px 2px 12px;scrollbar-width:none;margin:0 -4px">'+L.map(function(o){
      return '<div style="flex:none;width:78%;scroll-snap-align:start;border-radius:24px;padding:16px;background:linear-gradient(150deg,'+r.c+','+r.f+');box-shadow:0 10px 22px -12px '+r.f+';display:flex;flex-direction:column;color:#fff">'
        +'<div style="display:flex;gap:14px;align-items:center">'
        +(o.titre?sigle(o,74):'<div style="width:84px;height:84px;flex:none;border-radius:22px;background:#fff;padding:7px;box-shadow:0 4px 0 rgba(0,0,0,.15)">'+o.svg+'</div>')
        +'<div style="'+(o.titre?'font-family:Cinzel,serif;font-weight:700;font-size:17px':'font:800 17px Sora,sans-serif')+';line-height:1.15">'+esc(o.nom)+'</div></div>'
        +'<div style="font-size:13px;line-height:1.4;margin:12px 0 14px;opacity:.95;flex:1">'+esc(o.desc)+'</div>'
        +'<div>'+bouton(o,r.c,true)+'</div></div>';}).join('')+'</div>';}).join('');
};

var ORDRE=[['actuel','Actuel'],['rayons','1 Rayons'],['vitrines','2 Vitrines'],['etals','3 Étals']];
var choix='rayons';
function rendre(){
  var t=document.getElementById('shop-tab-permanent');if(!t)return;
  var z=document.getElementById('pm-zone');
  if(!z){z=document.createElement('div');z.id='pm-zone';var lb=document.getElementById('shop-lock-banner');lb.parentNode.insertBefore(z,lb.nextSibling);}
  [].forEach.call(t.children,function(e){if(e.id!=='pm-zone'&&e.id!=='shop-lock-banner'&&e.id!=='perm-custom-section')e.style.display=choix==='actuel'?'':'none';});
  z.style.display=choix==='actuel'?'none':'';
  if(choix!=='actuel')z.innerHTML=V[choix]();
}
var _orig=window.renderRewards;
window.renderRewards=function(){var r=_orig.apply(this,arguments);try{rendre();}catch(e){console.error(e);}return r;};
function panneau(){
  if(document.getElementById('pm-pan'))return;
  var p=document.createElement('div');p.id='pm-pan';
  p.style.cssText='position:fixed;left:8px;right:8px;top:calc(env(safe-area-inset-top,0px) + 6px);z-index:999999;background:rgba(21,18,26,.92);border-radius:16px;padding:8px;display:flex;gap:4px';
  p.innerHTML=ORDRE.map(function(o){return '<button data-v="'+o[0]+'" style="flex:1;min-height:38px;border:0;border-radius:10px;font:800 12px Sora;color:#fff">'+o[1]+'</button>';}).join('')
    +'<button data-x="1" style="min-height:38px;border:0;border-radius:10px;font:800 12px Sora;color:#fff;background:#3B3644;padding:0 10px">×</button>';
  document.body.appendChild(p);
  p.onclick=function(e){var b=e.target.closest('button');if(!b)return;if(b.dataset.x){p.style.display='none';return;}choix=b.dataset.v;maj();};
}
function maj(){document.querySelectorAll('#pm-pan [data-v]').forEach(function(b){b.style.background=b.dataset.v===choix?'#E0115F':'#3B3644';});rendre();}
window.PM={choisir:function(v){choix=v;maj();},panneau:panneau,maj:maj};
})();
