var _MERCHANTS=[
 {
  "icon": "⚒",
  "name": "Enguerrand le Forgeron",
  "title": "Celui qui forge les secondes chances",
  "desc": "Les mains noires de suie, le regard calme. Derrière lui, l'enclume rougeoie encore.",
  "sparkColor": "#a78bfa",
  "flameA": "#7c3aed",
  "flameB": "#ff8c42",
  "bgGrad": "linear-gradient(135deg,#1a0a2e 0%,#2d1b69 100%)",
  "accent": "#a78bfa",
  "lore": [
   "Trente ans durant, Enguerrand forgea les épées du comte de Montfaucon : lames, heaumes et fers de lance sortaient de sa forge, au pied du donjon. Puis vint l'hiver du grand siège. Le château brûla sept jours et sept nuits, et l'armée du comte périt avec lui.",
   "On retrouva Enguerrand au matin, debout dans les cendres, son marteau à la main. Le feu lui avait tout pris, sauf ses mains. Ce jour-là, il jura sur l'enclume de ne plus jamais forger une arme qui tue.",
   "Depuis, il ne forge que ce qui relève : une pierre qui efface une faute, des auras taillées dans la braise et dans l'ombre. « Le feu détruit, dit-il. Mais c'est aussi lui qui trempe l'acier. »"
  ],
  "speciality": "Seconde chance et auras forgées : ce qui relève après la chute."
 },
 {
  "icon": "⚗",
  "name": "Aliénor l'Alchimiste",
  "title": "Celle qui distilla l'aube",
  "desc": "Une fiole fumante à la main, des taches d'encre et de cuivre sur les doigts.",
  "sparkColor": "#5ee6c4",
  "flameA": "#0984e3",
  "flameB": "#5ee6c4",
  "bgGrad": "linear-gradient(135deg,#0a1a3e 0%,#1e3a7f 100%)",
  "accent": "#74b9ff",
  "lore": [
   "En l'an de la Grande Peste, on mura les portes de Montpellier. Aliénor, fille d'apothicaire, refusa de fuir. Dans sa tour, au-dessus des remparts, elle fit chauffer ses alambics quarante nuits durant, à la recherche du remède que les médecins disaient introuvable.",
   "Ses fioles ne sauvèrent pas tout le monde. Mais le quartier des tanneurs, qu'elle soignait, vit ses enfants passer l'hiver. On l'accusa alors de sorcellerie. Au matin du bûcher, ceux qu'elle avait sauvés se dressèrent devant les gardes, et le bûcher ne fut jamais allumé.",
   "De ces nuits, elle a gardé le secret des élixirs qui décuplent l'effort, et une certitude : « Ce qui se transforme lentement se transforme pour de bon. »"
  ],
  "speciality": "Élixirs et potions : décupler ce que tu gagnes, jour après jour."
 },
 {
  "icon": "✒",
  "name": "Anselme l'Écrivain",
  "title": "L'écrivain du Mont assiégé",
  "desc": "Une plume derrière l'oreille, de la poudre d'or jusque dans la barbe.",
  "sparkColor": "#d4a054",
  "flameA": "#e17055",
  "flameB": "#fdcb6e",
  "bgGrad": "linear-gradient(135deg,#3a2410 0%,#6b3f1a 100%)",
  "accent": "#d4a054",
  "lore": [
   "Pendant dix ans, les Anglais assiégèrent le Mont. Dix ans de famine, de boulets et de marées. Dans une tour de la forteresse, un jeune écrivain nommé Anselme continuait d'écrire et d'enluminer son livre, lettre après lettre, à la lueur d'une seule chandelle.",
   "Quand les remparts tremblaient, il trempait sa plume. Quand l'encre d'or vint à manquer, il broya l'or de sa propre bague. Le Mont ne tomba jamais, et le livre fut achevé le jour où l'ennemi leva le camp.",
   "Anselme enseigne qu'une œuvre se bâtit comme un rempart : un trait par jour, même sous les boulets. Ses bordures dorées, ses sceaux et ses titres racontent la gloire de ceux qui n'ont rien lâché."
  ],
  "speciality": "Ornements et titres : la gloire de ceux qui tiennent."
 },
 {
  "icon": "☉",
  "name": "Mélisende l'Astrologue",
  "title": "Celle qui éteignit le soleil",
  "desc": "Un astrolabe d'or entre les mains. Sa robe est semée d'étoiles qu'elle a toutes nommées.",
  "sparkColor": "#fd79a8",
  "flameA": "#e84393",
  "flameB": "#a29bfe",
  "bgGrad": "linear-gradient(135deg,#2a0a3e 0%,#5b1b6f 100%)",
  "accent": "#fd79a8",
  "lore": [
   "On interdisait les astres aux femmes. Alors Mélisende les étudia en cachette, sur les toits de Chartres, de la tombée du jour jusqu'aux matines, et nota chaque étoile dans un carnet cousu dans l'ourlet de sa robe.",
   "Un soir, elle annonça au chapitre que le soleil s'éteindrait en plein midi. On rit d'elle, puis on la jugea pour hérésie. Le jour du procès, à midi, la lune dévora le soleil : la salle se tut, et les juges tombèrent à genoux dans le noir.",
   "Elle ne prédit pas l'avenir, dit-elle : elle en lit les signes. Elle vend des aperçus du lendemain, des éclipses qui changent le cours d'une journée, et des coups du destin pour qui ose les provoquer."
  ],
  "speciality": "Visions et destin : voir demain, ou le changer."
 },
 {
  "icon": "⚔",
  "name": "Gaucher le Mercenaire",
  "title": "Revenu d'entre les morts",
  "desc": "Une cicatrice de la tempe au menton. Il ne marchande pas : il propose un pacte.",
  "sparkColor": "#ff7675",
  "flameA": "#d63031",
  "flameB": "#e17055",
  "bgGrad": "linear-gradient(135deg,#3a0a0a 0%,#7a1f1f 100%)",
  "accent": "#ff7675",
  "lore": [
   "À Crécy, la chevalerie de GrandMatin chargea quinze fois sous une pluie de flèches. Gaucher, chevalier sans terre, était de la seizième. Au soir, on le compta parmi les morts, sous les bannières tombées et les chevaux couchés dans la boue.",
   "À l'aube, un corbeau se posa sur son heaume. Gaucher ouvrit les yeux, se releva seul au milieu du champ et marcha trois jours jusqu'à la première ville. Depuis, il ne sert plus aucun roi : il loue son épée, et ne signe que les pactes qu'il est sûr d'honorer.",
   "Ses marchés sont rudes et sans détour : un échec changé en victoire, une nuit à haut risque, un titre arraché au champ de bataille. « Tomber n'est rien, dit-il. Rester couché, voilà la défaite. »"
  ],
  "speciality": "Pactes et risques : des échanges rudes, mais tenus."
 },
 {
  "icon": "🕯",
  "name": "Bertrand le Sage",
  "title": "L'ermite à la chandelle",
  "desc": "Un vieil homme au manteau de laine. À ses pieds, une chandelle qui ne s'éteint jamais.",
  "sparkColor": "#00b894",
  "flameA": "#00cec9",
  "flameB": "#55efc4",
  "bgGrad": "linear-gradient(135deg,#0a2e1a 0%,#1b6940 100%)",
  "accent": "#55efc4",
  "lore": [
   "Bertrand fut seigneur, et vainqueur de toutes ses guerres. Le soir de sa dernière victoire, il compta ses morts au lieu de ses terres. Le lendemain, il rendit son épée, son fief et son nom, et monta seul dans la montagne.",
   "Il s'installa dans une grotte au-dessus du col, là où les voyageurs se perdaient dans la tourmente. Chaque soir, il allumait une chandelle à l'entrée. Quarante hivers durant, elle ne s'éteignit pas, et des centaines d'égarés retrouvèrent le chemin grâce à elle.",
   "Il ne vend rien : il conseille. Choisir sa quête, écrire à celui qu'on sera, observer avant d'affronter, se relever d'une chute. « Personne ne montera à ta place. Mais je peux laisser la lumière allumée. »"
  ],
  "speciality": "Conseils et veille : choisir sa route, et retrouver le chemin."
 }
];
// ── Objets de chaque marchand (poids x3 et remise quand il est present) ──
// 0=Forgeron, 1=Alchimiste, 2=Enlumineur, 3=Astrologue, 4=Mercenaire, 5=Sage.
// La Boite Scellee E n est chez aucun ; chacun a une boite (D a S) ou la Cle du Neant.
var _MERCHANT_ITEMS={"0": ["cancel_sanction", "fire_aura", "dark_aura", "box_A"], "1": ["double_xp", "double_pts", "talisman_emotion", "mystery_fragment", "box_C"], "2": ["gold_border", "monarch_seal", "wisdom_boost", "temp_epic_title", "box_B"], "3": ["preview_quests", "prediction", "dice_fate", "eclipse", "box_S"], "4": ["xp_to_pts", "night_portal", "temp_leg_title", "fail_to_clear", "box_D"], "5": ["choose_secondary", "extra_letter", "watcher_shard", "reset_integrity", "void_key"]};
