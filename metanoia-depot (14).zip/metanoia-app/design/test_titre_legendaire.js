const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const nom=process.argv[2], out=process.argv[3];
(async()=>{const rm=process.argv[4]==='rm';const b=await chromium.launch();const p=await b.newPage({reducedMotion:rm?'reduce':'no-preference',viewport:{width:393,height:852},isMobile:true,hasTouch:true,deviceScaleFactor:2});
const err=[];p.on('pageerror',e=>err.push(e.message));p.on('console',m=>{if(m.type()==='error')err.push(m.text())});
await p.goto('http://127.0.0.1:8777/index.html');await p.waitForTimeout(3000);
await p.evaluate(()=>{ST._ob={age:1,situation:1,sportLevel:1,physGoal:0,sportAccess:[0,2],collectifSport:'',collectifJours:[],mindLevel:0,screenHours:3,sleep:1,resistances:[1,2],prog:'Standard'};ST.myWhy='x';ST._tutoSeen=true;_obFinish();});
await p.waitForTimeout(2000);
await p.addStyleTag({content:'.flash,.toast,#toast{display:none!important}'});
const info=await p.evaluate((nom)=>{document.querySelectorAll('.tuto-ui,#tuto-card,#tuto-ov,.tuto-overlay').forEach(x=>x.remove());ST.day=30;ST.equippedTitle=null;ST._titleCeremonies=[nom];save();
 try{ if(typeof equipTitle==='function') equipTitle(nom); }catch(e){}
 nav('s-main');renderMain();var tt=document.getElementById('title-text');
 return {txt:tt.textContent,cls:tt.className,lettres:tt.querySelectorAll('.tl').length,canvas:!!document.getElementById('title-fx-canvas'),mode:_FXV.mode,rar:_getTitleRarity(nom)};},nom);
console.log(JSON.stringify(info));
await p.evaluate(()=>{document.querySelectorAll('[id$="-ov"]').forEach(x=>{if(getComputedStyle(x).position==='fixed')x.remove()});document.getElementById('s-main').scrollTop=0});
for(let i=0;i<8;i++){await p.waitForTimeout(520);await p.screenshot({path:out+'_'+i+'.png',clip:{x:0,y:0,width:393,height:230}})}
console.log(await p.evaluate(()=>{var l=document.querySelector('#title-text .tl');if(!l)return 'pas de lettres';var cs=getComputedStyle(l);return cs.animationName+' '+cs.animationDuration+' tf='+cs.transform+' color='+cs.color+' bg='+cs.backgroundImage.slice(0,60)+' clip='+cs.webkitBackgroundClip}));
console.log('erreurs',err.slice(0,5));await b.close()})();
