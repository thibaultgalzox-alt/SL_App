# Fabrique design/titres/maquette/ a partir du VRAI code de www/ :
# feuilles fonts.css + theme.css + la feuille principale de index.html,
# l en-tete de #Quetes tel quel, et les fonctions des titres extraites telles
# quelles (aucune recopie a la main). Ne jamais retoucher la maquette :
# modifier www/index.html puis relancer ce script.
#   python3 design/titres/generer.py   (depuis la racine du depot)
import re, os, shutil, json
R=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
W=os.path.join(R,'www'); OUT=os.path.join(R,'design','titres','maquette')
s=open(os.path.join(W,'index.html'),encoding='utf-8').read()

def bloc(debut, ouvre='{'):
    """Texte depuis `debut` jusqu a l accolade (ou crochet) fermante equilibree."""
    i=s.index(debut); j=s.index(ouvre,i); ferme={'{':'}','[':']'}[ouvre]
    k=j; n=0; q=None; esc=False
    while k<len(s):
        c=s[k]
        if q:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c==q: q=None
        elif c in '\'"`': q=c
        elif s.startswith('//',k) and s[k-1] not in ':\\':
            k=s.index('\n',k); continue
        elif s.startswith('/*',k):
            k=s.index('*/',k)+2; continue
        elif c==ouvre: n+=1
        elif c==ferme:
            n-=1
            if n==0:
                fin=k+1
                if s[fin:fin+1]==';': fin+=1
                return s[i:fin]
        k+=1
    raise Exception('non ferme : '+debut)

CODE=[bloc('const NEW_TITLES_COMMON=[','['), bloc('const NEW_TITLES_EPIC=[','['), bloc('const NEW_TITLES_LEGENDARY=[','['),
      s[s.index('const SYM_EPIC='):s.index('\n',s.index('const SYM_EPIC='))],
      bloc('const SYM_R=[','['), bloc('const ID_T=[','['),
      bloc('function _getTitleRarity(name){'), bloc('var _TITLE_FX={'),
      bloc('function _titleFxSlug(n){'), bloc('function _epicFxSlug(n){'),
      bloc('function _applyTitleCosmetics(name){'), bloc('function _titleCosmetiquesIntactes(name,tt,hdr){'),
      s[s.index('var _FXW=null'):s.index('\n',s.index('var _FXW=null'))],
      bloc('function _fxTravailleur(){'), bloc('function _fxLancer(c,fx,hdr){'), bloc('function _fxTaille(){'),
      bloc('function _fxEtat(){'), bloc('function _fxArreter(){'),
      bloc('function _titleSplit(tt){'), bloc('function _titleSplitMeasure(tt){'), bloc('function _titleUnsplit(tt){')]
a=s.index('<style>',s.index('<head>')); css=s[a+7:s.index('</style>',a)]
# Seules les regles qui peuvent toucher l en-tete sont gardees : les autres
# visent des elements qui n existent pas dans la maquette (quetes, stats...).
CLES=[':root','html','body','*','.hdr','.pill','#rank-pill','#title-text','title-','ttx-','.tch','.tw','.tl','xp-','#xp','hdr-','#hdr','#act-','.app','.screen','#app-racine','canvas','h1']
def blocs(t):
    out=[];i=0;n=len(t)
    while i<n:
        if t.startswith('/*',i): i=t.index('*/',i)+2; continue
        if t[i].isspace(): i+=1; continue
        j=t.index('{',i); sel=t[i:j].strip(); d=1;k=j+1
        while d: 
            if t.startswith('/*',k): k=t.index('*/',k)+2; continue
            if t[k]=='{': d+=1
            elif t[k]=='}': d-=1
            k+=1
        out.append((sel,t[j+1:k-1]));i=k
    return out
def garder(sel):
    return any(c in sel for c in CLES)
def filtrer(t):
    res=[];kf={}
    for sel,corps in blocs(t):
        if sel.startswith('@keyframes'): kf[sel.split()[1]]='%s{%s}'%(sel,corps); continue
        if sel.startswith('@media') or sel.startswith('@supports'):
            sous=filtrer(corps)[0]
            if sous.strip(): res.append('%s{\n%s\n}'%(sel,sous))
            continue
        if sel.startswith('@'): res.append('%s{%s}'%(sel,corps)); continue
        if garder(sel): res.append('%s{%s}'%(sel,corps))
    return '\n'.join(res),kf
regles,KF=filtrer(css)
noms=set(re.findall(r'[\w-]+',regles))
css=regles+'\n'+'\n'.join(v for k,v in KF.items() if k in noms)
# Simulation de l economie de batterie : chaque regle des blocs
# « prefers-reduced-motion » de l app, recopiee sous html.rm (interrupteur).
sim=[]
for sel,corps in blocs(regles):
    if sel.startswith('@media') and 'prefers-reduced-motion' in sel:
        for s2,c2 in blocs(corps):
            sim.append(','.join('html.rm '+x.strip() for x in s2.split(','))+'{'+c2+'}')
css+='\n/* Simulation economie de batterie (maquette seulement) */\n'+'\n'.join(sim)
h0=s.index('<div class="hdr compact">'); h1=s.index('<!-- Stats en ligne fine -->',h0)
hdr=s[h0:h1].rstrip()
# l en-tete se termine par la fermeture de .hdr : on garde exactement ses balises
hdr=hdr[:hdr.rindex('</div>')+6]
hdr=re.sub(r'\son(click|keydown)="[^"]*"','',hdr)

page=open(os.path.join(R,'design','titres','gabarit.html'),encoding='utf-8').read()
page=page.replace('/*{{CSS_APP}}*/',css).replace('<!--{{ENTETE}}-->',hdr).replace('/*{{CODE_TITRES}}*/','\n'.join(CODE))
if os.path.exists(OUT): shutil.rmtree(OUT)
os.makedirs(OUT)
open(os.path.join(OUT,'index.html'),'w',encoding='utf-8').write(page)
for f in ['fonts.css','theme.css']: shutil.copy(os.path.join(W,f),OUT)
shutil.copytree(os.path.join(W,'fonts'),os.path.join(OUT,'fonts'))
print('ok', len(page), 'caracteres,', len(CODE), 'morceaux de code')
