const { chromium } = require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true,deviceScaleFactor:2});
const err=[];p.on('pageerror',e=>err.push(e.message));p.on('console',m=>{if(m.type()==='error')err.push(m.text())});
await p.goto('http://127.0.0.1:8791/index.html');await p.waitForTimeout(2500);
const noms=await p.evaluate(()=>[...document.querySelectorAll('.mq-b')].map(b=>b.dataset.n).filter(Boolean));
const res=[];
for(const n of noms){ await p.evaluate(n=>{document.querySelector('.mq-b[data-n="'+n.replace(/"/g,'\\"')+'"]').click()},n); await p.waitForTimeout(250);
  res.push(await p.evaluate(()=>{var tt=document.getElementById('title-text'),l=tt.querySelector('.tl'),cs=getComputedStyle(l||tt);return tt.textContent+' : '+(cs.animationName)+' '+cs.animationDuration+' | font '+cs.fontFamily.split(',')[0]+' '+cs.fontWeight}));}
console.log(res.join('\n'));
await p.evaluate(()=>document.querySelector('.mq-b[data-n="Souverain Absolu"]').click());await p.waitForTimeout(1600);await p.screenshot({path:'/tmp/mq3.png',clip:{x:0,y:0,width:393,height:300}});
console.log('erreurs',err);await b.close()})();
