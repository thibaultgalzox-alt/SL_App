const base=require('./test_base.js');(async()=>{const {b,p,err,T,etat,centre,w}=await base();
const info=()=>p.evaluate(()=>{var t=getToday();return t.secs.map((q,i)=>{var pl=document.querySelector('#ql-sec .sec-pile[data-sec="'+i+'"]'),c=pl.querySelector(':scope>.qcard');return {nom:q.name.slice(0,20),boost:_estBooste(q),bloque:pl.dataset.bloque||'',ruban:!!c.querySelector('.qribbon,.qboost'),xp:(c.querySelector('.qxp')||{}).textContent,dessousXp:(pl.querySelector('.sec-dessous .qxp')||{}).textContent||null,dessousBoostTxt:!!(pl.querySelector('.sec-dessous')&&/taux d.échec élevé/.test(pl.querySelector('.sec-dessous').textContent))}})});
async function swipe(i){let bx=await centre(i);let x=bx.x+50,y=bx.y+bx.height/2;await T('touchStart',[{x,y,id:1}]);for(let k=1;k<=10;k++){await T('touchMove',[{x:x+26*k,y,id:1}]);await w(16)}
 if(i===0) await p.screenshot({path:'boost_mi.png'});await T('touchEnd',[{x:x+260,y,id:1}]);await w(900)}
// cas 1 : boost avec cle sur la secondaire 0
await p.evaluate(()=>{var t=getToday();ST._boost={day:ST.day,id:t.secs[0].id,k:_dKey(t.secs[0].name)};ST._secSwipes=null;document.getElementById('ql-nn').dataset.fp='';renderMain()});await w(500);
console.log('avant',JSON.stringify(await info()));
await swipe(0);console.log('apres swipe boostee',JSON.stringify(await info()),'restants',await p.evaluate(()=>_secRestants()));
await swipe(1);console.log('apres swipe normale',JSON.stringify(await info()));
// cas 2 : ancien cache sans cle
await p.evaluate(()=>{var t=getToday();ST.day++;ST.weekPlan=genWeek();var t=getToday(),d=(ST.day-1)%7;t.secs=[Object.assign(gSE(ST.day),{id:'se'+d})];ST._boost={day:ST.day,id:t.secs[0].id};ST._secSwipes=null;document.getElementById('ql-nn').dataset.fp='';renderMain()});await w(500);
console.log('ancien cache avant',JSON.stringify(await info()));await swipe(0);console.log('ancien cache apres',JSON.stringify(await info()),JSON.stringify(await p.evaluate(()=>ST._boost)));
console.log('erreurs',err);await b.close()})();
