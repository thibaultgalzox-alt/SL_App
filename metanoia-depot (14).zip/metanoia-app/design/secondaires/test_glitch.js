const base=require('./test_base.js');(async()=>{const {b,p,err,T,etat,centre,w}=await base();
await p.evaluate(()=>{var o=window.trig;window._TR=[];window.trig=function(){_TR.push([].slice.call(arguments).join(','));return o.apply(this,arguments)}});
const nn=()=>p.evaluate(()=>{var t=getToday();return (t.nn||[]).map(q=>ST.questStatus[q.id]||null).join(',')});
async function reset(){await p.evaluate(()=>{ST.questStatus={};ST._secSwipes=null;ST._secFuites={};document.getElementById('ql-nn').dataset.fp='';renderMain()});await w(500)}
async function tenirA(i,dist){let bx=await centre(i);let x=bx.x+50,y=bx.y+bx.height/2;await T('touchStart',[{x,y,id:1}]);for(let k=1;k<=10;k++){await T('touchMove',[{x:x+dist*k/10,y,id:1}]);await w(16)}return {x:x+dist,y,bx}}
async function boutonPos(sel){return p.evaluate(sel=>{var e=document.querySelector(sel);if(!e)return null;var r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2,e.textContent.trim().slice(0,14)]},sel)}
async function tapB(A,pos){await T('touchStart',[{x:A.x,y:A.y,id:1},{x:pos[0],y:pos[1],id:2}]);await w(60);await T('touchEnd',[{x:pos[0],y:pos[1],id:2}]);await w(60)}
const R=(n,v)=>console.log(n.padEnd(46),v);
// 1. bouton de la carte de dessous pendant le swipe
await reset();let A=await tenirA(0,150);
let pos=await boutonPos('#ql-sec .sec-pile[data-sec="0"] .sec-dessous .qactions button');
await p.screenshot({path:'revele.png'});
R('1 boutons dessous visibles',JSON.stringify(pos)+' opac '+await p.evaluate(()=>getComputedStyle(document.querySelector('#ql-sec .sec-dessous .qactions')).display));
await tapB(A,pos);await T('touchEnd',[]);await w(800);R('  apres tape bouton dessous + lacher',JSON.stringify(await etat()));
// 1b. meme chose, sous le seuil : la carte doit revenir
await reset();A=await tenirA(0,90);pos=await boutonPos('#ql-sec .sec-pile[data-sec="0"] .sec-dessous .qactions button');await tapB(A,pos);
for(let k=1;k<=3;k++){await T('touchMove',[{x:A.x+5*k,y:A.y,id:1}]);await w(16)}R('1b pendant, carte suit encore',JSON.stringify((await etat()).tr));await T('touchEnd',[]);await w(800);R('  lacher sous le seuil',JSON.stringify(await etat()));
// 2. bouton d une autre secondaire pendant le swipe
await reset();A=await tenirA(0,150);pos=await boutonPos('#ql-sec .sec-pile[data-sec="1"]>.qcard .qactions button');
await tapB(A,pos);await T('touchEnd',[]);await w(800);R('2 bouton autre secondaire',JSON.stringify(await etat()));
// 3. bouton d une obligatoire
await reset();A=await tenirA(0,150);pos=await boutonPos('#ql-nn .qactions button');
await tapB(A,pos);await T('touchEnd',[]);await w(800);R('3 bouton obligatoire',JSON.stringify(await etat())+' nn='+await nn());
// 4. deux piles a la fois
await reset();A=await tenirA(0,200);let b1=await p.locator('#ql-sec .sec-pile[data-sec="1"] > .qcard').boundingBox();
let bx=b1.x+50,by=b1.y+b1.height/2;await T('touchStart',[{x:A.x,y:A.y,id:1},{x:bx,y:by,id:2}]);
for(let k=1;k<=10;k++){await T('touchMove',[{x:A.x+5,y:A.y,id:1},{x:bx+26*k,y:by,id:2}]);await w(16)}
R('4 pendant: transforms',JSON.stringify((await etat()).tr));
await T('touchEnd',[]);await w(900);R('  apres double lacher',JSON.stringify(await etat()));
// 5. swipe valide puis tape tout de suite sur la nouvelle carte et re-swipe
await reset();bx=await centre(0);let x=bx.x+50,y=bx.y+bx.height/2;
await T('touchStart',[{x,y,id:1}]);for(let k=1;k<=10;k++){await T('touchMove',[{x:x+26*k,y,id:1}]);await w(16)}await T('touchEnd',[]);
await w(80);pos=await boutonPos('#ql-sec .sec-pile[data-sec="0"] .sec-dessous .qactions button');
if(pos){await T('touchStart',[{x:pos[0],y:pos[1],id:3}]);await T('touchEnd',[]);}
await w(60);await T('touchStart',[{x,y,id:4}]);for(let k=1;k<=10;k++){await T('touchMove',[{x:x+26*k,y,id:4}]);await w(16)}await T('touchEnd',[]);
await w(900);R('5 swipe + tape + reswipe immediat',JSON.stringify(await etat()));
// 6. A tient un bouton, B swipe, A leve pendant
await reset();pos=await boutonPos('#ql-sec .sec-pile[data-sec="1"]>.qcard .qactions button');bx=await p.locator('#ql-sec .sec-pile[data-sec="0"] > .qcard').boundingBox();x=bx.x+50;y=bx.y+bx.height/2;
await T('touchStart',[{x:pos[0],y:pos[1],id:1}]);await w(40);await T('touchStart',[{x:pos[0],y:pos[1],id:1},{x,y,id:2}]);
for(let k=1;k<=6;k++){await T('touchMove',[{x:pos[0],y:pos[1],id:1},{x:x+20*k,y,id:2}]);await w(16)}
await T('touchEnd',[{x:x+120,y,id:2}]);await w(60);await T('touchEnd',[]);await w(800);R('6 bouton tenu + swipe',JSON.stringify(await etat()));
// 7. touchcancel au-dela du seuil
await reset();A=await tenirA(0,250);await T('touchCancel',[]);await w(800);R('7 annulation systeme au-dela du seuil',JSON.stringify(await etat()));
// 8. appli en arriere-plan
await reset();A=await tenirA(0,150);await p.evaluate(()=>{Object.defineProperty(document,'hidden',{value:true,configurable:true});document.dispatchEvent(new Event('visibilitychange'));delete document.hidden});await w(600);R('8 arriere-plan pendant swipe',JSON.stringify(await etat()));await T('touchEnd',[]);await w(600);R('  puis lacher',JSON.stringify(await etat()));
// 9. redessin pendant le swipe, puis nouveau swipe
await reset();A=await tenirA(0,150);await p.evaluate(()=>{document.getElementById('ql-nn').dataset.fp='';renderMain()});await w(100);await T('touchEnd',[]);await w(600);R('9 redessin pendant swipe',JSON.stringify(await etat()));
bx=await centre(0);x=bx.x+50;y=bx.y+bx.height/2;await T('touchStart',[{x,y,id:1}]);for(let k=1;k<=10;k++){await T('touchMove',[{x:x+26*k,y,id:1}]);await w(16)}await T('touchEnd',[]);await w(900);R('  swipe suivant',JSON.stringify(await etat()));
// 10. tape normale sur Accomplie
await w(500);pos=await boutonPos('#ql-sec .sec-pile[data-sec="1"]>.qcard .qactions button');await T('touchStart',[{x:pos[0],y:pos[1],id:1}]);await T('touchEnd',[]);await w(700);R('10 tape normale '+pos[2],JSON.stringify(await etat()));
console.log('appels trig',await p.evaluate(()=>_TR.join(' | ')));console.log('erreurs',err);await b.close()})();
