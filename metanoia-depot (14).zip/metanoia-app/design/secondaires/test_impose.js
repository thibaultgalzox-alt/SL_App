const base=require('./test_base.js');(async()=>{const {b,p,err,T,etat,centre,w}=await base();
const jet=()=>p.evaluate(()=>({jeton:(document.querySelector('.sec-jeton')||{}).textContent,restants:_secRestants(),piles:[...document.querySelectorAll('#ql-sec .sec-pile')].map(x=>(x.dataset.bloque||'libre')+(x.querySelector('.sec-dessous')?'+dessous':'')),astuce:!!document.querySelector('.sec-astuce')}));
console.log('jour normal',JSON.stringify(await jet()));
await p.evaluate(()=>{var t=getToday();var c=Object.assign({},t.secs[0]);delete c._suiv;ST._secImposee={q:c,day:ST.day};t.secs.forEach(q=>delete q._suiv);_secAppliquerImposee(t);document.getElementById('ql-nn').dataset.fp='';renderMain()});await w(500);
console.log('jour impose',JSON.stringify(await jet()));
let bx=await centre(1);let x=bx.x+50,y=bx.y+bx.height/2;await T('touchStart',[{x,y,id:1}]);for(let k=1;k<=10;k++){await T('touchMove',[{x:x+26*k,y,id:1}]);await w(16)}await T('touchEnd',[{x:x+260,y,id:1}]);await w(300);
console.log('swipe autre carte',JSON.stringify(await jet()),await p.evaluate(()=>{var t=document.querySelectorAll('.toast,#toast');return [...t].map(x=>x.textContent).join('|')}));
await p.evaluate(()=>document.querySelector('#sec-zone').scrollIntoView({block:'start'}));await w(300);await p.screenshot({path:'impose.png',clip:{x:0,y:0,width:393,height:420}});
console.log(err);await b.close()})();
