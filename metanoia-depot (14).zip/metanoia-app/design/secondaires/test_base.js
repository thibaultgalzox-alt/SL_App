const { chromium } = require('/opt/npm-tools/node_modules/playwright');
module.exports=async function(){const b=await chromium.launch({args:['--disable-features=OverscrollHistoryNavigation']});const p=await b.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true,deviceScaleFactor:2});
const err=[];p.on('pageerror',e=>err.push(e.message));
await p.goto('http://127.0.0.1:8777/index.html');await p.waitForTimeout(3500);
await p.evaluate(()=>{ST._ob={age:1,situation:1,sportLevel:1,physGoal:0,sportAccess:[0,2],collectifSport:'',collectifJours:[],mindLevel:0,screenHours:3,sleep:1,resistances:[1,2],prog:'Standard'};ST.myWhy='x';ST._tutoSeen=true;_obFinish();});
await p.waitForTimeout(2500);
await p.evaluate(()=>{document.querySelectorAll('.tuto-ui,#tuto-card,#tuto-ov,.tuto-overlay').forEach(x=>x.remove());ST.day=24;ST.integrity=90;ST._unlocksSeen={};for(var k in (window._UNLOCKS||{}))ST._unlocksSeen[k]=1;
 ST._tutoScreens=new Proxy({},{get:function(){return true}});window.isOpen=function(){return true};ST.weekPlan=genWeek();
 var t=getToday(),d=(ST.day-1)%7;t.secs=[Object.assign(gSE(24),{id:'se'+d}),Object.assign(gSM(),{id:'sm'+d})];ST._boost={day:ST.day,id:null};save();nav('s-main');renderMain()});
await p.waitForTimeout(1500);
await p.evaluate(()=>{document.querySelectorAll('[id$="-ov"],.tuto-ui').forEach(x=>{if(getComputedStyle(x).position==='fixed')x.remove()})});
const cdp=await p.context().newCDPSession(p);
const T=(type,pts)=>cdp.send('Input.dispatchTouchEvent',{type,touchPoints:pts});
const etat=()=>p.evaluate(()=>{var t=getToday();return {restants:_secRestants(),secs:t.secs.map(q=>q.name.slice(0,22)),statuts:t.secs.map(q=>ST.questStatus[q.id]||null),tr:[...document.querySelectorAll('#ql-sec .sec-pile>.qcard')].map(c=>c.style.transform||'-'),ecran:(document.querySelector('.screen.active')||{}).id}});
async function centre(i){await p.evaluate(i=>{document.querySelector('#ql-sec .sec-pile[data-sec="'+i+'"]').scrollIntoView({block:'center'})},i);await p.waitForTimeout(300);const bx=await p.locator('#ql-sec .sec-pile[data-sec="'+i+'"] > .qcard').boundingBox();return bx}
return {b,p,err,T,etat,centre,w:(ms)=>p.waitForTimeout(ms)}}
