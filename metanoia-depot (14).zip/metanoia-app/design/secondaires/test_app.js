const { chromium } = require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true,deviceScaleFactor:2});
const err=[];p.on('pageerror',e=>err.push(e.message));
await p.goto('http://127.0.0.1:8777/index.html');await p.waitForTimeout(3500);
await p.evaluate(()=>{ST._ob={age:1,situation:1,sportLevel:1,physGoal:0,sportAccess:[0,2],collectifSport:'',collectifJours:[],mindLevel:0,screenHours:3,sleep:1,resistances:[1,2],prog:'Standard'};ST.myWhy='x';ST._tutoSeen=true;_obFinish();});
await p.waitForTimeout(2500);
await p.evaluate(()=>{document.querySelectorAll('.tuto-ui,#tuto-card,#tuto-ov,.tuto-overlay').forEach(x=>x.remove());ST.day=24;ST.integrity=90;ST._unlocksSeen={};for(var k in (window._UNLOCKS||{}))ST._unlocksSeen[k]=1;
 ST._tutoScreens=new Proxy({},{get:function(){return true}});window.isOpen=function(){return true};ST.weekPlan=genWeek();
 var t=getToday(),d=(ST.day-1)%7;t.secs=[Object.assign(gSE(24),{id:'se'+d}),Object.assign(gSM(),{id:'sm'+d})];ST._boost={day:ST.day,id:null};save();nav('s-main');renderMain()});
await p.waitForTimeout(1500);
await p.evaluate(()=>{document.querySelectorAll('[id$="-ov"],.tuto-ui').forEach(x=>{if(getComputedStyle(x).position==='fixed')x.remove()})});
const cdp=await p.context().newCDPSession(p);
async function touch(x,y,dx,dy,steps,tenir){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});
 for(let k=1;k<=steps;k++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+dx*k/steps,y:y+dy*k/steps}]});await p.waitForTimeout(16)}
 if(tenir) return; await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await p.waitForTimeout(700)}
async function lacher(){await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await p.waitForTimeout(700)}
const etat=()=>p.evaluate(()=>{var t=getToday();return {ecran:(document.querySelector('.screen.active')||{}).id,bande:document.getElementById('app-racine').scrollLeft,restants:_secRestants(),jeton:(document.querySelector('.sec-jeton')||{}).textContent,secs:t.secs.map(q=>q.type+':'+q.name.slice(0,28)+(q._imposee?' [IMPOSEE]':'')),suiv:t.secs.map(q=>q._suiv?q._suiv.name.slice(0,28):null),piles:document.querySelectorAll('#ql-sec .sec-pile').length,dessous:document.querySelectorAll('#ql-sec .sec-dessous').length}});
async function centre(i){await p.evaluate(i=>{document.querySelector('#ql-sec .sec-pile[data-sec="'+i+'"]').scrollIntoView({block:'center'})},i);await p.waitForTimeout(300);const bx=await p.locator('#ql-sec .sec-pile[data-sec="'+i+'"] > .qcard').boundingBox();return [bx.x+50,bx.y+bx.height/2]}
console.log('depart',JSON.stringify(await etat()));
let [x,y]=await centre(0);
await p.screenshot({path:'/home/claude/outils/app_s0.png'});
await touch(x,y,120,3,12,true);
const op=await p.evaluate(()=>getComputedStyle(document.querySelector('#ql-sec .sec-dessous .qcard>.qh')).opacity);
console.log('pendant glissement : apercu opacite',op,'bande',await p.evaluate(()=>document.getElementById('app-racine').scrollLeft));
await p.screenshot({path:'/home/claude/outils/app_mi.png'});
await lacher();console.log('annule',JSON.stringify(await etat()));
await touch(x,y,260,4,14);await p.waitForTimeout(600);console.log('swipe 1',JSON.stringify(await etat()));
[x,y]=await centre(1);await touch(x+200,y,-240,2,10);await p.waitForTimeout(800);console.log('gauche sur une secondaire',JSON.stringify(await etat()));
await p.evaluate(()=>nav('s-main',null,{doux:false}));await p.waitForTimeout(900);
[x,y]=await centre(1);await touch(x,y,0,-300,10);console.log('vertical',JSON.stringify(await etat()), await p.evaluate(()=>document.getElementById('s-main').scrollTop));
[x,y]=await centre(1);await touch(x,y,260,4,14);await p.waitForTimeout(600);console.log('swipe 2',JSON.stringify(await etat()));
[x,y]=await centre(0);await touch(x,y,260,4,14);console.log('swipe 3 refuse',JSON.stringify(await etat()),await p.evaluate(()=>(document.querySelector('.toast,#toast')||{}).textContent));
// integrite 60 : 1 seul
await p.evaluate(()=>{ST.integrity=60;ST._secSwipes=null;renderMain()});await p.waitForTimeout(400);console.log('integ 60',JSON.stringify(await etat()));
// Fuite x3 -> imposee le lendemain
await p.evaluate(()=>{var t=getToday();ST._secFuites={};ST._secFuites[_dKey(t.secs[0].name)]=2;});
[x,y]=await centre(0);const nomFui=await p.evaluate(()=>getToday().secs[0].name);await touch(x,y,260,4,14);await p.waitForTimeout(500);
console.log('3e fuite',await p.evaluate(()=>JSON.stringify(ST._secImposee&&{day:ST._secImposee.day,nom:ST._secImposee.q.name.slice(0,28)})));
await p.evaluate(()=>{ST.day++;ST.integrity=90;var t=getToday(),d=(ST.day-1)%7;t.secs=[Object.assign(gSE(25),{id:'se'+d})];delete t.secs[0]._suiv;ST._boost={day:ST.day,id:null};renderMain()});await p.waitForTimeout(500);
console.log('lendemain',JSON.stringify(await etat()),await p.evaluate(()=>{var c=document.querySelector('#ql-sec .qcard');return c.querySelector('.qribbon')&&c.querySelector('.qribbon').textContent+' | '+c.querySelector('.qxp').textContent}));
await p.evaluate(()=>document.querySelector('#ql-sec .sec-pile').scrollIntoView({block:'center'}));await p.waitForTimeout(300);
await p.screenshot({path:'/home/claude/outils/app_imposee.png'});
[x,y]=await centre(0);await touch(x,y,260,4,14);console.log('imposee non swipable',JSON.stringify(await etat()));
console.log('erreurs',err);await b.close()})();
