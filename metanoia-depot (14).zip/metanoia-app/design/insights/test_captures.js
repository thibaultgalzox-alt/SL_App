const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const out=process.argv[2]||'ins', W=+(process.argv[3]||393), pro=process.argv[4]!=='nonpro';
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:W,height:852},isMobile:true,hasTouch:true,deviceScaleFactor:2});
const err=[];p.on('pageerror',e=>err.push(e.message));
await p.goto('http://127.0.0.1:8777/index.html');await p.waitForTimeout(3000);
await p.evaluate(()=>{ST._ob={age:1,situation:1,sportLevel:1,physGoal:0,sportAccess:[0,2],collectifSport:'',collectifJours:[],mindLevel:0,screenHours:3,sleep:1,resistances:[1,2],prog:'Standard'};ST.myWhy='x';ST._tutoSeen=true;_obFinish();});
await p.waitForTimeout(2000);
await p.evaluate((pro)=>{document.querySelectorAll('.tuto-ui,#tuto-card,#tuto-ov,.tuto-overlay').forEach(x=>x.remove());window._TEST_MODE=true;
 var s=7;Math.random=function(){s=(s*1103515245+12345)&0x7fffffff;return s/0x7fffffff};
 for(var i=0;i<140;i++){try{_testAutoOneDay()}catch(e){}}
 ST._proTest=pro;ST._bscs=[{day:120,score:44,rep:[],ids:[]}];window._dVoir=true;ST._unlocksSeen={};for(var k in (window._UNLOCKS||{}))ST._unlocksSeen[k]=1;ST._tutoScreens=new Proxy({},{get:function(){return true}});save();},pro);
await p.waitForTimeout(500);
await p.evaluate(()=>{document.querySelectorAll('[id$="-ov"],.tuto-ui').forEach(x=>{if(getComputedStyle(x).position==='fixed')x.remove()});_allerInsights()});
await p.waitForTimeout(2500);
await p.evaluate(()=>{document.querySelectorAll('[id$="-ov"],.tuto-ui,.unlock-ov').forEach(x=>{if(getComputedStyle(x).position==='fixed')x.remove()})});
console.log(await p.evaluate(()=>{var e=document.elementFromPoint(150,260);var c=document.querySelector('#st-insights .st-card');return (e.id||e.className)+' | '+getComputedStyle(c).backgroundColor+' | '+[...document.querySelectorAll('body *')].filter(x=>{var s=getComputedStyle(x);return s.position==='fixed'&&s.display!=='none'&&x.offsetWidth>300&&x.offsetHeight>500}).map(x=>x.id+'.'+x.className+' '+getComputedStyle(x).backgroundColor+' z'+getComputedStyle(x).zIndex+' op'+getComputedStyle(x).opacity).join(' ; ')}));
const h=await p.evaluate(()=>{var s=document.getElementById('s-stats');return s.scrollHeight});
await p.addStyleTag({content:'.flash,.toast,#toast,[class*=toast]{display:none!important}'});await p.evaluate(()=>{var n=document.getElementById('net-banner')||document.querySelector('[id*=net]');})
let y=0,n=0;while(y<h&&n<12){await p.evaluate(y=>{document.getElementById('s-stats').scrollTop=y},y);await p.waitForTimeout(250);await p.screenshot({path:out+'_'+n+'.png'});y+=780;n++}
console.log('hauteur',h,'captures',n,'jour',await p.evaluate(()=>ST.day),'erreurs',err);await b.close()})();
