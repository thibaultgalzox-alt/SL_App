# Fabrique www/accueil.js et www/accueil.css a partir de la maquette validee
import re
src=open('design/questionnaire/source.html',encoding='utf-8').read()
css=src[src.index('<style>')+7:src.index('</style>')]
js=src[src.index("<script>\n'use strict';")+len("<script>\n'use strict';"):src.rindex('</script>')]
def rep(t,a,b,n=1):
    c=t.count(a); assert c==n,(a,c); return t.replace(a,b)

# ---------- CSS ----------
css=rep(css,'{{POLICES}}\n','')
css=rep(css,'html,body{height:100%;overflow:hidden}\n','')
css=rep(css,":root{--bg:#4D102F;",":host{all:initial}\n#racine{--bg:#4D102F;")
css=rep(css,"body{font-family:'Sora',system-ui,sans-serif;background:var(--bg);","#racine{position:absolute;inset:0;overflow:hidden;font-family:'Sora',system-ui,sans-serif;background:var(--bg);")
css=css.replace('body.bascule','#racine.bascule')
css=rep(css,'#facettes{position:fixed;','#facettes{position:absolute;')
css=rep(css,'#app{position:fixed;','#app{position:absolute;')
css=rep(css,'.flash{position:fixed;','.flash{position:absolute;')
css=rep(css,'.flash-v1{position:fixed;','.flash-v1{position:absolute;')
css=rep(css,'.eclat-v1{position:fixed;','.eclat-v1{position:absolute;')
css=re.sub(r'#debug\{[^\n]*\n','',css)
css='/* Questionnaire d accueil (refonte du 16 novembre 2026), charge dans une\n   Shadow DOM par accueil.js : aucune regle ne sort, aucune regle de l app\n   n entre. Source : design/questionnaire/source.html */\n'+css.strip()+'\n'

# ---------- JS ----------
js=rep(js,"var PHENIX='{{PHENIX}}';","var PHENIX='accueil-phenix.webp';")
js=rep(js,"var OB={};\nvar MY_WHY='';","var OB={};          // = ST._ob, pose par demarrer()\nvar MY_WHY='';       // recopie dans ST.myWhy a la fin\nvar R=null,RAC=null; // racine Shadow DOM et conteneur\nvar RECONF=false;    // reconfiguration depuis les Parametres")
js=rep(js,"var p=PAL[a]||PAL.intro,r=document.documentElement.style;","var p=PAL[a]||PAL.intro,r=RAC.style;")
js=rep(js,"  var m=document.querySelector('meta[name=theme-color]');\n","")
js=rep(js,"document.body.classList.add('bascule');setTimeout(function(){document.body.classList.remove('bascule')},260)","RAC.classList.add('bascule');setTimeout(function(){RAC.classList.remove('bascule')},260)")
js=rep(js,"document.body.contains(e)","e.isConnected")
js=rep(js,"document.body.contains(el)","el.isConnected")
js=js.replace("document.body.appendChild(","RAC.appendChild(")
js=js.replace("document.getElementById(","R.getElementById(")
js=rep(js,"addEventListener('resize',function(){ajuster(document.querySelector('#scene .ecran:not(.sort)'))});",
 "// Pas de reajustement quand le clavier s ouvre sur un champ : l ecran ne doit pas retrecir sous les doigts\naddEventListener('resize',function(){if(!R)return;var a=R.activeElement;if(a&&/^(INPUT|TEXTAREA)$/.test(a.tagName))return;ajuster(R.querySelector('#scene .ecran:not(.sort)'))});")

# Enchainements : en reconfiguration, on saute les etudes et le miroir (comme l ancien parcours)
js=rep(js,"ensuite:E_66,","ensuite:(RECONF?E_sport:E_66),")
js=rep(js,"afficher(E_corps)};","afficher(RECONF?E_mental:E_corps)};")
js=rep(js,"ensuite:E_esprit,","ensuite:(RECONF?E_freins:E_esprit),")
js=rep(js,"cpt();e.querySelector('#go').onclick=function(){son('tap');afficher(E_strategie)};","cpt();e.querySelector('#go').onclick=function(){son('tap');afficher(RECONF?E_pourquoi:E_strategie)};")
# choixUnique : ensuite peut etre une fonction anonyme, afficher garde le nom de l ecran reel
js=rep(js,"b.classList.add('pop');suivant(cfg.ensuite,480);","b.classList.add('pop');suivant(cfg.ensuite,480);")

# Pourquoi : en reconfiguration, valider meme vide et finir tout de suite (comme _obSaveWhy)
js=rep(js,"+'<div class=\"bas\" data-a><button class=\"btn\" id=\"go\"'+(MY_WHY.trim()?'':' disabled')+'>Valider</button><button class=\"btn-fant\" id=\"skip\">Passer</button></div>',",
 "+'<div class=\"bas\" data-a><button class=\"btn\" id=\"go\"'+(MY_WHY.trim()||RECONF?'':' disabled')+'>Valider</button><button class=\"btn-fant\" id=\"skip\">Passer</button></div>',")
js=rep(js,"t.oninput=function(){MY_WHY=t.value;g.disabled=!t.value.trim()};\n      g.onclick=function(){MY_WHY=t.value.trim();son('tap');afficher(E_calibration)};\n      e.querySelector('#skip').onclick=function(){MY_WHY='';son('tap');afficher(E_calibration)};",
 "t.oninput=function(){MY_WHY=t.value;g.disabled=!RECONF&&!t.value.trim()};\n      g.onclick=function(){MY_WHY=t.value.trim();son('tap');if(RECONF)terminer();else afficher(E_calibration)};\n      e.querySelector('#skip').onclick=function(){if(!RECONF)MY_WHY='';son('tap');if(RECONF)terminer();else afficher(E_calibration)};")

# Programme : on prend les VRAIES fonctions de l app, pas une copie
i=js.index('// ====== Calcul du programme'); j=js.index('function E_calibration(){')
js=js[:i]+"// ====== Calcul du programme : les vraies fonctions de l app (lisent ST._ob) ======\nfunction calcScore(){return _obCalcScore()}\nfunction calcProg(){return _obCalcProg()}\n\n"+js[j:]

# Ecran final : plus de bouton de maquette, « Commencer » termine pour de vrai
js=rep(js,"+'<button class=\"btn-v1 apparait\" id=\"go\" style=\"animation-delay:1.8s\">Commencer</button>'\n      +'<button class=\"btn-fant apparait\" id=\"dbg\" style=\"animation-delay:2s;font-size:11px\">Maquette : voir les données collectées</button></div>',",
 "+'<button class=\"btn-v1 apparait\" id=\"go\" style=\"animation-delay:1.8s\">Commencer</button></div>',")
i=js.index("      e.querySelector('#go').onclick=function(){var g=e.querySelector('#go');g.textContent='Maquette");
j=js.index("    }};",i)
js=js[:i]+"      e.querySelector('#go').onclick=function(){var g=e.querySelector('#go');if(g.disabled)return;g.disabled=true;son('tap');terminer()};\n"+js[j:]

js=rep(js,"\nafficher(E_ouverture);\n","\n")

# ---------- Point d entree ----------
entree=r'''
// ====== Point d entree, appele par buildOB() ======
var HOTE=null;
function terminer(){
  ST._ob=OB;ST.myWhy=MY_WHY;
  ST._ob.prog=_obCalcProg();
  // _obFinish fait TOUT le travail reel (score, mode, ST.answers, genWeek,
  // navigation, tutoriel) : on ne le reecrit pas, on l appelle.
  var h=HOTE;
  _obFinish();
  // On retire le questionnaire seulement quand l app a quitte l ecran s-ob
  var t0=Date.now();
  (function guetter(){
    var ob=document.getElementById('s-ob');
    if(!h||!h.isConnected)return;
    if(!ob||!ob.classList.contains('active')||Date.now()-t0>15000){h.remove();if(HOTE===h)HOTE=null;return}
    setTimeout(guetter,250);
  })();
}
function annuler(){ // reconfiguration : retour aux Parametres sans rien changer
  var h=HOTE;HOTE=null;if(h)h.remove();
  cancelReconfig();
}
function demarrer(){
  var ob=document.getElementById('s-ob');if(!ob)return false;
  if(HOTE&&HOTE.isConnected)HOTE.remove();
  if(!ST._ob)ST._ob={};
  // On travaille sur une COPIE : en reconfiguration, « Annuler » laisse ST._ob intact
  try{OB=JSON.parse(JSON.stringify(ST._ob))}catch(e){OB={}}
  MY_WHY=ST.myWhy||'';RECONF=!!ST._obReconfig;
  PILE=[];ECRAN_FN=null;EN_TRANSITION=false;ACTE_COUR=null;ETAPE_COUR=null;
  HOTE=document.createElement('div');HOTE.id='nob-hote';
  HOTE.style.cssText='position:fixed;inset:0;z-index:200';
  R=HOTE.attachShadow({mode:'open'});
  R.innerHTML='<style>'+CSS+'</style>'
    +'<div id="racine">'
    +'<div id="facettes">'
    +'<svg class="hd" viewBox="0 0 230 230"><polygon class="f1" points="60,0 230,0 230,150"/><polygon class="f3" points="60,0 230,150 150,90"/><polygon class="f2" points="150,90 230,150 230,230"/><polygon class="f4" points="110,0 160,0 140,40"/></svg>'
    +'<svg class="bg" viewBox="0 0 250 250"><polygon class="f1" points="0,60 0,250 190,250"/><polygon class="f3" points="0,60 90,170 190,250"/><polygon class="f2" points="0,120 0,250 70,250"/><polygon class="f4" points="120,250 190,250 160,210"/></svg>'
    +'</div>'
    +'<div id="app"><div id="haut" class="cache">'
    +'<button id="retour" class="off" aria-label="Retour"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg></button>'
    +'<div id="actes"></div>'
    +(RECONF?'<button id="annuler" class="annuler">Annuler</button>':'')
    +'</div><div id="scene"></div></div></div>';
  RAC=R.getElementById('racine');
  R.getElementById('retour').onclick=retour;
  if(RECONF){R.getElementById('annuler').onclick=annuler;R.getElementById('haut').classList.add('toujours')}
  ob.appendChild(HOTE);
  afficher(RECONF?E_age:E_ouverture);
  return true;
}
window.NOB={demarrer:demarrer};
'''
js="/* Questionnaire d accueil de Metanoia (refonte du 16 novembre 2026).\n   Source validee par Thibs : design/questionnaire/source.html.\n   Tout vit dans une Shadow DOM et dans cette fonction : aucun nom global\n   ajoute sauf window.NOB. Les reponses vont dans ST._ob et ST.myWhy, avec les\n   memes champs et les memes valeurs qu avant, puis _obFinish() fait le reste. */\n(function(){\n'use strict';\n"+js.rstrip()+"\n"+entree+"})();\n"
css+="#haut.toujours{opacity:1;pointer-events:auto}\n.annuler{border:0;background:rgba(0,0,0,.18);color:var(--fg);font:700 12px 'Sora';padding:9px 12px;border-radius:12px}\n"
import json
js=js.replace("(function(){\n'use strict';\n","(function(){\n'use strict';\n// Feuille de style, injectee dans la Shadow DOM (pas de flash sans style)\nvar CSS="+json.dumps(css,ensure_ascii=False)+";\n",1)
open('www/accueil.js','w',encoding='utf-8').write(js)
print(len(js),len(css),js.count('document.'),js.count('—')+js.count('–')+css.count('—')+css.count('–'))
