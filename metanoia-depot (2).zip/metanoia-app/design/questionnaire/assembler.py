import base64,sys
F='/home/claude/metanoia-app/www/fonts/'
pol=''
for fam,poids,fic in [('Cinzel',700,'cinzel-latin-700-normal'),('Sora',400,'sora-latin-400-normal'),('Sora',600,'sora-latin-600-normal'),('Sora',700,'sora-latin-700-normal'),('Sora',800,'sora-latin-800-normal'),('Cormorant Garamond',600,'cormorant-garamond-latin-600-italic')]:
    b=base64.b64encode(open(F+fic+'.woff2','rb').read()).decode()
    st='italic' if 'italic' in fic else 'normal'
    pol+="@font-face{font-family:'%s';font-style:%s;font-weight:%d;font-display:block;src:url(data:font/woff2;base64,%s) format('woff2')}\n"%(fam,st,poids,b)
ph='data:image/webp;base64,'+base64.b64encode(open('/home/claude/metanoia-app/design/questionnaire/phenix.webp','rb').read()).decode()
mon=open('/tmp/monstres.js',encoding='utf-8').read()
s=open('/home/claude/metanoia-app/design/questionnaire/source.html',encoding='utf-8').read()
s=s.replace('{{POLICES}}',pol).replace('{{PHENIX}}',ph).replace('{{MONSTRES}}',mon)
open('/home/claude/metanoia-app/design/questionnaire/maquette.html','w',encoding='utf-8').write(s)
print(len(s), s.count('—')+s.count('–'))
