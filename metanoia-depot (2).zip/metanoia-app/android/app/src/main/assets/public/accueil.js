/* Questionnaire d accueil de Metanoia (refonte du 16 novembre 2026).
   Source validee par Thibs : design/questionnaire/source.html.
   Tout vit dans une Shadow DOM et dans cette fonction : aucun nom global
   ajoute sauf window.NOB. Les reponses vont dans ST._ob et ST.myWhy, avec les
   memes champs et les memes valeurs qu avant, puis _obFinish() fait le reste. */
(function(){
'use strict';
// Feuille de style, injectee dans la Shadow DOM (pas de flash sans style)
var CSS="/* Questionnaire d accueil (refonte du 16 novembre 2026), charge dans une\n   Shadow DOM par accueil.js : aucune regle ne sort, aucune regle de l app\n   n entre. Source : design/questionnaire/source.html */\n*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}\n:host{all:initial}\n#racine{--bg:#4D102F;--deep:#33091F;--hi:#FF8A1F;--hifg:#2a0e1a;--fg:#fff;--encre:#2a0e1a}\n#racine{position:absolute;inset:0;overflow:hidden;font-family:'Sora',system-ui,sans-serif;background:var(--bg);color:var(--fg);-webkit-font-smoothing:antialiased;user-select:none;-webkit-user-select:none;transition:background .5s ease,color .5s}\n\n/* ===== Facettes : le motif du phenix, statique ===== */\n#facettes{position:absolute;inset:0;pointer-events:none;overflow:hidden}\n#facettes svg{position:absolute;transition:transform .7s cubic-bezier(.2,.8,.2,1)}\n#facettes .hd{top:-30px;right:-50px;width:180px}\n#facettes .bg{bottom:-40px;left:-50px;width:210px}\n#facettes polygon{transition:fill .5s}\n#facettes .f1{fill:var(--deep)}\n#facettes .f2{fill:var(--hi);opacity:.9}\n#facettes .f3{fill:rgba(255,255,255,.10)}\n#facettes .f4{fill:rgba(0,0,0,.12)}\n#racine.bascule #facettes .hd{transform:translate(40px,-30px) rotate(8deg)}\n#racine.bascule #facettes .bg{transform:translate(-40px,30px) rotate(-8deg)}\n\n/* ===== Cadre ===== */\n#app{position:absolute;inset:0;display:flex;flex-direction:column;padding:calc(env(safe-area-inset-top) + 10px) 0 calc(env(safe-area-inset-bottom) + 14px)}\n#haut{height:44px;display:flex;align-items:center;gap:12px;padding:0 18px;transition:opacity .3s}\n#haut.cache{opacity:0;pointer-events:none}\n#retour{width:36px;height:36px;border-radius:12px;border:0;background:rgba(0,0,0,.18);color:var(--fg);display:grid;place-items:center;transition:opacity .3s,transform .15s}\n#retour:active{transform:scale(.9)}\n#retour.off{opacity:0;pointer-events:none}\n#retour svg{stroke:currentColor}\n#actes{flex:1;display:flex;gap:6px}\n.seg{flex:1;height:10px;border-radius:4px;background:rgba(0,0,0,.2);overflow:hidden}\n.seg i{display:block;height:100%;width:0;background:var(--fg);border-radius:5px;transition:width .7s cubic-bezier(.2,.8,.2,1)}\n#scene{flex:1;position:relative;overflow:hidden}\n.ecran{position:absolute;inset:0;overflow-y:auto;overscroll-behavior:contain;overflow-x:hidden;padding:6px 22px 22px;display:flex;flex-direction:column;scrollbar-width:none}\n.ecran::-webkit-scrollbar{display:none}\n.ecran.centre::before,.ecran.centre::after{content:'';flex:1 1 0;min-height:0}\n.ecran.sort{animation:sortie .3s ease forwards;pointer-events:none}\n@keyframes sortie{to{opacity:0;transform:translateX(-40px)}}\n.ecran.sort.arriere{animation-name:sortieB}\n@keyframes sortieB{to{opacity:0;transform:translateX(40px)}}\n[data-a]{opacity:0;transform:translateY(18px)}\n.ecran.entre [data-a]{animation:entree .5s cubic-bezier(.2,.9,.25,1.15) forwards;animation-delay:calc(var(--i,0) * 60ms + 60ms)}\n@keyframes entree{to{opacity:1;transform:none}}\n\n/* ===== Typo ===== */\n.acte{font:800 11px/1 'Sora';letter-spacing:.16em;text-transform:uppercase;opacity:.8;margin:10px 0 10px}\n.titre{font:800 30px/1.08 'Sora';letter-spacing:-.025em;margin-bottom:10px}\n.sous{font-size:14px;line-height:1.5;opacity:.85;margin-bottom:20px;max-width:340px}\n.narr{font-size:16px;line-height:1.6;white-space:pre-line;max-width:340px}\n.src{font-size:10.5px;opacity:.55;margin-top:10px}\n.centre-t{text-align:center;margin-left:auto;margin-right:auto}\n\n/* ===== Boutons : 3D a plat ===== */\n.btn{display:block;width:100%;max-width:380px;margin:0 auto;padding:17px 20px;border:0;border-radius:16px;font:800 16px 'Sora';letter-spacing:.01em;color:var(--bg);background:var(--fg);box-shadow:0 5px 0 var(--deep);transition:transform .08s,box-shadow .08s,opacity .3s}\n.btn:active{transform:translateY(4px);box-shadow:0 1px 0 var(--deep)}\n.btn:disabled{opacity:.4;box-shadow:none}\n.btn-fant{display:block;margin:14px auto 0;background:none;border:0;color:var(--fg);opacity:.75;font:700 14px 'Sora';padding:6px 14px}\n.bas{margin-top:auto;padding-top:22px}\n\n/* ===== Cartes ===== */\n.grille{display:grid;grid-template-columns:1fr 1fr;gap:12px;width:100%;max-width:400px}\n.liste{display:flex;flex-direction:column;gap:11px;width:100%;max-width:400px}\n.carte{position:relative;border:0;background:#fff;color:var(--encre);border-radius:18px;font:700 15px/1.25 'Sora';text-align:left;padding:16px;display:flex;align-items:center;gap:13px;box-shadow:0 5px 0 rgba(0,0,0,.22);transition:transform .08s,box-shadow .08s,background .2s,color .2s}\n.grille .carte{flex-direction:column;align-items:flex-start;min-height:128px;justify-content:space-between}\n.carte:active{transform:translateY(4px);box-shadow:0 1px 0 rgba(0,0,0,.22)}\n.carte .ico{width:44px;height:44px;border-radius:13px;display:grid;place-items:center;background:var(--bg);flex:0 0 auto;transition:background .2s}\n.carte .ico svg{width:58%;height:58%;stroke:#fff}\n.carte .lib{flex:1}\n.carte .ok{width:26px;height:26px;border-radius:50%;border:2.5px solid rgba(0,0,0,.15);flex:0 0 auto;display:grid;place-items:center;font-size:14px;font-weight:800;color:transparent;transition:all .2s}\n.grille .carte .ok{position:absolute;top:12px;right:12px}\n.carte.sel{background:var(--hi);color:var(--hifg)}\n.carte.sel .ico{background:var(--hifg)}\n.carte.sel .ico svg{stroke:var(--hi)}\n.carte.sel .ok{background:var(--hifg);border-color:var(--hifg);color:var(--hi);animation:coche .35s cubic-bezier(.2,.9,.3,1.6)}\n@keyframes coche{0%{transform:scale(.3)}}\n.carte.pop{animation:pop .35s cubic-bezier(.2,.9,.3,1.5)}\n@keyframes pop{40%{transform:scale(1.04)}}\n.carte.eteinte{opacity:.5}\n.liste.serree .carte{padding:13px 14px;font-size:14px}\n.grille.compacte{gap:9px}\n.grille.compacte .carte{min-height:0;padding:11px 11px 12px;font-size:12.5px;gap:8px;justify-content:flex-start}\n.grille.compacte .carte .ico{width:32px;height:32px;border-radius:10px}\n.grille.compacte .carte .ok{top:9px;right:9px;width:22px;height:22px;font-size:12px}\n.liste.serree .carte .ico{width:38px;height:38px;border-radius:11px}\n\n/* ===== Etudes ===== */\n.etude{background:#fff;color:var(--encre);border-radius:20px;padding:15px 16px;width:100%;max-width:400px;margin-bottom:14px;box-shadow:0 5px 0 rgba(0,0,0,.22)}\n.etude .stat{font:800 40px/1 'Sora';letter-spacing:-.03em;color:var(--bg)}\n.etude .stat small{font-size:18px;letter-spacing:0}\n.etude h4{font:800 19px/1.2 'Sora';letter-spacing:-.01em;color:var(--bg)}\n.etude p{font-size:14px;line-height:1.5;margin-top:8px}\n.etude .faire{display:flex;gap:10px;align-items:flex-start;margin-top:10px;padding:9px 11px;border-radius:12px;background:var(--hi);color:var(--hifg);font:700 13.5px/1.4 'Sora'}\n.etude .faire::before{content:'→';font-weight:800}\n.etude .src{opacity:.5}\nsvg .trace{stroke-dasharray:var(--l);stroke-dashoffset:var(--l);animation:tracer 1.6s cubic-bezier(.4,0,.2,1) .4s forwards}\n@keyframes tracer{to{stroke-dashoffset:0}}\n.apparait{opacity:0;animation:app .5s ease forwards}\n@keyframes app{to{opacity:1}}\n\n/* ===== Curseur ecrans ===== */\n.ecr-vue{display:flex;align-items:center;gap:22px;margin:6px 0 22px}\n.tel{width:78px;height:140px;border-radius:18px;border:4px solid var(--fg);position:relative;overflow:hidden;flex:0 0 auto}\n.tel .niv{position:absolute;left:0;right:0;bottom:0;background:var(--hi);transition:height .2s}\n.tel .cam{position:absolute;top:7px;left:50%;width:20px;height:5px;border-radius:3px;background:var(--fg);transform:translateX(-50%);z-index:2}\n.ecr-val{font:800 56px/1 'Sora';letter-spacing:-.03em}\n.ecr-val small{font-size:18px;letter-spacing:0}\n.ecr-an{font-size:13.5px;margin-top:8px;line-height:1.45;opacity:.9}\ninput[type=range]{-webkit-appearance:none;appearance:none;width:100%;max-width:400px;display:block;height:14px;border-radius:7px;background:linear-gradient(90deg,var(--hi) var(--p,30%),rgba(0,0,0,.22) var(--p,30%));outline:0}\ninput[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:34px;height:34px;border-radius:50%;background:#fff;box-shadow:0 4px 0 rgba(0,0,0,.25)}\ninput[type=range]::-moz-range-thumb{width:30px;height:30px;border-radius:50%;background:#fff;border:0}\n.graduation{display:flex;justify-content:space-between;max-width:400px;font-size:11px;font-weight:700;opacity:.7;margin-top:8px}\n\n/* ===== Miroir ===== */\n.frise{position:relative;width:100%;max-width:400px;padding-left:40px}\n.frise::before{content:'';position:absolute;left:13px;top:14px;bottom:14px;width:4px;border-radius:2px;background:rgba(0,0,0,.15)}\n.frise .rail{position:absolute;left:13px;top:14px;width:4px;border-radius:2px;background:var(--hi);height:0}\n.etape{position:relative;margin-bottom:12px;opacity:.4;transition:opacity .6s ease,transform .6s ease;transform:translateY(6px)}\n.etape.vue{opacity:1;transform:none}\n.etape .pt{position:absolute;left:-36px;top:16px;width:26px;height:26px;border-radius:50%;background:var(--deep);border:4px solid var(--bg);transition:background .4s}\n.etape.vue .pt{background:var(--hi)}\n.etape .bloc{background:#fff;color:var(--encre);border-radius:16px;padding:12px 14px;box-shadow:0 4px 0 rgba(0,0,0,.18);display:flex;justify-content:space-between;align-items:center;gap:10px}\n.etape .j{font:800 11px 'Sora';letter-spacing:.12em;color:var(--bg);filter:brightness(.6)}\n.etape h3{font:800 16px/1.2 'Sora';margin-top:3px}\n.etape p{font-size:12.5px;line-height:1.4;opacity:.75;margin-top:3px}\n.etape .rang{flex:0 0 auto;text-align:center;font:800 11px/1.1 'Sora';padding:8px 9px;border-radius:12px;background:var(--hi);color:var(--hifg);min-width:52px}\n.etape .rang b{display:block;font-size:18px}\n.badge-phx{width:96px;height:96px;border-radius:28px;background:#4D102F;margin:4px 0 16px;display:grid;place-items:center;box-shadow:0 5px 0 rgba(0,0,0,.25);transition:transform .6s cubic-bezier(.2,.9,.3,1.4)}\n.badge-phx img{width:74%;transition:filter .6s}\n\n/* ===== Phenix, marque ===== */\n.phenix{display:block;margin:0 auto;width:210px;max-width:60vw}\n.naissance{animation:naitre 1.4s cubic-bezier(.2,.9,.3,1.2) both}\n@keyframes naitre{0%{opacity:0;transform:translateY(30px) scale(.7)}100%{opacity:1;transform:none}}\n.marque{font:700 30px 'Cinzel';letter-spacing:.3em;text-align:center;margin:20px 0 22px;padding-left:.3em}\n.curseur-ecr::after{content:'';display:inline-block;width:3px;height:1em;margin-left:2px;vertical-align:-2px;background:var(--hi);animation:clign .8s steps(1) infinite}\n@keyframes clign{50%{opacity:0}}\n\n/* ===== Calibration ===== */\n.pct{font:800 88px/1 'Sora';letter-spacing:-.04em;text-align:center}\n.pct small{font-size:34px}\n.lignes-calib{max-width:300px;margin:20px auto 0;font:700 15px/2.2 'Sora'}\n.lignes-calib div{opacity:.4;transition:opacity .3s}\n.lignes-calib div.ok{opacity:1}\n.lignes-calib div.ok::before{content:'✓  ';color:var(--hi)}\n.prog-nom{font:700 46px/1.1 'Cinzel';text-align:center;letter-spacing:.04em;color:var(--hi);margin:4px 0 8px;animation:tampon .6s cubic-bezier(.2,.9,.3,1.4) both}\n@keyframes tampon{0%{transform:scale(2);opacity:0}100%{transform:none;opacity:1}}\n\n/* ===== Serment ===== */\n.contrat{width:100%;max-width:380px;margin:0 auto;padding:20px 18px;border-radius:20px;background:#FFF6EA;color:#3b1a10;box-shadow:0 5px 0 rgba(0,0,0,.25)}\n.contrat .t{font:800 11px 'Sora';letter-spacing:.16em;text-transform:uppercase;text-align:center;color:#4D102F;margin-bottom:10px}\n.contrat q{display:block;font:italic 600 21px/1.4 'Cormorant Garamond',serif;text-align:center;quotes:none}\n.contrat em{display:block;text-align:center;font-size:11.5px;color:#7a5a40;margin-top:10px}\n.sceau{width:120px;height:120px;margin:22px auto 8px;position:relative;border-radius:50%;border:0;background:none;touch-action:none;display:block}\n.sceau svg{position:absolute;inset:0;width:100%;height:100%}\n.sceau .coeur{position:absolute;inset:14px;border-radius:50%;background:var(--hi);box-shadow:0 6px 0 rgba(0,0,0,.3);display:grid;place-items:center;transition:transform .1s,box-shadow .1s}\n.sceau.tient .coeur{transform:translateY(4px) scale(.96);box-shadow:0 2px 0 rgba(0,0,0,.3)}\n.sceau .coeur img{width:66%}\n.aide-sceau{text-align:center;font:700 14px 'Sora'}\n.flash{position:absolute;inset:0;background:var(--hi);pointer-events:none;animation:flash .7s ease-out forwards;z-index:9}\n@keyframes flash{0%{opacity:0}20%{opacity:.9}100%{opacity:0}}\ntextarea{width:100%;max-width:400px;display:block;min-height:140px;border-radius:18px;border:0;background:#fff;color:var(--encre);font:400 16px/1.5 'Sora';padding:16px;resize:none;outline:0;user-select:text;-webkit-user-select:text;box-shadow:0 5px 0 rgba(0,0,0,.22)}\n.saisie-collectif{width:100%;max-width:400px;background:rgba(0,0,0,.16);border-radius:16px;padding:12px;margin-top:12px;display:none}\n.saisie-collectif.on{display:block}\n.saisie-collectif input{width:100%;border-radius:12px;border:0;background:#fff;color:var(--encre);font:600 15px 'Sora';padding:12px;outline:0;user-select:text;-webkit-user-select:text}\n.jours{display:flex;gap:6px;margin-top:10px}\n.jours button{flex:1;height:40px;border-radius:10px;border:0;background:rgba(255,255,255,.2);color:var(--fg);font:800 12px 'Sora'}\n.jours button.sel{background:var(--hi);color:var(--hifg)}\n.alerte{width:100%;max-width:400px;margin-bottom:12px;background:rgba(0,0,0,.18);border-radius:14px;padding:11px 13px;font-size:12.5px;line-height:1.5}\n.compte{font:800 14px 'Sora';margin-top:14px;min-height:18px}\n/* ===== Comment ca marche : tuiles reliees ===== */\n.chaine{width:100%;max-width:400px;display:flex;flex-direction:column;align-items:stretch}\n.chaine-tuile{opacity:0;transform:translateY(14px) scale(.96);animation:tuile .45s cubic-bezier(.2,.9,.3,1.3) forwards;animation-delay:inherit}\n.chaine-tuile .carte{pointer-events:none}\n@keyframes tuile{to{opacity:1;transform:none}}\n.lien{display:block;width:12px;height:40px;margin:0 auto;overflow:visible}\n.lien .fil{stroke:rgba(255,255,255,.55);stroke-width:2;stroke-linecap:round;stroke-dasharray:32;stroke-dashoffset:32;animation:fil .45s ease-out forwards;animation-delay:var(--d)}\n@keyframes fil{to{stroke-dashoffset:0}}\n.chaine-btn{opacity:0;transform:translateY(10px);animation:tuile .4s ease forwards}\n/* ===== Fin du parcours : version 1, choisie par Thibs ===== */\n.v1{--acc:#F0A050;--acc2:#ffd27a;width:100%;color:#fff}\n.v1 .radar{width:200px;height:200px;margin:0 auto 26px;position:relative}\n.v1 .radar svg{width:100%;height:100%}\n.titre-v1{font:700 20px/1.25 'Cinzel',serif;text-align:center}\n.lignes-v1{max-width:300px;margin:0 auto;font-size:13px;line-height:2.1;color:rgba(255,255,255,.55)}\n.lignes-v1 div.ok{color:#fff}\n.lignes-v1 div.ok::before{content:'✓ ';color:var(--acc2);font-weight:800}\n.lignes-v1 div.en::before{content:'◌ ';color:var(--acc2)}\n.pill-v1{display:table;margin:0 auto 14px;font:700 10px/1 'Sora';letter-spacing:.28em;text-transform:uppercase;color:var(--acc2);padding:7px 14px;border:1px solid rgba(255,210,122,.35);border-radius:20px;background:rgba(0,0,0,.18)}\n.sous-v1{font-size:13px;line-height:1.55;color:rgba(255,255,255,.72);text-align:center;margin:0 auto 18px;max-width:330px}\n.prog-v1{font:700 44px/1.1 'Cinzel';text-align:center;letter-spacing:.06em;background:linear-gradient(180deg,#fff,var(--acc2));-webkit-background-clip:text;background-clip:text;color:transparent;margin:6px 0 10px;animation:tampon-v1 .8s cubic-bezier(.2,.8,.2,1.3) both}\n@keyframes tampon-v1{0%{transform:scale(2.4);opacity:0;filter:blur(8px)}100%{transform:none;opacity:1;filter:none}}\n.contrat-v1{max-width:360px;margin:0 auto;padding:22px 20px;border-radius:22px;background:linear-gradient(170deg,#f6ead2,#e7d2a8);color:#3b1a10;box-shadow:0 20px 50px -18px rgba(0,0,0,.8),inset 0 0 0 1px rgba(255,255,255,.5),inset 0 0 0 7px rgba(140,90,30,.12)}\n.contrat-v1 .t{font:700 11px 'Sora';letter-spacing:.24em;text-transform:uppercase;text-align:center;color:#8a4b1e;margin-bottom:12px}\n.contrat-v1 q{display:block;font:italic 600 21px/1.45 'Cormorant Garamond',serif;text-align:center;quotes:none}\n.contrat-v1 em{display:block;text-align:center;font-size:11px;color:#7a5a40;margin-top:12px}\n.sceau-v1{width:132px;height:132px;margin:22px auto 8px;position:relative;border-radius:50%;border:0;background:none;touch-action:none;display:block}\n.sceau-v1 svg{position:absolute;inset:0;width:100%;height:100%}\n.sceau-v1 .coeur{position:absolute;inset:18px;border-radius:50%;background:radial-gradient(circle at 40% 35%,#d9443b,#7a1020 70%);box-shadow:0 8px 24px -6px #000,inset 0 2px 0 rgba(255,255,255,.3);display:grid;place-items:center;transition:transform .15s}\n.sceau-v1.tient .coeur{transform:scale(.93)}\n.sceau-v1 .coeur img{width:62%;filter:brightness(1.4) sepia(1) saturate(.6) hue-rotate(-10deg) drop-shadow(0 1px 0 rgba(0,0,0,.4));opacity:.85}\n.aide-v1{text-align:center;font-size:12.5px;color:rgba(255,255,255,.75)}\n.flash-v1{position:absolute;inset:0;background:radial-gradient(circle,#fff,#ffd27a 40%,transparent 75%);pointer-events:none;animation:flash .9s ease-out forwards;z-index:9}\n.eclat-v1{position:absolute;left:50%;top:42%;width:10px;height:10px;pointer-events:none}\n.eclat-v1 i{position:absolute;width:6px;height:16px;border-radius:3px;background:#ffd27a;left:0;top:0;animation:jaillir 1s ease-out forwards}\n@keyframes jaillir{0%{transform:rotate(var(--r)) translateY(0) scale(1);opacity:1}100%{transform:rotate(var(--r)) translateY(-160px) scale(.3);opacity:0}}\n.phenix-v1{display:block;margin:0 auto;width:230px;max-width:60vw;filter:drop-shadow(0 0 30px rgba(255,140,60,.55))}\n.naissance-v1{animation:naitre-v1 2.2s cubic-bezier(.2,.8,.2,1) both,souffle-v1 4s ease-in-out 2.2s infinite}\n@keyframes naitre-v1{0%{opacity:0;transform:translateY(40px) scale(.6);filter:brightness(3) blur(6px)}60%{opacity:1;filter:brightness(1.6) blur(0) drop-shadow(0 0 60px rgba(255,170,80,1))}100%{transform:none}}\n@keyframes souffle-v1{50%{transform:translateY(-8px) scale(1.02);filter:drop-shadow(0 0 44px rgba(255,160,70,.8))}}\n.marque-v1{font:700 22px 'Cinzel';letter-spacing:.18em;text-align:center;margin:18px 0 6px;background:linear-gradient(180deg,#fff 30%,#ffd27a);-webkit-background-clip:text;background-clip:text;color:transparent}\n.filet-v1{width:60px;height:1px;margin:0 auto 22px;background:linear-gradient(90deg,transparent,#ffd27a,transparent)}\n.narr-v1{font-size:15px;line-height:1.75;color:rgba(255,255,255,.9);text-align:center;max-width:340px;margin:0 auto}\n.btn-v1{display:block;width:100%;max-width:340px;margin:0 auto;padding:16px 20px;border:0;border-radius:16px;font:700 15px 'Sora';color:#2a0b12;background:linear-gradient(135deg,#ffd27a,#F0A050);box-shadow:0 8px 24px -6px #F0A050,inset 0 1px 0 rgba(255,255,255,.6)}\n.btn-v1:active{transform:scale(.97)}\n.btn-v1:disabled{opacity:.6}\n#haut.toujours{opacity:1;pointer-events:auto}\n.annuler{border:0;background:rgba(0,0,0,.18);color:var(--fg);font:700 12px 'Sora';padding:9px 12px;border-radius:12px}\n";

var PHENIX='accueil-phenix.webp';

// ====== Etat (memes champs que ST._ob dans l app) ======
var OB={};          // = ST._ob, pose par demarrer()
var MY_WHY='';       // recopie dans ST.myWhy a la fin
var R=null,RAC=null; // racine Shadow DOM et conteneur
var RECONF=false;    // reconfiguration depuis les Parametres

// ====== Couleurs par acte : aplats francs ======
var PAL={
  intro:{bg:'#4D102F',deep:'#33091F',hi:'#D9A84E',hifg:'#2a0e1a',fg:'#fff'},
  1:{bg:'#6C2BD9',deep:'#4B169E',hi:'#FFD23F',hifg:'#2a0e1a',fg:'#fff'},
  2:{bg:'#FF5A1F',deep:'#C93A0B',hi:'#FFE14D',hifg:'#2a0e1a',fg:'#fff'},
  3:{bg:'#0B7CFF',deep:'#0656B8',hi:'#7CF5D2',hifg:'#062a4a',fg:'#fff'},
  4:{bg:'#E0115F',deep:'#A00A42',hi:'#FFD23F',hifg:'#2a0e1a',fg:'#fff'},
  5:{bg:'#FFB400',deep:'#D98E00',hi:'#4D102F',hifg:'#fff',fg:'#2a0e1a'},
  6:{bg:'#4D102F',deep:'#33091F',hi:'#FFB400',hifg:'#2a0e1a',fg:'#fff'}
};
var ACTE_COUR=null;
function palette(a){
  if(ACTE_COUR===a)return;var change=ACTE_COUR!==null;ACTE_COUR=a;
  var p=PAL[a]||PAL.intro,r=RAC.style;
  for(var k in p)r.setProperty('--'+k,p[k]);
  if(change){RAC.classList.add('bascule');setTimeout(function(){RAC.classList.remove('bascule')},260)}
}

// ====== Sons et vibrations ======
// Son unique du formulaire : « Bois » (n° 2 de la bibliotheque, choix de Thibs),
// un coup sec et chaud : triangle 880 -> 700 Hz sur 60 ms + bruit filtre a 1,4 kHz.
var AC=null,BRUIT_BOIS=null;
var SON_DERNIER=0;
function son(){
  if(EN_TRANSITION)return;
  var maintenant=performance.now();if(maintenant-SON_DERNIER<150)return;SON_DERNIER=maintenant;
  try{
    if(!AC)AC=new (window.AudioContext||window.webkitAudioContext)();
    if(AC.state==='suspended')AC.resume();
    var t=AC.currentTime+.005;
    var o=AC.createOscillator(),g=AC.createGain();o.type='triangle';
    o.frequency.setValueAtTime(880,t);o.frequency.exponentialRampToValueAtTime(700,t+.06);
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.35,t+.001);g.gain.exponentialRampToValueAtTime(.0001,t+.061);
    o.connect(g);g.connect(AC.destination);o.start(t);o.stop(t+.12);
    if(!BRUIT_BOIS){var n=Math.ceil(AC.sampleRate*.07);BRUIT_BOIS=AC.createBuffer(1,n,AC.sampleRate);var d=BRUIT_BOIS.getChannelData(0);for(var k=0;k<n;k++)d[k]=Math.random()*2-1}
    var b=AC.createBufferSource(),f=AC.createBiquadFilter(),g2=AC.createGain();b.buffer=BRUIT_BOIS;
    f.type='bandpass';f.frequency.value=1400;f.Q.value=2;
    g2.gain.setValueAtTime(.0001,t);g2.gain.exponentialRampToValueAtTime(.25,t+.001);g2.gain.exponentialRampToValueAtTime(.0001,t+.016);
    b.connect(f);f.connect(g2);g2.connect(AC.destination);b.start(t);
  }catch(e){}
}
function vibre(ms){try{navigator.vibrate&&navigator.vibrate(ms)}catch(e){}}

// ====== Icones (traits, 24x24) ======
function ico(nom){
  var P={
    pousse:'<path d="M12 21v-9"/><path d="M12 12c0-4 3-7 8-7 0 5-3 8-8 7z"/><path d="M12 14c0-3-2-6-7-6 0 4 3 7 7 6z"/>',
    eclair:'<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
    flamme:'<path d="M12 22c4 0 7-3 7-7 0-5-5-7-4-12-3 2-6 5-6 9-1-1-2-3-2-4-1 2-2 4-2 7 0 4 3 7 7 7z"/>',
    diamant:'<path d="M6 3h12l4 6-10 12L2 9z"/><path d="M2 9h20M9 3l3 18 3-18"/>',
    toque:'<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2 9 2 12 0v-5"/><path d="M22 9v6"/>',
    mallette:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 012-2h4a2 2 0 012 2v2M3 13h18"/>',
    boussole:'<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
    maison:'<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
    lune:'<path d="M20 14.5A8.5 8.5 0 019.5 4 8.5 8.5 0 1020 14.5z"/>',
    vagues:'<path d="M3 8c3-3 6 3 9 0s6 3 9 0M3 14c3-3 6 3 9 0s6 3 9 0"/>',
    halteres:'<path d="M6 7v10M18 7v10M3 9.5v5M21 9.5v5M6 12h12"/>',
    goutte:'<path d="M12 3c4 5 6 8 6 11a6 6 0 01-12 0c0-3 2-6 6-11z"/>',
    coeur:'<path d="M12 20s-8-5-8-11a4.5 4.5 0 018-2.8A4.5 4.5 0 0120 9c0 6-8 11-8 11z"/>',
    pas:'<path d="M8 15c-2 0-3-2-3-5s1-6 3-6 3 3 3 6-1 5-3 5z"/><path d="M16 20c2 0 3-2 3-5s-1-6-3-6-3 3-3 6 1 5 3 5z"/>',
    course:'<circle cx="15" cy="4.5" r="2"/><path d="M5 21l4-6 3 2 1-5 4 3h3"/><path d="M8 11l3-3 4 1"/>',
    ballon:'<circle cx="12" cy="12" r="9"/><path d="M12 7l4 3-1.5 5h-5L8 10z"/>',
    livre:'<path d="M4 5c3-1 6-1 8 1v14c-2-2-5-2-8-1z"/><path d="M20 5c-3-1-6-1-8 1v14c2-2 5-2 8-1z"/>',
    casque:'<path d="M4 15v-3a8 8 0 0116 0v3"/><rect x="3" y="14" width="4" height="7" rx="1.5"/><rect x="17" y="14" width="4" height="7" rx="1.5"/>',
    vide:'<circle cx="12" cy="12" r="9"/><path d="M8 12h8"/>',
    pile0:'<rect x="3" y="7" width="16" height="10" rx="2"/><path d="M21 10v4M6 10v4"/>',
    pile1:'<rect x="3" y="7" width="16" height="10" rx="2"/><path d="M21 10v4M6 10v4M9 10v4M12 10v4"/>',
    pile2:'<rect x="3" y="7" width="16" height="10" rx="2"/><path d="M21 10v4M6 10v4M9 10v4M12 10v4M15 10v4"/>',
    soleil:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
    cible:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/>',
    telephone:'<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/>',
    interdit:'<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>',
    burger:'<path d="M4 10c0-4 4-6 8-6s8 2 8 6z"/><path d="M3 13h18M4 16h16a3 3 0 01-3 3H7a3 3 0 01-3-3z"/>',
    verre:'<path d="M6 3h12l-1 7a5 5 0 01-10 0z"/><path d="M12 15v6M8 21h8"/>',
    porte:'<path d="M5 21V4a1 1 0 011-1h9l3 2v16"/><path d="M3 21h18"/><circle cx="12.5" cy="12" r="1"/>',
    formulaire:'<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M9 10h6M9 14h6M9 18h3"/>',
    engrenage:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
    chaine:'<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"/>'
  };
  return '<svg viewBox="0 0 24 24" fill="none" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'+(P[nom]||'')+'</svg>';
}

// ====== Moteur d ecrans ======
var PILE=[],ECRAN_FN=null,EN_TRANSITION=false,ACTES=['1','2','3','4','5','6'];
// Etape de chaque ecran dans le parcours (la barre n apparait qu a partir de l age)
var ETAPES={E_age:1,E_situation:2,E_66:3,E_sport:4,E_objectif:5,E_acces:6,E_corps:7,E_mental:8,E_ecrans:9,E_sommeil:10,E_esprit:11,E_freins:12,E_strategie:13,E_miroir:14,E_pourquoi:15,E_calibration:16,E_programme:17,E_final:18};
var NB_ETAPES=18,ETAPE_COUR=null;
// Courbe concave : la barre avance vite au debut puis ralentit, pour donner
// tot le sentiment d avancer. 1-(1-x)^1.6 : 20 % du parcours = 30 % de barre,
// la moitie = 67 %, 80 % = 92 %.
function courbe(x){x=Math.max(0,Math.min(1,x));return 1-Math.pow(1-x,1.6)}
function progression(etape,sous){
  var h=R.getElementById('haut'),z=R.getElementById('actes');
  if(!z.children.length)z.innerHTML='<div class="seg"><i></i></div>';
  ETAPE_COUR=etape;h.classList.toggle('cache',etape==null);
  if(etape==null)return;
  z.firstChild.firstChild.style.width=(courbe((etape-1+(sous||0))/(NB_ETAPES-1))*100).toFixed(2)+'%';
}
function progressionSous(sous){if(ETAPE_COUR!=null)progression(ETAPE_COUR,sous)}
function afficher(fn,opts){
  opts=opts||{};if(EN_TRANSITION&&!opts.force)return;EN_TRANSITION=true;
  var sc=R.getElementById('scene'),vieux=sc.querySelector('.ecran:not(.sort)');
  if(ECRAN_FN&&!opts.arriere&&!opts.sansPile)PILE.push(ECRAN_FN);
  ECRAN_FN=fn;var d=fn();
  palette(d.acte);progression(ETAPES[fn.name]!=null?ETAPES[fn.name]:null,0);
  R.getElementById('retour').classList.toggle('off',!d.retour||!PILE.length);
  if(vieux){vieux.classList.add('sort');if(opts.arriere)vieux.classList.add('arriere');setTimeout(function(){vieux.remove()},320)}
  var e=document.createElement('div');e.className='ecran'+(d.centre?' centre':'');e.innerHTML=d.html;
  typo(e);var n=0;e.querySelectorAll('[data-a]').forEach(function(x){x.style.setProperty('--i',n++)});
  setTimeout(function(){sc.appendChild(e);ajuster(e);void e.offsetHeight;e.classList.add('entre');if(d.apres)d.apres(e);EN_TRANSITION=false},vieux?150:0);
}
// Tout l ecran doit tenir sans defiler : si le contenu deborde, on le reduit
// (zoom CSS, qui refait la mise en page) jusqu a ce qu il tienne, sans
// descendre sous 70 %. En dessous, et seulement la, le defilement reste possible.
function ajuster(e){
  if(!e||!e.isConnected)return;
  e.style.zoom='';var k=1;
  for(var n=0;n<4;n++){
    var trop=e.scrollHeight-e.clientHeight;
    if(trop<=1)break;
    k=Math.max(.7,k*(e.clientHeight/e.scrollHeight)*.995);e.style.zoom=k;
    if(k<=.7)break;
  }
  e.classList.toggle('ajuste',k<1);
}
// Pas de reajustement quand le clavier s ouvre sur un champ : l ecran ne doit pas retrecir sous les doigts
addEventListener('resize',function(){if(!R)return;var a=R.activeElement;if(a&&/^(INPUT|TEXTAREA)$/.test(a.tagName))return;ajuster(R.querySelector('#scene .ecran:not(.sort)'))});
function retour(){if(!PILE.length||EN_TRANSITION)return;son('tap');afficher(PILE.pop(),{arriere:true})}
function suivant(fn,delai){setTimeout(function(){afficher(fn)},delai||0)}

function carte(o,i,sel){return '<button class="carte'+(sel?' sel':'')+'" data-i="'+i+'"><span class="ico">'+ico(o[0])+'</span><span class="lib">'+o[1]+'</span><span class="ok">✓</span></button>'}
function choixUnique(cfg){
  var cur=OB[cfg.champ];
  return {acte:cfg.acte,frac:cfg.frac,retour:true,centre:true,
    html:'<div class="acte" data-a>'+cfg.label+'</div><div class="titre" data-a>'+cfg.titre+'</div>'
      +(cfg.sous?'<div class="sous" data-a>'+cfg.sous+'</div>':'<div style="height:14px"></div>')
      +'<div class="'+(cfg.forme||'grille')+'" data-a>'+cfg.opts.map(function(o,i){return carte(o,i,cur===i)}).join('')+'</div>',
    apres:function(e){
      var verrou=false;
      e.querySelectorAll('.carte').forEach(function(b){b.addEventListener('click',function(){
        if(verrou)return;verrou=true;OB[cfg.champ]=+b.dataset.i;son('sel');vibre(12);
        e.querySelectorAll('.carte').forEach(function(x){x.classList.toggle('sel',x===b);x.classList.toggle('eteinte',x!==b)});
        b.classList.add('pop');suivant(cfg.ensuite,480);
      })});
    }};
}
// Carte d etude : stat ou titre, une phrase, une action, la source
function etude(c){
  return '<div class="etude" data-a>'+(c.stat?'<div class="stat">'+c.stat+'</div>':'')+(c.h?'<h4>'+c.h+'</h4>':'')
    +(c.p?'<p>'+c.p+'</p>':'')+(c.faire?'<div class="faire">'+c.faire+'</div>':'')+'<div class="src">'+c.src+'</div></div>';
}

// ====== Ecrans ======
var L1='Acte I · Qui tu es',L2='Acte II · Ton corps',L3='Acte III · Ton esprit',L4='Acte IV · Tes freins',L5='Acte V · Qui tu peux devenir',L6='Acte VI · Le serment';
function E_ouverture(){
  return {acte:'intro',centre:true,
    html:'<img class="phenix naissance" src="'+PHENIX+'" alt="">'
      +'<div class="marque apparait" style="animation-delay:.8s">METANOIA</div>'
      +'<p class="narr centre-t" id="pitch" style="min-height:104px;text-align:center"></p>'
      +'<div style="height:26px"></div>'
      +'<button class="btn" id="go" style="opacity:0;pointer-events:none;transition:opacity .4s">Je veux changer</button>',
    apres:function(e){
      var t='Parfois, tu galères à tenir une bonne habitude.\nOn te propose d\'en tenir plusieurs, et à long terme.';
      setTimeout(function(){machine(R.getElementById('pitch'),t,24,function(){var g=R.getElementById('go');if(g){g.style.opacity=1;g.style.pointerEvents='auto'}})},1100);
      e.querySelector('#go').onclick=function(){vibre(20);afficher(E_bienvenue)};
    }};
}
function E_bienvenue(){
  var tuiles=[['formulaire','Tu réponds au formulaire, pour créer un programme adapté'],['engrenage','Ton programme est créé, en fonction de tes réponses'],['flamme','Tu peux enfin commencer à changer, et ce gratuitement.']];
  // Tuiles reliees par un fil flechee qui se trace de haut en bas, etape par etape
  var T=0,h='';
  tuiles.forEach(function(t,i){
    h+='<div class="chaine-tuile" style="animation-delay:'+T+'ms"><div class="carte"><span class="ico">'+ico(t[0])+'</span><span class="lib">'+t[1]+'</span></div></div>';
    T+=420;
    if(i<tuiles.length-1){
      h+='<svg class="lien" viewBox="0 0 12 40" style="--d:'+T+'ms"><line class="fil" x1="6" y1="4" x2="6" y2="36"/></svg>';
      T+=520;
    }
  });
  return {acte:'intro',retour:true,centre:true,
    html:'<div class="titre" data-a>Comment ça marche</div><div style="height:14px"></div>'
      +'<div class="chaine">'+h+'</div>'
      +'<div style="height:32px"></div><button class="btn chaine-btn" id="go" style="animation-delay:'+(T+150)+'ms">Compris</button>',
    apres:function(e){
      // un petit son a chaque etape qui apparait
      for(var k=1;k<3;k++)setTimeout(function(){son('tap');vibre(6)},k*940);
      e.querySelector('#go').onclick=function(){son('tap');afficher(E_age)};
    }};
}
function E_age(){return choixUnique({acte:1,frac:.2,label:L1,titre:'Quel âge as-tu ?',champ:'age',ensuite:E_situation,
  opts:[['pousse','15-18 ans'],['eclair','19-24 ans'],['flamme','25-30 ans'],['diamant','30 ans et plus']]})}
function E_situation(){return choixUnique({acte:1,frac:.6,label:L1,titre:'Ta situation actuelle ?',champ:'situation',ensuite:(RECONF?E_sport:E_66),
  opts:[['toque','Lycéen / Étudiant'],['mallette','En activité'],['boussole','En transition'],['maison','Sans activité principale']]})}

function E_66(){
  var pts=[];for(var j=0;j<=120;j+=4){pts.push((10+j*2.4).toFixed(1)+','+(130-110*(1-Math.exp(-j/26))).toFixed(1))}
  var x66=10+66*2.4,y66=(130-110*(1-Math.exp(-66/26))).toFixed(1);
  return {acte:1,frac:1,retour:true,
    html:'<div class="acte" data-a>Ce que montrent les études</div><div class="titre" data-a>Une habitude devient automatique.</div><div style="height:6px"></div>'
      +'<div class="etude" data-a><div class="stat">66 <small>jours</small></div><p>en médiane, de 18 à 254 selon les personnes.</p>'
      +'<svg viewBox="0 0 310 145" style="width:100%;display:block;margin-top:10px"><line x1="10" y1="130" x2="300" y2="130" stroke="#e8dcd2" stroke-width="2"/>'
      +'<polyline class="trace" style="--l:400" points="'+pts.join(' ')+'" fill="none" stroke="var(--bg)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>'
      +'<g class="apparait" style="animation-delay:1.7s"><circle cx="'+x66+'" cy="'+y66+'" r="9" fill="var(--hi)" stroke="var(--bg)" stroke-width="4"/><text x="'+(x66-4)+'" y="'+(+y66+30)+'" font-size="13" font-weight="800" fill="#2a0e1a" font-family="Sora" text-anchor="middle">Jour 66</text></g>'
      +'<text x="10" y="144" font-size="10" font-weight="700" fill="#9a8a80" font-family="Sora">Jour 1 : effort</text><text x="300" y="144" font-size="10" font-weight="700" fill="#9a8a80" font-family="Sora" text-anchor="end">automatisme</text></svg>'
      +'<div class="src">Lally et al., 2010, European Journal of Social Psychology</div></div>'
      +etude({h:'Rater une fois ne casse rien.',p:'L\'automatisme revenait vite après un oubli.',faire:'Un jour raté ? Reprends dès le lendemain.',src:'Lally et al., 2010'})
      +'<div class="bas" data-a><button class="btn" id="go">Continuer</button></div>',
    apres:function(e){e.querySelector('#go').onclick=function(){son('tap');afficher(E_sport)}}};
}

function E_sport(){return choixUnique({acte:2,frac:.15,label:L2,titre:'Ton rapport au sport en ce moment ?',champ:'sportLevel',ensuite:E_objectif,forme:'liste',
  opts:[['flamme','Je m\'entraîne déjà régulièrement'],['vagues','J\'essaie, mais c\'est irrégulier'],['lune','Je ne fais rien du tout']]})}
function E_objectif(){return choixUnique({acte:2,frac:.4,label:L2,titre:'Quel objectif physique vises-tu ?',champ:'physGoal',ensuite:E_acces,
  opts:[['halteres','Prise de masse / muscle'],['goutte','Sécher, perdre du poids, affiner'],['coeur','Améliorer mon endurance'],['pas','Juste bouger plus']]})}
function E_acces(){
  if(!OB.sportAccess)OB.sportAccess=[];if(OB.collectifSport==null)OB.collectifSport='';if(!OB.collectifJours)OB.collectifJours=[];
  var o=[['halteres','J\'ai accès à une salle de sport / je vais m\'y inscrire'],['maison','Pas de salle, je peux faire du sport à la maison'],['course','Je peux courir dehors'],['ballon','Je fais en plus un sport collectif régulier']];
  var J=['L','M','Me','J','V','S','D'];
  return {acte:2,frac:.7,retour:true,
    html:'<div class="acte" data-a>'+L2+'</div><div class="titre" data-a>Ce que tu as accès à faire ?</div><div class="sous" data-a>Plusieurs choix possibles</div>'
      +'<div class="alerte" data-a style="'+(OB.physGoal===0?'':'display:none')+'">⚠️ Tu as sélectionné l\'objectif <strong>Prise de masse</strong>. Il est alors fortement recommandé d\'avoir accès à une salle de sport. Sinon, tu peux fonctionner en poids de corps.</div>'
      +'<div class="liste serree" data-a>'+o.map(function(x,i){return carte(x,i,OB.sportAccess.indexOf(i)>=0)}).join('')+'</div>'
      +'<div class="saisie-collectif'+(OB.sportAccess.indexOf(3)>=0?' on':'')+'" id="coll"><input id="coll-nom" placeholder="Quel sport ?" value="'+esc(OB.collectifSport)+'"><div class="jours">'+J.map(function(j,i){return '<button data-j="'+i+'" class="'+(OB.collectifJours.indexOf(i)>=0?'sel':'')+'">'+j+'</button>'}).join('')+'</div></div>'
      +'<div class="bas" data-a><button class="btn" id="go">Continuer</button></div>',
    apres:function(e){
      e.querySelectorAll('.carte').forEach(function(b){b.onclick=function(){
        var i=+b.dataset.i,a=OB.sportAccess,k=a.indexOf(i);son('sel');vibre(10);
        if(k>=0)a.splice(k,1);else{a.push(i);if(i===0){var m=a.indexOf(1);if(m>=0)a.splice(m,1)}if(i===1){var n=a.indexOf(0);if(n>=0)a.splice(n,1)}}
        e.querySelectorAll('.carte').forEach(function(x){x.classList.toggle('sel',a.indexOf(+x.dataset.i)>=0)});
        b.classList.remove('pop');void b.offsetWidth;b.classList.add('pop');
        e.querySelector('#coll').classList.toggle('on',a.indexOf(3)>=0);ajuster(e);
      }});
      e.querySelector('#coll-nom').oninput=function(){OB.collectifSport=this.value};
      e.querySelectorAll('.jours button').forEach(function(b){b.onclick=function(){var j=+b.dataset.j,a=OB.collectifJours,k=a.indexOf(j);son('tap');if(k>=0)a.splice(k,1);else a.push(j);b.classList.toggle('sel',a.indexOf(j)>=0)}});
      e.querySelector('#go').onclick=function(){son('tap');if(!OB.sportAccess.length)OB.sportAccess=[1];afficher(RECONF?E_mental:E_corps)};
    }};
}
function E_corps(){
  var c2=(OB.sportAccess||[]).indexOf(3)>=0
    ?{stat:'66 % <small>contre 24 %</small>',p:'ont tenu leurs résultats quand ils s\'étaient engagés avec des amis, contre ceux venus seuls.',faire:'Ton sport collectif compte : garde ce rendez-vous.',src:'Wing et Jeffery, 1999, Journal of Consulting and Clinical Psychology'}
    :{stat:'68 %',p:'des personnes qui ont maintenu leurs résultats faisaient leur sport à heure fixe.',faire:'Choisis ton heure de sport, et garde-la.',src:'Bond et al., 2019, Obesity'};
  return {acte:2,frac:1,retour:true,
    html:'<div class="acte" data-a>Ce que montrent les études</div><div class="titre" data-a>Deux astuces qui marchent.</div><div style="height:6px"></div>'
      +etude({stat:'+51 %',p:'de séances quand les livres audio préférés n\'étaient disponibles qu\'à la salle.',faire:'Réserve ton podcast préféré à tes séances.',src:'Milkman, Minson et Volpp, 2014, Management Science'})
      +etude(c2)
      +'<div class="bas" data-a><button class="btn" id="go">Continuer</button></div>',
    apres:function(e){e.querySelector('#go').onclick=function(){son('tap');afficher(E_mental)}}};
}

function E_mental(){return choixUnique({acte:3,frac:.15,label:L3,titre:'Comment te stimules-tu intellectuellement ?',champ:'mindLevel',ensuite:E_ecrans,forme:'liste',
  opts:[['livre','Je lis régulièrement'],['casque','Podcasts / vidéos éducatives'],['vide','Honnêtement, pas grand-chose']]})}
function E_ecrans(){
  if(OB.screenHours===undefined)OB.screenHours=3;
  return {acte:3,frac:.45,retour:true,
    html:'<div class="acte" data-a>'+L3+'</div><div class="titre" data-a>Tes écrans, combien d\'heures par jour en moyenne ?</div><div class="sous" data-a>Hors travail / études obligatoires</div>'
      +'<div class="ecr-vue" data-a><div class="tel"><div class="cam"></div><div class="niv" id="niv"></div></div><div><div class="ecr-val" id="val"></div><div class="ecr-an" id="an"></div></div></div>'
      +'<div data-a><input type="range" id="sl" min="0" max="10" step=".5" value="'+OB.screenHours+'"><div class="graduation"><span>0 h</span><span>10 h</span></div></div>'
      +'<div class="bas" data-a><button class="btn" id="go">Valider</button></div>',
    apres:function(e){
      var sl=e.querySelector('#sl'),dernier=-1;
      function maj(){var v=parseFloat(sl.value);OB.screenHours=v;sl.style.setProperty('--p',(v*10)+'%');
        e.querySelector('#niv').style.height=(v*10)+'%';e.querySelector('#val').innerHTML=fmt(v)+'<small> h/jour</small>';
        e.querySelector('#an').textContent=v>0?'Chaque heure reprise, c\'est 365 h par an pour toi.':'Un vrai atout.';
        if(v!==dernier){if(dernier>=0){son('tap');vibre(4)}dernier=v}}
      sl.oninput=maj;maj();e.querySelector('#go').onclick=function(){son('tap');afficher(E_sommeil)};
    }};
}
function E_sommeil(){return choixUnique({acte:3,frac:.75,label:L3,titre:'Tu dors combien d\'heures en moyenne ?',champ:'sleep',ensuite:(RECONF?E_freins:E_esprit),forme:'liste',
  opts:[['pile0','Moins de 6h'],['pile1','6 à 7h'],['pile2','8h et plus']]})}
function E_esprit(){
  var c1=(OB.screenHours||0)>=1
    ?{stat:'+60 min',p:'libres par jour, et plus de bien-être, en désactivant Facebook pendant 4 semaines.',faire:'Teste une semaine sans ton appli la plus prenante.',src:'Allcott et al., 2020, American Economic Review'}
    :{h:'Les habitudes du matin tiennent mieux.',p:'Et celles qu\'on a choisies soi-même aussi.',faire:'Place tes quêtes clés le matin.',src:'Singh et al., 2024, Healthcare'};
  return {acte:3,frac:1,retour:true,
    html:'<div class="acte" data-a>Ce que montrent les études</div><div class="titre" data-a>Reprends la main sur ton attention.</div><div style="height:6px"></div>'
      +etude(c1)
      +etude({h:'Téléphone hors de vue.',p:'Une semaine en mode Ne pas déranger donnait moins d\'inattention et d\'agitation qu\'avec les notifications.',faire:'Active Ne pas déranger pendant tes quêtes.',src:'Kushlev, Proulx et Dunn, 2016, CHI'})
      +'<div class="bas" data-a><button class="btn" id="go">Continuer</button></div>',
    apres:function(e){e.querySelector('#go').onclick=function(){son('tap');afficher(E_freins)}}};
}

var FREINS=[['soleil','Me lever le matin'],['cible','Rester concentré / ne pas procrastiner'],['telephone','Résister aux réseaux sociaux'],['interdit','La pornographie'],['burger','La nourriture / junk food'],['verre','L\'alcool / substances'],['porte','Sortir de chez moi'],['chaine','Tenir mes engagements sur la durée']];
function E_freins(){
  if(!OB.resistances)OB.resistances=[];
  return {acte:4,frac:.4,retour:true,
    html:'<div class="acte" data-a>'+L4+'</div><div class="titre" data-a>Ce que tu as du mal à contrôler ?</div><div class="sous" data-a>Sois honnête. C\'est sans doute la question la + importante</div>'
      +'<div class="grille compacte" data-a>'+FREINS.map(function(f,i){return carte(f,i,OB.resistances.indexOf(i)>=0)}).join('')+'</div>'
      +'<div class="compte" id="cd"></div>'
      +'<div class="bas" data-a><button class="btn" id="go">Continuer</button></div>',
    apres:function(e){
      function cpt(){var n=OB.resistances.length;e.querySelector('#cd').textContent=n?n+' sélectionné'+(n>1?'s':''):''}
      e.querySelectorAll('.carte').forEach(function(b){b.onclick=function(){
        var i=+b.dataset.i,a=OB.resistances,k=a.indexOf(i);son('sel');vibre(10);
        if(k>=0)a.splice(k,1);else a.push(i);b.classList.toggle('sel',a.indexOf(i)>=0);
        b.classList.remove('pop');void b.offsetWidth;b.classList.add('pop');cpt();
      }});
      cpt();e.querySelector('#go').onclick=function(){son('tap');afficher(RECONF?E_pourquoi:E_strategie)};
    }};
}
function E_strategie(){
  var porno=(OB.resistances||[]).indexOf(3)>=0;
  return {acte:4,frac:1,retour:true,
    html:'<div class="acte" data-a>Ce que montrent les études</div><div class="titre" data-a>La discipline, ça s\'organise.</div><div style="height:6px"></div>'
      +etude({h:'Les plus disciplinés n\'ont pas moins d\'envies.',p:'Ils évitent surtout les situations de tentation.',faire:'Éloigne la tentation avant le moment à risque.',src:'Hofmann et al., 2012, Journal of Personality and Social Psychology'})
      +etude({h:'« Si..., alors je... »',p:'Sur 94 tests, ces plans amélioraient nettement l\'atteinte des objectifs.',faire:'Si l\'envie arrive, alors je sors de la pièce.',src:'Gollwitzer et Sheeran, 2006'})
      +(porno?etude({stat:'7 jours',p:'sans pornographie n\'ont provoqué aucun symptôme de manque mesurable chez 176 utilisateurs réguliers.',faire:'Une semaine, c\'est atteignable.',src:'Fernandez et al., 2023, Archives of Sexual Behavior'}):'')
      +'<div class="bas" data-a><button class="btn" id="go">Voir qui je peux devenir</button></div>',
    apres:function(e){e.querySelector('#go').onclick=function(){son('tap');afficher(E_miroir)}}};
}

// ====== Miroir ======
function sports(){
  var h=[],a=OB.sportAccess||[];
  if(a.indexOf(0)>=0)h.push('Salle');else if(a.indexOf(1)>=0)h.push('Sport à la maison');
  if(a.indexOf(2)>=0)h.push('course');
  if(a.indexOf(3)>=0)h.push(OB.collectifSport?esc(OB.collectifSport):'sport collectif');
  var s=h.join(', ');return s?s.charAt(0).toUpperCase()+s.slice(1)+'.':'';
}
function E_miroir(){
  var E=[['Jour 1','Ton programme démarre.','Calibré sur tes réponses.'],
         ['Jour 21','Tes premières séries.',sports()||'Ton corps reprend le rythme.'],
         ['Jour 66','Le cap de l\'automatisme.','Ce qui coûtait un effort devient naturel.'],
         ['Jour 180','Une autre version de toi.','Tes habitudes font partie de toi.']];
  return {acte:5,frac:0,retour:true,
    html:'<div class="acte" data-a>'+L5+'</div>'
      +'<div class="badge-phx" id="phm" data-a style="transform:scale(.7)"><img src="'+PHENIX+'" style="filter:grayscale(1) brightness(1.3)"></div>'
      +'<div class="frise" data-a><div class="rail" id="rail"></div>'
      +E.map(function(x,i){return '<div class="etape" id="et'+i+'"><div class="pt"></div><div class="bloc"><div><div class="j">'+x[0].toUpperCase()+'</div><h3>'+x[1]+'</h3><p>'+x[2]+'</p></div></div></div>'}).join('')
      +'</div><div class="src" data-a style="max-width:380px">Jour 66 : Lally et al., 2010.</div>'
      +'<div class="bas" data-a><button class="btn" id="go" style="opacity:0;pointer-events:none;transition:opacity .4s">Je veux devenir cette version</button></div>',
    apres:function(e){
      // Une seule animation continue : le rail descend, chaque etape s allume quand il l atteint,
      // le defilement suit en douceur, sans a-coups ni retours en arriere.
      var ph=e.querySelector('#phm'),img=ph.querySelector('img'),rail=e.querySelector('#rail');
      var et=[0,1,2,3].map(function(k){return e.querySelector('#et'+k)});
      var main=false,vu=-1,DUREE=3800,t0=0;
      ['touchstart','wheel','pointerdown'].forEach(function(ev){e.addEventListener(ev,function(){main=true},{passive:true})});
      function lisse(x){return x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2}
      function boucle(t){
        if(!e.isConnected)return;
        if(!t0)t0=t;var p=Math.min(1,(t-t0)/DUREE);
        var bas=et[3].offsetTop+20;rail.style.height=(bas*p)+'px';
        while(vu<3&&bas*p>=et[vu+1].offsetTop+20-1){vu++;et[vu].classList.add('vue');vibre(8);progressionSous((vu+1)/4)}
        var q=lisse(p);ph.style.transform='scale('+(.7+.42*q)+')';img.style.filter='grayscale('+(1-q).toFixed(3)+') brightness('+(1.3-.3*q).toFixed(3)+')';
        if(!main){var max=e.scrollHeight-e.clientHeight;if(max>0)e.scrollTop=max*lisse(p)}
        if(p<1)requestAnimationFrame(boucle);else fin();
      }
      function fin(){var g=e.querySelector('#go');g.style.opacity=1;g.style.pointerEvents='auto'}
      setTimeout(function(){requestAnimationFrame(boucle)},500);
      e.querySelector('#go').onclick=function(){afficher(E_pourquoi)};
    }};
}

function E_pourquoi(){
  return {acte:6,frac:.2,retour:true,
    html:'<div class="acte" data-a>'+L6+'</div><div class="titre" data-a>Pourquoi veux-tu changer ?</div><div class="sous" data-a>La réponse ne sera visible que par toi. Elle est là pour te permettre de clarifier ton pourquoi, et te sera réaffichée dans les moments difficiles.</div>'
      +'<textarea id="why" data-a placeholder="Avec tes mots...">'+esc(MY_WHY)+'</textarea>'
      +'<div class="bas" data-a><button class="btn" id="go"'+(MY_WHY.trim()||RECONF?'':' disabled')+'>Valider</button><button class="btn-fant" id="skip">Passer</button></div>',
    apres:function(e){
      var t=e.querySelector('#why'),g=e.querySelector('#go');
      t.oninput=function(){MY_WHY=t.value;g.disabled=!RECONF&&!t.value.trim()};
      g.onclick=function(){MY_WHY=t.value.trim();son('tap');if(RECONF)terminer();else afficher(E_calibration)};
      e.querySelector('#skip').onclick=function(){if(!RECONF)MY_WHY='';son('tap');if(RECONF)terminer();else afficher(E_calibration)};
    }};
}

// ====== Calcul du programme : les vraies fonctions de l app (lisent ST._ob) ======
function calcScore(){return _obCalcScore()}
function calcProg(){return _obCalcProg()}

function E_calibration(){
  OB.prog=calcProg();
  var L=['Analyse de ton corps','Analyse de ton esprit','Analyse de tes freins','Calibration de tes quêtes'];
  return {acte:6,frac:.4,centre:true,
    html:'<div class="v1"><div class="radar" data-a><svg viewBox="0 0 200 200">'
      +'<circle cx="100" cy="100" r="90" fill="none" stroke="rgba(255,255,255,.12)"/><circle cx="100" cy="100" r="60" fill="none" stroke="rgba(255,255,255,.12)"/><circle cx="100" cy="100" r="30" fill="none" stroke="rgba(255,255,255,.12)"/>'
      +'<g><path d="M100 100 L100 10 A90 90 0 0 1 178 55 Z" fill="var(--acc2)" opacity=".28"/><line x1="100" y1="100" x2="100" y2="10" stroke="var(--acc2)" stroke-width="2"/><animateTransform attributeName="transform" type="rotate" from="0 100 100" to="360 100 100" dur="1.6s" repeatCount="indefinite"/></g>'
      +'<circle cx="100" cy="100" r="80" fill="none" stroke="var(--acc)" stroke-width="2" stroke-dasharray="6 10"><animateTransform attributeName="transform" type="rotate" from="360 100 100" to="0 100 100" dur="9s" repeatCount="indefinite"/></circle>'
      +'</svg><img src="'+PHENIX+'" style="position:absolute;left:50%;top:50%;width:70px;transform:translate(-50%,-50%);filter:drop-shadow(0 0 14px rgba(255,160,70,.8))"></div>'
      +'<div class="titre-v1" data-a>Le Système analyse tes réponses</div><div style="height:12px"></div>'
      +'<div class="lignes-v1" data-a>'+L.map(function(l,i){return '<div id="lc'+i+'">'+l+'</div>'}).join('')+'</div></div>',
    apres:function(){
      var i=0;(function pas(){var d=R.getElementById('lc'+i);if(!d){setTimeout(function(){afficher(E_programme,{sansPile:true})},450);return}
        d.classList.add('en');setTimeout(function(){d.classList.remove('en');d.classList.add('ok');son('tap');vibre(6);progressionSous(.25*(i+1));i++;pas()},800)})();
    }};
}
function E_programme(){
  PILE=[];
  var desc={'Foundation':'1 quête obligatoire les 3 premiers jours, 2 au 5e, 3 au 7e. Les sanctions débutent au Jour 14.',
    'Standard':'2 quêtes obligatoires les 4 premiers jours, 3 dès le Jour 6. Sanctions actives au Jour 7.',
    'Discipline':'3 non-négociables dès le premier jour. Sanctions actives dès le Jour 5.'};
  return {acte:6,frac:.85,centre:true,
    html:'<div class="v1"><div class="pill-v1" data-a>Le système a tranché</div><div class="sous-v1" data-a style="margin-bottom:0">Tu commences le programme</div>'
      +'<div class="prog-v1">'+OB.prog+'</div>'
      +'<div class="sous-v1" data-a>'+desc[OB.prog]+'</div><div style="height:16px"></div>'
      +'<div class="contrat-v1" data-a><div class="t">Ton engagement</div><q>« Je promets de faire de mon mieux pour réussir les 67 premiers jours, et de ne jamais abandonner sans m\'être battu jusqu\'au bout. »</q><em>En signant, je m\'engage personnellement. Pas pour l\'app - pour moi.</em></div>'
      +'<button class="sceau-v1" id="sceau" data-a><svg viewBox="0 0 132 132"><circle cx="66" cy="66" r="62" fill="none" stroke="rgba(255,255,255,.18)" stroke-width="6"/><circle id="arc" cx="66" cy="66" r="62" fill="none" stroke="var(--acc2)" stroke-width="6" stroke-linecap="round" stroke-dasharray="389.6" stroke-dashoffset="389.6" transform="rotate(-90 66 66)" style="filter:drop-shadow(0 0 6px var(--acc2))"/></svg><div class="coeur"><img src="'+PHENIX+'" alt=""></div></button>'
      +'<div class="aide-v1" id="aide" data-a>Maintiens le sceau pour signer</div></div>',
    apres:function(e){
      vibre(30);eclat();
      var b=e.querySelector('#sceau'),arc=e.querySelector('#arc'),t0=0,raf=0,fait=false,DUREE=1600,dv=0;
      function boucle(t){var p=Math.min(1,(t-t0)/DUREE);arc.style.strokeDashoffset=389.6*(1-p);var q=Math.floor(p*8);if(q!==dv){dv=q;vibre(8)}
        if(p>=1){signer();return}raf=requestAnimationFrame(boucle)}
      function debut(ev){if(fait)return;ev.preventDefault();b.classList.add('tient');t0=performance.now();dv=0;son('tap');raf=requestAnimationFrame(boucle);e.querySelector('#aide').textContent='Tiens bon...'}
      function fin(){if(fait)return;cancelAnimationFrame(raf);b.classList.remove('tient');arc.style.transition='stroke-dashoffset .4s';arc.style.strokeDashoffset=389.6;setTimeout(function(){arc.style.transition=''},400);e.querySelector('#aide').textContent='Maintiens le sceau pour signer'}
      function signer(){fait=true;b.classList.remove('tient');vibre([30,60,80]);
        var f=document.createElement('div');f.className='flash-v1';RAC.appendChild(f);setTimeout(function(){f.remove()},1200);eclat();
        setTimeout(function(){afficher(E_final,{sansPile:true})},700)}
      b.addEventListener('pointerdown',debut);b.addEventListener('pointerup',fin);b.addEventListener('pointerleave',fin);b.addEventListener('pointercancel',fin);
      b.addEventListener('contextmenu',function(ev){ev.preventDefault()});
    }};
}
function E_final(){
  return {acte:6,frac:1,centre:true,
    html:'<div class="v1"><img class="phenix-v1 naissance-v1" src="'+PHENIX+'">'
      +'<div class="marque-v1 apparait" style="animation-delay:.9s">Bienvenue, chasseur</div>'
      +'<div class="filet-v1 apparait" style="animation-delay:1.1s"></div>'
      +'<p class="narr-v1 apparait" style="animation-delay:1.3s">Ton serment est scellé. Ta première quête t\'attend.</p>'
      +'<div style="height:30px"></div>'
      +'<button class="btn-v1 apparait" id="go" style="animation-delay:1.8s">Commencer</button></div>',
    apres:function(e){
      e.querySelector('#go').onclick=function(){var g=e.querySelector('#go');if(g.disabled)return;g.disabled=true;son('tap');terminer()};
    }};
}
function eclat(){var c=document.createElement('div');c.className='eclat-v1';for(var i=0;i<18;i++){var s=document.createElement('i');s.style.setProperty('--r',(i*20)+'deg');s.style.animationDelay=(Math.random()*.1)+'s';c.appendChild(s)}RAC.appendChild(c);setTimeout(function(){c.remove()},1200)}

// ====== Outils ======
function machine(el,txt,v,fin){
  if(!el)return;var i=0;el.classList.add('curseur-ecr');
  (function t(){if(!el.isConnected)return;el.textContent=txt.slice(0,i);
    if(i<txt.length){var c=txt[i];i++;setTimeout(t,c==='\n'?v*8:/[.,:!]/.test(c)?v*5:v)}else{el.classList.remove('curseur-ecr');fin&&fin()}})();
  el.onclick=function(){i=txt.length};
}
// espaces insecables avant ? ! : ; et apres les guillemets ouvrants
function typo(e){var w=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),t;while(t=w.nextNode()){if(t.parentNode.closest('textarea'))continue;var v=t.nodeValue.replace(/ ([?!:;»])/g,' $1').replace(/« /g,'« ');if(v!==t.nodeValue)t.nodeValue=v}}
function fmt(v){return String(Math.round(v*10)/10).replace('.',',')}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}

// ====== Point d entree, appele par buildOB() ======
var HOTE=null;
function terminer(){
  ST._ob=OB;ST.myWhy=MY_WHY;
  ST._ob.prog=_obCalcProg();
  // _obFinish fait TOUT le travail reel (score, mode, ST.answers, genWeek,
  // navigation, tutoriel) : on ne le reecrit pas, on l appelle.
  var h=HOTE;
  _obFinish();
  // On retire le questionnaire seulement quand l app a quitte l ecran s-ob
  var t0=Date.now();
  (function guetter(){
    var ob=document.getElementById('s-ob');
    if(!h||!h.isConnected)return;
    if(!ob||!ob.classList.contains('active')||Date.now()-t0>15000){h.remove();if(HOTE===h)HOTE=null;return}
    setTimeout(guetter,250);
  })();
}
function annuler(){ // reconfiguration : retour aux Parametres sans rien changer
  var h=HOTE;HOTE=null;if(h)h.remove();
  cancelReconfig();
}
function demarrer(){
  var ob=document.getElementById('s-ob');if(!ob)return false;
  if(HOTE&&HOTE.isConnected)HOTE.remove();
  if(!ST._ob)ST._ob={};
  // On travaille sur une COPIE : en reconfiguration, « Annuler » laisse ST._ob intact
  try{OB=JSON.parse(JSON.stringify(ST._ob))}catch(e){OB={}}
  MY_WHY=ST.myWhy||'';RECONF=!!ST._obReconfig;
  PILE=[];ECRAN_FN=null;EN_TRANSITION=false;ACTE_COUR=null;ETAPE_COUR=null;
  HOTE=document.createElement('div');HOTE.id='nob-hote';
  HOTE.style.cssText='position:fixed;inset:0;z-index:200';
  R=HOTE.attachShadow({mode:'open'});
  R.innerHTML='<style>'+CSS+'</style>'
    +'<div id="racine">'
    +'<div id="facettes">'
    +'<svg class="hd" viewBox="0 0 230 230"><polygon class="f1" points="60,0 230,0 230,150"/><polygon class="f3" points="60,0 230,150 150,90"/><polygon class="f2" points="150,90 230,150 230,230"/><polygon class="f4" points="110,0 160,0 140,40"/></svg>'
    +'<svg class="bg" viewBox="0 0 250 250"><polygon class="f1" points="0,60 0,250 190,250"/><polygon class="f3" points="0,60 90,170 190,250"/><polygon class="f2" points="0,120 0,250 70,250"/><polygon class="f4" points="120,250 190,250 160,210"/></svg>'
    +'</div>'
    +'<div id="app"><div id="haut" class="cache">'
    +'<button id="retour" class="off" aria-label="Retour"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg></button>'
    +'<div id="actes"></div>'
    +(RECONF?'<button id="annuler" class="annuler">Annuler</button>':'')
    +'</div><div id="scene"></div></div></div>';
  RAC=R.getElementById('racine');
  R.getElementById('retour').onclick=retour;
  if(RECONF){R.getElementById('annuler').onclick=annuler;R.getElementById('haut').classList.add('toujours')}
  ob.appendChild(HOTE);
  afficher(RECONF?E_age:E_ouverture);
  return true;
}
window.NOB={demarrer:demarrer};
})();
