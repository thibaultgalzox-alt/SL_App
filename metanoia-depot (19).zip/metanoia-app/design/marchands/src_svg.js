    // 1 - ALIENOR L ALCHIMISTE : meme facture qu Enguerrand. Coiffe de lin,
    // tresse auburn, robe sarcelle, tablier tache, hotte d osier (herbes,
    // pot), fiole verte levee qui bouillonne et fume (SMIL)
    '<svg viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">'
    +'<defs><radialGradient id="al-glow"><stop offset="0%" stop-color="#5ee6c4" stop-opacity=".45"/><stop offset="100%" stop-color="#5ee6c4" stop-opacity="0"/></radialGradient>'
    +'<linearGradient id="al-robe" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#1f4c57"/><stop offset="1" stop-color="#357580"/></linearGradient>'
    +'<linearGradient id="al-osier" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#8a6435"/><stop offset="1" stop-color="#b88a50"/></linearGradient>'
    +'<radialGradient id="al-liq" cx=".4" cy=".35"><stop offset="0%" stop-color="#d8fff4"/><stop offset=".5" stop-color="#5ee6c4"/><stop offset="1" stop-color="#1f9c80"/></radialGradient></defs>'
    +'<circle cx="100" cy="140" r="95" fill="url(#al-glow)"/>'
    +'<ellipse cx="98" cy="233" rx="48" ry="5" fill="rgba(0,0,0,.28)"/>'
    // hotte d osier, herbes qui depassent, pot de terre accroche
    +'<path d="M 72 60 Q 68 50 74 44 M 76 62 Q 76 48 82 42 M 118 62 Q 120 50 116 42 M 122 60 Q 128 50 126 44" stroke="#4f8a3a" stroke-width="2.2" fill="none" stroke-linecap="round"/>'
    +'<circle cx="74" cy="43" r="3" fill="#9b7ad8"/><circle cx="82" cy="41" r="2.6" fill="#b394e8"/><circle cx="116" cy="41" r="2.8" fill="#f2c94e"/><circle cx="126" cy="43" r="3" fill="#9b7ad8"/>'
    +'<rect x="66" y="62" width="62" height="98" rx="10" fill="url(#al-osier)"/>'
    +'<path d="M 68 74 L 126 74 M 68 86 L 126 86 M 68 98 L 126 98 M 68 110 L 126 110 M 68 122 L 126 122 M 68 134 L 126 134 M 68 146 L 126 146" stroke="#6e4c26" stroke-width="1.2" opacity=".6"/>'
    +'<rect x="64" y="60" width="66" height="7" rx="3.5" fill="#6e4c26"/>'
    +'<line x1="64" y1="104" x2="56" y2="116" stroke="#4a3020" stroke-width="1.6"/><path d="M 48 116 L 64 116 L 62 136 Q 56 141 50 136 Z" fill="#b5633b"/><rect x="47" y="114" width="18" height="4" rx="2" fill="#8f4a2b"/>'
    // robe longue
    +'<path d="M 80 100 Q 82 92 96 92 Q 110 92 113 100 L 122 222 L 70 222 Z" fill="url(#al-robe)"/>'
    +'<path d="M 74 222 L 80 168 M 118 222 L 112 168" stroke="#163a43" stroke-width="1.6" opacity=".7"/>'
    +'<path d="M 78 224 Q 78 218 86 218 L 94 218 L 94 230 L 78 230 Z" fill="#3a281c"/><path d="M 100 218 L 108 218 Q 116 218 116 224 L 116 230 L 100 230 Z" fill="#3a281c"/>'
    // bras gauche (cote image) : main sur une bourse
    +'<path d="M 82 100 Q 74 118 75 134" stroke="#2a5c66" stroke-width="11" stroke-linecap="round" fill="none"/>'
    +'<path d="M 75 132 Q 76 146 82 152" stroke="#e2b08a" stroke-width="8" stroke-linecap="round" fill="none"/>'
    // tablier de lin tache, ceinture de fioles
    +'<path d="M 86 108 L 106 108 L 112 206 L 80 206 Z" fill="#e7dcc4"/>'
    +'<circle cx="93" cy="170" r="4" fill="#5ee6c4" opacity=".35"/><circle cx="102" cy="186" r="3" fill="#9b7ad8" opacity=".35"/><circle cx="99" cy="150" r="2.4" fill="#c98a3a" opacity=".4"/>'
    +'<path d="M 84 100 L 86 140 M 109 100 L 107 140" stroke="#4a3020" stroke-width="4" stroke-linecap="round"/>'
    +'<rect x="80" y="138" width="34" height="5.5" fill="#5a3a22"/>'
    +'<rect x="86" y="143" width="5" height="10" rx="1.5" fill="#9b7ad8"/><rect x="94" y="143" width="5" height="10" rx="1.5" fill="#f2c94e"/><rect x="102" y="143" width="5" height="10" rx="1.5" fill="#5ee6c4"/>'
    +'<path d="M 78 148 L 90 148 L 89 162 Q 84 166 79 162 Z" fill="#7a4d2b"/><circle cx="82" cy="152" r="5" fill="#e2b08a"/>'
    // tresse auburn sur l epaule
    +'<path d="M 86 66 Q 80 84 84 104" stroke="#8a3e1e" stroke-width="7" stroke-linecap="round" fill="none"/>'
    +'<path d="M 82 74 L 88 78 M 81 84 L 87 88 M 82 94 L 88 97" stroke="#6a2c14" stroke-width="1.4"/><circle cx="84" cy="106" r="3" fill="#e7dcc4"/>'
    // cou et tete : coiffe de lin, visage
    +'<rect x="91" y="72" width="10" height="20" fill="#d39a78"/>'
    +'<ellipse cx="96" cy="58" rx="13" ry="15" fill="#e8b892"/>'
    +'<path d="M 83 50 Q 86 44 96 44 Q 106 44 109 50 Q 104 47 96 48 Q 88 47 83 50 Z" fill="#8a3e1e"/>'
    +'<path d="M 80 58 Q 78 36 96 34 Q 114 36 112 58 Q 112 48 106 45 Q 96 41 86 45 Q 80 48 80 58 Z" fill="#f2ece0"/>'
    +'<path d="M 80 56 Q 79 70 84 76 M 112 56 Q 113 70 108 76" stroke="#f2ece0" stroke-width="3.5" fill="none" stroke-linecap="round"/>'
    +'<path d="M 82 40 Q 96 33 110 40" stroke="#d9cfbc" stroke-width="1.2" fill="none"/>'
    +'<path d="M 87 52.5 Q 90 51 93 52.5 M 99 52.5 Q 102 51 105 52.5" stroke="#6a2c14" stroke-width="1.4" fill="none" stroke-linecap="round"/>'
    +'<ellipse cx="90" cy="57" rx="1.6" ry="1.9" fill="#2b1d14"/><ellipse cx="102" cy="57" rx="1.6" ry="1.9" fill="#2b1d14"/>'
    +'<circle cx="87" cy="63" r="2.6" fill="#e8907a" opacity=".35"/><circle cx="105" cy="63" r="2.6" fill="#e8907a" opacity=".35"/>'
    +'<path d="M 96 57 L 95 62.5 L 97.5 63" stroke="#c08a68" stroke-width="1.2" fill="none" stroke-linecap="round"/>'
    +'<path d="M 92.5 67.5 Q 96 69.5 99.5 67.5" stroke="#b5574e" stroke-width="1.6" fill="none" stroke-linecap="round"/>'
    // bras droit leve, fiole qui bouillonne ; leger balancement
    +'<g><animateTransform attributeName="transform" type="rotate" values="-3 112 100;4 112 100;-3 112 100" dur="4s" repeatCount="indefinite" calcMode="spline" keySplines=".45 0 .55 1;.45 0 .55 1"/>'
    +'<path d="M 112 100 Q 126 92 130 76" stroke="#2a5c66" stroke-width="11" stroke-linecap="round" fill="none"/>'
    +'<path d="M 130 78 Q 132 66 133 58" stroke="#e8b892" stroke-width="8" stroke-linecap="round" fill="none"/>'
    +'<circle cx="133" cy="44" r="20" fill="#5ee6c4" opacity=".25"><animate attributeName="opacity" values=".15;.4;.15" dur="2.6s" repeatCount="indefinite"/></circle>'
    +'<rect x="129" y="20" width="8" height="12" rx="1.5" fill="#cfeee6" opacity=".9"/><rect x="128" y="18" width="10" height="4" rx="1.5" fill="#b5633b"/>'
    +'<circle cx="133" cy="42" r="12" fill="url(#al-liq)" stroke="#e6fff9" stroke-width="1.3"/>'
    +'<path d="M 125 38 Q 127 33 131 32" stroke="#ffffff" stroke-width="1.6" fill="none" opacity=".75" stroke-linecap="round"/>'
    +'<circle cx="130" cy="48" r="1.6" fill="#e6fff9"><animate attributeName="cy" values="50;36" dur="1.3s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;0" dur="1.3s" repeatCount="indefinite"/></circle>'
    +'<circle cx="136" cy="48" r="1.2" fill="#e6fff9"><animate attributeName="cy" values="50;35" dur="1.7s" begin=".5s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;0" dur="1.7s" begin=".5s" repeatCount="indefinite"/></circle>'
    +'<circle cx="133" cy="46" r="1" fill="#e6fff9"><animate attributeName="cy" values="50;37" dur="1.1s" begin=".2s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;0" dur="1.1s" begin=".2s" repeatCount="indefinite"/></circle>'
    +'<circle cx="133" cy="54" r="5.5" fill="#e8b892"/>'
    +'<circle cx="133" cy="16" r="3" fill="#b8fff0"><animate attributeName="cy" values="17;-4" dur="3s" repeatCount="indefinite"/><animate attributeName="r" values="2.4;6" dur="3s" repeatCount="indefinite"/><animate attributeName="opacity" values=".8;0" dur="3s" repeatCount="indefinite"/></circle>'
    +'<circle cx="136" cy="16" r="2.4" fill="#f2c94e"><animate attributeName="cy" values="17;-4" dur="3.6s" begin="1.2s" repeatCount="indefinite"/><animate attributeName="r" values="2;5" dur="3.6s" begin="1.2s" repeatCount="indefinite"/><animate attributeName="opacity" values=".7;0" dur="3.6s" begin="1.2s" repeatCount="indefinite"/></circle>'
    +'<circle cx="130" cy="16" r="2.4" fill="#c4a8ff"><animate attributeName="cy" values="17;-4" dur="3.3s" begin="2.1s" repeatCount="indefinite"/><animate attributeName="r" values="2;5.5" dur="3.3s" begin="2.1s" repeatCount="indefinite"/><animate attributeName="opacity" values=".7;0" dur="3.3s" begin="2.1s" repeatCount="indefinite"/></circle>'
    +'</g>'
    +'</svg>',
@@@
    // 3 - MELISENDE L ASTROLOGUE : meme facture qu Enguerrand. Cheveux sombres
    // et diademe a etoile, robe bleu nuit semee d etoiles d argent, cape,
    // astrolabe a la ceinture (son reseau tourne). Elle observe le ciel dans
    // une grande lunette de laiton sur trepied, pointee vers le haut (SMIL :
    // etoiles de la robe qui scintillent, lentille qui luit, mise au point).
    '<svg viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">'
    +'<defs><radialGradient id="vy-glow"><stop offset="0%" stop-color="#a29bfe" stop-opacity=".45"/><stop offset="100%" stop-color="#a29bfe" stop-opacity="0"/></radialGradient>'
    +'<linearGradient id="vy-robe" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#151c44"/><stop offset="1" stop-color="#2c3a78"/></linearGradient>'
    +'<linearGradient id="vy-laiton" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f2d27a"/><stop offset=".5" stop-color="#c8963a"/><stop offset="1" stop-color="#7a5418"/></linearGradient></defs>'
    +'<circle cx="100" cy="150" r="92" fill="url(#vy-glow)"/>'
    +'<ellipse cx="108" cy="233" rx="62" ry="5" fill="rgba(0,0,0,.3)"/>'
    // trepied de bois de la lunette
    +'<path d="M 154 24 L 132 232 M 154 24 L 176 232 M 154 24 L 160 232" stroke="#5a3a22" stroke-width="3.2" stroke-linecap="round"/>'
    +'<path d="M 140 150 L 170 150" stroke="#4a2e1a" stroke-width="2"/>'
    // cape
    +'<path d="M 76 98 Q 66 150 62 226 L 132 226 Q 128 150 118 98 Z" fill="#2a1f4e"/>'
    // robe bleu nuit semee d etoiles
    +'<path d="M 80 98 Q 82 90 97 90 Q 112 90 115 98 L 124 224 L 70 224 Z" fill="url(#vy-robe)"/>'
    +'<g fill="#e8ecff"><circle cx="86" cy="150" r="1.3"><animate attributeName="opacity" values=".3;1;.3" dur="2.2s" repeatCount="indefinite"/></circle><circle cx="104" cy="172" r="1.5"><animate attributeName="opacity" values="1;.3;1" dur="2.8s" repeatCount="indefinite"/></circle><circle cx="92" cy="196" r="1.2"><animate attributeName="opacity" values=".3;1;.3" dur="1.9s" repeatCount="indefinite"/></circle><circle cx="112" cy="206" r="1.3"><animate attributeName="opacity" values="1;.4;1" dur="2.5s" repeatCount="indefinite"/></circle><circle cx="80" cy="212" r="1.1"><animate attributeName="opacity" values=".4;1;.4" dur="3.1s" repeatCount="indefinite"/></circle><circle cx="98" cy="128" r="1.1"><animate attributeName="opacity" values=".4;1;.4" dur="2.4s" repeatCount="indefinite"/></circle></g>'
    +'<path d="M 108 184 l 1.5 3.5 3.5 1.5 -3.5 1.5 -1.5 3.5 -1.5 -3.5 -3.5 -1.5 3.5 -1.5 Z" fill="#cfd6ff"/>'
    +'<path d="M 74 226 Q 74 220 82 220 L 92 220 L 92 230 L 74 230 Z" fill="#1e1830"/><path d="M 100 220 L 110 220 Q 118 220 118 226 L 118 230 L 100 230 Z" fill="#1e1830"/>'
    // ceinture d argent et astrolabe dont le reseau tourne
    +'<rect x="80" y="140" width="36" height="5" fill="#b8c0d8"/>'
    +'<line x1="84" y1="145" x2="84" y2="152" stroke="#b8c0d8" stroke-width="1.4"/><circle cx="84" cy="162" r="10" fill="#c8963a"/><circle cx="84" cy="162" r="7.5" fill="#2a1f4e"/>'
    +'<g><animateTransform attributeName="transform" type="rotate" values="0 84 162;360 84 162" dur="14s" repeatCount="indefinite"/><circle cx="84" cy="162" r="5.5" fill="none" stroke="#f2d27a" stroke-width="1"/><path d="M 78 162 L 90 162 M 84 156 L 84 168" stroke="#f2d27a" stroke-width=".9"/><circle cx="87" cy="158" r="1.2" fill="#f2d27a"/></g>'
    // bras gauche (cote image) : vient regler l oculaire
    +'<path d="M 80 100 Q 74 120 86 124 Q 102 116 110 66" stroke="#22306a" stroke-width="10" stroke-linecap="round" fill="none"/>'
    // cou et tete, penchee vers l oculaire
    +'<g transform="rotate(8 98 64)">'
    +'<path d="M 82 52 Q 80 80 86 102 L 112 102 Q 116 78 112 52 Z" fill="#3a2418"/>'
    +'<rect x="92" y="70" width="11" height="20" fill="#d39a78"/>'
    +'<ellipse cx="97" cy="56" rx="13" ry="15" fill="#e8b892"/>'
    +'<path d="M 83 56 Q 82 38 97 37 Q 112 38 111 56 Q 107 45 97 45 Q 87 45 83 56 Z" fill="#3a2418"/>'
    +'<path d="M 84 47 Q 97 41 110 47" stroke="#cfd6ff" stroke-width="1.5" fill="none"/><path d="M 97 40 l 1.4 2.6 2.8 .4 -2 2 .5 2.8 -2.7 -1.3 -2.7 1.3 .5 -2.8 -2 -2 2.8 -.4 Z" fill="#f2f4ff"><animate attributeName="opacity" values=".7;1;.7" dur="2s" repeatCount="indefinite"/></path>'
    +'<path d="M 87 51 Q 90 49.5 93 51 M 100 51 Q 103 49.5 106 51" stroke="#3a2418" stroke-width="1.4" fill="none" stroke-linecap="round"/>'
    +'<path d="M 88 56 Q 91 58 94 56" stroke="#2b1d14" stroke-width="1.6" fill="none" stroke-linecap="round"/><ellipse cx="103" cy="55.5" rx="1.6" ry="1.9" fill="#2b1d14"/>'
    +'<circle cx="88" cy="62" r="2.4" fill="#e8907a" opacity=".3"/>'
    +'<path d="M 97 56 L 96 61.5 L 98.5 62" stroke="#c08a68" stroke-width="1.2" fill="none" stroke-linecap="round"/>'
    +'<path d="M 93.5 66.5 Q 97 68.5 100.5 66.5" stroke="#b5574e" stroke-width="1.5" fill="none" stroke-linecap="round"/>'
    +'</g>'
    // la lunette de laiton, pointee vers le ciel
    +'<g transform="translate(2 -18) rotate(-38 152 40)">'
    +'<rect x="96" y="35" width="88" height="10" rx="2" fill="url(#vy-laiton)"/>'
    +'<rect x="104" y="36.5" width="10" height="7" rx="1.5" fill="#7a5418"/>'
    +'<rect x="88" y="37" width="12" height="6" rx="1.5" fill="url(#vy-laiton)"><animate attributeName="x" values="88;91;88" dur="5s" repeatCount="indefinite"/></rect>'
    +'<rect x="128" y="33.5" width="3" height="13" fill="#8a5c1e"/><rect x="160" y="33.5" width="3" height="13" fill="#8a5c1e"/><rect x="178" y="32" width="6" height="16" rx="1.5" fill="#8a5c1e"/>'
    +'<circle cx="152" cy="40" r="4" fill="#4a2e1a"/>'
    +'<rect x="183" y="34" width="2" height="12" fill="#cfe4ff"><animate attributeName="opacity" values=".4;1;.4" dur="3s" repeatCount="indefinite"/></rect>'
    +'</g>'
    // main sur l oculaire, bras droit qui tient le tube
    +'<circle cx="110" cy="64" r="5" fill="#e0a882"/>'
    +'<path d="M 114 100 Q 128 78 134 42" stroke="#22306a" stroke-width="10" stroke-linecap="round" fill="none"/>'
    +'<circle cx="134" cy="40" r="5.2" fill="#e0a882"/>'
    +'</svg>',
@@@
    // 0 - ENGUERRAND LE FORGERON : forgeron itinerant, visage nu et barbe,
    // tablier de cuir, sac a dos (paquetage, poele, tenailles), marteau qui
    // frappe l enclume posee sur sa souche (SMIL, tourne meme en mouvement reduit)
    '<svg viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">'
    +'<defs><radialGradient id="fg-glow"><stop offset="0%" stop-color="#ffb35a" stop-opacity=".5"/><stop offset="100%" stop-color="#ffb35a" stop-opacity="0"/></radialGradient>'
    +'<linearGradient id="fg-acier" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#c9d2da"/><stop offset=".25" stop-color="#7d8892"/><stop offset="1" stop-color="#3f4850"/></linearGradient>'
    +'<linearGradient id="fg-tunique" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#2f5446"/><stop offset="1" stop-color="#4a7a64"/></linearGradient>'
    +'<linearGradient id="fg-cuir" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#6a3f22"/><stop offset="1" stop-color="#96603a"/></linearGradient></defs>'
    +'<circle cx="100" cy="170" r="90" fill="url(#fg-glow)"/>'
    +'<ellipse cx="112" cy="233" rx="66" ry="5" fill="rgba(0,0,0,.28)"/>'
    // sac a dos : paquetage roule en haut, cadre, poele et tenailles accrochees
    +'<rect x="64" y="80" width="64" height="92" rx="8" fill="#7a4d2b"/>'
    +'<rect x="64" y="80" width="64" height="22" rx="8" fill="#5f3b20"/>'
    +'<line x1="66" y1="58" x2="66" y2="84" stroke="#4a3020" stroke-width="3" stroke-linecap="round"/><line x1="126" y1="58" x2="126" y2="84" stroke="#4a3020" stroke-width="3" stroke-linecap="round"/>'
    +'<rect x="58" y="62" width="76" height="19" rx="9.5" fill="#a8402e"/><rect x="58" y="62" width="76" height="6" rx="3" fill="#c55a44"/>'
    +'<rect x="72" y="61" width="5" height="21" fill="#4a3020"/><rect x="115" y="61" width="5" height="21" fill="#4a3020"/>'
    +'<line x1="62" y1="104" x2="54" y2="122" stroke="#2c2c30" stroke-width="3" stroke-linecap="round"/><circle cx="50" cy="132" r="11" fill="#34343a"/><circle cx="50" cy="132" r="7.5" fill="#4a4a52"/>'
    +'<path d="M 131 100 L 140 138 M 128 101 L 134 139" stroke="#3a3a40" stroke-width="2.4" stroke-linecap="round" fill="none"/>'
    // jambes et bottes
    +'<rect x="83" y="186" width="13" height="34" rx="3" fill="#4b3a2c"/><rect x="99" y="186" width="13" height="34" rx="3" fill="#43342a"/>'
    +'<path d="M 79 232 L 79 218 Q 79 214 84 214 L 96 214 L 97 232 Z" fill="#2e2118"/><path d="M 98 232 L 99 214 L 111 214 Q 116 214 116 220 L 117 232 Z" fill="#2e2118"/>'
    // tunique
    +'<path d="M 76 102 Q 78 92 96 92 Q 114 92 118 102 L 115 192 L 79 192 Z" fill="url(#fg-tunique)"/>'
    // bras gauche (cote image) : main sur la bretelle
    +'<path d="M 79 100 Q 70 118 71 132" stroke="#3a6453" stroke-width="12" stroke-linecap="round" fill="none"/>'
    +'<path d="M 71 130 Q 72 144 80 150" stroke="#d39a72" stroke-width="9" stroke-linecap="round" fill="none"/><circle cx="81" cy="150" r="5.5" fill="#d39a72"/>'
    // tablier de cuir, bretelles du sac, ceinture et bourse
    +'<path d="M 86 104 L 106 104 L 110 198 L 82 198 Z" fill="url(#fg-cuir)"/>'
    +'<path d="M 86 104 L 106 104" stroke="#4a2c16" stroke-width="2"/><circle cx="96" cy="150" r="2" fill="#4a2c16" opacity=".6"/>'
    +'<path d="M 81 96 L 84 140" stroke="#4a3020" stroke-width="4.5" stroke-linecap="round"/><path d="M 111 96 L 108 140" stroke="#4a3020" stroke-width="4.5" stroke-linecap="round"/>'
    +'<rect x="78" y="140" width="38" height="6" fill="#2e1f14"/><rect x="93" y="139" width="8" height="8" rx="1.5" fill="none" stroke="#d4a64a" stroke-width="1.6"/>'
    +'<path d="M 108 146 L 118 146 L 117 158 Q 113 162 109 158 Z" fill="#8a5a32"/>'
    // cou et tete : visage nu, cheveux courts, barbe fournie
    +'<rect x="90" y="72" width="12" height="22" fill="#c48a63"/>'
    +'<circle cx="81.5" cy="58" r="3.5" fill="#c48a63"/><circle cx="110.5" cy="58" r="3.5" fill="#c48a63"/>'
    +'<ellipse cx="96" cy="57" rx="14" ry="16" fill="#d9a27a"/>'
    +'<path d="M 82 54 Q 81 38 96 38 Q 111 38 110 54 Q 106 45 96 46 Q 86 45 82 54 Z" fill="#4a3324"/>'
    +'<path d="M 82 58 Q 82 75 89 82 Q 96 88 103 82 Q 110 75 110 58 Q 106 66 104 68 Q 96 63 88 68 Q 86 66 82 58 Z" fill="#6d4c33"/>'
    +'<path d="M 89 69 Q 96 64 103 69 Q 96 67 89 69 Z" fill="#5a3d28"/>'
    +'<path d="M 86 51.5 L 92.5 50.5 M 99.5 50.5 L 106 51.5" stroke="#3a2618" stroke-width="1.8" stroke-linecap="round"/>'
    +'<circle cx="90" cy="55.5" r="1.7" fill="#2b1d14"/><circle cx="102" cy="55.5" r="1.7" fill="#2b1d14"/>'
    +'<path d="M 96 56 L 94.5 62 L 97.5 62.5" stroke="#b07c58" stroke-width="1.3" fill="none" stroke-linecap="round"/>'
    // enclume sur sa souche, bien en vue
    +'<path d="M 132 206 L 166 206 L 168 232 L 130 232 Z" fill="#8a5a32"/><ellipse cx="149" cy="206" rx="19" ry="4" fill="#b07a48"/><ellipse cx="149" cy="206" rx="10" ry="2" fill="none" stroke="#8a5a32" stroke-width="1"/>'
    +'<path d="M 136 205 L 162 205 L 158 196 L 156 189 L 142 189 L 140 196 Z" fill="#3f4850"/>'
    +'<path d="M 124 176 L 170 176 Q 186 177 196 181 Q 184 186 170 187 L 166 189 L 128 189 Q 124 184 124 176 Z" fill="url(#fg-acier)"/>'
    +'<path d="M 125 176.5 L 170 176.5 Q 184 177.5 194 180.5" stroke="#eef3f7" stroke-width="1.2" fill="none" opacity=".8"/>'
    // gerbe d etincelles a l impact
    +'<g opacity="0"><animate attributeName="opacity" values="0;0;1;0;0" keyTimes="0;.66;.69;.86;1" dur="2.4s" repeatCount="indefinite"/>'
    +'<circle cx="150" cy="175" r="9" fill="#ffd27a" opacity=".55"/>'
    +'<path d="M 150 174 L 140 160 M 150 174 L 147 156 M 150 174 L 157 157 M 150 174 L 165 163 M 150 174 L 133 168 M 150 174 L 168 172" stroke="#ffb02e" stroke-width="2" stroke-linecap="round"/>'
    +'<circle cx="138" cy="157" r="1.6" fill="#ffe08a"/><circle cx="160" cy="154" r="1.6" fill="#ffe08a"/><circle cx="170" cy="166" r="1.4" fill="#ffe08a"/></g>'
    // bras droit et marteau : leve, puis frappe l enclume
    +'<g transform="rotate(0 116 99)"><animateTransform attributeName="transform" type="rotate" values="-48 116 99;-48 116 99;0 116 99;0 116 99;-48 116 99" keyTimes="0;.5;.67;.74;1" calcMode="spline" keySplines=".4 0 .6 1;.7 0 1 1;0 0 1 1;.3 0 .4 1" dur="2.4s" repeatCount="indefinite"/>'
    +'<path d="M 116 99 Q 126 112 128 127" stroke="#3a6453" stroke-width="12" stroke-linecap="round" fill="none"/>'
    +'<path d="M 128 125 Q 132 142 134 155" stroke="#d39a72" stroke-width="9" stroke-linecap="round" fill="none"/>'
    +'<line x1="131" y1="154" x2="153" y2="168" stroke="#7a5030" stroke-width="3.6" stroke-linecap="round"/>'
    +'<g transform="rotate(-58 151 167)"><rect x="140" y="160.5" width="22" height="13" rx="2" fill="url(#fg-acier)"/><rect x="140" y="160.5" width="22" height="3" rx="1.5" fill="#dfe6ec" opacity=".7"/></g>'
    +'<circle cx="134" cy="155" r="6" fill="#d39a72"/></g>'
    +'</svg>',
@@@
    // 4 - GAUCHER LE MERCENAIRE : meme facture qu Enguerrand et Alienor.
    // Bassinet a nasal, coiffe de mailles, visage marque d une cicatrice,
    // cotte de mailles, surcot dechire, bouclier perce de fleches sur le dos,
    // mains sur le pommeau de l epee plantee. Un corbeau arrive et se pose
    // sur son heaume, y reste, puis repart (SMIL, cycle de 16 s).
    '<svg viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%;overflow:visible">'
    +'<defs><radialGradient id="mc-glow"><stop offset="0%" stop-color="#ff9a6a" stop-opacity=".45"/><stop offset="100%" stop-color="#ff9a6a" stop-opacity="0"/></radialGradient>'
    +'<linearGradient id="mc-acier" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#5c656e"/><stop offset=".6" stop-color="#a9b3bd"/><stop offset="1" stop-color="#d8e0e6"/></linearGradient>'
    +'<pattern id="mc-maille" width="4" height="4" patternUnits="userSpaceOnUse"><rect width="4" height="4" fill="#7d868e"/><circle cx="2" cy="2" r="1.2" fill="none" stroke="#4e565d" stroke-width=".7"/></pattern></defs>'
    +'<circle cx="100" cy="170" r="90" fill="url(#mc-glow)"/>'
    +'<ellipse cx="100" cy="233" rx="54" ry="5" fill="rgba(0,0,0,.3)"/>'
    // bouclier sur le dos, fleches brisees plantees
    +'<path d="M 54 80 L 104 80 L 104 120 Q 104 150 79 162 Q 54 150 54 120 Z" fill="#2a4a8a" stroke="#1a2c52" stroke-width="3"/>'
    +'<path d="M 79 84 L 79 156 M 58 110 L 100 110" stroke="#c09a3a" stroke-width="5" opacity=".85"/>'
    +'<path d="M 62 92 L 48 76 M 70 132 L 54 122 M 92 98 L 84 80" stroke="#3a2416" stroke-width="2" stroke-linecap="round"/>'
    +'<path d="M 48 76 L 44 74 L 47 79 Z M 54 122 L 49 121 L 53 125 Z M 84 80 L 81 77 L 82 82 Z" fill="#e8e0cc"/>'
    // jambes : chausses de mailles, bottes
    +'<rect x="83" y="184" width="13" height="36" rx="3" fill="url(#mc-maille)"/><rect x="100" y="184" width="13" height="36" rx="3" fill="url(#mc-maille)"/>'
    +'<path d="M 79 232 L 80 216 L 96 216 L 97 232 Z" fill="#2e2118"/><path d="M 99 232 L 100 216 L 114 216 Q 118 218 118 232 Z" fill="#2e2118"/>'
    // cotte de mailles et surcot dechire aux couleurs passees
    +'<path d="M 76 102 Q 78 92 98 92 Q 118 92 120 102 L 118 190 L 78 190 Z" fill="url(#mc-maille)"/>'
    +'<path d="M 82 100 L 114 100 L 118 196 L 110 188 L 104 198 L 97 189 L 90 199 L 85 189 L 78 196 Z" fill="#cfc3a8"/>'
    +'<path d="M 98 104 L 98 176 M 86 128 L 110 128" stroke="#9a2a2a" stroke-width="6" opacity=".55"/>'
    +'<path d="M 88 150 Q 94 156 92 166 M 108 140 Q 104 148 108 156" stroke="#8a7a5c" stroke-width="1.2" fill="none" opacity=".7"/>'
    +'<rect x="79" y="140" width="38" height="5.5" fill="#3a2416"/><rect x="95" y="139" width="7" height="7.5" rx="1.2" fill="none" stroke="#b5a070" stroke-width="1.5"/>'
    // bras gauche (cote image) : maille, bandage, main sur le pommeau
    +'<path d="M 80 100 Q 72 118 76 134" stroke="url(#mc-maille)" stroke-width="12" stroke-linecap="round" fill="none"/>'
    +'<path d="M 76 132 Q 82 144 94 146" stroke="#c48a63" stroke-width="8.5" stroke-linecap="round" fill="none"/>'
    +'<path d="M 74 124 L 80 129 M 75 128 L 81 133" stroke="#e8e0cc" stroke-width="2.6" stroke-linecap="round"/>'
    // epee plantee devant lui
    +'<rect x="125.5" y="150" width="5" height="82" fill="url(#mc-acier)"/><path d="M 125.5 232 L 128 236 L 130.5 232 Z" fill="#a9b3bd"/>'
    +'<rect x="116" y="144" width="24" height="5" rx="2" fill="#6a5030"/><rect x="125" y="128" width="6" height="17" rx="2" fill="#4a3020"/><circle cx="128" cy="127" r="4.5" fill="#b5a070"/>'
    // bras droit : main sur la garde
    +'<path d="M 116 100 Q 126 114 126 128" stroke="url(#mc-maille)" stroke-width="12" stroke-linecap="round" fill="none"/>'
    +'<circle cx="127" cy="133" r="6" fill="#c48a63"/><circle cx="96" cy="146" r="5.5" fill="#c48a63"/>'
    // cou en coiffe de mailles, visage
    +'<path d="M 82 60 Q 82 84 88 92 L 108 92 Q 114 84 114 60 Z" fill="url(#mc-maille)"/>'
    +'<ellipse cx="98" cy="64" rx="11.5" ry="13" fill="#d39a72"/>'
    +'<path d="M 89 71 Q 98 80 107 71 Q 106 76 98 78 Q 90 76 89 71 Z" fill="#6a4a36" opacity=".55"/>'
    +'<path d="M 90 59.5 L 95 60.5 M 101 60.5 L 106 59.5" stroke="#3a2618" stroke-width="1.9" stroke-linecap="round"/>'
    +'<circle cx="93" cy="63.5" r="1.6" fill="#2b1d14"/><circle cx="103" cy="63.5" r="1.6" fill="#2b1d14"/>'
    +'<path d="M 103.5 66 L 108 74" stroke="#a5523f" stroke-width="1.4" stroke-linecap="round"/>'
    +'<path d="M 94.5 72.5 Q 98 71.5 101.5 72.5" stroke="#7a4030" stroke-width="1.5" fill="none" stroke-linecap="round"/>'
    // bassinet a nasal
    +'<path d="M 84 58 Q 84 34 98 30 Q 112 34 112 58 L 106 56 Q 98 52 90 56 Z" fill="url(#mc-acier)"/>'
    +'<rect x="96.5" y="52" width="3" height="16" rx="1.2" fill="#8d969e"/>'
    +'<path d="M 84 58 Q 98 50 112 58" stroke="#4e565d" stroke-width="1.6" fill="none"/>'
    +'<path d="M 90 40 Q 94 34 99 33" stroke="#eef3f7" stroke-width="1.6" fill="none" opacity=".75" stroke-linecap="round"/>'
    // le corbeau : arrive du haut a droite, se pose sur le sommet du heaume, reste, repart
    +'<g opacity="0"><animate attributeName="opacity" values="0;0;1;1;0" keyTimes="0;.059;.06;.995;1" dur="16s" repeatCount="indefinite"/>'
    +'<animateTransform attributeName="transform" type="translate" values="420 -50;420 -50;220 -12;140 8;98 31;98 31;98 31;72 10;-80 -14;-420 -50" keyTimes="0;.06;.14;.22;.3;.6;.84;.88;.93;1" calcMode="spline" keySplines="0 0 1 1;.3 0 .7 1;.3 0 .7 1;.2 0 .4 1;0 0 1 1;0 0 1 1;.4 0 .8 .6;.2 0 .6 1;.3 0 .8 1" dur="16s" repeatCount="indefinite"/>'
    // corps du corbeau (origine = ses pattes), retourne : il regarde vers la gauche
    +'<g transform="scale(-1.35 1.35)"><path d="M -2 0 L -1 -3 M 2 0 L 1 -3" stroke="#3a3530" stroke-width="1.2" stroke-linecap="round"/>'
    +'<path d="M -9 -8 Q -4 -13 4 -11 Q 9 -10 10 -14 Q 14 -15 15 -12 L 19 -11 L 15 -9 Q 12 -4 4 -3 Q -4 -2 -9 -6 L -15 -5 Z" fill="#14121a"/>'
    +'<circle cx="13" cy="-12.5" r=".9" fill="#d8d0b0"/>'
    // aile repliee (au poser), aile deployee qui bat (en vol)
    +'<path d="M -6 -9 Q 2 -12 8 -7 Q 0 -4 -6 -7 Z" fill="#2a2632"><animate attributeName="opacity" values="0;0;1;1;0;0" keyTimes="0;.28;.3;.84;.86;1" dur="16s" repeatCount="indefinite"/></path>'
    +'<g><animate attributeName="opacity" values="1;1;0;0;1;1" keyTimes="0;.28;.3;.84;.86;1" dur="16s" repeatCount="indefinite"/>'
    +'<g transform="translate(0 -9)"><path d="M 0 0 Q -6 -15 -16 -17 Q -8 -7 -6 1 Z" fill="#1d1a24"><animateTransform attributeName="transform" type="scale" values="1 1;1 -.7;1 1" dur=".36s" repeatCount="indefinite"/></path>'
    +'<path d="M 4 0 Q 4 -15 12 -19 Q 10 -7 6 1 Z" fill="#2a2632"><animateTransform attributeName="transform" type="scale" values="1 1;1 -.6;1 1" dur=".36s" repeatCount="indefinite"/></path></g></g>'
    +'</g></g>'
    +'</svg>',
@@@
    // 2 - ANSELME L ECRIVAIN : meme facture qu Enguerrand. Ecrivain de la
    // forteresse, aucun attribut religieux : beret, plume derriere l oreille,
    // pourpoint bordeaux, ceinture et encrier, besace de rouleaux. EN VEDETTE : un grand livre d heures ouvert (lettrine rouge et
    // or, miniature bleue) et sa plume, qui ecrit ; les lignes apparaissent
    // une a une, l or scintille (SMIL).
    '<svg viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">'
    +'<defs><radialGradient id="ar-glow"><stop offset="0%" stop-color="#f2c94e" stop-opacity=".45"/><stop offset="100%" stop-color="#f2c94e" stop-opacity="0"/></radialGradient>'
    +'<linearGradient id="ar-coule" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#5a1822"/><stop offset="1" stop-color="#8a2e38"/></linearGradient>'
    +'<linearGradient id="ar-page" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fbf3dc"/><stop offset="1" stop-color="#e8d8b0"/></linearGradient></defs>'
    +'<circle cx="100" cy="160" r="90" fill="url(#ar-glow)"/>'
    +'<ellipse cx="98" cy="233" rx="50" ry="5" fill="rgba(0,0,0,.28)"/>'
    // besace de cuir et rouleaux, sur le cote gauche
    +'<line x1="112" y1="96" x2="66" y2="150" stroke="#5a3a22" stroke-width="3.5"/>'
    +'<rect x="50" y="140" width="28" height="34" rx="5" fill="#7a4d2b"/><rect x="50" y="140" width="28" height="11" rx="5" fill="#5f3b20"/>'
    +'<rect x="53" y="128" width="7" height="16" rx="3" fill="#efe2c4"/><rect x="61" y="124" width="7" height="20" rx="3" fill="#e2d2a8"/><rect x="69" y="130" width="6" height="14" rx="3" fill="#efe2c4"/>'
    +'<rect x="60" y="124" width="9" height="3" fill="#a8302a"/>'
    // chausses et bottes
    +'<rect x="84" y="176" width="13" height="44" rx="3" fill="#3a3a48"/><rect x="100" y="176" width="13" height="44" rx="3" fill="#33333f"/>'
    +'<path d="M 80 232 L 81 210 Q 81 206 86 206 L 96 206 L 97 232 Z" fill="#4a2e1a"/><path d="M 99 232 L 100 206 L 111 206 Q 116 206 116 212 L 117 232 Z" fill="#4a2e1a"/>'
    // pourpoint bordeaux a boutons, basques
    +'<path d="M 78 96 Q 80 88 98 88 Q 116 88 118 96 L 121 182 Q 98 188 75 182 Z" fill="url(#ar-coule)"/>'
    +'<path d="M 98 92 L 98 182" stroke="#3a0e16" stroke-width="1.4"/><circle cx="100.5" cy="104" r="1.4" fill="#d4a054"/><circle cx="100.5" cy="116" r="1.4" fill="#d4a054"/><circle cx="100.5" cy="128" r="1.4" fill="#d4a054"/>'
    +'<path d="M 84 90 Q 98 98 112 90 L 110 96 Q 98 101 86 96 Z" fill="#efe6d0"/>'
    // ceinture, boucle, encrier
    +'<rect x="76" y="158" width="44" height="6" fill="#3a2416"/><rect x="94" y="157" width="8" height="8" rx="1.5" fill="none" stroke="#d4a054" stroke-width="1.6"/>'
    +'<rect x="110" y="164" width="9" height="11" rx="2" fill="#2a2a30"/><rect x="111" y="162" width="7" height="3" fill="#8a6440"/>'
    // tete : cheveux bruns, barbe courte, beret, plume derriere l oreille, regard baisse sur le livre
    +'<rect x="92" y="70" width="12" height="18" fill="#c48a63"/>'
    +'<circle cx="83.5" cy="56" r="3.3" fill="#c48a63"/><circle cx="112.5" cy="56" r="3.3" fill="#c48a63"/>'
    +'<ellipse cx="98" cy="55" rx="14" ry="16" fill="#e0a882"/>'
    +'<path d="M 83 58 Q 82 40 98 38 Q 114 40 113 58 Q 110 48 104 46 Q 96 44 90 47 Q 85 50 83 58 Z" fill="#5a3a24"/>'
    +'<path d="M 85 60 Q 86 72 92 76 Q 98 80 104 76 Q 110 72 111 60 Q 108 67 104 69 Q 98 66 92 69 Q 88 67 85 60 Z" fill="#5a3a24"/>'
    +'<path d="M 112 46 L 126 28" stroke="#fbf7ee" stroke-width="3.4" stroke-linecap="round"/><path d="M 113 45 L 125 29" stroke="#cfc6b4" stroke-width=".7"/>'
    +'<path d="M 80 44 Q 82 30 100 30 Q 118 31 117 42 Q 112 46 98 45 Q 86 45 80 44 Z" fill="#2e5446"/><path d="M 80 44 Q 98 48 117 42" stroke="#1e3a30" stroke-width="2" fill="none"/>'
    +'<path d="M 88 50 L 94 49.5 M 102 49.5 L 108 50" stroke="#5a3d28" stroke-width="1.6" stroke-linecap="round"/>'
    +'<path d="M 89 56.5 Q 92 58.5 95 56.5 M 101 56.5 Q 104 58.5 107 56.5" stroke="#2b1d14" stroke-width="1.6" fill="none" stroke-linecap="round"/>'
    +'<path d="M 98 55 L 96.5 61 L 99.5 61.5" stroke="#b8805a" stroke-width="1.2" fill="none" stroke-linecap="round"/>'
    +'<path d="M 94 65.5 Q 98 67.5 102 65.5" stroke="#a85a48" stroke-width="1.5" fill="none" stroke-linecap="round"/>'
    // bras gauche (cote image) qui porte le livre
    +'<path d="M 80 98 Q 70 118 76 132 Q 82 140 92 140" stroke="#6a2430" stroke-width="12" stroke-linecap="round" fill="none"/>'
    // LE LIVRE D HEURES, ouvert, tenu devant lui
    +'<g transform="rotate(-6 100 130)">'
    +'<path d="M 58 112 Q 80 106 100 112 L 100 152 Q 80 146 58 152 Z" fill="#6a1e24"/><path d="M 100 112 Q 120 106 142 112 L 142 152 Q 120 146 100 152 Z" fill="#6a1e24"/>'
    +'<path d="M 61 110 Q 80 104 99 110 L 99 149 Q 80 143 61 149 Z" fill="url(#ar-page)"/><path d="M 101 110 Q 120 104 139 110 L 139 149 Q 120 143 101 149 Z" fill="url(#ar-page)"/>'
    +'<path d="M 99 110 L 99 149" stroke="#c8b68a" stroke-width="1.2"/>'
    // page gauche : lettrine rouge et or, bordure enluminee, texte
    +'<path d="M 63 112 Q 80 107 97 112" stroke="#c8a040" stroke-width="1.4" fill="none"/><path d="M 63 146 Q 80 141 97 146" stroke="#2a4a8a" stroke-width="1.4" fill="none"/>'
    +'<rect x="65" y="114" width="14" height="14" rx="1.5" fill="#a8302a"/><rect x="66.5" y="115.5" width="11" height="11" fill="none" stroke="#f2c94e" stroke-width="1"/>'
    +'<path d="M 68 126 L 72 117 L 76 126 M 69.5 122.5 L 74.5 122.5" stroke="#f2c94e" stroke-width="1.6" fill="none" stroke-linecap="round"/>'
    +'<path d="M 82 117 L 95 116 M 82 121 L 95 120 M 82 125 L 94 124 M 66 131 L 95 129.5 M 66 135 L 95 133.5 M 66 139 L 92 137.5" stroke="#3a2a20" stroke-width="1.1" stroke-linecap="round" opacity=".75"/>'
    +'<circle cx="64" cy="140" r="1.6" fill="#2a4a8a"/><circle cx="64" cy="144" r="1.2" fill="#a8302a"/>'
    // page droite : miniature bleue et or, lignes qui s ecrivent
    +'<rect x="104" y="112" width="31" height="15" rx="1" fill="#2a4a8a"/><rect x="105.5" y="113.5" width="28" height="12" fill="none" stroke="#f2c94e" stroke-width="1"/>'
    +'<path d="M 108 124 L 113 117 L 117 122 L 121 116 L 131 124 Z" fill="#6f8fc8"/><circle cx="127" cy="117" r="2" fill="#f2c94e"/>'
    +'<path d="M 105 131 L 135 130 M 105 135 L 135 134" stroke="#3a2a20" stroke-width="1.1" stroke-linecap="round" opacity=".75"/>'
    +'<line x1="105" y1="139" x2="105" y2="139" stroke="#3a2a20" stroke-width="1.1" stroke-linecap="round" opacity=".8"><animate attributeName="x2" values="105;133;133;105" keyTimes="0;.45;.95;1" dur="6s" repeatCount="indefinite"/><animate attributeName="y2" values="139;138;138;139" keyTimes="0;.45;.95;1" dur="6s" repeatCount="indefinite"/></line>'
    +'<line x1="105" y1="143" x2="105" y2="143" stroke="#3a2a20" stroke-width="1.1" stroke-linecap="round" opacity=".8"><animate attributeName="x2" values="105;105;125;125;105" keyTimes="0;.45;.85;.95;1" dur="6s" repeatCount="indefinite"/><animate attributeName="y2" values="143;143;142.3;142.3;143" keyTimes="0;.45;.85;.95;1" dur="6s" repeatCount="indefinite"/></line>'
    // or qui scintille
    +'<circle cx="72" cy="114" r="1.3" fill="#fff6c0"><animate attributeName="opacity" values="0;1;0" dur="2.2s" repeatCount="indefinite"/></circle>'
    +'<circle cx="131" cy="114" r="1.2" fill="#fff6c0"><animate attributeName="opacity" values="0;1;0" dur="2.8s" begin="1s" repeatCount="indefinite"/></circle>'
    +'<circle cx="77" cy="127" r="1" fill="#fff6c0"><animate attributeName="opacity" values="0;1;0" dur="1.9s" begin=".6s" repeatCount="indefinite"/></circle>'
    +'</g>'
    +'<circle cx="92" cy="141" r="5.5" fill="#c48a63"/>'
    // bras droit et LA PLUME, qui suit l ecriture des deux lignes
    +'<g><animateTransform attributeName="transform" type="translate" values="1.9 -2.6;29.7 -6.5;29.7 -6.5;2.3 1.4;2.3 1.4;22.2 -1.4;22.2 -1.4;1.9 -2.6" keyTimes="0;.45;.46;.47;.48;.85;.95;1" dur="6s" repeatCount="indefinite"/>'
    +'<g><animateTransform attributeName="transform" type="translate" values="0 0;.8 -1.2;0 0;-.6 -.8;0 0" dur=".5s" repeatCount="indefinite"/>'
    +'<path d="M 117 98 Q 128 112 122 128 Q 116 134 108 138" stroke="#6a2430" stroke-width="11" stroke-linecap="round" fill="none"/>'
    +'<circle cx="107" cy="138" r="5" fill="#c48a63"/>'
    +'<path d="M 104 141 L 132 98" stroke="#5a4030" stroke-width="1.2"/>'
    +'<path d="M 104 141 L 106 137" stroke="#1a1410" stroke-width="1.8" stroke-linecap="round"/>'
    +'<path d="M 113 126 Q 112 106 136 88 Q 142 86 140 92 Q 130 112 118 128 Z" fill="#fbf7ee" stroke="#cfc6b4" stroke-width=".8"/>'
    +'<path d="M 116 124 L 136 92 M 118 118 L 124 116 M 121 113 L 128 110 M 124 108 L 131 104 M 127 103 L 134 99" stroke="#cfc6b4" stroke-width=".8"/>'
    +'</g></g>'
    +'</svg>',
@@@
    // 5 - BERTRAND LE SAGE : meme facture qu Enguerrand. Vieil ermite,
    // crane degarni, cheveux et longue barbe blancs, manteau de laine a
    // col de fourrure, neige sur les epaules, baton de marche noueux, et
    // dans l autre main le bougeoir de sa chandelle (flamme qui vacille, SMIL).
    '<svg viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">'
    +'<defs><radialGradient id="sg-glow"><stop offset="0%" stop-color="#ffc878" stop-opacity=".5"/><stop offset="100%" stop-color="#ffc878" stop-opacity="0"/></radialGradient>'
    +'<linearGradient id="sg-laine" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#4a3a30"/><stop offset="1" stop-color="#7a6452"/></linearGradient>'
    +'<radialGradient id="sg-halo"><stop offset="0%" stop-color="#ffd890" stop-opacity=".8"/><stop offset="100%" stop-color="#ffd890" stop-opacity="0"/></radialGradient></defs>'
    +'<circle cx="100" cy="170" r="90" fill="url(#sg-glow)"/>'
    +'<ellipse cx="100" cy="233" rx="54" ry="5" fill="rgba(0,0,0,.28)"/>'
    // baton de marche noueux, tenu dans la main gauche (cote image)
    +'<path d="M 66 34 Q 62 40 64 48 L 70 232" stroke="#6a4a2a" stroke-width="4.2" stroke-linecap="round" fill="none"/>'
    +'<circle cx="66.5" cy="90" r="2.6" fill="#5a3a20"/><circle cx="68.4" cy="160" r="2.4" fill="#5a3a20"/>'
    +'<path d="M 63 36 Q 66 30 70 34" stroke="#f2f4ff" stroke-width="2.2" stroke-linecap="round" fill="none"/>'
    // bottes entourees de bandes
    +'<path d="M 80 232 L 81 214 L 97 214 L 97 232 Z" fill="#3a2a20"/><path d="M 101 232 L 101 214 L 116 214 Q 120 218 120 232 Z" fill="#3a2a20"/>'
    +'<path d="M 81 220 L 97 218 M 81 226 L 97 224 M 101 218 L 117 220 M 101 224 L 118 226" stroke="#8a7a62" stroke-width="1.3"/>'
    // long manteau de laine
    +'<path d="M 78 96 Q 80 88 98 88 Q 116 88 118 96 L 126 216 L 70 216 Z" fill="url(#sg-laine)"/>'
    +'<path d="M 98 104 L 98 214" stroke="#3a2c24" stroke-width="1.4"/><path d="M 74 214 L 80 160 M 122 214 L 116 160" stroke="#3a2c24" stroke-width="1.4" opacity=".6"/>'
    +'<path d="M 72 212 Q 98 220 124 212 L 126 218 Q 98 226 70 218 Z" fill="#5a4838"/>'
    +'<rect x="76" y="146" width="44" height="5" fill="#2e2219"/><rect x="95" y="145" width="7" height="7" rx="1.2" fill="none" stroke="#a89a80" stroke-width="1.4"/>'
    // col de fourrure et neige sur les epaules
    +'<path d="M 76 98 Q 84 86 98 92 Q 112 86 120 98 Q 112 106 98 104 Q 84 106 76 98 Z" fill="#c8b89a"/>'
    +'<path d="M 79 96 Q 84 92 88 95 M 90 93 Q 94 89 98 93 M 100 93 Q 104 89 108 93 M 110 95 Q 114 92 117 96" stroke="#a8987a" stroke-width="1.2" fill="none"/>'
    +'<path d="M 76 97 Q 80 92 86 94" stroke="#f4f6ff" stroke-width="2.6" stroke-linecap="round" fill="none"/><path d="M 110 94 Q 116 92 120 97" stroke="#f4f6ff" stroke-width="2.6" stroke-linecap="round" fill="none"/>'
    // bras gauche (cote image) vers le baton
    +'<path d="M 80 100 Q 70 110 68 122" stroke="#5a4838" stroke-width="11" stroke-linecap="round" fill="none"/><circle cx="67.5" cy="124" r="5.5" fill="#d6a07c"/>'
    // tete : crane degarni, couronne et barbe blanches
    +'<rect x="92" y="72" width="12" height="14" fill="#c48a63"/>'
    +'<circle cx="83.5" cy="57" r="3.4" fill="#c48a63"/><circle cx="112.5" cy="57" r="3.4" fill="#c48a63"/>'
    +'<ellipse cx="98" cy="55" rx="14" ry="16" fill="#e0a882"/>'
    +'<path d="M 84 54 Q 81 44 86 40 Q 85 48 88 52 Z M 112 54 Q 115 44 110 40 Q 111 48 108 52 Z" fill="#eceef4"/>'
    +'<ellipse cx="95" cy="43" rx="6" ry="2.6" fill="#f0c4a2" opacity=".7"/>'
    +'<path d="M 83 58 Q 82 80 88 98 Q 94 118 98 122 Q 102 118 108 98 Q 114 80 113 58 Q 110 68 106 70 Q 98 66 90 70 Q 86 68 83 58 Z" fill="#eef0f6"/>'
    +'<path d="M 92 80 Q 94 100 98 116 M 104 80 Q 102 100 98 116 M 98 76 L 98 112" stroke="#c8ccd8" stroke-width="1" fill="none"/>'
    +'<path d="M 88 68 Q 93 64 98 68 Q 103 64 108 68 Q 103 70 98 69 Q 93 70 88 68 Z" fill="#dfe2ea"/>'
    +'<path d="M 86 49 Q 90 47 94 49.5 M 102 49.5 Q 106 47 110 49" stroke="#e6e8ef" stroke-width="2.4" stroke-linecap="round" fill="none"/>'
    +'<path d="M 88.5 55 Q 91 57 93.5 55 M 102.5 55 Q 105 57 107.5 55" stroke="#2b1d14" stroke-width="1.6" fill="none" stroke-linecap="round"/>'
    +'<path d="M 86 58 Q 88 60 90 59 M 106 59 Q 108 60 110 58" stroke="#b87a58" stroke-width=".9" fill="none"/>'
    +'<path d="M 98 54 L 96.5 61 L 99.5 61.5" stroke="#b8805a" stroke-width="1.2" fill="none" stroke-linecap="round"/>'
    // bras droit : le bougeoir et la chandelle, tenus devant lui
    +'<path d="M 116 100 Q 128 116 124 134" stroke="#5a4838" stroke-width="11" stroke-linecap="round" fill="none"/>'
    +'<circle cx="124" cy="136" r="15" fill="url(#sg-halo)"><animate attributeName="r" values="14;17;15;16.5;14" dur="1.9s" repeatCount="indefinite"/></circle>'
    +'<path d="M 112 142 Q 124 148 136 142 L 134 146 Q 124 151 114 146 Z" fill="#b8862f"/><path d="M 133 144 Q 141 144 140 150 Q 138 154 134 150" stroke="#b8862f" stroke-width="1.8" fill="none"/>'
    +'<rect x="120.5" y="126" width="7" height="17" rx="1" fill="#efe6d0"/><path d="M 120.5 128 Q 119 132 120.5 134" stroke="#efe6d0" stroke-width="1.6" fill="none"/>'
    +'<circle cx="124" cy="146" r="5.5" fill="#d6a07c"/>'
    +'<path d="M 124 126 L 124 123" stroke="#2a1a10" stroke-width="1"/>'
    +'<path d="M 121.4 123 Q 121 117 124 110 Q 127 117 126.6 123 Z" fill="#ffb648"><animateTransform attributeName="transform" type="rotate" values="0 124 123;-7 124 123;3 124 123;-4 124 123;6 124 123;0 124 123" dur="2.3s" repeatCount="indefinite"/><animate attributeName="d" values="M 121.4 123 Q 121 117 124 110 Q 127 117 126.6 123 Z;M 121.6 123 Q 121.2 116 124 108 Q 126.8 116 126.4 123 Z;M 121.4 123 Q 121 117 124 110 Q 127 117 126.6 123 Z" dur=".7s" repeatCount="indefinite"/></path>'
    +'<ellipse cx="124" cy="119.5" rx="1.2" ry="2.6" fill="#fff8e0"/>'
    +'</svg>',
