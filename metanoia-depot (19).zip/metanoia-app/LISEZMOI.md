# Metanoia - projet Android (Capacitor)

## Si tu reprends ce projet, lis d abord ceci

Ce document est la memoire du projet. Il est tenu a jour apres chaque
chantier et il fait foi : ce qui n y est pas ecrit n a pas ete verifie.

### Les neuf regles de Thibs, elles priment sur tout le reste

1. **L economie de jetons est centrale.** Jamais de `grep` non borne, jamais
   de vidage du fichier. Toute lecture passe par `cut -c1-N`, `head`, ou une
   plage etroite de `sed -n` / `awk`. Le fichier principal fait plus d un
   million et demi de caracteres : une lecture complete brule une session.
2. **Toujours renvoyer les fichiers modifies**, en disant lesquels ont bouge
   et lesquels n ont pas bouge. Apres CHAQUE patch, l archive
   `metanoia-depot.zip` est reconstruite et renvoyee, et ce LISEZMOI est mis
   a jour dans le meme envoi : c est lui que Thibs joint a chaque nouvelle
   discussion.
3. **Ne pas creer d autres bugs.** Verifier AVANT de livrer, jamais apres.
4. **Demander** quand c est reellement ambigu, pas pour se defausser.
5. **Francais**, ton direct et concis, commentaires de code compris.
6. **Thibs conteste les conclusions fausses, et il a raison.** Une hypothese
   se verifie avant d etre enoncee comme un fait. Se retracter explicitement
   quand on s est trompe, dans la reponse ET dans ce document.
7. **Aucun cadratin ni demi-cadratin.** Ni le caractere lui-meme, ni son
   echappement `\u2014` ou `\u2013`, ni l entite `&mdash;` ou `&ndash;`. Le
   compteur est a zero, il y reste. Y compris dans ce document, qui ne peut
   donc pas citer les caracteres interdits.
8. **Ne jamais reformuler un texte fourni par Thibs.** Corriger une faute,
   oui. Changer un mot parce qu on le prefere, non.
9. **Session lourde.** Instruction de Thibs (10 novembre 2026), a appliquer
   dans chaque session, des qu elle commence a etre surchargee :
   « Envoie-moi un message quand la session commence à être lourde et que je devrais en commencer une nouvelle. »

### La methode : verifier par execution, jamais par lecture

Obligatoire apres chaque modification de `www/index.html` :

```python
import re, os
s = open('index.html', encoding='utf-8').read()
print(len(s), len(re.findall(r'<script', s)))          # doit afficher 6
print(s.count('\u2014') + s.count('\u2013'))           # doit afficher 0
blocs = re.findall(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>', s, re.S)
print(len(blocs))                                      # doit afficher 4
from lxml import html as LH; LH.fromstring(s)          # analyse HTML
```

puis `node --check` sur chacun des quatre blocs extraits. (Reference
corrigee le 15 novembre 2026 : le fichier compte 5 balises et 4 blocs
inline depuis un ajout non reporte ici ; le code n etait pas en cause.)

Un `grep -c` sur une classe de caracteres contenant les deux tirets longs
donne, en locale C, des faux positifs sur les octets UTF-8 : ne pas s en
servir pour compter. Seul le comptage Python ci-dessus fait foi.

Pour verifier un COMPORTEMENT, et non la syntaxe, charger l application
reelle dans un navigateur plutot que raisonner sur le code :

```bash
cd www && python3 -m http.server 8777 &
```

puis Playwright (`/opt/npm-tools/node_modules/playwright`, Chromium en
`/opt/pw-browsers/chromium`) sur `http://127.0.0.1:8777/index.html`. On peut
poser un etat complet depuis la page : `ST.onboarded=true`, `ST.day=20`,
`ST.weekPlan=genWeek()`, puis appeler les vraies fonctions. C est ainsi qu
ont ete trouves les defauts du systeme de sanction. Quand charger toute
l application est inutile, extraire la VRAIE fonction du fichier par
equilibrage d accolades et l executer avec des doublures, jamais la
retaper.

### Les pieges deja payes

- Ecrire `</script>` a l interieur d un bloc inline genere depuis Python
  termine le bloc par surprise. Passer par un `<script src="...">` separe.
- Un ternaire multi-lignes dont les lignes `?` et `:` portent le `+` de
  concatenation est une erreur de syntaxe. Les lignes de continuation ne
  portent pas le `+`. Pris trois fois.
- `Array.indexOf(clone)` renvoie -1 : il compare des references.
- `todayStr()` produit `annee-mois-jour` avec un mois indexe a ZERO et sans
  zero de tete : `2026-9-16` pour le 16 octobre 2026. Ce n est pas de l ISO.
- Le creneau de jeu va de 8 h a minuit par defaut. Ce qui se declenche
  « a 22 h » dans de vieux commentaires se declenche en realite a la FIN du
  creneau.
- pg_cron rapporte `succeeded` pour un `select net.http_post(...)` parce que
  l appel ne fait que mettre en file. Le vrai resultat est dans
  `net._http_response`.
- Les fonctions Edge de Supabase refusent un appel sans jeton
  d autorisation AVANT d executer le corps : un en-tete maison n est jamais
  atteint.
- Un declencheur BEFORE qui `return null` annule l UPDATE en silence, et ils
  se declenchent dans l ordre alphabetique de leur nom.
- `navigator.onLine` signifie « une interface reseau est active », pas
  « internet marche ». Sous Android il ment en mode avion.
- Le bac a sable de developpement n a pas de DNS : impossible d y verifier
  un domaine ou une zone.

### Documents de reference hors depot

Thibs joint ces documents en debut de discussion. Ils sont DATES : ce qui
suit dans ce LISEZMOI les corrige quand ils divergent.

| Document | Date | Etat |
|---|---|---|
| Migration vers Capacitor | 7 octobre | phases 1 a 7 faites, phase 8 a faire |
| Compiler et configurer | 7 octobre | reference pour la compilation et la phase 5 |
| Audit de securite | 9 octobre | onze points, etat a jour dans la section du meme nom plus bas |
| Plan d acquisition 90 jours | 15 octobre | vit dans la conversation marketing ; seules ses taches app sont reprises ici |

Les chiffres de ces documents sont perimes : ils citent un `index.html` de
1,58 million de caracteres et 1 444 608 emblemes, le second est juste, le
premier ne l est plus (voir ci-dessous).

### Reperes chiffres au 18 octobre 2026

| Mesure | Valeur |
|---|---|
| `www/index.html` | 2 139 001 caracteres (23 novembre, 14 h 35, marchands integres) |
| `LISEZMOI.md` | ce fichier |
| Balises `<script>` | 6, dont 4 blocs inline (16 novembre : + `accueil.js`) |
| Cadratins | 0 |
| Archive livree | `metanoia-depot.zip`, 262 fichiers (23 novembre) |

L archive se reconstruit toujours ainsi, et sa premiere entree DOIT etre
`metanoia-app/` :

```bash
cd /home/claude && rm -f /mnt/user-data/outputs/metanoia-depot.zip \
  && zip -rq /mnt/user-data/outputs/metanoia-depot.zip metanoia-app \
  -x 'metanoia-app/.git/*' -x 'metanoia-app/node_modules/*' \
  -x 'metanoia-app/*/node_modules/*' -x 'metanoia-app/android/.gradle/*' \
  -x 'metanoia-app/android/build/*' -x 'metanoia-app/android/app/build/*' \
  -x '*.zip'
```

Apres toute modification de `www/`, passer `npx cap copy android` avant de
zipper, sinon l archive emporte un `android/app/src/main/assets/public`
perime.

---

Phases 1 a 4 du plan de migration. Le projet se compile dans Android Studio ;
il n'a pas pu etre compile ici, faute d'Android SDK (`dl.google.com` inaccessible).

## Pour le lancer

```bash
npm install
npx cap sync android
npx cap open android      # ouvre Android Studio
```

Puis dans Android Studio : Run, ou Build > Build APK(s).

## Ce qui est fait

- **Phase 1** - socle Capacitor, `appId` `com.metanoia_app`, `appName` Metanoia.
- **Phase 2** - polices et Supabase en local. Plus aucune dependance distante
  sauf Google Sign-In (phase 5).
- **Phase 3** - service worker retire, ligne « Version de l'application »
  retiree des parametres.
- **Phase 4** - stockage natif a deux copies, avec migration automatique.
- **Phase 5** - connexion Google native via @capgo/capacitor-social-login.
  Le script GSI distant n'est plus charge qu'en web. En natif, le selecteur
  de comptes Android renvoie un idToken, passe au meme signInWithIdToken de
  Supabase qu'auparavant. REQUIERT un client OAuth Android dans la console
  Google Cloud (voir ci-dessous).
- **Icones** - phenix seul sur fond bordeaux #4D102F, 5 densites, icone
  adaptative + heritee. Le mot METANOIA est retire de l'icone du lanceur
  (il serait rogne par le masque rond) mais reste sur l'icone du store
  et sur l'ecran de lancement.

## Ou se trouve quoi

| Fichier | Role |
|---|---|
| `www/index.html` | l'application, seul fichier modifie par rapport a ta version |
| `www/fonts.css` + `www/fonts/` | les 13 fichiers de police, 239 Ko |
| `www/supabase.js` | la bibliotheque Supabase, version locale |
| `capacitor.config.json` | identifiant, nom, dossier web |
| `android/` | le projet Android genere |
| `store/icone-play-512.png` | l'icone 512x512 pour la fiche Play Store |

## Compiler sans ordinateur

Le dossier `.github/workflows/android.yml` compile l'APK sur les serveurs de
GitHub. Depose le projet sur un depot GitHub, puis onglet Actions, « APK
Android », bouton « Run workflow ». L'APK se telecharge en bas de la page du
run, et l'empreinte SHA-1 s'affiche dans le journal de l'etape du meme nom.
Tout se fait depuis un navigateur, telephone compris.

## Changer l'identifiant de l'application

`com.metanoia_app` vient du domaine metanoia-app.com : Android refuse les
tirets, la regle Java les remplace par un underscore. Il est **definitif une
fois publie** sur le Play Store, modifiable librement avant. Les cinq endroits :
`capacitor.config.json`, `android/app/build.gradle` (`namespace` et
`applicationId`), `android/app/src/main/res/values/strings.xml`, le chemin
`android/app/src/main/java/com/metanoia_app/` et la ligne `package` de
`MainActivity.java`.

## A faire dans la console Google Cloud

Sans ces deux reglages, la connexion Google echoue en natif :

1. APIs & Services > Credentials > Create credentials > OAuth client ID,
   type **Android**, nom au choix.
   - Package name : `com.metanoia_app`
   - SHA-1 : `4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97`
2. Verifier dans Supabase (Authentication > Providers > Google) que le
   provider est actif et que le Client ID **Web** y figure.

- **Phase 6** - notifications locales natives (@capacitor/local-notifications).
  Les rappels sont desormais programmes par Android et partent application
  fermee, ce que l'ancien setInterval ne faisait pas. Le Web Push, impossible
  sans service worker, est court-circuite en natif.
- **Phase 7** - greffon d'horloge monotone, ecrit sur mesure
  (`android/.../HorlogePlugin.java`, enregistre dans MainActivity).
  Il expose SystemClock.elapsedRealtime(), que l'utilisateur ne peut pas
  regler, et l'instant de demarrage du telephone. Le rattrapage des jours
  borne desormais ce qu'il rejoue par ce temps reellement ecoule.

- **Evenements** - le canal force par Prediction est devenu un vrai second
  canal, strictement equivalent au naturel : volume, points, quete bonus
  Hard Mode et clear de Frenesie, pas seulement l'XP. Avant, deux tirages sur
  six (`double_pts`, `frenzy`) n'avaient aucun effet, et un shadow force ne
  donnait pas son x2 points. Regle ajoutee : Prediction s'adapte a l'evenement
  du jour et ne peut jamais etre le meme que lui. Reelection a trois endroits,
  au tirage (on retire l'evenement calendaire de demain), au passage de jour
  dans advDay(), et en garde-fou a chaque lecture dans _evForce(), parce que
  l'etat du jour bouge encore apres advDay. Plafond d'XP d'une journee ramene
  de 4990 a 3314 pour les quetes seules.
  Donjon : la condition « 1 quete en evenement » (10 donjons sur 108, Rang C+)
  fabriquait un doubleXP d'office les jours sans evenement calendaire, meme
  quand une Prediction etait deja active : les deux se multipliaient et le jour
  passait a x6. Une Prediction active compte desormais comme un evenement, donc
  plus de fabrication, et elle valide la condition par elle-meme.

- **Audit de securite** - quatre correctifs appliques a index.html.
  1. Le panneau de developpement est reserve au compte administrateur.
     Avant : cinq tapes dans le coin haut droit l ouvraient pour n importe quel
     joueur, sur telephone, sans outil (mesure : 25 050 points en cinq clics).
     RENSEIGNE ADMIN_UID OU ADMIN_EMAIL, declares juste avant toggleTestMode() :
     laisses vides, le panneau est desactive pour tout le monde, toi compris.
     Le mode test ne se rallume plus seul au demarrage, la session n etant pas
     encore resolue a cet instant : cinq tapes une fois connecte le rouvrent.
  2. submitReview() a une garde d idempotence. Avant : un double-clic creditait
     deux fois l XP, les points, UN JOUR DE SERIE et ecrivait deux bilans.
  3. _shopAddToInventory conserve price et orig. Avant : la revente retombait
     toujours sur son repli a 100 et rendait 50 pts, donc acheter a 41 puis
     revendre creait 9 pts par cycle.
  4. _sellInvItem ne decale plus l index une seconde fois, et ne vend qu un
     exemplaire d une pile. Avant, sous bouclier : cliquer la 3e case vendait
     le 1er objet, et toute la pile partait pour le prix d un seul.

  Reste a corriger, par ordre de gravite : l import de sauvegarde n a aucune
  borne (ligne 4972), et la policy de lecture de profiles expose le state_blob
  de tous les joueurs a tous les joueurs.

- **Deconnexion** - l interface repond au doigt leve : la ligne « Se
  deconnecter » disparait avant la synchronisation cloud, qui peut prendre six
  secondes, et le message suit. Puis la progression repart a J1 en conservant
  le questionnaire, le pourquoi et la date de mise a jour du formulaire, pour
  qu un changement de compte ne force personne a tout refaire.
  Filet hors ligne : _socLogout prend un instantane « avant-deconnexion » TANT
  QUE le compte est encore connu, donc range dans l anneau de ce compte. Il
  reapparait seul dans Reglages > Sauvegardes locales a la prochaine connexion
  de CE compte, et nulle part ailleurs. La reinitialisation ne purge donc NI
  IndexedDB NI localStorage, contrairement a testReset : ce serait effacer
  l instantane qu on vient de prendre.

- **Import de sauvegarde retire.** Un fichier importe remplacait l etat entier
  du jeu, et sa validation tenait en une ligne : « day est un nombre OU
  onboarded vaut true ». Le borner ne reglait rien, parce que TOUTES les
  valeurs de reference viennent du fichier : plafonner l XP a 5000 par jour n a
  aucun sens quand le nombre de jours est ecrit par celui qui triche. L export
  reste : le RGPD, article 20, ne porte que sur la SORTIE des donnees et
  n oblige a accepter aucun import. Les fonctions rgpdImport,
  _rgpdExtraitEtat et _rgpdImportFichier sont conservees intactes : pour
  reactiver, il suffit de remettre le bloc HTML d origine.
- **Diagnostic Google B5 reserve a l administrateur.** Il n apparait que sur un
  echec de connexion, jamais sur un succes. Son contenu est ecrit pour le
  developpeur : les joueurs recoivent desormais une phrase comprehensible,
  l outil reste entier pour le compte admin.

- **Rappel de sauvegarde dans Activite.** L import retire, un joueur sans
  compte n a plus aucun moyen de transferer sa progression : on le lui dit.
  Deux mecanismes complementaires. Une entree de journal (_actCheckCompte),
  posee a partir de J3 et au plus UNE par semaine de jeu grace a la cle
  « compte-rappel-<semaine> » : c est elle qui allume la pastille et fait
  ouvrir le panneau. Et une banniere CALCULEE a l ouverture, jamais stockee,
  qui porte le bouton « Creer un compte » et disparait a la seconde ou le
  joueur se connecte. Le bouton reutilise ST._socPulse, le clignotement du
  tutoriel, applique par nav() sur l ecran Social.

- **Fuite du state_blob fermee.** profiles porte a la fois les colonnes
  publiques du classement ET state_blob, la sauvegarde personnelle complete.
  L ancienne policy ne filtrait que les LIGNES, donc un GET
  /rest/v1/profiles?select=* rendait l etat de jeu entier de tous les joueurs.
  Correctif en trois temps, fichier metanoia-fuite-state-blob.sql :
  une vue « classement » qui n expose que les colonnes publiques et ecarte les
  suspects ; une fonction metanoia_pseudo_pris qui verifie l unicite sans lire
  la table ; et profiles restreinte a sa propre ligne en lecture.
  Cote client, quatre points : le classement interroge la vue, et les trois
  controles d unicite du pseudo passent par la fonction. Les dix autres acces a
  profiles sont des ecritures, la suppression RGPD, ou la lecture de sa propre
  ligne : tous inchanges.
  LE SQL ET L APPLICATION SE DEPLOIENT ENSEMBLE : une ancienne version du
  client lirait le classement dans profiles et afficherait une liste vide.

- **Greffon d horloge : la detection etait fausse.** HORLOGE_NATIVE ne testait
  que Capacitor.Plugins.Horloge. Or Capacitor.Plugins ne porte pas forcement un
  greffon natif sans pendant JavaScript : la voie documentee est
  registerPlugin(). Resultat, HORLOGE_NATIVE valait faux sur l appareil,
  _ratMonotone renvoyait null, _ratPlafondMonotone aussi, et TOUT le garde-fou
  etait saute EN SILENCE. L heure du telephone redevenait seule maitresse du
  calendrier. Constate en vrai : heure avancee, l application a suivi jusqu au
  jour 975, et le cliquet a ensuite refuse de revenir.
  Correctif : on essaie Capacitor.Plugins.Horloge PUIS registerPlugin.
  Ajout d un ecran de diagnostic reserve a l administrateur, bouton « Horloge »
  du panneau de test : il dit si le greffon repond, ce qu il renvoie, le
  plafond calcule et l etat du cliquet. Il porte aussi « Reparer », qui relache
  le cliquet et retablit un numero de jour saisi a la main, parce que le
  cliquet interdit de reculer par construction.

- Panneau de test ouvert apres la perte de la session. L identite admin n etait
  verifiee qu a l ouverture : au clic, dans toggleTestMode et au demarrage.
  Rien ne la revalidait ensuite, donc quand le jeton Supabase expirait, panneau
  affiche, il restait visible et pleinement utilisable.
  Correctif : `_verrouPanneauTest()`, appele dans le cycle de rendu et dans
  onAuthStateChange juste apres la reaffectation de _socUser. Il ferme le
  panneau, remet _TEST_MODE a faux et persiste. Teste : admin ouvre, session
  perdue, panneau ferme, reouverture refusee, admin revient, panneau rouvert,
  et le verrou ne gene jamais l admin connecte.

- Rappel de compte affiche aux utilisateurs connectes. Supabase restaure la
  session en asynchrone : au demarrage, `_socUser` vaut null pendant une
  seconde alors que le compte existe, et le cycle de rendu tranchait pendant
  ce laps. Deux bannieres posees « a l instant » sur un compte actif.
  Correctif : drapeau `_socAuthPret`, pose par `onAuthStateChange`, par la
  resolution de `getSession` y compris en echec, et tout de suite quand il n y
  a ni SDK ni configuration. Marqueur durable `ST._socDejaConnecte` pour ne
  pas reclamer un compte a un appareil qui en a deja porte un, cas du
  demarrage hors ligne. `_actPurgeCompte()` retire les bannieres deja posees
  des que la session arrive, par la cle `k` desormais retenue sur chaque
  entree, et par le titre pour celles creees avant. Cadence inchangee : un
  rappel par semaine tant qu il n y a pas de compte.

- Confirmation de deconnexion. Le geste partait d un seul appui et remet
  l appareil au jour 1. Une demande de confirmation precede desormais tout,
  et une fois les animations finies l application quitte les reglages pour
  l ecran des Quetes, onglet actif compris.

- Emblemes de guilde. Composition en cinq couches, entierement vectorielle et
  generee a l execution : 32 symboles, 14 cadres, 18 fonds, 10 effets et
  12 palettes, soit 967 680 combinaisons. Rien n est stocke en image, une
  guilde ne retient qu un code de moins de trente caracteres de la forme
  `v1|s<symbole>|f<cadre>|b<fond>|e<effet>|c<palette>`, ecrit dans la colonne
  `emblem` deja existante. Aucune migration SQL : la policy
  `guilds_update_owner` reserve deja l ecriture au proprietaire.
  Les emblemes d avant, qui etaient des emojis, restent affiches tels quels :
  `embSVG` les reconnait et les rend sans conversion.
  A la creation d une guilde, les cinq couches sont tirees au sort. Le Maitre
  les change ensuite dans les reglages de guilde, couche par couche, chaque
  vignette montrant SON embleme avec cette seule couche modifiee. Les autres
  membres y voient l embleme en grand, sans pouvoir le toucher.
  Les effets sont de petites particules posees en couronne, jamais au centre,
  jouees seulement a partir de 40 px et coupees par
  `prefers-reduced-motion`.

- Reglages de guilde : le bouton Enregistrer passait sous le bord de l ecran,
  donc le premier reflexe devenait la croix, qui jetait tout. La boite est
  desormais une colonne, en-tete fixe, corps qui defile, pied colle avec le
  bouton toujours visible. Hauteur bornee a min(80vh, 640px) et marge basse
  calee sur env(safe-area-inset-bottom) : elle ne depasse plus de l ecran.
  La croix previent quand un embleme, une devise ou un mode de recrutement
  n est pas enregistre.

- Effets d embleme refaits : ils se ressemblaient tous, c etaient onze fois
  les memes points. Onze effets distincts par la forme, le sens et le tempo.
  En continu : Comete (une comete et sa queue font le tour), Braises (elles
  montent du bas en vacillant), Neige (des flocons tombent a des vitesses
  differentes), Runes (deux anneaux tournent en sens contraires), Bulles
  (elles montent en ondulant), Poussiere (des motes respirent sur place).
  En salve, deux secondes d activite puis cinq de silence sur un cycle de
  sept : Etincelles (des eclats a quatre branches claquent), Foudre (un
  eclair traverse avec un flash), Onde (deux ondes de choc partent du
  centre), Balayage (une lame de lumiere passe en diagonale).
  Foudre et Balayage passent PAR DESSUS le symbole, les autres dessous.
  Au repos, sans animation, l eclair et le flash sont a opacite nulle : ni
  mouvement reduit ni vieux moteur ne laissent un aplat blanc sur le blason.
  Dans le selecteur seulement, les effets en salve rejouent toutes les
  2,6 s, sinon on choisirait la Foudre sans l avoir jamais vue frapper.
  Le catalogue passe a 32 x 14 x 18 x 11 x 12 = 1 064 448 combinaisons.

- Foudre : la tension vient du clignotement, plus d un deplacement. La chute
  verticale est abandonnee. Pendant le premier quart du cycle, neuf eclats
  nerveux clignotent a des positions et des instants irreguliers, trois fois
  chacun, avec une amplitude qui monte a l approche de la frappe, pendant que
  le voile du blason respire sourdement. Puis l eclair apparait ENTIER et bat
  trois fois en moins de 0,3 s. L impact laisse une onde rasante et quatre
  eclats qui giclent. Trois couches pour la matiere, un halo large, le corps
  dans la palette et un coeur blanc plus etroit, plus deux fourches.
  Cycle de 5 s, deux frappes par cycle.
  Verifie : les 42 balises d animation ont des keyTimes valides, de meme
  longueur que leurs valeurs, partant de 0, finissant a 1 et jamais
  decroissants, un controle qui compte puisqu un keyTimes malforme est
  ignore en silence par le moteur. Puis 24 captures a 75 ms : 24 images
  differentes, precurseurs, frappe, onde, silence.

- Cadrage du symbole par cadre. Une banniere n a pas sa masse au centre du
  carre de 64 : le symbole tombait sur les encoches du bas. Chaque cadre peut
  desormais porter un decalage vertical `dy`, applique au symbole. Pose sur
  Banniere -6, Pointe -5, Blason -2,5, Ecu -2, Gothique -1,5, Creneaux +1.

- Cinq cadres de plus : Rouage, Epines, Soleil, Banniere, Pointe. Le
  catalogue passe a 32 x 19 x 18 x 11 x 12 = 1 444 608 combinaisons.

- Foudre invisible : bug a moi. La base du groupe valait
  `translate(32 32) scale(0)` et `additive="sum"` MULTIPLIE les transformations,
  donc l echelle animee etait annulee par le zero de depart et l eclair ne
  s affichait jamais. Base ramenee a `translate(32 32)` seul, eclair agrandi,
  et deux frappes par cycle au lieu d une.

- Braises redessinees : un point tres clair dans un halo chaud a deux
  couches, une montee en zigzag sur cinq points, et un vacillement sur sept
  pas d echelle au lieu d une simple apparition. Elles ne se confondent plus
  avec les Bulles.

- Changer une valeur dans l editeur relancait toutes les animations : la
  grille entiere etait reconstruite a chaque choix. Or le contenu des
  vignettes voisines ne change pas, seules la selection et l apercu bougent.
  `_embChoisir` ne touche donc plus qu a ces deux la, via `_embMajApercu` et
  `_embMajSelection`. Verifie : apres un choix, les noeuds SVG de la grille
  sont les MEMES objets qu avant, donc SMIL continue sans redemarrer.

## Audit du 10 octobre, huit defauts corriges

Audit mene par un second regard sur le code recent, chaque defaut reproduit
avant correction et reverifie apres.

1. XSS stockee par le nom de guilde. `g.name` etait concatene dans
   `innerHTML` sans `_esc` a quatre endroits : classement, recherche de
   guildes, bandeau de guilde, onglet Guilde. Une guilde nommee
   `<img src=x onerror=...>` executait du code chez tous ceux qui ouvraient
   ces vues. Un cinquieme site, le profil public, echappait correctement :
   c est l oubli qui saute aux yeux. Corrige partout, devise comprise, et
   `_esc` echappe desormais aussi les guillemets puisqu il alimente des
   attributs HTML. Verifie : 0 image injectee, le texte s affiche tel quel.

2. Un mode de recrutement abandonne finissait par partir au serveur.
   `_guildSetMode` ecrivait `_GUILD.info.recruitment` immediatement, donc la
   croix ne detectait aucune modification et un choix abandonne repartait au
   prochain enregistrement de la devise. Le choix ne vit plus que dans
   `_GUILD_MODE_DRAFT`, l affichage et l enregistrement le lisent, et il est
   consomme a l enregistrement. Verifie : etat reel intact a `ask` apres un
   choix `closed`, la croix previent, Revenir conserve, Quitter jette.

3. Le chat se figeait pour de bon si la session tombait pendant qu il etait
   ouvert. `_guildRenderMsgs` lisait `_socUser.id` sans garde, l exception
   partait dans le callback Realtime et le fil ne se redessinait plus jamais.
   Garde ajoutee, et une session perdue referme desormais le chat et coupe
   l abonnement.

4. Un seul code d embleme corrompu vidait tout le classement. Le modulo de JS
   conserve le signe, un index negatif restait negatif, et `embSVG` levait
   dans un `.map()`. Bornage par `((v%n)+n)%n`, plus un repli sur le premier
   element si le catalogue change. Verifie : `v1|s-1|f-9|...` rend sans lever.

5. Deux tapes rapides sur Reglages empilaient deux overlays aux identifiants
   dupliques : l editeur ne remplissait que le premier, la croix n en fermait
   qu un. L ancien overlay est retire avant d en creer un nouveau.

6. Choisir un mode de recrutement renvoyait le panneau tout en haut. La
   position de defilement est desormais relevee puis restauree.

7. Le curseur sautait en fin de champ a chaque frappe dans la recherche de
   guildes, ce qui rendait impossible la correction d un mot au milieu. La
   position est retenue a la frappe et restauree apres le re-rendu. Les DEUX
   branches sont couvertes, celle avec resultats et celle sans, cette
   derniere etant un doublon que le premier correctif avait manque.

8. `_embAppliquerMode` etait du code mort depuis le passage en SMIL : il
   posait des classes qu aucune regle CSS ne ciblait. Le reglage « Jamais »
   n eteignait donc que ce qui etait redessine ensuite. Chaque svg porte
   maintenant son code dans `data-emb`, et le changement de mode les
   redessine tous sur place. Verifie : 20 balises d animation, 0 apres
   Jamais, 20 au retour.

## Passe du 11 octobre

- Fond du bloc Correlation aligne sur celui de la Time Capsule,
  `linear-gradient(135deg,var(--gold-bg),#F8F0E2)`, et bordure adoucie. Le
  vert des jauges et les flammes ressortent nettement mieux dessus.

- Ecran blanc a la reprise de l application, cause trouvee cote ANDROID et
  non cote web. Le theme `AppTheme.NoActionBar` portait
  `android:background = @null` et aucun `windowBackground` : entre la reprise
  de l activite et le premier rendu de la WebView, Android peignait donc du
  blanc. Trois reglages : `android:windowBackground` et
  `android:colorBackground` sur le theme, pointant une couleur
  `metanoiaFond` = #F8F4EE ajoutee dans `colors.xml`, et `backgroundColor`
  dans `capacitor.config.json` pour que la WebView elle-meme parte en beige.
  Le rechargement reste aussi long, mais il ne se voit plus.

- Quatre cosmetiques redessines dans la facture des autres items de la
  boutique, apres les avoir tous rendus cote a cote pour comparer :
  Aura de l Ombre, Bordure Doree, Aura de Feu, Sceau du Monarque. Boite de
  100, fond arrondi, ombre portee au sol, facettes en aplats franches, un
  eclat clair pour le volume, des particules pour la vie. Les quatorze
  autres ne sont pas touches, ils tenaient deja.
  Le croissant de l Aura de l Ombre est obtenu par soustraction de deux
  disques : les arcs de la premiere version debordaient de la sphere et se
  lisaient comme un anneau exterieur.

- Emojis des onglets du classement remplaces par quatre illustrations
  maison, en COULEUR : globe bleu et vert, lames acier a poignees dorees,
  coupe en or a trois tons, flamme a quatre tons. Aplats francs, deux a
  quatre tons par icone, aucun degrade, 15 px.
  Les couleurs sont fixes et ne suivent pas l etat de l onglet : chaque
  icone porte au moins un ton clair, donc le contraste tient aussi bien sur
  la pastille sombre que sur le fond clair.
  Trois partis pris avaient ete rendus cote a cote avant de trancher :
  monochrome en `currentColor`, couleur pleine, et pastille coloree. La
  version monochrome passait par des DECOUPES en masque plutot que des
  accents peints en blanc, parce qu un accent blanc disparait des que le
  fond est clair. Elle n est pas retenue, mais la lecon vaut pour toute
  icone bicolore posee sur deux fonds.

### Incident de fabrication, et ce que j en retiens

En posant ces icones j ai utilise une expression reguliere globale de la
forme `<svg ...>.*?</svg> Libelle</button>`. Appliquee en chaine, chaque
icone fraichement inseree devenait le point de depart du match suivant, qui
avalait alors la fin du bouton precedent : les quatre boutons ont fusionne en
un seul et 2 000 caracteres ont disparu. Restaure depuis la derniere archive
livree, puis rejoue par un remplacement LIGNE PAR LIGNE, borne a la ligne du
bouton vise. A retenir : sur ce fichier, ne jamais faire porter un `.*?` sur
plusieurs lignes quand on remplace en boucle.

## Correlation Energie x Reussite, deuxieme passe

- Bloc reduit d un tiers : 195 px de haut avant, 129 apres, soit 34 % de
  moins. Piste de 78 a 37 px, icone de 32 a 27, valeur de 17 a 15, marges et
  rembourrages resserres partout. La graduation tous les 25 % est conservee,
  c est elle qui permet de distinguer 93 de 98.

- Illustrations redessinees. Les precedentes etaient des traits de 2 px a 20
  ou 32 % d opacite : fines et pales, c est exactement le reproche. Les trois
  nouvelles sont des masses pleines, et forment une progression lisible d un
  seul regard. La braise : une masse basse et trapue qui ne monte plus, une
  seule volute de fumee large, un coeur a peine tiede. La flamme : droite et
  franche, avec un coeur clair et un point blanc au centre. Le brasier : deux
  langues laterales pour la masse, un coeur tres clair, et six eclats qui
  giclent autour. Une seule volute sur la braise et non deux, car a 27 px
  deux traits proches se confondaient en un crochet illisible.

- L etoile des libelles passe a l or de l application, `var(--gold)`, en
  enveloppant le caractere dans un `span` au rendu. Le libelle lui-meme n est
  pas touche.

## La croix des reglages de guilde ne faisait rien

Symptome : on modifie quelque chose, on tape la croix, rien ne se passe ; on
tape ensuite Enregistrer et c est la demande « Quitter sans enregistrer ? »
qui surgit, au mauvais moment.

Cause : `#sl-confirm-overlay` etait a `z-index:9999`, exactement comme
`guild-set-overlay`. A z-index egal, c est l ordre du DOM qui tranche, et le
panneau de reglages est ajoute a la fin du body : il passait donc DEVANT la
confirmation. La croix ouvrait bien le dialogue, mais derriere le panneau,
invisible et injoignable. Il ne reapparaissait qu une fois le panneau retire
par l enregistrement. La confirmation passe a `z-index:99990`, au-dessus de
tous les panneaux de l application.

Au passage, `slConfirm` n avait qu un seul resolveur : ouvrir un dialogue par
dessus un autre laissait le premier en suspens pour toujours, et son
appelant restait bloque. Le precedent recoit desormais `false` avant d etre
remplace.

Verifie : `elementFromPoint` au centre de l ecran renvoie `sl-confirm-box`,
z 99990 contre 9999, le titre est le bon, Quitter referme les deux, et deux
dialogues coup sur coup se resolvent tous les deux au lieu d en bloquer un.
Parcours complet verifie aussi : embleme, mode et devise modifies puis
enregistres partent bien en un `guild_settings` et un `update guilds`, les
brouillons sont consommes, et la reouverture ne declenche plus aucun
avertissement residuel.

## Retouches visuelles du 10 octobre

- Bulle du chat, la sienne : eclaircie de `#d07e45 / #ad5a28` vers
  `#e2995f / #c2743c`, avec une ombre portee sur le texte pour garder la
  lisibilite du blanc sur ce ton plus clair.

- Correlation Energie x Reussite. La piste faisait 54 px de haut sur toute la
  largeur de la colonne : trois dalles, dont une vide qui se lisait comme une
  barre. Elle est desormais etroite, 46 px au plus, haute de 78 px, creusee
  plus franchement et graduee tous les 25 %, si bien qu une piste vide se lit
  comme vide et qu on distingue 93 de 98. La jauge a du volume par un
  degrade de lumiere, la carte prend le grain de papier et l ombre portee du
  reste de l application. Aucune modification du JS, les fonctionnalites et
  le barème de couleur sont intacts.

- Trois listes gardaient encore l animation coupee : l onglet Guilde du
  classement (`_socLoadGuildRanking`), les cartes de la recherche de guildes
  (`_guildBrowseCard`) et l overlay Classement des guildes
  (`_guildShowRanking`). Elles passaient `false` en troisieme argument, un
  reste de l epoque ou les animations coutaient une keyframe CSS par
  particule. Plus aucun appel ne coupe l animation. Verifie : a 22, 26, 28,
  30, 34, 38, 54 et 58 px, 42 balises d animation emises, et 0 en dessous du
  seuil de 20 px.

- Emblemes animes dans le classement Guilde : ils y etaient rendus en 15 px
  avec l animation coupee. Passes a 22 px et animes, et le seuil d animation
  descend de 36 a 20 px.

- Chat de guilde. Treize fois « Thibs a accompli une quete » noyaient les
  vrais messages : les evenements identiques qui se suivent sont desormais
  replies en une seule ligne portant un compteur. Mesure sur un jeu de
  19 messages : 6 lignes affichees, compteurs x13 et x2.
  Matiere et contraste : grain de papier sur la feuille, en-tete sur un
  bandeau soutenu avec l embleme en 34 px anime, evenements reduits a des
  pastilles discretes, bulles detachees par une ombre portee et un filet, la
  sienne en degrade avec reflet et assise, barre de saisie avec champ creuse
  et bouton d envoi en relief. Les messages reposent sur la barre de saisie
  grace a un `margin-top:auto` sur le premier, et non a
  `justify-content:flex-end` qui casse le defilement vers le haut.

- Effets passes en SMIL, et correction de ma lecture precedente du
  diagnostic. J avais conclu que ma regle de mouvement reduit coupait tout :
  c etait faux. Les elements testes par le diagnostic ne portent AUCUNE de
  mes classes, donc cette regle ne les touchait pas, et les trois techniques
  CSS repondaient NON quand meme. La vraie cause : Android met l echelle de
  duree des animations a zero en economie de batterie, et Chromium annule
  alors toutes les animations CSS du document. SMIL est un moteur separe, il
  continue de tourner, ce que le diagnostic montrait deja.
  Les onze effets sont donc reecrits en SMIL, sans une seule keyframe, et
  `embStyles()` n injecte plus rien. Contrainte posee : chaque effet doit
  rester visible par `animateTransform` seul, la seule technique prouvee sur
  l appareil ; les animations d opacite ne sont plus qu un bonus. Les salves
  passent a 6 s, dont environ 1,5 s d activite, et 2,4 s dans le selecteur.
  Le choix Automatique / Toujours / Jamais est desormais tranche en JS avant
  le rendu : en Jamais ou en mouvement reduit, aucune balise d animation n est
  meme emise.
  Verifie par comparaison de pixels sous mouvement reduit emule, 26 captures
  par effet sur 7,3 s, soit un cycle entier : les dix effets produisent
  26 images differentes. Mes deux sondes logicielles precedentes,
  `getComputedStyle` et `transform.animVal`, ne refletent pas SMIL et
  donnaient toutes deux de faux FIGE.

- Verdict du diagnostic d animation, et vrai coupable. Sur l appareil :
  61 images par seconde, donc la WebView peint parfaitement, et
  `prefers-reduced-motion` ACTIF. Les trois techniques CSS repondaient NON et
  SMIL oui, pour une seule raison : ma propre feuille coupait toutes les
  animations CSS sous mouvement reduit, et ne couvrait pas SMIL. Les effets n
  ont jamais ete casses, ils etaient desactives expres sur un telephone en
  economie de batterie. L hypothese d une WebView qui ne repeint pas etait
  fausse, le diagnostic l a tuee.
  Correctif : reglage « Animations des emblemes » dans les Reglages, trois
  etats qui tournent a chaque tape. Automatique suit le telephone, Toujours
  anime meme en economie de batterie, Jamais coupe partout. Le choix pose une
  classe sur la racine du document, et la regle de mouvement reduit ne s
  applique plus que si le joueur n a pas force. Teste sous mouvement reduit
  emule : en Automatique `animationName` vaut `none`, en Toujours `embBrz`,
  en Jamais `none`, et l eclair garde une opacite nulle quand il est coupe.

- Ecran de demarrage. Quand Android recycle la WebView, l application se
  recharge entierement, et comme le document fait 1,5 Mo dont 1,27 Mo de
  script, l utilisateur voyait du blanc plusieurs secondes. Un ecran peint
  AVANT le gros script affiche desormais le nom et une barre de progression
  pilotee a la main, retiree a la fin du boot, avec un filet de securite a
  12 s. Cela ne rend pas le chargement plus rapide, cela supprime le blanc.
  ATTENTION, la reference structurelle change : le document compte desormais
  4 balises `<script` et 3 blocs inline, contre 3 et 2 auparavant.

- Diagnostic d animation, bouton « Animations » du panneau de test, reserve a
  l administrateur. Il mesure, sans rien croire sur parole : les images par
  seconde reellement servies par la WebView, l etat de `prefers-reduced-motion`,
  et quatre techniques testees une par une en comparant une position ou une
  opacite a deux instants, animation CSS d opacite, transform CSS sur un `<g>`
  SVG, transform CSS avec `transform-box`, et SMIL `animateTransform`. Il
  donne aussi la version du moteur et dit si on tourne dans une WebView.
  Raison d etre : « une frame par clic » signale une WebView qui ne repeint
  que sur interaction, et aucune animation ne vaut d etre dessinee avant de
  savoir laquelle de ces quatre techniques fonctionne sur l appareil.

- Effets d embleme invisibles sur telephone. Deux causes mesurees.
  Primo, la taille : une particule de rayon 1 dans le carre de 64 mesure
  0,8 px quand le blason est rendu en 52 px, et un flocon faisait 1,46 px de
  diametre a l ecran. Les effets tournaient, ils etaient simplement trop
  petits pour se voir. Correctif : un facteur d echelle `_ech` passe a chaque
  effet, 2,1 et davantage encore quand le blason est petit, plus le blason du
  bandeau qui passe de 52 a 58 px. Mesure : le flocon passe de 1,46 a
  3,43 px, l apercu de l editeur de 1,46 a 4,25 px.
  Secundo, `prefers-reduced-motion`. Le mode economie de batterie d Android
  et le reglage d accessibilite « Supprimer les animations » le declenchent
  tous les deux, et la feuille coupe alors toutes les animations, ce qui est
  voulu. Verifie par emulation : en `reduce`, `animationName` vaut `none` sur
  tous les elements d effet. Ce n est pas un defaut, mais c est la premiere
  chose a verifier quand un effet ne bouge pas.

- Regression introduite par la passe de matiere, puis corrigee. Pour que le
  grain de papier reste sous le contenu, la feuille posait
  `#s-social > * { position:relative }`. Or chaque ecran porte sa propre
  barre de navigation `.bnav`, qui est un ENFANT DIRECT de l ecran et qui est
  en `position:fixed` : la regle la repassait dans le flux, et elle se
  retrouvait au milieu de l ecran, avec du vide en dessous, uniquement dans
  l onglet Social. Correctif : le grain passe en `z-index:-1`, ce qui le
  peint sous le contenu en flux sans toucher aux enfants, et la regle sur les
  enfants est supprimee. Mesure apres correctif, sur les cinq ecrans :
  `position:fixed`, bord bas a 915 pour une fenetre de 915.

- Matiere et profondeur, onglet Social. Meme palette, mais le grain du papier
  revient en fond, les cartes se detachent par une ombre portee et un filet,
  le bandeau de guilde devient un en-tete sur un ton plus soutenu, la ligne du
  joueur est creusee au lieu d etre simplement teintee, et le bouton de chat
  prend un reflet en haut et une assise en bas.

- Panneau de test deplacable et repliable. Il s etait rempli au point de
  masquer la zone observee. Poignee en haut a gauche, glissement au doigt
  comme a la souris (pointer events avec setPointerCapture), position bornee
  au viewport et retenue dans localStorage (`metanoia_pos_test`), bouton de
  repli qui ne laisse que la barre de titre (`metanoia_repli_test`).
  Boutons reorganises en grille de 3 colonnes, largeur fixee a 338 px.
  Mesure a 430 px de large : ancien 215 x 288, nouveau 338 x 170, soit 41 %
  de hauteur en moins, et 35 px une fois replie. Libelles inchanges.

- Fuseaux horaires. Pas de reglage ajoute, par choix : le greffon monotone
  borne deja tout bond de calendrier au temps reellement ecoule. Mesure : un
  saut de fuseau de +12 h sans vol donne 0 jour rejoue, le meme saut apres
  24 h de vol en donne 1, une horloge avancee de 880 jours en donne 0. Un
  voyage vers l ouest borne l ecart a 0, le jour ne recule jamais.

- Historique des bilans. L affichage demarre a 12 entrees, un bouton « Voir
  plus » en ajoute 30 a chaque appui et disparait quand tout est affiche.
  Compteur `_BILAN_VUS`, pose du bouton par `_stBilanPlus(total)` juste apres
  le rendu. Verifie dans Chromium sur la fonction extraite du fichier, avec
  57 entrees : 12, puis 42, puis 57, bouton retire, jamais duplique. Cas
  limites passes : liste vide (message « Aucun bilan encore. » intact, pas de
  bouton), pile 12 (pas de bouton), 13 (« 1 restant », singulier).

- Cartes Cosmetique. Le violet nuit est remplace par l ambre profond,
  bordure doree double : filet exterieur `2px solid #F6D98A` et lisere
  interieur `inset 0 0 0 1px rgba(255,241,201,.5)`. Fond
  `linear-gradient(155deg,#A8560F,#D9931F)`. Touche les cartes quotidiennes
  (`.dfront.dcosmetic`, `.ddesc.dcosmetic`, `.dback-cosmetic`, coins dores)
  et, pour rester accordee, la grille `.rc.cosmetic` avec son badge et son
  bouton. Encres passees en creme : nom #FFFDF6, libelles #FFE7B0, prix
  #FFF1C9, halo d icone en rgba(255,214,130,.65). Rendu verifie dans Chromium
  sur les regles extraites du fichier, pour les trois faces et pour la grille.
  Piege rencontre : `.ddesc-icon` n heritait d aucune couleur et restait
  sombre sur l ambre, une regle dediee a ete ajoutee.

- Cartes du jour desynchronisees. Symptome : on retourne une carte, elle
  montre un objet, on la retourne encore et c est un autre objet. Cause
  mesuree : le DOM de la grille datait d un jour boutique anterieur. Le flip
  dos vers face avant ne lit rien, il se contente de tourner la carte deja
  presente, mais le flip suivant rappelle `_getDailyPicked()`, qui renvoie le
  tirage du jour courant. Le jour peut avancer sans passer par
  `renderRewards()` : `_testSetJour` (ligne 9012) ne rappelle que
  `renderMain()`, et en mode reel la bascule de 14h change `_shopDayNum()`
  alors que l ecran est deja ouvert. Correctif : la grille porte
  `data-jour`, et `_dailyGrillePerimee()` la reconstruit avant tout
  retournement et avant tout achat. Verifie dans Chromium sur la fonction
  extraite du fichier : meme jour elle laisse passer sans rien faire, jour
  avance elle reconstruit, remarque la grille, previent par un toast et
  annule le retournement, l appel suivant laisse passer, une grille non
  marquee est reconstruite sans toast, une grille absente ne leve rien.

- Reste ouvert, non corrige : `_getDailyPickedRaw` clone l item
  `mystery_fragment` pour y inscrire le nom du fragment, donc
  `_DAILY_POOL.indexOf(clone)` vaut -1 et `ST._shopDailyPickIdx` devient
  irrecuperable. Au redemarrage, le tirage du jour est donc recalcule au lieu
  d etre restaure. Le seed est deterministe, mais `filteredPool` depend de
  `_itemPurchasable`, qui depend des fragments et des titres restants : si
  l un d eux est acquis dans la journee, le pool retrecit et les quatre
  offres changent. Correctif propose : memoriser l index de l item source et
  l id du fragment, puis rederiver le clone a la restauration.

## Audit de l ecran Stats

Cinq defauts corrige, tous verifies par execution.

- `sr7` efface a chaque jour d absence. Ligne 8771, le rattrapage des jours
  manques faisait `if(ST.sr7.length>7) ST.sr7=ST.sr7.slice(-7)`, reste d une
  epoque ou sr7 ne gardait qu une semaine. Les autres points d ecriture (8395,
  8666, 14060) ne tronquent pas. Mesure : 45 jours de suivi, une seule journee
  manquee, sr7 tombe de 45 a 7 valeurs, et le « Taux 30j » de l ecran Stats
  devient un taux sur 7 jours. Borne portee a 400, comme dayLog.

- Gain XP hebdomadaire sous-estime. `_gainXp` prenait `w2[0].xp` comme
  origine, donc le gain du premier jour de la fenetre disparaissait. Mesure :
  sept jours a +30 XP affichaient 180 au lieu de 210, soit un septieme en
  moins. L origine est desormais le dernier releve anterieur a la fenetre, et
  les bornes sont reperees par numero de jour et non par position, le reste du
  bloc supposant dayLog trie. Sept cas verifies, dont un dayLog desordonne,
  un debut d historique, une semaine a trous et un releve sans champ xp.

- Heatmap desalignee des jours de semaine. Les cellules etaient empilees par
  paquets de sept depuis le premier jour affiche (`dow=i%7`), donc les
  libelles L M M J V S D a gauche ne disaient vrai que si J1 tombait un lundi,
  soit un utilisateur sur sept. Mesure : un J1 un jeudi se retrouvait sur la
  ligne « L ». La grille s ancre maintenant sur le premier releve portant un
  `dow`, et les vieilles sauvegardes sans ce champ gardent l ancien calage.
  Verifie sur 365 jours : zero cellule mal placee.

- Etiquette de la sparkline 30j. Elle annoncait toujours J(jour-29) alors que
  la courbe porte `last30.length` points. Elle suit maintenant le nombre reel
  de points, six cas verifies.

- Etiquette de la sparkline XP. « Jour 1 » etait ecrit en dur dans le HTML
  alors que dayLog est borne a 400 entrees. Elle affiche desormais le premier
  jour reellement trace.

Signale, non corrige :

- `d.absent` est lu a six endroits (9500, 9505, 9541, 14844, 14845, 15009)
  mais n est jamais ecrit dans dayLog : la notion de journee d absence n est
  branchee nulle part, tous ces filtres sont donc sans effet.
  **Perime (verifie le 15 novembre 2026) :** `absent:true` est maintenant
  ecrit, au rattrapage des journees manquees quand on revient apres plusieurs
  jours d absence. Les sept lectures ont donc un effet. Point clos.
- Zones de flow : le commentaire annonce « au moins 5 jours de donnees », le
  code teste `>=3`. Le code est le bon, le commentaire trompe le lecteur.
- Fluidite : `renderStats()` reinjecte 48 Ko de SVG pour la heatmap, mesure a
  5,5 ms sur Chromium de bureau, donc de l ordre de 25 ms en WebView. C est
  differe par `requestIdleCallback`, donc invisible a l ouverture, mais
  recalcule a chaque appui sur « Voir plus ». Non corrige : le gain ne
  justifiait pas le risque d un cache.

Hypotheses verifiees puis ecartees, pour ne pas les reprendre :

- Changement d onglet et position de defilement : teste dans Chromium avec
  des panes de hauteurs tres differentes, le defilement retombe a 0 de
  lui-meme. Pas de defaut.
- Double attribut `style` sur une cellule de heatmap : les deux conditions
  (`isToday` et cellule cliquable) sont mutuellement exclusives.
- Correlation energie et bilans de sanction : la condition d entree ne filtre
  pas `isSanction`, mais les bilans de sanction ne portent aucun champ
  `energy`, donc ils sont deja exclus.

## Audit de l ecran Social

Trois defauts corriges, tous verifies par execution.

- XSS stockee par le pseudo, chez le Maitre de guilde. La liste des membres
  transportait le pseudo dans l attribut `onclick` des boutons Promouvoir et
  Exclure, echappe pour la seule apostrophe : un pseudo contenant un guillemet
  double refermait l attribut. `_guildPromote` et `_guildKick` le passaient
  ensuite a `slConfirm`, qui l insere en HTML brut. La validation du pseudo
  est purement cliente (meme regle a l inscription et au changement), et la
  table `profiles` s ecrit en upsert direct : rien n empeche un membre de
  poser un pseudo piege. Mesure avant correction : deux attributs parasites
  injectes et du code execute au simple survol du bouton. Le pseudo est
  desormais relu dans le roster par `_guildPseudoDe(uid)` et echappe par
  `_esc` au seul endroit qui part en HTML. Apres correction : zero attribut
  parasite, zero balise creee, rien d execute.

- XP de saison mesuree sur la mauvaise periode. `_socCalcSeasonXp` renvoyait
  `_socXpGainedLastDays(14)`, une fenetre glissante de quatorze jours DE JEU,
  alors que la saison est une periode calendaire de quatorze jours. Le premier
  jour d une saison, cette fenetre portait encore treize jours de la
  precedente. Mesure : un joueur a +100 XP par jour declarait 1400 XP de
  saison le jour ou il n en avait gagne que 100, et un joueur de trois jours
  declarait tout son cumul. Le classement de saison etait donc decide par l
  activite d avant la saison. On ancre maintenant le total d XP au premier
  contact avec une nouvelle saison (`ST._socSeasonAncre`) et on compte l
  ecart. Neuf cas verifies, dont le changement de saison, la restauration d
  une sauvegarde plus ancienne (pas de gain negatif) et l idempotence (trois
  appels de suite, aucune sauvegarde superflue).

- Icone d evenement de guilde injectee en HTML brut. Dans `_guildRenderMsgs`,
  `m.body` etait echappe mais `m.icon`, pose par un client via le RPC
  `guild_event` et stocke dans le meme enregistrement, ne l etait pas.

Signale, non corrige :

- Les recompenses hebdomadaires ne sont jamais distribuees. `_SOC_TABS` vaut
  `['global','guild','season','streak']` : il n y a pas d onglet `weekly`,
  donc `_socRecordBestRank('weekly', ...)` n est jamais appele, aucune cle
  `w:` ne peut exister, et le bareme `_SOC_WEEKLY_PRIZES` (500 pts et une Cle
  du Neant pour le premier) est du code mort. A trancher : supprimer le
  bareme, ou reintroduire l onglet.
- La recompense de saison depend de la consultation. `ST._socRanks` n est
  alimente que par `_socLoadLeaderboard`, lui-meme appele seulement quand on
  clique sur un onglet, et l onglet par defaut est `global` a chaque
  ouverture. Un joueur premier de sa saison qui n ouvre jamais l onglet
  Saison ne touche rien. De plus c est le MEILLEUR rang vu lors d une
  consultation qui est retenu, pas le rang final. Correctif propose : charger
  le classement saison en arriere-plan a l ouverture de l ecran Social, et
  retenir le dernier rang plutot que le meilleur.
- Au-dela de la cinquantieme place, `myRank` reste a 0 : le joueur ne voit
  pas du tout sa position, la requete etant limitee a 50 lignes.
- Les guildes de demonstration sont concatenees au vrai classement et
  faussent les rangs. Deja marque `[DEMO]` dans le code, a retirer avant le
  Play Store.

## Audit de l ecran Identite

Trois defauts corriges, tous verifies par execution.

- Barre du prochain trait, fausse de bout en bout. Elle comparait le nombre
  TOTAL de fragments possedes a un denominateur `_nextTrait.fragNeeded||5`,
  or `fragNeeded` n existe sur aucun des dix traits et chacun demande trois
  fragments precis. Mesure : un joueur a vingt fragments dont aucun du trait
  vise lisait 5/5, barre pleine, pour une progression reelle de 0/3. On
  compte desormais les fragments DE CE TRAIT sur le nombre qu il demande.
  Sept cas verifies, dont le cas « plus aucun trait » (pas de division par
  zero).

- Total des fragments fige a 40 dans le calcul comme dans l affichage, alors
  qu un commentaire du code prevoit explicitement l ajout de fragments par
  mise a jour. Remplace par `FRAGMENTS.length`.

- Titre temporaire expire : le joueur etait desequipe meme s il avait gagne
  ce titre pour de bon entre-temps. Acheter un titre epique temporaire puis
  le debloquer legitimement le faisait disparaitre de la tete du joueur au
  bout de sept jours. La recherche ignorait aussi `NEW_TITLES_COMMON`, que le
  mode test peut accorder en temporaire. Six cas verifies.

- Titre « Aspirant » accorde trop tot. Il porte `traits:[]`, et
  `[].every()` vaut true : il tombait donc des le premier `checkFragments()`,
  soit des J1, alors qu il doit arriver a J2 avec le deblocage de l ecran
  Identite. Le marqueur `_starterTitle` etait declare mais lu nulle part. La
  boucle des titres communs teste maintenant `_isUnlocked('tab_identity')`,
  la meme condition que l onglet, pour que les deux ne divergent jamais.
  Verifie : rien a J1, accorde et annonce a J2, et un joueur qui le possede
  deja n est pas renotifie.

Signale, non corrige :

- `_buildTraitCard` divise par `tr.frags.length` sans garde. Aucun trait n a
  de liste vide aujourd hui, mais rien ne l empeche.

Verifie puis ecarte :

- Integrite des donnees : aucun id en double parmi les 40 fragments, 10
  traits et 36 titres, aucun nom de titre en double, aucune reference croisee
  cassee, tous les fragments ont une fonction `check`, et aucun id n est
  partage entre l espace des traits et celui des titres (les titres
  legendaires acceptant les deux).
- `RANKS` est strictement croissant, et la couleur du « Rang Planetaire I »,
  absente de la table, est bien rattrapee par le repli sur expression
  reguliere.
- Le rang A : j avais signale a tort qu il n existait pas. L echelle d XP du
  joueur va bien de B a S, mais le rang A est un TIER DE DONJON
  (`_DUNGEON_ORDER`, index 4), obtenable depuis #Quetes par l offset de
  `_rollDungeonChoices` (12 % au rang n+1, 3 % au n+2). Rien a corriger.
- Les dix fragments que ne reference aucun trait sont voulus.
- `_checkedTitles` est amorce au demarrage, aucun titre deja obtenu n est
  reannonce apres un rechargement.

## Audit de la Boutique

Quatre defauts corriges, tous verifies par execution.

- Duplication de boucliers. Deux lignes d une autre branche s etaient glissees
  dans `shield_1/3/5` : un dialogue « Tu t autorises... Reclamer cette
  recompense », pose APRES l activation. L annuler sortait par `return` avant
  le bloc de consommation. Mesure : bouclier 3j actif, quantite toujours a 1.
  Repetable a chaque expiration, donc bouclier gratuit a vie. Lignes retirees.

- Tout se revendait 50 pts. `_shopAddToInventory` stocke `price` et `orig`
  depuis un correctif precedent, mais AUCUN des quatorze appelants ne les
  transmet : ils valaient donc toujours 0 et `_sellInvItem` retombait sur son
  repli a 100. Le commentaire du code annoncait ce bug comme corrige, il ne l
  etait pas. On retrouve desormais les prix dans `_DAILY_POOL` par `effect`,
  ce qui couvre aussi les objets gagnes en donjon, en boite ou en recompense.
  Mesure apres correction : Elixir 30 pts au lieu de 50 (fin de l exploit),
  Reset Integrite 348 au lieu de 50 (fin de la spoliation). Balayage des 14
  objets au prix d achat le plus bas possible : zero revente rentable.

- `_shopUseItem` et `_sellInvItem` supprimaient par l index capture AVANT le
  `await` de confirmation. Si l inventaire avait bouge pendant la modale, c
  est un autre objet qui partait. On retire par la reference, avec garde sur
  -1, `splice(-1,1)` retirant sinon le dernier element.

Signale, non corrige :

- Les remises du marchand sont CONSTANTES. `_shopItemPrice` calcule
  `seed=(ST.day*137+i*31+idx*17)&0x7fffffff` puis `seed/0x7fffffff`, sans
  jamais melanger : pour des jours realistes le quotient vaut ~0,00001, donc
  `Math.round(rng*20)` vaut toujours 0. Mesure sur 2000 jours, 6 positions et
  4 marchands : la remise marchand vaut toujours exactement 10 % et la faveur
  toujours exactement 20 %, contre les 10 a 30 % et 20 a 35 % annonces par le
  code. Il faudrait atteindre le jour 391 877 pour voir le premier cran. Le
  reste du fichier utilise pourtant un vrai generateur
  (`seed*1103515245+12345`) dans `_getDailyPickedRaw`.
  ATTENTION : corriger ce melange seul ROUVRE l achat-revente rentable.
  Mesure avec le generateur corrige : 6,8 % des combinaisons deviennent
  profitables, jusqu a +32 pts par cycle sur le Reset Integrite, parce que le
  prix plancher tombe a 45,5 % du prix d origine alors que la revente est a
  50 %. Les deux corrections vont donc ensemble : melanger le seed ET
  plafonner la revente au prix reellement paye (ou la ramener a 40 %).

- `price` et `discount` des 30 objets du catalogue ne sont lus nulle part :
  tout le code passe par `item.orig||item.price`, donc `orig` gagne toujours.
  Les `-25%` inscrits dans les donnees sont decoratifs.

- `activate_shield` est le seul effet absent de `_DAILY_POOL` : les boucliers
  gardent donc le repli de revente a 50 pts.

## Remises du marchand, nouvelles bornes

Remise marchand ramenee a 5-10 %, faveur a 10-20 %, et le seed est desormais
melange par le generateur deja utilise dans `_getDailyPickedRaw`. Verifie sur
400 jours, 6 positions, 4 marchands et 10 prix : les six valeurs de remise
marchand et les onze de faveur sont toutes parcourues. Le prix plancher vaut
0,90 x 0,80 = 72 % du prix d origine, contre une revente a 50 %, donc zero
combinaison rentable a l achat-revente sur 96 000 testees.

## Audit de l ecran Quetes

Trois defauts corriges, tous verifies par execution.

- Un echec de quete principale comptait DOUBLE pour les donjons. Dans `trig`,
  `if(q2.type==='disc')ST.weeklyBoss.discFail=...;_dngFail();` : le `if` sans
  accolades ne couvrait que l incrementation de `discFail`, donc `_dngFail()`
  tombait pour toute quete principale echouee, en plus de l appel place en
  tete de la branche. Mesure : trois echecs reels donnaient un compteur a 6,
  et un donjon « max 3 fail » etait perdu alors que le plafond etait respecte.
  Les echecs de quetes secondaires, eux, comptaient juste.

- XP et points farmables a l infini. La garde de `trig` bloquait perfect vers
  clear, mais laissait passer perfect vers fail, puis fail vers perfect : le
  cycle creditait a chaque tour sans jamais reprendre. Mesure : dix cycles sur
  une seule quete donnaient 180 XP, et avant le jour 15, ou l echec ne coute
  ni points ni integrite, les points montaient aussi, 220 contre 100 au
  depart. Apres le jour 14 l XP restait farmable, seuls les points devenaient
  perdants. Une quete validee ne peut plus etre repassee en echec ; corriger
  un clic malheureux reste possible dans l autre sens. Matrice des six etats
  verifiee.

- Taux du Top/Flop au-dessus de 100 %. `questLog[].gen` est incremente par
  `advDay` en FIN de journee, `ok` par `trig` PENDANT la journee : un joueur
  parfait avait donc toujours ok = gen+1. Mesure : 200 %, 150 %, 133 %,
  125 %... le premier taux reellement affiche etant 150 % au jour 3. Le
  denominateur est borne par `Math.max(gen, ok)`.

Signale, non corrige :

- Asymetrie de la penalite d echec. Dans `trig`, echouer une quete principale
  apres le jour 14 coute 5 points d integrite ET 15 points. Dans `advDay`, l
  auto-echec d une quete laissee sans reponse ne coute que l integrite. Ne
  rien faire est donc moins punitif que de marquer honnetement son echec. A
  trancher : aligner `advDay` sur `trig`, ou retirer les 15 points de `trig`.

## Arbitrages tranches et bugs du 11 octobre

- Penalite d echec unifiee. Rater une quete obligatoire coute 5 points d
  integrite, et plus aucun point, quel que soit le chemin. Il y en avait
  TROIS, pas deux : `trig` (declare), `advDay` (bascule du jour) et
  `submitReview` (quetes non traitees au bilan). Les deux premiers retiraient
  15 points, le troisieme aussi et sans la franchise des quatorze premiers
  jours. Les trois appliquent maintenant la meme regle.

- Datation et evenements du mode test, meme cause. `_logDate` figeait une
  epoque au premier appel, puis chaque +1j ajoutait un jour a `ST.day` sans
  avancer le calendrier : la date projetee derivait, et le jour courant
  finissait dans le futur (mesure : jour 1033 date au 21/11/2026 alors qu on
  etait le 11/10). Deux consequences : la heatmap affichait des dates fausses,
  et `_evDateDecalee(0)` lit cette date pour choisir l evenement du jour alors
  que hors mode test il lit `new Date()`. Couper le mode test changeait donc
  la source, l evenement disparaissait de l ecran mais ses effets restaient
  acquis. Le jour courant est desormais ancre sur aujourd hui, le jour N-1 sur
  hier, et basculer le mode test ne change plus l evenement. `ST._dayEpoch`
  disparait.

- Notifications. L ecran Parametres ne lisait que l API web `Notification`,
  que la WebView Android n expose pas toujours : la pastille restait eteinte
  et l activer repondait « Notifications non supportees sur cet appareil »
  alors que le greffon `@capacitor/local-notifications` etait present et
  fonctionnel. `toggleNotif` passe maintenant par le greffon quand il existe,
  et une sonde silencieuse au demarrage (`checkPermissions`, qui ne declenche
  aucune demande) renseigne la pastille des le lancement.

- Animations des emblemes : toujours actives, pour tout le monde. La ligne de
  reglage a trois etats est retiree des Parametres, ainsi que son rendu.

- `slConfirm` : un `cancelLabel` vide masque desormais le bouton. La chaine
  vide etant falsy, le `||` remettait « Annuler » : la fiche Confidentialite
  et donnees, qui demandait deja un seul bouton, en affichait deux.

- Plafond monotone. Le `floor` strict comptait des tranches de 24 h et non des
  minuits franchis : fermer a 23h et rouvrir a 13h le lendemain donnait 14 h,
  donc plafond 0, donc passage de jour bloque ET utilisateur marque suspect
  pour un usage normal. On ajoute ce que le jour avait deja consomme a la
  derniere note (`horloge.msJour`), credit borne a moins de 24 h, qui ne peut
  donc jamais offrir plus d un jour. Huit cas verifies, dont la fraude
  classique (montre avancee de 24 h, app fermee a 23h, reouverture une minute
  apres) qui reste bloquee.

- Journal des incidents d horloge. Les cinq points de mise en doute
  consignent desormais un incident date dans `ST._horlogeIncidents` (borne a
  40). L ecran de diagnostic affiche le compte et propose « Signaler a
  l assistance », qui ouvre le client mail prerempli vers
  metanoia.assistance@gmail.com. Aucun envoi automatique n est possible :
  l application n a pas de service d envoi, seul le client mail du telephone
  peut expedier. Le journal part aussi vers Supabase avec le state_blob.

- Recompenses de classement : uniquement en fin de saison. Le bareme
  `_SOC_WEEKLY_PRIZES` est supprime, les vieilles cles « w: » sont
  neutralisees sans rien verser, et `_socRecordBestRank` retient le DERNIER
  rang connu au lieu du meilleur jamais apercu.

- Rang de saison note en arriere-plan. `_socNoterRangSaison()` est appele a
  l ouverture du Social, quel que soit l onglet affiche : un joueur premier
  qui n ouvrait jamais l onglet Saison ne touchait plus rien.

- Rang visible au-dela de la cinquantieme place. `_socRangExact(tab)`
  interroge le serveur en comptage pur (`head:true`, aucune ligne rapatriee,
  donc aucun risque pour le quota) et une ligne « toi » est ajoutee avec le
  numero exact.

- Conseil du Sage. Une secondaire ACCOMPLIE ne peut plus etre remplacee : le
  statut etait efface sans controle, donc on encaissait XP et points, on
  remplacait la quete, et on encaissait de nouveau. En echec ou en partie, le
  remplacement reste permis.

- Instantane « avant-deconnexion ». `_socLogout` le prenait mais rien ne le
  rejouait. `_snapVeillerDeconnexion()` compare au retour et propose la
  restauration quand l instantane est plus avance que la progression en
  place, une seule fois par instantane.

- `_buildTraitCard` : `0/0` donnait `NaN`, donc `width:NaN%`, que le
  navigateur ignore, soit une barre vide sans explication. Garde posee.

## Evenements : regression de mon correctif, puis correction reelle

Ancrer `_logDate` sur aujourd hui reglait la heatmap mais CASSAIT les
evenements en mode test : la date de tirage ne bougeait plus d un jour simule
a l autre, donc meme jour de semaine, meme cle de semaine, donc le meme
evenement en boucle, et aucun si la journee reelle n en portait pas. C est la
regression signalee immediatement apres livraison.

Deux pieces, parce que le probleme etait double.

- La date d AFFICHAGE et la date de TIRAGE sont separees. `_logDate` reste
  ancre sur aujourd hui et sert a l historique et a la heatmap, qui doivent
  montrer des dates passees plausibles. `_evDateDecalee` derive desormais, en
  mode test, une date du NUMERO de jour (`_EV_EPOQUE_TEST`, calee a midi pour
  qu aucun fuseau ne fasse basculer le jour), pour que chaque jour simule tire
  son propre evenement. Cette date n est jamais affichee.

- L evenement du jour est FIGE dans l etat (`ST._evFige = {j, id}`), au
  premier calcul de la journee. Il etait recalcule a chaque affichage, et la
  source de date differait selon que le mode test etait actif : le couper
  faisait disparaitre l evenement de l ecran alors que ses effets etaient deja
  encaisses. Fige, il ne peut plus changer en cours de journee, ni en
  basculant le mode test, ni en changeant de fuseau. Les previsions du
  lendemain (offset non nul) ne sont pas concernees.

Mesures apres correction :

- Mode test, 14 jours simules : huit types d evenements distincts, les jours
  defilent bien avec leurs evenements.
- Un jour simule portant `easyDay` le GARDE apres coupure du mode test, et
  sur trois lectures consecutives.
- Le figeage ne rejoue pas le tirage : trois appels le meme jour, une seule
  sauvegarde.
- Taux de drop sur 730 jours : 62,5 % de jours avec evenement hors mode test,
  58,5 % en mode test, l ecart tenant a l echantillonnage. Repartition
  conforme aux seuils annonces (doubleXP 13 %, easyDay 12 %, hardMode 11 %,
  double_pts 10 %, frenzy 8 %, shadow 5 %, lucky 3 %).
- Garantie de deux evenements par semaine calendaire : minimum observe 2 sur
  52 semaines completes, moyenne 4,16, aucune semaine en dessous.
- Plus longue serie sans evenement : 6 jours, identique dans les deux modes.

## Lot du 14 octobre

- Dates en double dans la heatmap. La date etait HORODATEE au moment de l
  ecriture de l entree : plusieurs jours de jeu enregistres le meme jour reel
  portaient donc la meme date. Cela arrive avec le mode test, mais aussi hors
  mode test, le rattrapage d absence poussant N entrees d un coup avec
  `_logDate`, qui ignore son argument. D ou deux entrees au 12/10 et un jour
  courant date de la veille. `_dateDeJour(n)` compte desormais a rebours
  depuis aujourd hui, a l AFFICHAGE : chaque jour a sa date, le jour courant
  est aujourd hui. La date stockee reste en repli.

- Sanction muette. Deux causes, mesurees sur les trois chemins.
  `window._TEST_MODE` exemptait TOUTE la session : en mode test, aucune
  sanction ne pouvait tomber, meme sur un jour reellement vecu. Seuls les
  jours FABRIQUES par le panneau doivent l etre, et c est ce que porte
  `_testExemptDay` ; les lots +7j et +30j restent proteges autrement, car
  `_testAutoOneDay` pose `reviewDone=true` avant d appeler advDay.
  Seconde cause, plus sournoise : une sanction restee en attente rend muets
  les TROIS chemins a la fois, tous testant `!ST.sanctionPending`. Un etat
  incoherent (texte vide) ou perime bloquait donc le mecanisme entier en
  silence. `ST.sanctionJour` est memorise et une purge au demarrage nettoie,
  verifiee sur six cas (la sanction d hier est conservee, celle de trois jours
  purgee).

- L ecran de sanction nomme les quetes manquees. Il annoncait un nombre sans
  jamais dire lesquelles.

- Plume de Sagesse : nouvel effet, « ton prochain jour rate ne casse pas ta
  serie ». L ancien +10 % XP sur 3 jours doublonnait avec l Elixir
  d experience. La serie est entamee a CINQ endroits (bilan du soir,
  rattrapage, ouverture tardive, deux chemins de cloture) : tous passent
  desormais par `_plumeProtege()`, qui consomme la protection une seule fois.
  Verifie : avec la plume, un jour rate laisse la serie a 12 au lieu de 11 ;
  quatre jours rates la ramenent quand meme a zero.

- Ecran blanc au retour au premier plan. Meme cause que les animations CSS :
  la WebView Android ne repeint que sur interaction. Un voile dedie
  (`#repaint-kick`, z-index -1, sans pointer-events) voit son opacite varier
  de maniere imperceptible pendant quatorze images au retour, ce qui invalide
  la surface. On ne touche NI a `body` NI a `documentElement` : une opacite ou
  une transformation sur l un d eux creerait un contexte d empilement et
  deplacerait tous les `position:fixed`, dont la barre de navigation, qui est
  un enfant direct de chaque ecran - c est la panne deja vue en septembre.
  Branche sur `appStateChange` de Capacitor, `pageshow`, `focus` et
  `visibilitychange`. Verifie dans Chromium : la barre du bas reste collee au
  bas pendant et apres le reveil, le defilement est conserve, les clics
  traversent le voile.

## Audit de l ecran Quetes, second passage

Trois defauts corriges, tous verifies par execution.

- Le melange des jours n en etait pas un. `genWeek` placait les grosses
  seances avec `sort(() => Math.random()-0.5)`, un comparateur incoherent qui
  ne produit PAS une permutation uniforme. Mesure sur 60 000 tirages de six
  jours : le lundi arrivait en premiere position 28,9 % du temps contre 16,7 %
  attendus, et le samedi en seconde position 5,2 %. Les grosses seances
  tombaient donc nettement plus souvent en debut de semaine. Un melange de
  Fisher-Yates (`_melanger`) remplace les QUATRE occurrences du motif : deux
  dans `genWeek`, deux dans l injection des quetes d arc. Apres correction,
  l ecart est de 16,4 a 16,9 % partout.

- Le doublement des points dependait du canal. `ptsV` passait la Potion de
  double points et l evenement NATUREL par un meme OU, mais ajoutait un second
  x2 pour l evenement FORCE par Prediction. Mesure sur une quete body a 2
  points : potion seule 4, potion + evenement naturel 4, potion + evenement
  force 8. Le doublement s applique desormais au plus une fois, quelle que
  soit sa source ; shadow reste cumulable, c est un effet distinct. Huit cas
  verifies, dont la combinaison naturel double_pts + force shadow, inchangee
  a 6.

- Quota « En partie » incoherent entre les quetes. `_enGalere` etait declare
  DANS la branche des quetes non-negociables, mais relu plus bas par le De du
  Destin, qui rend obligatoires AUSSI l eau et les secondaires. Pour ces
  quetes-la, la variable valait `undefined` et le quota retombait a 2 : le
  meme jour, un joueur en difficulte lisait « En partie(3) » sur sa quete body
  et « En partie(2) » sur sa quete eau. Le calcul passe par `_quotaPartiel()`,
  appele aux deux endroits.

Verifie et sain :

- Le creneau horaire, sur les 24 heures de debut possibles : toujours 16
  heures couvertes, y compris quand la fenetre enjambe minuit (20h donne bien
  20h-11h).
- `getToday()` et l indexation du plan hebdomadaire, avec son garde-fou.
- `_claimDungeon` : le drapeau `claimed` est pose apres la distribution, mais
  toute la fonction est synchrone, donc aucune double reclamation possible.
- `_ensureHardModeQuest` : garde contre le doublon effective.
- Les 318 identifiants lus par `getElementById` : 48 ne sont pas declares
  dans le HTML statique, mais ce sont des couches creees dynamiquement ou du
  code mort assume, et AUCUN n est lu sans garde. Aucune exception silencieuse.
- Les compteurs de serie de donjon : un seul chemin actif, protege par
  `_lastCountedDay` ; le bloc du bilan est neutralise par un `if(false &&`
  volontaire.

Signale, non corrige :

- Indicateur de synchronisation du Social : REBRANCHE. `_socUpdateSyncBar`
  existait et etait appelee a dix endroits, mais ses deux elements
  (`soc-sync-dot`, `soc-sync-label`) n avaient jamais ete declares : la
  fonction sortait sur son garde et n affichait rien. La barre est posee sous
  la carte profil. Verifie dans Chromium sur la fonction extraite du fichier :
  les quatre etats donnent la bonne couleur et le bon libelle, gris au repos,
  or pendant la synchronisation, vert au succes, rouge a l erreur, et un etat
  inconnu retombe sur le repos. Un point a noter : les libelles de la fonction
  sont ecrits sans accents (« Sync auto activee », « Synchronise »), sans
  doute parce qu ils n avaient jamais ete relus a l ecran. Je n y touche pas,
  c est du texte.
- Code mort assume, documente dans le fichier : `xp-nxt`, `s-streak`, `slbl`
  et `s-shop` (l ecran boutique s appelle `s-rewards`).

## Classement de Saison casse, 15 octobre

Thibs signale trois symptomes sur l onglet Saison du Social : les comptes de
demonstration affichent tous 0 XP, lui-meme avec plus de cent points de
saison n apparait pas en tete, et il n a jamais vu l ecran de resultat de fin
de saison.

La cause des deux premiers est une faute de frappe a deux endroits.
`_demoMergeRanking` triait sur `xp_season` et `_demoHunters` fabriquait un
champ `xp_season`, alors que la colonne s appelle `season_xp` partout
ailleurs (neuf occurrences). Consequences : `_socRowValue` lit `season_xp`,
donc chaque chasseur de demonstration valait 0 ; et le tri de saison comparait
une cle que personne ne porte, donc il ne triait rien.

Troisieme point, independant : Thibs etait absent des lignes renvoyees par le
serveur (son `season_id` etait perime), et le repli `_socRangExact` que j
avais ajoute affichait alors « #1 » sous la vingt-cinquieme place, ce qui est
incoherent.

Trois corrections, verifiees par execution :

- `xp_season` renomme en `season_xp` aux deux endroits. Apres coup, les
  demonstrations affichent de vraies valeurs (1431, 1404, 1377...) et plus
  aucune ligne a 0.
- Nouvelle fonction `_socAssurerMaLigne(rows, tab)`, appelee juste apres
  `_demoMergeRanking`, qui insere le joueur courant a partir de ses valeurs
  locales quand le serveur ne l a pas renvoye, puis retrie. Thibs apparait
  desormais a la douzieme place dans la liste elle-meme.
- La ligne « hors classement » du bas n est plus affichee que si le rang
  depasse 25.

Structure revue apres coup : 4 balises `<script`, 3 blocs en ligne, `node
--check` passe sur les trois, analyse lxml valide, cadratins a zero.

## Grade de Second, rond de profil dans la guilde, 16 octobre

Trois ajouts demandes par Thibs sur le Social.

**Le grade de Second.** Hierarchie a trois etages : Maitre > Second > Membre,
sans plafond sur le nombre de Seconds. Une seule fonction decide du rang,
`_gldRang`, et tout le reste en decoule : `_gldPeutAgir(role)` exige un rang
strictement superieur, donc un Second ne peut pas exclure un autre Second ni
toucher au Maitre ; `_gldPeutRecruter()` ouvre l etat de recrutement et les
demandes d adhesion au Maitre et au Second. L emblem et la devise restent au
Maitre seul. Matrice verifiee par execution, les neuf combinaisons :

    moi      cible    agir    recruter
    owner    owner    false   true
    owner    second   true    true
    owner    member   true    true
    second   owner    false   true
    second   second   false   true
    second   member   true    true
    member   *        false   false

Changement de comportement a signaler : avant, **n importe quel membre**
pouvait accepter ou refuser une candidature. C est desormais reserve au
Maitre et au Second, sans quoi donner ce pouvoir au Second ne voudrait rien
dire. Le texte du mode « sur demande » a ete corrige en consequence.

**Le rond dans la liste de guilde.** Le meme `.soc-lb-avatar` que les
classements Serie et Global, en 30 px, pose entre le numero et le pseudo. Un
clic dessus ouvre le profil du joueur, avec `event.stopPropagation()` pour ne
pas declencher le menu de la ligne. Le reste de la ligne garde le systeme
actuel : clic sur le pseudo pour promouvoir ou exclure.

**Le profil joueur.** `_openUserProfile` existait deja, ouvert depuis les
classements. Ajoute : la serie, la devise de la guilde sous son nom, et un
blason gris par defaut pour les chasseurs sans guilde (`_blasonGris`, qui
reprend l ecu `EMB.CAD[1]` en pierre grise, sans symbole ni animation).
« Record » devient « Top global », qui est bien ce que mesure `best_rank`.
Tant que `user_public_profile` ne renvoie pas `streak`, la case affiche un
tiret et non un zero : un zero affirmerait une serie cassee.

**Ce qui manque cote serveur.** Les roles vivent dans Supabase et le depot ne
contient aucun SQL. Il faut : autoriser `second` dans la contrainte de
`guild_members.role`, creer `guild_set_role(p_user, p_role)`, et modifier
`guild_kick`, `guild_settings`, `guild_request_decide` et
`user_public_profile`. Je n ai jamais vu le corps de ces quatre fonctions,
donc je ne les ai pas reecrites a l aveugle : Thibs doit d abord executer un
bloc d inspection. Tant que le SQL n est pas pose, le client degrade
proprement (le bouton « Nommer Second » renvoie une erreur, rien d autre ne
casse).

## Retouches du Second, 16 octobre

Retours de Thibs apres installation.

- « Retirer le grade » devient « Retrograder Membre », et la confirmation
  suit : titre « Retrograder en Membre ? », bouton « Retrograder ».
- Le texte vu par un membre simple dans les reglages parle maintenant du
  Maitre « et son ou ses Seconds », puisque leur nombre n est pas plafonne.
- `.gact-pop` debordait. Avec trois boutons, la bulle d actions depassait a
  droite et il fallait faire defiler la liste pour atteindre « Exclure ». Elle
  passe en `flex-wrap:wrap` avec `max-width:calc(100% - 56px)` et
  `white-space:normal`. Mesure apres coup a 430 px : bulle de 334 px de large,
  86 px de haut, deux lignes, `scrollWidth` du document inchange a 430.

Confirme par Thibs sur l appareil : la nomination d un Second fonctionne, et
un Second peut bien changer l etat de recrutement.

## La garde anti-triche, telle qu elle est reellement

Etabli le 16 octobre en lisant le serveur, parce que rien de tout cela n est
dans le depot. A connaitre avant de toucher au Social.

Le classement ne lit pas `profiles` mais une vue `classement`, definie
`select ... from profiles where suspect = false`. Un profil marque disparait
donc de TOUS les classements, pas seulement de celui de saison.

Trois declencheurs `BEFORE` sur `profiles`, executes dans l ordre
alphabetique de leur nom : `a_reject_stale_client_rev`, `b_garde_partage`,
`trg_guard_progress`, puis `zz_exempt_dev_suspect` que j ai ajoute.

`garde_partage` est la vraie garde. Seaux de jetons separes sur l XP, la
serie, les points et les objets ; elle ECRETE au lieu de refuser, pour que la
sauvegarde personnelle passe quand meme, et journalise tout dans
`fraude_journal` avec l IP et l agent. Le piege est a la ligne
`if v_gel and coalesce(old.suspect,false) then v_budget := 0` : une fois
marque, le budget d XP tombe a zero DEFINITIVEMENT, donc chaque
synchronisation redeborde et remarque. Un compte ne sort jamais de cet etat
tout seul, et `v_accepte` restant a 0, ni `xp_weekly` ni `season_xp` ne
peuvent plus croitre. C est la raison du `season_xp = 0` observe.

`guard_profile_progress` n ecrit pas `suspect`. Il annule silencieusement
toute mise a jour qui divise la progression par plus de cinq, par un
`return null`. Piege latent : le client croit avoir sauvegarde, le serveur n
a rien ecrit, personne n est averti.

Le compte Thibs avait ete marque, puis gelé depuis le 11 octobre : motif
`xp_gel`, 30976 XP envoyes, 17751 acceptes, 13225 d ecart a chaque envoi. Une
derogation a ete posee dans `garde_partage` pour les comptes de
developpement, qui sortent avant toute garde. A retirer avant une ouverture
publique.

## Un repere « C est toi » dans le profil

Ouvrir son propre profil depuis un classement ou depuis la liste de guilde ne
donnait aucun indice qu il s agissait de soi. Une pastille vermeil est posee
a cote du pseudo quand `userId` vaut celui du compte connecte. Le pseudo
passe en `text-overflow:ellipsis` pour que la pastille ne soit jamais
poussee hors de l ecran. Mesure a 430 px avec le pseudo le plus long
observe : aucun debordement horizontal.

## Navigation entre profils, 16 octobre

- L onglet de classement « Guilde » devient « Guildes ». Il classe des
  guildes, pas une guilde.
- Le bloc guilde du profil joueur passe d une ligne de tableau a une carte :
  blason en 54 px au lieu de 26, nom en Cinzel 17 px, devise entre
  guillemets. Sans guilde, l ecu gris et « Ce chasseur avance seul ».
- Cette carte est cliquable et ouvre `_guildOpenPublicProfile`, qui existait
  deja et dont les cartes de membres appellent `_openUserProfile`. La boucle
  joueur vers guilde vers joueur est donc fermee. `_profileShell` appelle
  `_profileCloseAll` en entree, et `_scrollLockOn` est compte, donc enchainer
  les feuilles ne derègle pas la position de defilement du fond.
- Les cartes de membres du profil de guilde affichent SECOND, en plus de
  MAITRE.

Limite assumee : il n y a pas de retour. Chaque feuille remplace la
precedente, donc fermer ramene a l ecran, pas au profil d ou l on venait.

## Guilde peuplee a l essai, sous-onglets inverses, 16 octobre

`_demoMembresGuilde()` reprend les quinze premiers chasseurs de
`_demoHunters()` et les met a la forme du roster : `user_id`, `pseudo`, `xp`,
`role`. Le troisieme recoit le grade de Second, sans quoi le grade ne se
verrait jamais a l essai. Le rendu les concatene au roster reel puis retrie
par XP decroissante, et le compteur de membres compte la liste affichee.

J avais d abord reserve l injection au mode test. C etait trop prudent et
incoherent avec le reste : les chasseurs de demonstration des classements
sont permanents, pilotes par le seul `_DEMO_ON`. Les membres factices suivent
donc le meme interrupteur, et `_DEMO_ON = false` fait tout disparaitre d un
coup.

La garde qui reste, elle, est necessaire : un faux membre n est jamais
actionnable (`!m._demo`), donc aucun appel a `guild_kick` ou
`guild_set_role` ne peut partir sur un identifiant qui n existe pas en base.

Mesure a 430 px avec deux membres reels : 17 sur 30, sept lignes visibles, le
reste au defilement dans la zone de 340 px, aucun debordement horizontal.

Le sous-titre du chat continue de compter les membres REELS, ce qui est
correct : on ne discute pas avec des chasseurs factices.

Les sous-onglets du Social sont inverses : Guilde d abord, Classements
ensuite. L onglet ouvert par defaut reste Classements.

## Un compte marque le sait enfin, 16 octobre

Jusqu ici, un joueur marque `suspect` disparaissait de tous les classements,
voyait son XP publique gelee a vie, et n en etait jamais informe. Il en
concluait que l application etait cassee. Trois pieces corrigent ca.

`_fraudeVerifier()` est appelee a la fin de `_socLoadProfile`, qui lit deja
la ligne complete du joueur. Elle compare `_socProfile.suspect` a
`ST._compteEnRevue` et n agit QUE sur un changement d etat : une
synchronisation qui ne change rien n ecrit rien. Les cles d Activite
`revue:on:<id>` et `revue:off:<id>` sont liberees l une par l autre, donc un
compte peut etre marque, reabilite, puis remarque, et chaque bascule produit
une entree.

Transitions verifiees par execution, sur la vraie fonction extraite du
fichier :

    jamais marque        pas de banniere, aucune entree
    marque               banniere + 1 entree
    deux syncs de plus   toujours 1 entree (pas de doublon)
    reabilite            banniere retiree + entree de resolution
    remarque plus tard   nouvelle entree

Le bandeau `#soc-revue-banner` est pose au-dessus des onglets de classement,
affiche par `_socRenderConnected` selon `ST._compteEnRevue`. Il porte un
bouton vers `_fraudeContacter()`, qui ouvre un courriel prerempli vers
l assistance avec l identifiant du compte, le pseudo, le jour de jeu et la
version. L identifiant est ce qui permet de retrouver la ligne dans
`fraude_journal` cote serveur. Mesure a 430 px : aucun debordement.

Au passage, le veilleur de guilde ne signalait que le titre de Maitre. Il
annonce maintenant aussi la nomination et le retrait du grade de Second.

Ce qui n est PAS fait : l envoi d un courriel AU joueur au moment du
marquage. Postgres ne sait pas envoyer de courrier ; il faut un service
externe. Decision en attente.

## Le cron fantome des notifications, 16 octobre

Trouve en remontant des 401 dans `net._http_response`. Un job pg_cron,
`metanoia-reminders`, appelait l Edge Function `send-reminders` toutes les
quinze minutes. Il n envoyait que `Content-Type` et `x-cron-secret`, pas
`Authorization` : la passerelle des Edge Functions de Supabase exige un JWT
AVANT d executer la fonction, donc la fonction n etait jamais atteinte.
Quatre-vingt-seize echecs par jour.

Le piege qui l avait cache : `cron.job_run_details` affichait `succeeded` a
chaque fois. pg_cron rapporte le succes du SQL, et le SQL etait un
`select net.http_post(...)`, qui reussit toujours puisqu il ne fait que
mettre la requete en file. Le resultat HTTP arrive ailleurs, dans
`net._http_response`. Un cron vert pour un echec total.

Sans importance au fond, parce que `send-reminders` est le chemin Web Push de
l epoque PWA : `_pushSaveViaRPC` envoie `endpoint`, `p256dh` et `auth`, les
trois elements d un abonnement de service worker. Dans la WebView Capacitor,
`pushManager.getSubscription()` ne renvoie rien, donc aucun abonnement n a
jamais ete enregistre et la fonction travaillait sur une table vide. Les
notifications actuelles passent par `LocalNotifications`, planifiees sur
l appareil, sans serveur.

Job supprime par `select cron.unschedule('metanoia-reminders')`. L Edge
Function est conservee : elle ne coute plus rien et servira si des
notifications poussees depuis le serveur reviennent un jour.

Code mort cote app, consequence de la meme bascule : tout le sous-systeme
Web Push. Retire le 16 octobre, 5001 caracteres.

Je n avais d abord nomme que trois fonctions a Thibs. En verifiant avant de
supprimer, `_pushSaveViaRPC` avait encore un appelant vivant, `_pushSubscribe`,
lui-meme appele depuis six endroits dont les reglages. Retirer trois fonctions
isolees aurait laisse un appelant sans appele. Le bloc entier est donc parti :
`PUSH_VAPID_PUBLIC`, `_pushB64ToU8`, `_pushLocalDate`, `_pushTz`,
`_pushNNRemaining`, `_pushSubscribe`, `_pushDungeonStart`, `_testNotif`,
`_pushSaveViaRPC`, `_pushSyncState`, `_pushSyncStateThrottled`, les six
appels gardes, le desabonnement dans `toggleNotif` et le bouton « Test notif »
du panneau de test.

Verifications apres coup : zero reference restante a `_push*`, `_testNotif` ou
`pushManager` dans tout le fichier ; `_testGrantTitles`, `_notifPrompt`,
`toggleNotif`, `_saveFlush` et `scheduleNotif` ont survecu ; `node --check`
passe sur les trois blocs. `toggleNotif` reste coherent : chemin natif par
`_notifNatifPlanifier`, chemin web par `scheduleNotif`.

## La chaine de courriel, 16 octobre

Un compte marque recoit desormais un courriel, en plus de l entree d Activite
et du bandeau poses le matin meme. Etat final de la chaine, cote serveur :

Le domaine **metanoia-app.com** a ete achete chez IONOS, qui heberge aussi
la zone DNS. Trois enregistrements y ont ete poses pour Resend, tous relatifs
a l envoi : `TXT resend._domainkey` pour la signature DKIM, `MX send` vers
`feedback-smtp.eu-west-1.amazonses.com` priorite 10, et `TXT send` portant
`v=spf1 include:amazonses.com ~all`. La region Resend est eu-west-1, ce qui
correspond au MX.

Point a retenir pour plus tard : le courrier d IONOS vit sur la RACINE (MX
`mx00`/`mx01.ionos.fr`, SPF sur `@`, DKIM sur `s1-ionos`/`s2-ionos`) tandis
que Resend vit sur le sous-domaine `send` et sur `resend._domainkey`. Aucune
collision, les deux cohabitent. Rien ne doit etre supprime dans la zone.

Aucune boite aux lettres n a ete creee. Les messages partent de
`assistance@metanoia-app.com` pour la delivrabilite, avec un champ `reply_to`
vers `metanoia.assistance@gmail.com` : la reponse d un joueur arrive donc
dans la boite deja consultee, sans redirection ni abonnement.

Il n y a plus aucune cle a saisir nulle part. La cle Resend vit dans le
coffre Supabase sous le nom `resend_api_key`, et les deux fonctions la lisent
par `vault.decrypted_secrets`. La table `mail_config` que j avais proposee
faisait doublon avec cet existant : elle a ete supprimee, ainsi que la
fonction `envoyer_mail`.

Verifie par execution : deux reponses 200 dans `net._http_response`, l envoi
de test a 08:04:59 UTC et le cron quotidien `metanoia-alerte-fraude` a
08:00:00.

Correction d une affirmation fausse de ma part le matin meme : j avais ecrit
qu aucun chemin ne ramenait un compte marque a la normale. C est faux,
`metanoia_annuler_triche` et `metanoia_blanchir` existent, et l alerte
quotidienne donne meme la commande prete pour chaque profil. Ce qui manquait
etait la moitie joueur, pas la moitie serveur.

## Un compte en revue ne se reinsere plus dans les classements

Defaut introduit par ma propre correction de la veille, vu sur l appareil
pendant le test de bout en bout : le compte marque etait bien exclu de la vue
`classement` cote serveur, mais `_socAssurerMaLigne` l y remettait depuis les
valeurs locales. Il s affichait donc PREMIER du classement Global, juste sous
le bandeau lui annoncant que ses classements etaient suspendus.

`_socAssurerMaLigne` sort maintenant immediatement si `ST._compteEnRevue`.
Trois cas verifies par execution sur la vraie fonction :

    compte normal                     insere, rang 1
    compte en revue                   non insere, liste inchangee
    en revue mais renvoye par serveur affiche quand meme

Le troisieme cas est voulu : si le serveur renvoie la ligne, c est que le
compte n est plus exclu, et c est lui qui a raison contre un drapeau local
qui n aurait pas encore ete rafraichi.

## Le bandeau de revue passe au vert, 16 octobre

Demande de Thibs : apres un clic sur « Contacter l assistance », le bandeau
doit afficher « Assistance contactee » en vert.

Le bandeau n est plus du HTML fige dans la page mais un conteneur vide rempli
par `_fraudeRendreBanniere()`, appelee par `_socRenderConnected` et par
`_fraudeContacter`. Deux etats : alerte ambre avec le bouton d action, ou
accuse de reception vert avec la date d ouverture du message.

Nuance assumee : ouvrir le client mail ne prouve pas que le message a ete
envoye, le joueur peut abandonner. Plutot que de changer le libelle demande,
l etat vert porte un lien « Envoyer un autre message », pour qu un joueur qui
a renonce ne reste pas devant un bandeau qui lui ment.

`ST._revueContactee` est remis a zero lors d une rehabilitation, pour qu un
futur marquage reparte de l etat d alerte et non d un accuse perime.

Rendu mesure a 430 px, les deux etats, aucun debordement horizontal.

Au passage, une erreur de ma part dans une requete donnee a Thibs :
`select public.metanoia_blanchir((select id from profiles where ...))`
echoue en 55006, parce que la sous-requete tient une lecture active sur
`profiles` pendant que la fonction tente `alter table ... disable trigger`.
Il faut passer l identifiant en dur.

## Bouton de fin de saison, 16 octobre

Pour verifier les recompenses sans attendre quatorze jours. `_testFinSaison()`
n avance pas l horloge : elle inscrit le rang choisi sous la saison
PRECEDENTE (`s:<id-1>`) et efface sa cle de versement, ce qui place
`_socCheckPeriodRewards` dans exactement la situation d une bascule reelle,
puisque celle-ci ne verse que pour une cle dont l identifiant differe de la
saison courante. Reserve au mode test, bouton dans le panneau de test.

Bareme verifie par execution sur la vraie table `_SOC_SEASON_PRIZES` :

    rang  1       Champion de la saison   +2000 pts  Boite Rang S   titre leg. 7j
    rang  2 a 3   Podium de saison        +1200 pts  Boite Rang A   titre epique 5j
    rang  4 a 10  Top 10 de saison         +700 pts  Cle du Neant
    rang 11 a 25  Top 25 de saison         +300 pts  Boite Rang C
    rang 26+      aucune recompense

## Trois restes d audit traites, 16 octobre

**Mystere Systemique : la selection du jour n etait pas figee.** Quand une
des quatre cartes etait un Mystere Systemique, `_getDailyPickedRaw` en faisait
une copie pour y ecrire le fragment revele. `_getDailyPicked` memorisait
ensuite la selection par `_DAILY_POOL.indexOf(it)`, qui compare des
references : la copie n etant pas dans le catalogue, l indice valait -1. Au
rechargement `_DAILY_POOL[-1]` etait `undefined`, le compte ne tombait plus
juste, et QUATRE cartes neuves etaient retirees. Un cache memoire masquait le
probleme tant que l application restait ouverte ; il apparaissait au
redemarrage, et les cartes changeaient parce que le pool est refiltre selon l
etat courant (points, deblocages, fragments restants).

Correctif : `_dailyCarteFragment(ix, fragId)` fabrique la carte revelee, et
c est le SEUL endroit qui la fabrique, pour que le tirage et la
reconstruction ne puissent plus diverger. Une entree memorisee est desormais
soit un indice simple, soit `{i:indice, f:fragment}`. Les anciennes
sauvegardes, qui ne contiennent que des indices simples, restent lues.

**Boucliers : prix de reference.** `activate_shield` n est pas dans
`_DAILY_POOL`, la recherche de prix par `effect` echouait donc, et
`_sellInvItem` retombait sur son repli a 100 : TOUT bouclier se revendait
50 pts. Le tarif est maintenant repris de `UTIL_R`, source unique deja
utilisee par la boutique, donc aucun second jeu de prix a maintenir.

**Champs morts du catalogue.** Les 30 entrees de `_DAILY_POOL` portaient
`price` et `discount`. `discount` n etait lu nulle part : les badges de remise
viennent de `pr.discountTag`, calcule a la volee par `_prixItem`. `price` n
etait jamais lu non plus, parce que tous les consommateurs ecrivent
`item.orig || item.price` et que les 30 entrees ont un `orig`. Le piege etait
la : modifier `price` n avait aucun effet. Les deux champs sont supprimes, 759
caracteres, et les `|| item.price` des lecteurs sont conserves comme filet
pour les inventaires deja sauvegardes.

Verifie par execution sur les vraies fonctions extraites du fichier :

    premier tirage        memorise [0, {i:1,f:"f3"}, 2]
    apres redemarrage     memes cartes, aucun nouveau tirage
    sauvegarde ancienne   indices simples toujours lus
    bouclier 1j           orig 80  -> revente 40 pts
    bouclier 3j           orig 200 -> revente 100 pts
    bouclier 5j           orig 350 -> revente 175 pts
    cle du neant          orig 900 -> revente 450 pts (inchange)

## Zones de Flow : seuil d affichage, 16 octobre

Le commentaire annoncait cinq jours de donnees, le code en exigeait trois.

Precision importante, parce que je l avais d abord mal presentee a Thibs : la
FENETRE est bien celle des trente derniers jours, `dayLog.slice(-30)`. Elle
vaut donc neuf journees a J10, quand l ecran Stats se debloque, puis une de
plus chaque jour jusqu a trente ou elle se met a glisser. Le `>= 3` n etait
pas une fenetre de trois jours mais un MINIMUM d affichage, sous lequel le
bloc annonce « En attente » au lieu d un verdict.

Ce minimum ne mord donc que pour un axe peu renseigne : la Discipline, qui
apparait plus tard que Body et Mind, ou un historique troue par des journees
sous bouclier, explicitement exclues par `!d.shield`. Mais dans ce cas precis
le verdict devenait absurde : a trois journees, une seule quete ratee faisait
passer le conseil de « trop facile, augmente la difficulte » a « trop dur,
baisse-la ».

Seuil porte a cinq, dans une constante unique `_FLOW_MIN_JOURS` partagee par
les trois axes, au lieu de trois litteraux a tenir synchronises. Le
commentaire dit maintenant ce que fait le code.

Verifie par execution :

    3 jours, 2 reussis    En attente
    4 jours, 3 reussis    En attente
    5 jours, 3 reussis    60 %  Zone de Flow
    5 jours, 4 reussis    80 %  Zone de Flow
    9 jours, 8 reussis    89 %  trop facile
    30 jours, 20 reussis  67 %  Zone de Flow

## Erreur JS a l ouverture d une boite, 16 octobre

Signalee par Thibs sur l appareil : `Uncaught TypeError: Cannot read
properties of null (reading 'style')` a la ligne 12882, pendant qu une boite
de Rang C affichait son recapitulatif.

Course entre un minuteur et les appuis du joueur. Au premier appui,
`_boxNext` programme `_boxShow(0)` 600 ms plus tard, le temps de l animation
du coffre, mais pose `S.i=0` immediatement. Trois appuis rapides pendant ces
600 ms faisaient donc defiler la sequence sans attendre : objet 2, puis
recapitulatif. Or `_boxRecap` remplace le contenu de l overlay, donc
`box-item` disparait. Le minuteur retombait ensuite sur un noeud absent.
`_boxNext` se protegeait par `if(!pane) return`, `_boxShow` n avait aucune
garde.

Trois correctifs, du plus cible au plus defensif :

- `S.ouverture` ignore les appuis pendant l animation d ouverture. C est la
  cause racine.
- `_boxShow` sort si `box-item` a disparu.
- `_boxClose` annule le minuteur encore en vol.

Reproduit et verifie dans Chromium, sur les vraies fonctions extraites du
fichier, en comparant la version d avant et celle d apres :

    AVANT  trois appuis rapides  objet 2 | RECAP  puis TypeError
    APRES  trois appuis rapides  objet 1         aucune erreur
    APRES  parcours normal       objet 1 | objet 2 | RECAP  aucune erreur

## Fiche de profil reagencee, 16 octobre

D apres un croquis de Thibs. L en-tete ne bouge pas : rond, pseudo, pastille
« C est toi ». Dessous, deux colonnes en `flex:2` et `flex:3`, soit 2/5 et
3/5 de la largeur utile.

A gauche, empilees : Rang, XP, Serie, puis un bloc Classements qui regroupe
Global, Saison et Record en trois lignes au lieu de trois tuiles. Les tuiles
passent du format centre au format libelle au-dessus, valeur en dessous : sur
2/5 de largeur, une valeur centree sous un libelle en capitales devenait
illisible.

A droite, la guilde. Embleme en 150 px, le maximum tenable (3/5 de 394 px a
430 px d ecran, moins les marges, laisse environ 209 px ; a 360 px il reste
167 px). Dessous le nom en Cinzel, la devise en italique entre guillemets, et
le grade du joueur dans sa guilde. Sans guilde : ecu gris et « Aucune
guilde ». L embleme et le nom ouvrent le profil de la guilde.

Le bloc « Chasseur depuis » reste en dessous des deux colonnes. Je l avais
supprime par erreur en remplacant le corps de la fiche ; restaure.

Le grade vient de `u.guild_role`, que `user_public_profile` doit renvoyer.
Tant que le SQL n est pas pose, un repli cherche le role dans `_GUILD.roster`,
ce qui ne marche que pour un membre de MA guilde, la policy de lecture de
`guild_members` n allant pas plus loin.

Rendu verifie dans Chromium sur trois cas : Maitre avec devise a 430 px,
Second avec pseudo long a 430 px, sans guilde a 360 px. Aucun debordement.

## Liste des membres : demi-ligne et chainage, 16 octobre

Deux retours de Thibs sur la liste de guilde.

**La huitieme ligne est maintenant coupee en deux.** A sept lignes pile, la
liste paraissait complete et rien n invitait a la faire defiler. La hauteur
n est pas figee : `_guildAjusterListe()` mesure une VRAIE ligne apres le
rendu, puis pose `maxHeight = 7,5 x hauteur`. Une valeur en dur aurait
coupe au mauvais endroit, les polices Sora et Cinzel ne donnant pas la meme
hauteur que les polices systeme. Sous huit membres, aucune limite n est
posee : il n y a rien a faire defiler.

Un fondu de 34 px, `#gld-fog`, grise le bas de la liste et s eteint des qu on
atteint le dernier membre, pour ne pas promettre une suite qui n existe pas.

**Le chainage de defilement est coupe.** La liste n avait pas
`overscroll-behavior`, donc un dernier glissement vers le bas, une fois
arrive au bout, faisait defiler l ecran entier derriere elle. Meme correctif
que celui deja pose sur les feuilles de profil.

Mesure a 430 px : 7,51 lignes visibles, `overscrollBehaviorY` a `contain`,
fondu opaque en haut de liste et transparent en bas, bas du fondu aligne au
pixel sur le bas de la liste, et aucune limite de hauteur a cinq membres.

Reste non traite, faute d avoir pu le reproduire : le grand vide sous la
carte quand l ecran lui-meme est fait defiler. Il vient probablement de
`.screen.active{min-height:100dvh;overflow-y:auto}`, qui fait de chaque ecran
un second conteneur defilant a l interieur du corps. C est une regle globale
qui touche les cinq ecrans, je n y touche pas sans arbitrage.

## Bandeau reseau refermable, 16 octobre

Demande de Thibs : un joueur qui SAIT etre hors reseau pour plusieurs jours
ne doit pas subir le bandeau rouge en permanence ; et le retour du reseau
doit se voir.

Une croix est posee a droite du message. La fermeture est memorisee dans
`ST._netMasque`, donc elle survit aux redemarrages, ce qui est tout l interet
pour une absence de reseau qui dure. Elle est OUBLIEE des que la connexion
revient : une coupure ulterieure reaffiche l alerte, sinon un joueur ayant
ferme le bandeau une fois ne serait plus jamais prevenu.

Au retour du reseau, le meme element passe en bleu avec « Connexion
retablie » pendant une seconde, puis disparait et reprend sa couleur rouge
pour la fois suivante. Le `toast` qui annoncait deja le retour dans le
gestionnaire `online` est supprime : il faisait doublon.

Machine a etats verifiee par execution, les six transitions :

    coupure                  rouge affiche, croix presente
    fermeture                masque, ST._netMasque enregistre
    toujours hors ligne      reste masque
    retour du reseau         bleu « Connexion retablie », masque oublie
    une seconde plus tard    masque, fond revenu au rouge
    nouvelle coupure         rouge reaffiche

## Le bandeau hors-ligne n apparaissait pas, 16 octobre

Thibs coupe sa connexion, rien ne s affiche. Ce n etait pas le bandeau qui
etait casse : c est l etat reseau qui n etait jamais reevalue.

`_netProbe` n etait appelee qu a quatre endroits : au demarrage, sur l
evenement `online`, au retour d arriere-plan via `visibilitychange`, et avant
une action reseau par `_netGuard`. Aucune sonde periodique. Couper le reseau
en gardant l application au premier plan ne declenchait donc rien, sauf si la
WebView emettait `offline`, ce qu elle ne fait pas toujours : le commentaire
du code le dit lui-meme, `navigator.onLine` signifie « une interface reseau
est active », pas « internet marche ». Wifi associe a une box sans acces, et
l evenement ne part jamais.

Une sonde est posee toutes les 30 s, uniquement quand l ecran est visible.
Avec le cache interne de 15 s de `_netProbe`, cela fait une vraie requete par
demi-minute, vers la racine PostgREST, quelques centaines d octets. Hors
ligne, `_netProbe` sort avant toute requete : la sonde ne coute alors rien.

Verifie par execution avec l intervalle accelere :

    au premier plan        4 sondes en 180 ms (dont la forcee du demarrage)
    en arriere-plan        0 sonde
    retour au premier plan 3 sondes

## Le temps reel du bandeau hors-ligne, 16 octobre

Suite du precedent. Thibs : couper brutalement la radio, mode avion ou wifi
et donnees eteints, n affiche rien ; il faut fermer et rouvrir. Seule une
connexion qui se degrade en douceur declenche le bandeau a vue.

C est coherent avec ce que faisait le code. La WebView d Android garde
`navigator.onLine` a true en mode avion et n emet pas `offline` de facon
fiable, donc le seul signal restant etait la sonde des 30 s. Une degradation
progressive, elle, fait echouer les requetes applicatives, et celles-la
reagissaient plus vite. D ou l asymetrie qu il decrit.

Trois leviers, du plus decisif au moins couteux.

**1. Le greffon natif `@capacitor/network`.** Il ecoute le
`ConnectivityManager` du systeme et previent a l instant de la bascule, sans
la moindre requete. `_NET.natif` memorise son verdict et `_netIsOnline()` le
fait primer sur `navigator.onLine`, precisement parce que celui-ci ment.
Le greffon reste facultatif : `_netPlugin()` renvoie null s il manque et tout
continue par sonde. `npm i` puis `npx cap sync android` ont deja ete passes
ici, le greffon est enregistre dans `capacitor.plugins.json`.

**2. La sonde resserree a 10 s** quand le greffon manque, 25 s quand il est
la. Elle reste indispensable dans les deux cas : un wifi associe a une box
sans acces est « connecte » pour le systeme comme pour le greffon.

**3. Une sonde au premier toucher** apres cinq secondes sans contact. Celui
qui pose le doigt sur l ecran attend une reponse immediate.

Pour rendre cette cadence tenable, la sonde passe de GET a HEAD. La
remarque de la section precedente, « quelques centaines d octets », etait
fausse : un GET sur la racine PostgREST rapatrie tout le schema OpenAPI,
plusieurs dizaines de kilo-octets. En HEAD, il n y a plus de corps. Si un
intermediaire refusait HEAD, un repli GET est tente une fois avant de
conclure que le serveur est muet, et HEAD est alors abandonne pour la
session : aucun faux bandeau possible.

Verifie par execution, vraies fonctions extraites du fichier, requetes vers
la sonde interceptees :

    sans greffon, coupure brutale   bandeau apres 8 514 ms, navigator.onLine
                                    reste a true tout du long
    avec greffon, coupure brutale   bandeau apres 1 ms, _netIsOnline() suit
                                    le natif malgre onLine a true
    avec greffon, retour reseau     bandeau bleu « Connexion retablie »,
                                    efface apres la seconde
    toucher apres coupure           bandeau apres 59 ms
    HEAD refuse                     sequence HEAD puis GET, reseau juge
                                    joignable, aucun bandeau a tort
    connexion saine pendant 12 s    aucun bandeau, 2 sondes

Note relevee au passage : `capacitor.plugins.json` du depot ne listait pas
`@capacitor/local-notifications`, et `capacitor.config.json` n avait pas le
`backgroundColor`. Ces fichiers sont generes, ils etaient simplement
anterieurs a ces deux ajouts ; le `cap sync` les a remis a jour. Rien n
indique un defaut sur l appareil, ou chaque construction les regenere.

## Le claquement de cil survivait au redemarrage, 16 octobre

Thibs : le battement est encore la quand on ferme puis rouvre l application
et qu on retourne sur la Guilde. Question posee : defaut supprimable, ou
limite atteinte ? Supprimable, et la cause etait ailleurs que la transition.

L ecran Social est en `display:none` tant qu il n est pas ouvert, et
`_guildLoad` rend la liste bien avant, au demarrage. Un element non rendu
mesure zero partout : `scrollHeight - scrollTop - clientHeight` valait donc
0, `maj()` en concluait « liste arrivee au bout » et eteignait la brume,
puis armait la transition par-dessus. A l ouverture de l onglet, la huitieme
ligne apparaissait nette avant de se voiler en fondu. Le correctif precedent
posait bien `opacity:1` a la construction, mais l ajustement l ecrasait dans
la seconde qui suivait.

Mesure du defaut, avant correctif, rendu avec le conteneur masque :

    opacite posee a la construction   1
    apres `_guildAjusterListe`        0, transition armee
    a l ouverture de l onglet         0 puis 1, le battement

Deux corrections. `_guildAjusterListe` sort desormais sans rien conclure
quand `clientHeight` vaut 0 : une mesure impossible ne decide plus de rien,
et l etat pose a la construction reste en place. Et l ajustement est rejoue
a l instant ou un ecran devient actif, aux deux endroits qui posent
`classList.add('active')`, la ou `_ajusterPaddingBas()` est deja appele :
l ecran est mesurable des cet instant.

Troisieme point, pour solder la reserve notee plus haut. `_GLD_HLIGNE`
repartait de 49 px a chaque lancement, donc un appareil dont la ligne mesure
autre chose subissait un reajustement a la premiere ouverture, a chaque
session. La valeur mesuree est maintenant conservee dans `ST._gldHLigne`,
relue par `_gldHLigne()`, bornee a 20-120 px pour ecarter une valeur
aberrante lue dans un etat corrompu.

Verifie par execution, vraie fonction extraite du fichier, ligne forcee a
56 px pour simuler un appareil different :

    session 1, ouverture      368 px corriges en 420, valeur mémorisée,
                              une seule ecriture d etat
    session 2, construction   420 px poses d emblee, saut 0
    session 2, opacites       1 sur vingt frames, aucun passage par 0
    valeur aberrante 9999     ignoree, retour a 49 px
    defilement                0,53 a mi-fondu, 0 en bas, 1 au retour en haut
    guilde de 5 membres       aucune brume, aucune hauteur posee

## Audit du systeme de sanction, 16 octobre

Demande de Thibs : verifier que la sanction fonctionne. Audit par execution
de la chaine cliente, vraies fonctions extraites du fichier.

Huit scenarios, resultats avant correctif :

    compte sain                aucun bandeau, aucune activite, present au
                               classement
    marque par le serveur      bandeau orange, une entree d activite,
                               non reinsere au classement
    profil recharge trois fois aucun message en double
    contact assistance         mailto vers l assistance, sujet et
                               identifiant presents, bandeau passe au vert
    rehabilite                 bandeau retire, contact oublie, retour au
                               classement
    recidive                   le bandeau repart de l etat d alerte
    etat client perime         DEFAUT, reinsere au classement
    colonne `suspect` absente  DEFAUT, annonce une rehabilitation

Les deux defauts avaient la meme racine. `_socLoadProfile` avale ses
erreurs : hors ligne, `_socProfile` reste nul, et l absence de marque etait
lue comme une rehabilitation. Un joueur sanctionne qui relancait
l application sans reseau recevait « Ton compte est de nouveau en regle »,
perdait le bandeau et revenait au classement local, alors que le serveur le
tenait toujours a l ecart. Le meme chemin s ouvrait si la colonne `suspect`
venait a manquer de la reponse.

`_fraudeVerifier` ne conclut desormais plus rien d une information qu il n a
pas : profil absent ou `suspect` non booleen, on sort sans toucher a l etat.

Verifie apres correctif :

    redemarrage hors ligne     sanction maintenue, aucun message, bandeau
                               affiche, pas de reinsertion au classement
    colonne absente            etat conserve, derniere entree inchangee
    marquage et rehabilitation reels   inchanges, toujours corrects

Points cote serveur restant a confirmer avec Thibs : l exclusion des
suspects dans la vue `classement`, les seuils de `guard_profile_progress`,
l etat du declencheur `zz_alerte_suspect` et son rang alphabetique, le gel
annonce de l XP publique, les droits de lecture du joueur sur sa propre
colonne `suspect`, et les deux voies de sortie `metanoia_annuler_triche` et
`metanoia_blanchir`.

## Audit de l ecran de sanction, 16 octobre

Thibs : l ecran de sanction doit apparaitre des qu une quete obligatoire
n est pas accomplie, et il ne l a plus vu depuis longtemps. Audit en
chargeant l application reelle dans un navigateur et en pilotant un joueur
au jour 20, quetes du jour generees par `genWeek()`.

Trois chemins menent a la sanction, et ils ne disaient pas la meme chose.

**Le bilan du soir** (`submitReview`) sanctionne des la premiere quete
obligatoire ratee. Mesure : une ratee sur trois, ecran affiche, texte et
contexte poses. Celui-la marchait.

**Le controleur de fin de creneau**, qui marque en echec les quetes restees
sans statut, exigeait DEUX quetes ratees. Mesure avant correctif : une seule
quete ratee, echec bien enregistre, integrite a 75, et `sanctionPending`
reste faux, aucun ecran. La regle s appliquait donc ou non selon que le
joueur faisait son bilan ou non. Seuil ramene a une quete.

Deuxieme defaut du meme bloc : l ecran ne s affichait que si le joueur se
trouvait sur l accueil ou sur le bilan. Ailleurs, la sanction etait posee en
memoire mais il gardait la main sur toute l application jusqu au redemarrage
suivant, alors que cet ecran est precisement celui qu on ne peut pas
contourner. Il s affiche desormais depuis n importe quel ecran, sauf pendant
l integration.

Ce correctif en a cree un autre, vu a la mesure suivante et corrige :
`buildSanction` ne pose rien avant le jour 15, donc l ecran s ouvrait VIDE
pendant la franchise. L ancien code avait le meme defaut, limite a l accueil
et au bilan. L affichage est maintenant conditionne a `ST.sanctionPending`.

Retire au passage : `_lateOpen`, variable lue nulle part et dont le calcul
etait faux, `ST._openedBefore22h||(ST.day||1)` retombant sur le jour courant
quand le marqueur manque, ce qui rendait la negation toujours fausse. C est
`_wasActive` qui fait ce travail. Corrige aussi le commentaire qui annoncait
un auto-echec « a 22h » : le creneau par defaut va de 8 h a minuit, et c est
sa fin qui declenche.

Etat verifie apres correctifs :

    1 ratee, bilan du soir          sanction, ecran affiche
    1 ratee, depuis #Social         sanction, ecran affiche
    1 ratee, depuis #Stats          sanction, ecran affiche
    1 ratee, bouclier actif         aucune sanction, quete non marquee,
                                    integrite intacte a 80
    1 ratee, jour 12                aucune sanction, pas d ecran vide
    1 ratee, joueur absent du jour  aucune sanction (garde volontaire)
    0 ratee                         rien

Les deux trous restants ont ete tranches par Thibs dans la foulee.

**L absence de la journee se sanctionne.** Le garde `_wasActive` exigeait que
le joueur ait ete vu pendant le creneau : ne pas ouvrir l application du tout
ne coutait donc aucune sanction. Il est retire.

**Une seule sanction au retour d une absence de plusieurs jours.** Le
rattrapage comptait les sanctions dues dans `CATCHUP._sanctionsDues`, les
recopiait dans `b.sanctions`, et personne ne lisait jamais ce champ : elles
etaient perdues sans un mot. Les quetes du dernier jour fautif sont
desormais retenues dans `CATCHUP._ratees`, et une sanction unique est posee
au retour, mentionnee dans le recapitulatif d absence. Une par jour manque
ecraserait celui qui revient ; aucune effacait l absence.

Verifie par execution, meme methode :

    absence de 5 jours              J20 vers J25, serie 5 vers 0, integrite
                                    80 vers 5, 5 jours comptes, UNE sanction,
                                    ecran affiche
    absence de 5 jours, bouclier    aucune sanction, serie et integrite
                                    intactes
    joueur absent de la journee     sanction, ecran affiche
    bouclier, jour 12, 0 ratee      inchanges

Note de lecture pour la suite : `todayStr()` produit `annee-mois-jour` avec
un mois indexe a partir de zero et sans zero de tete, `2026-9-16` pour le
16 octobre 2026. Format maison coherent entre producteur et consommateur,
mais il fait trebucher quiconque le lit comme une date ISO.

## Journal du 16 octobre, resume pour une reprise rapide

La seance du 16 octobre a ete longue. Dans l ordre, ce qui a change :

| Sujet | Resultat |
|---|---|
| Grade de Second | hierarchie Maitre, Second, Membre, avec matrice de droits |
| Rond de profil, fiche joueur | fiche en deux colonnes, carte de guilde cliquable |
| Classement de Saison | reparee, faute de frappe `xp_season` vers `season_xp` |
| Compte de Thibs gele | degele, exemption posee pour le mode test |
| Cron fantome | il echouait 96 fois par jour, remis en marche |
| Web Push mort | code retire, inerte sous Capacitor |
| Chaine de courriel | Resend plus pg_net, domaine verifie, code 200 observe |
| Compte en revue | bandeau, entree d activite, courriel, bouton assistance |
| Carte Mystere Systemique | le clone cassait le gel de la carte du jour |
| Boucliers | revente alignee sur la boutique, 40 / 100 / 175 |
| Champs morts du catalogue | 30 `price` et 30 `discount` retires |
| Zones de Flow | seuil porte a 5 jours, puis glissant de 9 a 30 |
| Course a l ouverture des boites | verrou pose, erreur JS supprimee |
| Fiche de profil | reagencee selon le croquis de Thibs |
| Liste de membres | demi-ligne visible, chainage de defilement coupe |
| Bandeau reseau | croix de fermeture, retour bleu, sonde periodique |
| Temps reel du bandeau | greffon natif `@capacitor/network` installe et synchronise |
| Brume de la liste | deux defauts successifs, dont un de mon fait |
| Systeme de sanction client | un defaut grave trouve et corrige |
| Ecran de sanction | seuil incoherent entre chemins, corrige |

Les deux derniers meritent d etre relus en detail plus bas : ce sont les
seuls de la journee qui touchaient a des regles de jeu, et non a l affichage.

## Le vide sous le dernier bloc, 16 octobre

Thibs : on peut encore faire defiler en dehors des blocs, et ca laisse un
espace. Mesure plutot que supposition, sur une reproduction fidele des regles
`body`, `.screen.active`, `.app` et `.bnav`.

La cause n est ni le chainage de defilement ni `min-height:100dvh`, mais la
reserve de place sous le contenu, qui sert a ne pas passer sous la barre de
navigation fixe. Elle etait ecrite en dur : `5,5 rem` par defaut sur `.app`,
et `6 rem` en style en ligne sur le Social. Soit 88 et 96 px, pour une barre
qui en mesure 54.

`_ajusterPaddingBas()` mesure la barre pour de vrai et pose sa hauteur plus
14 px de respiration, sur les `.app` de l ecran actif. Appelee aux deux
endroits qui activent un ecran, et sur `resize`.

Mesure avant et apres, barre de 54 px, defilement pousse jusqu en bas :

    avant   padding 96 px   vide sous la carte 96 px   dont 42 px hors barre
    apres   padding 68 px   vide sous la carte 68 px   dont 14 px hors barre

Les 14 px restants sont voulus : sans eux le dernier bloc collerait a la
barre.

## Le mot « Guilde » en Cinzel

Demande de Thibs, viser l immersion. L etiquette passe de 8,5 px en Sora gris
a 12,5 px en Cinzel dore, interlettrage a 0,20 em, avec un leger relief clair.
Cinzel est deja la serif d apparat des titres d ecran et des noms de guilde :
le mot devient une enseigne gravee au lieu d une etiquette de formulaire.

## La fermeture du bandeau survivait a la reconnexion, 16 octobre

Bug introduit par moi le matin meme. `ST._netMasque` n etait remis a faux que
sur une TRANSITION observee de hors-ligne vers en ligne, dans `_netPaint`. Au
demarrage de l application, `_netEtatPrec` vaut `null` : si le reseau est la,
on passe par la branche qui masque, sans jamais effacer le drapeau. Une
fermeture faite avant un redemarrage survivait donc a la reconnexion, et la
coupure suivante restait muette.

Le drapeau est maintenant efface des que `_netOk()` est vrai, pas seulement
sur une transition, et la sauvegarde n est declenchee que s il valait vrai.

Verifie par execution, le scenario exact :

    coupure                        bandeau affiche
    fermeture                      masque, drapeau pose
    redemarrage, en ligne          drapeau efface
    nouvelle coupure               bandeau reaffiche

Avant le correctif, la derniere etape ne montrait rien.

## Le saut de hauteur de la liste de guilde, 16 octobre

Defaut introduit par moi une heure plus tot. Le gabarit posait
`max-height:340px`, puis `_guildAjusterListe` corrigeait a 368 apres le rendu.
Le bouton « Chat de guilde » descendait donc d un demi-cran sous les yeux du
joueur a chaque ouverture de l onglet.

La hauteur est desormais posee DES la construction du HTML, a partir de
`_GLD_HLIGNE`, la hauteur de ligne mesuree au rendu precedent, initialisee a
49 px. `_guildAjusterListe` ne touche plus a la hauteur que si la mesure
reelle s ecarte du cache d au moins un pixel : sinon elle rejouerait
exactement le saut qu on cherche a supprimer. Elle conserve son role sur le
fondu de bas de liste.

Verifie par execution, hauteur avant et apres l appel a l ajustement :

    17 membres   368 px avant, 368 px apres, saut 0, 7,51 lignes visibles
    5 membres    245 px avant, 245 px apres, aucune limite posee

Reserve : si la hauteur de ligne reelle sur l appareil differe de 49 px, le
tout premier affichage apres installation bougera de cet ecart, puis plus
jamais, le cache etant corrige des le premier rendu.

## Le battement de cil de la brume, 16 octobre

Deuxieme defaut du meme lot, du meme auteur. Le gabarit posait la brume
`#gld-fog` a `opacity:0` avec `transition:opacity .18s`, et c est
`_guildAjusterListe` qui la montait a 1 apres le rendu. En arrivant sur
l onglet Guilde, le joueur voyait donc la huitieme ligne nette une fraction
de seconde avant qu elle soit voilee.

La brume est maintenant posee a son etat final des la construction du HTML,
`opacity:1` quand le roster depasse sept membres, et sans transition. La
transition n est armee qu au `requestAnimationFrame` suivant, de sorte que
le premier affichage est sec et que seules les variations au defilement
restent adoucies.

Verifie par execution, opacites relevees sur vingt-sept frames depuis
l insertion du HTML :

    avant   17 membres   0 puis 1   le battement
    apres   17 membres   1 seulement
    apres    5 membres   0 seulement, aucune brume
    apres   17 membres   transition vide au premier rendu, « opacity 0.18s »
                         au frame suivant, 0,53 a mi-fondu lors du
                         defilement vers le bas, 0 en bas de liste

## Audit de securite du 9 octobre, etat des onze points au 18 octobre

Etat verifie dans le code le 18 octobre, pas recopie du document d audit.

| # | Faille | Etat |
|---|---|---|
| 1 | Cinq tapes ouvrent le panneau de triche | corrige, `ADMIN_UID` renseigne, verrou `_verrouPanneauTest()` |
| 2 | Import sans borne | ferme par retrait de l import, fonctions conservees |
| 3 | `state_blob` lisible par tous | corrige, vue `classement` et `metanoia_pseudo_pris` |
| 4 | Bilan validable en boucle | corrige, garde d idempotence |
| 5 | Revente a 50 pts fixes | corrige, prix par `_DAILY_POOL` et `UTIL_R` pour les boucliers |
| 6 | Mauvais objet vendu sous bouclier | corrige |
| 7 | Journee off rachetable le meme jour | INJOIGNABLE, voir ci-dessous |
| 8 | `trig()` cycle perfect, fail, perfect | corrige, `trig` refuse fail sur perfect, clear et dayoff |
| 9 | `_pickChosenSec` rouvre une secondaire validee | corrige, refus si la secondaire est perfect |
| 10 | `slConfirm` a resolveur unique | corrige, le precedent recoit `false` |
| 11 | Policies de guilde et RPC | NON VERIFIE, question serveur 7 plus bas |

**Point 7.** La branche `if(r.name==='Journee off sans penalite')` existe
toujours dans `buyRew()` (ligne 14400 au 18 octobre) et n a toujours aucune
garde de jour. Mais aucun objet du catalogue ne porte ce nom : le seul autre
resultat d une recherche sur ce libelle est la branche elle-meme, et l objet
`day_off` d inventaire est purge au demarrage. Branche morte, sans risque
aujourd hui. Decision de Thibs le 18 octobre : documenter, ne pas toucher.
Si l objet revient un jour au catalogue, poser d abord un test du type
`ST._dayOffDay === ST.day`, sinon chaque achat reincremente la serie,
remonte l integrite de 3 et ecrit un bilan pour le meme jour.

**Point 10, consequence a connaitre.** L audit signalait que le resolveur
unique neutralisait PAR ACCIDENT cinq doubles depenses, dont
`_openSealedBox` et `_buyPermItem` : la premiere promesse ne se resolvait
jamais, donc la premiere depense n avait pas lieu. Depuis le correctif, la
premiere promesse se resout a `false`, ce qui produit le meme effet,
volontairement cette fois. Le jour ou `slConfirm` gerera une vraie pile de
modales qui laisse les deux confirmations aboutir, ces cinq chemins devront
etre gardes un par un.

## Lot du 18 octobre : vide sous la guilde, balayage entre ecrans

### Le vide sous le dernier bloc, cause reelle

Thibs envoie deux captures de #Social, onglet Guilde : la carte tient dans
l ecran, et pourtant on peut faire defiler vers le haut et faire apparaitre
un vide sous la carte. Il veut un ecran fige.

Retractation de la section « Le vide sous le dernier bloc » du 16 octobre.
J y ecrivais que `_ajusterPaddingBas()` posait la reserve « sur les `.app`
de l ecran actif ». C etait faux : seul le Social possede un `.app`
interieur. Les quatre autres ecrans n en ont aucun, et la mesure d alors
portait sur une reproduction, pas sur l application.

La vraie structure, mesuree dans l application chargee : un
`<div class="app">` ENVELOPPE tous les ecrans, enfant direct de `body`. Il
herite de `.app{padding:.5rem 1rem 5.5rem}`, donc 8 px en haut et 88 px en
bas. Or l ecran actif impose `min-height:100dvh`. Total : 8 + 100dvh + 88,
toujours plus haut que la fenetre, quel que soit le contenu. Sur l appareil
s y ajoute la marge haute du systeme, car `targetSdk 36` impose le bord a
bord et `viewport-fit=cover` rend `env(safe-area-inset-*)` non nul. Le
Social cumulait en plus sa propre reserve interieure.

Correctif :

- le conteneur racine porte desormais `id="app-racine"` et SEUL il reserve
  la place de la barre du bas, `padding-bottom:var(--res-bas,5.5rem)` ;
- `_ajusterPaddingBas()` ne touche plus aux `.app` : il mesure la barre et
  pose `--res-bas` = hauteur + 14 px sur la racine du document ;
- l ecran actif retranche tout ce qui l entoure :
  `min-height:calc(100dvh - .5rem - var(--res-bas) - env(top) - env(bottom))` ;
- le `.app` interieur du Social passe de `padding-bottom:6rem` a `0`.

Les ecrans fixes (`s-ob`, `s-welcome`, `s-sanction`) ne sont pas concernes :
ils ont leur propre `inset` ou `top`/`bottom`.

Mesure avant et apres, application reelle a 430 x 900, `env()` remplace par
40 px en haut et 30 px en bas dans une copie pour simuler un telephone
(Chromium les evalue a 0, forcer le padding du body ne suffit pas) :

    ecran                 defilement en trop   ecart dernier bloc / barre
    Social court   avant  136 px               338 px
                   apres    0 px               202 px
    Social long    avant  bas a 102 px de la barre
                   apres  bas a  14 px de la barre
    Quetes, Boutique      14 px sous le dernier bloc, contre 20 avant
    Identite, Stats       28 et 24 px, marge propre du dernier element

Un ecran dont le contenu tient ne defile donc plus du tout ; un ecran plus
long s arrete 14 px au-dessus de la barre, comme voulu le 16 octobre.

### Balayage horizontal entre les cinq ecrans

Demande de Thibs : changer d onglet d un geste, a gauche ou a droite.

`_swpDebut`, `_swpFin` et `_swpAller`, places juste apres `nav()`. Un geste
d au moins 70 px, deux fois plus horizontal que vertical et de moins de
700 ms clique le bouton voisin dans la barre de l ecran ACTIF. Donc
strictement le meme chemin qu un appui : son, memoire de defilement,
fermeture du chat de guilde, onglets grises. Ordre : Quetes, Identite,
Boutique, Stats, Social ; aucun bouclage aux deux bouts.

Le geste est ignore : a plusieurs doigts, dans un champ ou un canvas, dans
tout element qui defile lui-meme a l horizontale, sur tout element en
position fixe (fenetres superposees, barre du bas, ecran de sanction), sur
un ecran autre que les cinq principaux, pendant le tutoriel et pendant
l integration. Un element peut s exclure avec l attribut `data-noswipe`.
Ecouteurs passifs : ils ne retardent ni ne bloquent aucun defilement.

Verifie par de vrais evenements tactiles (CDP `Input.dispatchTouchEvent`) :

    Quetes > Identite > Boutique > Stats > Social    un geste chacun
    Social vers la gauche                            reste (bout)
    Social vers la droite                            Stats
    geste vertical, 50 px, 1 200 ms                  rien
    depart dans une zone defilante horizontale       rien
    depart sur une fenetre fixe                      rien
    tutoriel actif                                   rien
    jour 1, Quetes vers la gauche                    Identite, comme au doigt

Le dernier cas n est pas une erreur : au jour 1, les onglets verrouilles
gardent `nav()` et sont seulement grises, `renderIdentity()` decide de
l affichage. Un appui fait la meme chose.

Piege de test, a ne pas reprendre pour un defaut : Chromium en emulation
mobile recharge la page sur un glissement vers la droite (navigation
arriere par debordement), avec ou sans ce code. Lancer avec
`--disable-features=OverscrollHistoryNavigation`. La WebView Android n a pas
ce geste.

Non traite : les sous-onglets Guilde et Classements du Social ne se
balaient pas, le geste change d ecran principal.

## Donjons : refonte en cours, et retrait de « Quete en evenement », 18 octobre

### Refonte visuelle : decisions de Thibs (livree, voir section suivante)

Thibs a retenu le parti « tableau de chasse » pour le donjon deplie, et la
variante 4 « anneaux autour des monstres » pour le donjon replie.
Decisions :

- chaque condition est un papier epingle, il n y a pas de papier de boss ;
- tampon vert « ACCOMPLI » pour une condition remplie, rouge « MANQUE »
  pour une condition ratee ;
- coffre scelle : TOUTES les cases en « Scelle », et le texte exact de
  Thibs, a ne pas reformuler : « Coffre scelle. Utilise Eclat du Veilleur
  pour connaitre ses recompenses a l avance » (avec ses accents dans
  l application) ;
- Eclat du Veilleur utilise (`ST._veilRevealed` contient l id du donjon) :
  toutes les recompenses s affichent, donjon commence ou non ;
- les illustrations reutilisent l existant : `_monsterSVG` (7 monstres),
  `_itemSVG` (coffres `box_E` a `box_S`, objets). Le fond clair de ces SVG
  se retire par la regex
  `/<rect(?=[^>]*width="(9[6-9]|100)")(?=[^>]*fill="#F[0-9A-F]{5}")[^>]*>/i`,
  verifiee sur les 33 objets.

Tranche ensuite : illustration de perte « Cendres », regle du tampon
« MANQUE » (des que la condition est impossible), nombre de cases scellees
= vrai nombre de recompenses.

### Les conditions de donjon, telles que le code les compte

Verifie dans `_variantConds`, `_dngTrack`, `_dngFail` et `advDay`. Chaque
donjon a entre 1 et 4 conditions.

| Cle | Libelle | Ce que le code compte reellement | Donjons |
|---|---|---|---|
| body | Quetes Body | quetes body validees, Accomplie ou En partie | 58 |
| mind | Quetes Mind | idem pour mind | 53 |
| water | Eau bue | quetes eau validees | 40 |
| total | Quetes totales | toute quete validee | 32 |
| sec | Quetes secondaires | secondaires validees | 24 |
| noFail | Jours sans fail | jours consecutifs sans quete obligatoire en `fail` | 22 |
| nnStreak | NN Xj d affilee | jours consecutifs ou les 3 obligatoires sont validees | 16 |
| maxFail | Discipline (max X fail) | quetes marquees `fail` pendant le donjon, obligatoires ET secondaires, plus les obligatoires non traitees en fin de journee | 16 |
| integ | Integrite >= X % | integrite courante ; cible = integrite au tirage + 10 a 18, plafond 95 | 10 |
| perfect | Quetes parfaites | quetes validees « Accomplie », pas « En partie » | 8 |
| hardQuest | Quete Hard Mode | une quete Hard Mode validee Accomplie | 8 |

Constat du 18 octobre, REGLE le soir meme : `noFail` et `nnStreak`
comptaient la meme chose, car `advDay` passe en `fail` toute obligatoire non
traitee AVANT de compter les series. `nnStreak` exige desormais les 3
obligatoires en « Accomplie » (bouclier et journee off neutres). Ce tableau
est remplace par celui de la section suivante.

### Retrait de « Quete en evenement »

Decision de Thibs. Quatre points touches :

- `_variantConds` : quand le tirage tombe sur `duringEvent`, il est ecarte
  et un autre candidat est tire. Le candidat reste dans la liste, sinon les
  poids changeaient et le tirage des 98 autres donjons avec. Verifie sur les
  108 : exactement les 10 donjons qui l avaient changent, chacun gagne une
  autre condition, les 98 autres sont identiques. Nouveaux tirages :
  c4 +nnStreak 4, c16 +body 4, b17 +water 5, b18 +nnStreak 5, a4 +perfect 4,
  a9 +noFail 6, a12 +mind 5, a15 +sec 3, a18 +body 6, s5 +water 7.
- `_normalizeConds` force `duringEvent:false`, `_dungeonProgress` ne
  l affiche plus, `_condSummary` ne le cite plus, `_dngTrack` ne pose plus
  `_eventDone`.
- `_evJourNaturel` ne fabrique plus de Double XP pour un donjon. C etait le
  mecanisme qui garantissait un evenement faisable, et dont le correctif du
  « x6 » parlait plus haut : il disparait avec la condition.
- Donjon lance AVANT le patch, sauvegarde avec la condition : verifie par
  execution, la condition disparait de l affichage, le donjon est gagne si le
  reste est rempli, et au jour 10 l evenement du jour passe de `doubleXP`
  fabrique a `null`.

## Donjons : refonte livree, 18 octobre au soir

### Conditions, etat final (18 types, 1 a 4 par donjon)

| Cle | Libelle | Ce que le code compte | Cibles E/D/C/B/A/S |
|---|---|---|---|
| body, mind, disc | Quetes Body / Mind / Discipline | quetes de ce type validees, Accomplie ou En partie | 2..7 (mind 1..6) |
| water | Eau bue | jours avec l eau validee | 2..7 |
| total | Quetes totales | toute quete validee | 4/6/9/12/15/18 |
| sec | Quetes secondaires | secondaires validees | 1/2/2/3/3/4 |
| perfect | Quetes parfaites | quetes en Accomplie | C+ : 2/3/4/5 |
| noFail | Jours sans fail | jours consecutifs sans obligatoire en fail | 2..7 |
| nnStreak | NN d affilee | jours consecutifs, 3 obligatoires en Accomplie | 2/3/3/4/5/6 |
| integ | Integrite | integrite au tirage + 10 a 18, plafond 95 | C+ |
| maxFail | Echecs toleres (ex « Discipline (max X fail) », renomme pour ne pas se confondre avec Quetes Discipline) | quetes ratees pendant le donjon | C+ : 3/2/1/0 |
| hardQuest | Quete Hard Mode | une quete Hard Mode en Accomplie | C+ |
| leveTot | Leve-tot | quetes validees dans les 2 premieres heures du creneau, heure REELLE | 2/3/4/6/8/10 |
| bilans | Bilans du soir | bilans ecrits, 1 par jour au plus | C+ : 4/5/5/6 |
| jourParfait | Journees parfaites | jours ou TOUTES les quetes sont en Accomplie (`_dayIsPerfect`) | D+ : 1/1/2/2/3 |
| sansPartie | Sans demi-mesure | rompue a la premiere « En partie » | C+ |
| ascete | Ascete | rompue au premier achat (`_buyDailyCard`, `_buyPermItem`, `buyRew`) | C+ |
| sansObjet | Sans artifice | rompue au premier objet utilise (`_shopUseItem`, hors boites) | B+ |

Refusees par Thibs : Energie haute, Journees completes, Obligatoires avant
midi. Paires jamais tirees ensemble (`_EXCL` dans `_variantConds`) :
noFail/maxFail, noFail/nnStreak, nnStreak/jourParfait, jourParfait/perfect,
jourParfait/sansPartie. Ajouter des candidats a change le tirage de tous les
donjons, c etait le but ; un donjon en cours garde ses conditions figees.

Mesure sur les 108 : 9 donjons a 1 condition, 36 a 2, 36 a 3, 27 a 4,
aucune paire exclue, aucun « en evenement ».

### Regle de perte du butin

- Une condition est MANQUEE des qu elle ne peut plus etre atteinte dans les
  journees restantes (plafonds par jour : 1 pour body/mind/disc/eau, 2
  secondaires, 6 quetes ; +10 d integrite par jour), ou a la fin pour Hard
  Mode, ou des la rupture pour les conditions « a tenir ». Une fois posee,
  elle est verrouillee (`act._manques`). Une condition atteinte l est aussi
  (`act._acquis`), meme si une serie retombe ensuite.
- Taux conserve = (conditions - manquees) / conditions, applique aux CASES
  (XP et points compris, decision de Thibs). Cases perdues =
  arrondi(cases x manquees / conditions), au moins 1, et au moins une case
  gardee tant qu une condition tient.
- L ordre de perte est tire UNE fois (`L._ordre`, `_dngOrdre`) a la premiere
  condition manquee, puis sauvegarde : rouvrir l application ne change rien,
  et une seconde condition manquee ajoute des cases sans rendre les autres.
- Au bout des 7 journees, le donjon n est plus efface : il passe
  `termine` et reste affiche jusqu a la reclamation (« Reclamer ce qui reste
  (X %) », ou « Clore le donjon » a 0 %). Le choix suivant vient apres.
- Seule une victoire SANS condition manquee compte pour `dungeonWins`,
  `dungeonStreak` et le bonus permanent de serie.
- Les compteurs ne tournent que pendant la fenetre reelle (`_dngEnCours`) :
  avant, ils comptaient aussi la veille d une Porte qui s ouvrait le
  lendemain. Donjon lance dans la journee : ce qui est deja valide ce jour la
  est repris, sans les echecs ni les « En partie ».

### Interface

- Replie : coffre miniature (scelle = assombri et « ? »), rang, nom, barre,
  jours ou « Termine », pile de 4 recompenses au plus puis « +n », et un
  anneau par condition. Le bouton de reclamation apparait aussi replie.
- Deplie : lore, « TABLEAU DE CHASSE », un papier epingle par condition avec
  un (i) en haut a droite. Toucher un papier insere l explication
  (`_dngInfo`) sous SA rangee, une seule a la fois, retoucher referme.
- Tresor : coffre du rang avec rayons, cases scellees, revelees (Eclat du
  Veilleur) ou en cendres, badge « X % conserve », texte de Thibs a ne pas
  reformuler sous un coffre scelle.
- Ecran de victoire : cases perdues barrees avec les cendres, titre
  « Donjon termine · X % du butin » pour une reclamation partielle.

Defaut trouve en route et corrige : la cle de cache de `#boss-zone` ne
suivait que `_body`, `_mind` et `claimed`. Un achat, un objet, l Eclat ou la
fin du donjon ne redessinaient pas la fiche. Elle porte maintenant l etat
complet du donjon actif.

Verifie par execution, vraies fonctions de l application :

    cases perdues   4c 1/4 -> 1 ; 6c 1/3 -> 2 ; 2/3 -> 4 ; 3/3 -> 6 ;
                    3c 1/2 -> 2 ; ordre stable et cumulatif
    fin + reclame   termine pose, choix non retires ; 1 manquee sur 3 :
                    points et fragment perdus, XP, cle, boite, titre verses,
                    dungeonWins inchange, donjon libere
    victoire        butin complet, dungeonWins +1
    fenetre         Porte de demain : rien compte la veille
    advDay          tout Accomplie : NN 1, sans fail 1, parfait 1 ;
                    une En partie : NN 0, sans fail 2 ; un echec : 0 et 0
    impossible      integ 60/95 a 2 jours, bilans 1/4 a 2 jours, serie,
                    echecs depasses : tous MANQUE ; a 6 jours : en cours
    affichage       430 et 360 px, 9 recompenses et 4 conditions : aucun
                    debordement ; (i) ouvre, change, referme
    rattrapage      entree a 10 h : Accomplie et En partie du jour repris,
                    echec non repris, Sans demi-mesure intacte

### Entree dans un donjon en cours de journee (regle de Thibs, 18 octobre)

Le creneau dure 16 h (`CRENEAU_DUREE`). `_dngStartDay` :

- dans les 11 premieres heures du creneau, le donjon commence AUJOURD HUI et
  les quetes deja validees du jour sont reprises (sans echecs ni « En
  partie ») ;
- dans les 5 dernieres heures (`_dngHeuresRestantes(h) <= 5`), il commence
  DEMAIN, et le joueur voit le texte de Thibs, a ne pas reformuler : « Ta
  journee est bien entamee. Pour ne pas te penaliser, le donjon commencera
  demain. » (accents dans l application). Bouton unique « Compris » ;
- hors creneau, demain, comme avant.

Cela remplace l ancien avertissement « Journee deja entamee » et ses deux
boutons « Continuer / Je reviens demain ». `_dngNNToutesTraitees`, qui ne
servait qu a lui, est supprimee.

Verifie : creneau 8 h, de 8 h a 18 h aujourd hui, de 19 h a 23 h demain, 3 h
demain ; creneau 20 h enroule, de 20 h a 6 h aujourd hui, de 7 h a 11 h
demain. Entree a 10 h : aucun dialogue de plus, quete du jour reprise. Entree
a 20 h : le message, puis la confirmation habituelle, et rien de repris.

### Retours de Thibs sur l appareil, 18 octobre au soir

- « Une carte Accomplie alors que le donjon ne commence que demain. » Vrai :
  l Integrite est une valeur vivante, elle etait lue avant l ouverture de la
  Porte. Avant `startDay`, plus rien n est compte, accompli ni manque
  (`avant` dans `_dungeonProgress`), progression a 0 %, et la fiche depliee
  le dit : « La Porte s ouvre demain : rien n est compte aujourd hui ».
- Les quetes « En partie » comptent bien pour Body, Mind, Discipline, Eau,
  Secondaires et Totales. Ce que Thibs voyait venait de la Porte de demain.
- Condition remplie mais reversible (Integrite, flag `vivant`) : jamais
  ACCOMPLI avant la fin. Elle affiche « Tenu », comme les conditions a tenir,
  et redevient « 90/95 » si elle retombe. Jugee a la fin ou a la reclamation.
- Eclat du Veilleur : utilisable sur le donjon EN COURS (`_dngEclat`), depuis
  le sac ou par un bouton sous le coffre scelle, avec le nombre d Eclats.
  Revele 100 % du coffre, cases en cendres barrees. Une seconde utilisation
  est refusee sans consommer d Eclat.
- Message « </b... » au bas de l ecran : c etait le Cristal de focus.
  `toast()` ecrit en `textContent`, donc `<b>En partie</b>` s affichait brut.
  Remplace par des guillemets. Au passage, le Cristal (les deux chemins,
  `_crystalFocusSur` et l objet du sac) compte desormais pour le donjon : il
  rompt Sans artifice, retire l echec de `_fail` et compte la quete en
  « En partie ».
- Hard Mode : il etait force TOUS les jours tant que la quete n etait pas
  faite. Un seul jour force par donjon desormais (`_dngJourHard`), entre le
  2e et le 6e jour, deduit de l identifiant, memorise dans `_hardVu` des
  qu il tombe ; un jour « minimum » le repousse au suivant. Le (i) donne le
  jour. Verifie : sur 7 jours simules, un seul H.

### Incident de fabrication, a ne pas reproduire

Un script de patch a plante PENDANT l ecriture (`UnicodeEncodeError` sur une
paire de substitution d emoji) apres avoir ouvert `index.html` en ecriture :
le fichier est tombe a 0 octet. Restaure depuis l archive livree, verifie
identique a la copie Android. Deux lecons :

- toujours ecrire dans `index.html.tmp` puis `os.replace` ;
- le fichier melange accents en caracteres reels et en sequences `\u`
  selon les zones ; un remplacement doit essayer les deux formes, sans
  decoder les paires de substitution (`\ud83d...`).

### Trois retouches du 19 octobre

- Integrite sans pourcentages : c est un nombre de 0 a 100, et une
  obligatoire ratee retire 5 POINTS (verifie : `ST.integrity-5` partout).
  Le (i) dit « au moins 95 d integrite sur 100 », l ecran de choix
  « integ. >= 95 ».
- Eclat du Veilleur depuis la fiche : confirmation `_dngEclatDemande`
  (« Reveler »), pour qu un toucher de passage ne consomme rien. Le sac a
  deja la sienne. Verifie : un refus ne revele rien et ne consomme rien.
- Toute la fiche deplie et replie (`onclick` sur `.boss-card`). Papiers,
  explication et boutons arretent la propagation. Verifie : toucher les
  anneaux deplie, un papier ou l explication ne replie pas, le texte replie.

Nombre de conditions par rang, rappel : E 1 a 2, D 2, C 2 a 3, B 3, A 3 a 4,
S 4 (`nConds` dans `_variantConds`).

### Economie mesuree le 19 octobre, base de la refonte des recompenses

- Journee parfaite, vraies fonctions : 25 a 31 XP et 10 a 12 pts, quel que
  soit le rang. Semaine simulee par `_testAutoOneDay` : 136 a 195 XP, 58 a
  70 pts. Les rangs Planetaire demandent 4 600 a 6 700 XP chacun.
- Ancien butin, 5 000 tirages par rang avec `_genDungeonLoot` : le nombre de
  cases plafonne a 6,5 du rang C au rang S. Seuls XP et points montent
  (S : 625 XP, 296 pts). Valeur hors XP en prix boutique : C 847, S 1 084,
  soit +28 % seulement pour un donjon bien plus dur.
- Une Boite Scellee ne s ouvre qu avec une Cle du Neant (`_hasKeyFor`).

## Butin de donjon en cases, 19 octobre

Decide par Thibs apres analyse. Le butin n est plus une poignee de champs
fixes mais une liste `L.cases`, une entree par case :
`{k:'xp',n}`, `{k:'pts',n}`, `{k:'item',effect,name,icon,rarity}`,
`{k:'frag',id,name}`, `{k:'cosm',effect,...}`, `{k:'titleEpic'|'titleLeg',id,name}`,
`{k:'shield',days}`, `{k:'cle'}`, `{k:'box',rank}`. `L.v=2`, `L.xpCase`.

Regles (`_genDungeonLoot`) :

| Rang | Cases | Cases XP | Cases points | Budget XP | Budget points |
|---|---|---|---|---|---|
| E | 4 | 1 | 1 | ancien x1,5 (~47) | ancien x0,75 (~12) |
| D | 6 | 1-2 | 1 | ~94 | ~22 |
| C | 8 | 2 | 1-2 | ~172 | ~41 |
| B | 10 | 2-3 | 2 | ~312 | ~74 |
| A | 12 | 3 | 2-3 | ~547 | ~130 |
| S | 14 | 3-4 | 3 | ~937 | ~222 |

- +1 case dans 15 % des donjons. Le budget XP et points est PARTAGE entre
  les cases (`_dngPartage`), pas multiplie par elles.
- Chaque autre case : objet 40, fragment 10, cosmetique 15, bouclier 5,
  cle 15, coffre 15.
- Objet (`_dngTirerObjet`) : consommables seulement. Commun x4, rare x2,
  epique x1 a partir du rang C, et les trois objets a 400 pts et plus
  (Pierre de Renaissance, Reset Integrite, Cristal de focus) a partir du
  rang B, poids 0,5. Decision de Thibs : favoriser les communs, qui se
  revendent peu.
- Fragment : un au plus par donjon (le suivant devient un objet), jamais un
  fragment deja possede ; tous possedes : case d XP.
- Cosmetique : Aura de l Ombre, Bordure Doree, Aura de Feu, Sceau du Monarque
  (60, temporaires, stockables, donc pas de remplacement), titre temporaire
  epique (28) ou legendaire (12) non possede, sinon case d XP. Les titres
  symboliques de la boutique sont EXCLUS (decision de Thibs).
- Bouclier : 1 jour 50 %, 3 jours 35 %, 5 jours 15 %.
- Coffre : rang du donjon 70 %, rang +1 30 %, plafonne a S.
- Revalidation (`_revalideTitresButin`) : un titre ou fragment obtenu entre
  le tirage et la reclamation devient une case d XP de valeur `xpCase`.
- Ancien butin : `_dngNormaliser` le convertit sur place, et traduit l ancien
  ordre de perte par cle (`_ordre`) en ordre par index (`_ordreI`).
- Cases perdues, fiche, ecran de choix, reclamation : tout passe par les
  index de `L.cases`. `_dngNomCase` donne le nom affiche partout.

Mesure, 5 000 butins par rang, valeur hors XP au prix boutique :

    rang  cases  objets  fragment  cles  coffres  valeur  (ancien)
    E     4,1    0,87    0,20      0,33  0,31     312     (286)
    C     8,2    1,94    0,39      0,70  0,68     734     (847)
    S    14,2    3,26    0,55      1,15  1,16    1879    (1084)

Le rang C vaut un peu moins qu avant en prix boutique : moins de fragments
(600 pts chacun) et moins de points, deux choix voulus. La progression E vers
S passe de x3,8 a x6.

Verifie : fragments jamais plus d un ; epiques jamais avant C, objets
premium jamais avant B ; tout possede, 0 fragment et 0 titre sur 2 000
donjons S, convertis en XP ; reclamation partielle 1 manquee sur 3, 8 cases,
3 perdues, les 5 autres versees exactement ; coffre de 15 cases rendu sur
trois lignes sans debordement a 430 px.

## Lot du 19 octobre : popups, abstinences, onglet Tests

### Une popup coupait l ouverture du butin
Cause : `_claimDungeon` et `_claimDailyBoss` appelaient `checkRankUp()` AVANT
d afficher l ecran de victoire, et sortaient par `return` si le rang montait.
L ecran de rang s ouvrait, le butin (deja verse) ne s affichait jamais.
Correctif : la victoire s affiche d abord ; `checkRankUp` est appele a sa
fermeture (donjon : bouton de `dungeon-victory-ov` ; boss du jour : bouton de
`boss-victory-ov`). Seul cas ou le rang passe d abord : donjon clos en
cendres (r >= N), qui n a pas d ecran de victoire.
Enchainement : `trig` sauvegarde avant de sortir sur un rang ou un titre ;
`closeRankUp()` appelle `checkNewTitles()`, pour qu un titre gagne en meme
temps qu un rang ne soit plus perdu.
Teste : rang monte pendant la reclamation, victoire visible et rang absent ;
apres fermeture, ecran de rang affiche.

### Abstinences : Tenu ou Fail
Dans `buildQ`, `isBinaire` : `d4`, `D102` (junk food), `D103` (alcool et
drogue), `D104` et `SD005` (pornographie), ou un nom qui contient
pornographie, alcool ou junk food (via `q._srcId||q.id`). Boutons « Tenu » et
« Fail », plus de « En partie », pas de de du destin ; une fois validee, la
quete affiche « Tenu » au lieu de « Accomplie ». Statut stocke : `perfect`.

### Onglet Tests de #Stats, version 2 (19 octobre)
La version 1 (dix cartes : rebond, paliers, qualite, jour x axe, obstacles et
plan si-alors, SRBAI, regularite, sanctions, resistance, nouveau depart) a ete
retiree : Thibs la jugeait en dessous des trois autres onglets. Les cles
`_planSiAlors` et `_srbai` ne sont plus utilisees.
Principe de la v2 : apprendre a l utilisateur quelque chose sur lui, en
confrontant ce qu il croit (mesure dans l app) a ce que ses donnees montrent.
Retenus par Thibs : 1, 3, 4 et le ressenti du matin. Refuses : pari du matin
(trop d effort quotidien, « on decide pour lui »), test go/no-go (sans rapport).
Bouton `stTab('st-tests',this)`, volet `#st-tests` > `#st-tests-body`, rendu
par `_renderTests()` (ouverture de l onglet, et `renderStats()` si actif).
Fonctions prefixees `_t`, juste avant `stTab`. Chaque carte sous try/catch.
1. Du matin ou du soir : rMEQ (Adan et Almirall 1991), 5 items, score 4-25,
   seuils 22/18/12/8. Stocke `ST._chrono` `{day,score,rep}`. Compare au
   moment reel : mediane de la 1re validation du jour et part des
   validations avant midi (`ST._valHeures`), des 7 jours de donnees.
2. Ta maitrise de toi : Brief Self-Control Scale (Tangney et al. 2004),
   13 items 1-5, inverses 2,3,4,5,7,9,10,12,13, score 13-65. Position par
   loi normale, moyenne 39,5 et ecart-type 8,5 (normes publiees : 606
   etudiants, 95 % entre 22,5 et 56). Compare au taux de quetes Discipline
   tenues sur 60 jours (10 occasions minimum). Remesure conseillee a 90 jours.
   Stocke `ST._bscs`. Traduction libre.
3. Ton ressenti du matin est-il fiable : taux de jours reussis selon
   `dayLog.morningMood` (good/ok/bad, reponse a « Comment te sens-tu ? »),
   120 jours, 3 jours minimum par cote. Verdict selon l ecart.
4. Tes conditions de reussite : 20 jours minimum, 120 jours. Cinq facteurs
   (week-end, lendemain d echec, bilan fait la veille, serie de 7 jours et +,
   1re quete dans les 3 h du creneau), 5 jours minimum de chaque cote ; les
   3 plus marquants affiches, verdict si l ecart atteint 10 points.
Collecte conservee : `ST._valHeures` (via `_tNoterHeure` dans `trig`) et
`_delaiMin` des bilans de sanction (non affiche pour l instant).
Teste a 360 et 430 px : etat vide et donnees fictives, 4 cartes, aucune
erreur, aucun debordement ; scores verifies a la main (rMEQ 18, BSCS 34).

## Donjon invisible apres une journee bouclee, 19 octobre

Bug : toutes les quetes validees, l entree dans un donjon affichait le toast
« la Porte se referme derriere toi » mais la carte ne changeait jamais.
Cause : la vue simplifiee (`renderMainDone`, drapeau `ql-nn.dataset.simplified`)
n est dessinee qu une fois ; ensuite `renderMain` ne faisait que
`_updateSimplifiedCd` et `_updateHeader` puis `return`. Le donjon etait cree
dans `ST._dungeonActive`, jamais redessine. Le mode test sautait cette vue,
d ou un affichage correct en test. Touchait aussi toute action sur la carte
donjon ou boss dans cette vue (Eclat, depli, reclamation).
Correctif : dans cette branche, `boss-zone` est redessinee a chaque
`renderMain` (`_renderDungeonCard` des le jour 7, `_renderDailyBoss` avant).

Regle tranchee par Thibs : si toutes les quetes du jour sont validees
(`allFullDone()`), le donjon commence le lendemain ; les quetes ont ete faites
hors du donjon. `_dngStartDay` renvoie alors jour+1 et `_confirmDungeon`
affiche « Tes quetes du jour sont deja validees, hors du donjon. Le donjon
commencera demain. » La regle des 11 premieres heures reste valable pour une
journee entamee mais pas bouclee.
Teste : quetes toutes validees, entree a 10 h, startDay = jour+1, carte
« Demain » affichee, aucun compteur repris.

Bloc gris « Nouvelles quetes dans ... - A demain. » supprime de la vue
simplifiee (`renderMainDone` et `_updateSimplifiedCd`) ; seul le bandeau vert
reste.

## Bouclier = Accomplie, et fond du curseur de creneau, 19 octobre

Regle (Thibs) : un jour sous bouclier, toutes les quetes comptent comme
« Accomplie » partout (donjon, stats). L affichage « Bouclier » reste sous
les quetes.
Bug : le statut `shield` n etait jamais compte par le donjon (les compteurs ne
montent que via `_dngTrack` a la validation) ; les cibles devenaient
impossibles et passaient « manquee ».
Correctif :
- `_dngBouclier()`, appelee en tete de `_dungeonProgress` : une fois par jour
  (`act._bouclierJour`), credite chaque quete du jour comme Accomplie (total,
  perfect, axe, secondaires, eau, leve-tot) sauf celles deja comptees
  (`act._vus`, liste du jour tenue par `_dngTrack`), puis vide `_manques`
  pour que les manquees soient recalculees. Un donjon deja marque manque a
  cause du bouclier se repare donc a l ouverture suivante.
- `_dayIsPerfect`, `perfCount` du bilan et la condition « Jour parfait »
  acceptent `shield` comme `perfect`.
Teste : bouclier le jour 2, Body et Discipline marques manques ; apres
credit, Body 2/7, Discipline 2/7, Leve-tot 5/10, aucune manquee, credit non
double au second appel.

Parametres, creneau actif : fond du bloc `.cr-bloc` passe de `#F2C75C` a
`var(--gold-bg)`, la couleur de la pastille « Xh restantes aujourd hui ».

## Onglet Tests, premier tri de Thibs (19 octobre, 11 h)
- Retire : « Du matin ou du soir ? » (`_tChrono`, `_T_Q.chrono`). Les
  reponses deja donnees restent dans `ST._chrono`, inutilisees.
- Remis depuis la v1 : « Prochains paliers » (`_tPaliers`) et « Obstacles
  recurrents » avec le plan si-alors (`_tObstacles`, `_T_OBST`,
  `_tPlanEnregistrer`, `ST._planSiAlors`).
- Ordre : paliers, conditions de reussite, ressenti du matin, obstacles,
  maitrise de toi.
- Question ouverte de Thibs : a quoi sert d enregistrer le plan ? Pour
  l instant il n est que conserve et reaffiche dans la carte ; aucune autre
  partie de l app ne s en sert. Pistes proposees : le rappeler dans le bilan
  du soir quand l obstacle ecrit tombe dans la meme categorie, ou dans le
  rappel du matin.
Teste a 360 px : 5 cartes, aucune erreur, aucun debordement.

## Declics et boost, 19 octobre (apres-midi)

Cap fixe par Thibs : les Stats avancees deviendront payantes (version Pro).
Elles doivent creer des declics : visuels, compris en 2 secondes, textes
personnalises tires des habitudes reelles. Pas de module « parce qu il en
faut ». Le paiement (abonnement Google Play) reste un chantier a part.

### Fil de declics (onglet Tests, en tete)
`_renderDeclics()` appelle dix fonctions `_d*`. Chacune renvoie null (rien
de net) ou `{s:score, h:html}` ; le fil trie par score et liste a la fin
ceux qui attendent des donnees. Carte commune `_dCarte` : etiquette, phrase
en gras, visuel, « Ce que ca veut dire ». Les alertes passent toujours en
tete (score 300 pour le seuil, 250 pour le motif actif).
Identite d une quete : `_dKey(nom)` (avant « : », sans chiffres ni unites),
nom affiche `_dNomK` (celui du jour si la quete est au programme).
1. `_dSeuil` : series cassees (bouclier neutre), zone = quartiles 25-75 des
   longueurs, 3 ruptures minimum. Dans la zone : alerte avec le texte de
   Thibs et la quete qui tombe le plus souvent le jour de la rupture.
   Visuel : barres des 11 dernieres series, zone en rouge, serie en cours.
2. `_dDomino` : obligatoires seulement (les secondaires passees noyaient
   l effet). Lien affiche si l ecart atteint 25 points ; 8 occurrences et 3
   echecs minimum. Visuel : la quete au centre, ses liens.
3. `_dMotif` : 5 signaux testes dans les 2 jours avant chaque journee ratee
   (En partie, matin « Pas bien », pas de bilan, secondaire passee, energie
   <= 2). Retenu si present avant 50 % des chutes et 25 points au-dessus des
   jours reussis. S il est present dans les 2 derniers jours : alerte.
4. `_dMoteur` : premiere quete validee du jour (`ST._valHeures`, collecte
   depuis le 19 octobre) et taux de journees bouclees ; 4 jours par type.
5. `_dEvite` : secondaire la plus passee sur 90 jours, 45 % minimum et 20
   points au-dessus des autres.
6. `_dCout` : jours pour retrouver une journee reussie apres un ecart,
   premiere moitie des ecarts contre la seconde ; 30 jours et 6 ecarts.
7. `_dMots` : mots des champs `relapse` et `block` des bilans, jours rates
   contre jours reussis ; 4 bilans rates minimum, 20 points d ecart.
8. `_dEffet` : jours de donjon contre hors donjon. Nouvelle collecte
   `ST._dngJours` (via `_dDngNoterJour` dans `_dungeonProgress`), donc vide
   au depart.
9. `_dProfil` : archetype tire des donnees (Marathonien, Phenix,
   Intermittent, Sprinteur, Batisseur) et 4 axes : endurance, rebond,
   regularite, constance. 30 jours minimum.
10. `_dBoost` : rappel du boost du jour.
Les anciens modules restent dessous, sous « Modules precedents ».

### Boost x4 (idee de Thibs)
`_boostDuJour()` : une fois par jour (`ST._boost`), parmi les obligatoires et
secondaires du jour hors Hard Mode, la quete la plus ratee ou passee sur 90
jours (4 occurrences et 40 % minimum). `_estBooste(q)` : pas de cumul avec
Hard Mode ni De du Destin. Carte : bordure, bandeau « Boost x4 », phrase de
Thibs, XP et points affiches x4. `trig` : XP et points x4 sur Accomplie
seulement (choix a confirmer par Thibs, « En partie » n est pas booste).
Teste : secondaire boostee 3 XP et 1 pt deviennent 12 et 4 ; une autre
quete garde son gain normal.

Teste a 360 et 393 px sur 160 jours fictifs (`pw/gen.js` du scratchpad) :
les dix declics s affichent, aucune erreur, aucun debordement.

## Onglet Tests, version 3 : tri et garde-fous, 19 octobre

Tri de Thibs : restent seuil de rupture, effet domino, quete-moteur, ce qui
marche sur toi (donjon), profil, maitrise de toi (BSCS). Tout le reste est
supprime du code (motif, evitement, mots, cout d un ecart, carte du boost,
paliers, obstacles, ressenti, conditions). Le boost x4 sur les quetes reste.

Critique de Thibs : des constats faux ou absurdes (domino sur « eteindre son
telephone apres 22h30 », quete jouee apres les autres ; « Pas d alcool » donne
comme quete qui casse les series pour 3 ruptures sur 48). Il veut des regles
universelles, pas des cas particuliers. Garde-fous communs (en tete du code) :
1. Minimum de donnees par declic.
2. Ecart reel : test de deux proportions `_dZ`, `_dNet` si |z| >= 1,96.
3. Comparaison a la propre base du joueur, jamais un chiffre brut.
4. Ordre dans la journee : `_dHeuresK()` donne l heure mediane de
   validation par quete (5 validations minimum). Nouvelle collecte : `k`
   (cle de quete) ajoute a `ST._valHeures` par `_tNoterHeure`.
5. Conseil faisable : `_dTardive` (mediane a 11 h ou plus apres le debut du
   creneau) remplace « valide-la tot » par « decide des le matin comment tu
   vas la tenir ».
Changements :
- Seuil : risque de casser par jour de serie (ruptures a L / series ayant
  atteint L), fenetre de 2 a 4 jours ou ce risque est nettement plus haut
  qu ailleurs (z >= 1,96, 3 ruptures et 5 series exposees minimum). La carte
  montre les deux taux. Quete nommee seulement si elle tombe dans 40 % des
  ruptures au moins ET nettement plus que les autres jours ; sinon l alerte
  dit « rater une journee ». Alerte des le jour lo-1 (jamais avant le jour 1).
- Domino : une source ne compte que les obligatoires validees au moins 1 h
  apres elle ; sans heures connues, pas de domino (il apparaitra apres 5
  validations par quete). Ecart de 20 points et z >= 1,96.
- Quete-moteur et effet du donjon : ecart soumis au meme test.
Correctif 14 h : textes du seuil en « apres X a Y jours de serie » (plus de
« le 1e jour ») ; compte a rebours = lo - serie, « demain » a 1 (plus de
« dans 0 jour »). Rappel : la zone porte sur tout l historique ; une longue
serie ne compte qu une fois par jour de serie atteint, elle ne deplace pas
la zone si les ruptures courtes dominent.
Seuil pondere et reglable (19 octobre, 14 h) : `_dZone(R,cur,mode)` calcule
la zone, `_dPoids` donne le poids d une rupture selon `ST._seuilMode` :
'pondere' (defaut, demi-vie 180 jours : moitie a 6 mois, quart a un an),
'6m' (180 derniers jours seulement), 'tout' (historique a egalite). Les
minimums (3 ruptures, 5 series exposees) portent sur les vrais effectifs, le
test z sur les sommes ponderees. Hors mode 'tout', la zone est aussi calculee
sur tout l historique : si elle differe, la carte dit si elle recule (progres)
ou avance. Selecteur de 3 boutons sous la carte (`_dSeuilReglage`,
`_dSeuilMode`) ; si un mode choisi ne donne rien de net, la carte reste
affichee avec le selecteur, pour pouvoir revenir.
Teste : historique ancien 5-6 jours, recent 9-10 jours ; pondere et 6 mois
donnent 9 a 10 jours avec « ta zone recule », tout l historique donne 5 a 6.
Teste a 360 et 393 px sur 160 jours fictifs, dont le cas « Pas d alcool »
(non designee) : seuil, domino, moteur, profil et maitrise s affichent ;
« ce qui marche sur toi » ecarte (91 % contre 77 % sur 33 jours, non
significatif). Boost x4 reverifie.

## Formulation des declics : les quatre pieges, 19 octobre (15 h)

Demande de Thibs : revoir la formulation pour eviter (1) le pourcentage
d echec qui devient une excuse, (2) l effet « au point ou j en suis » apres
une rupture, (3) le retour centre sur la personne plutot que sur l action,
(4) la fatigue d alerte. Pas de recompense pour l instant (decision de Thibs).
Regle : jamais de pourcentage d echec affiche ; toujours une preuve que c est
faisable (tire de l historique du joueur) et une action.
- Seuil : les cases « risque de casser X % / le reste du temps » deviennent
  « jour N, ton cap a franchir (ou cap franchi) » et « deja franchi K fois ».
  Alerte reformulee : « Attention : nous avons analyse tes habitudes. Tu
  entres dans ta zone de rupture, la ou tes series s arretent le plus
  souvent. Sois vigilant, et donne tout pour passer ce seuil ! » (la fin est
  le texte de Thibs ; « predire que tu vas rater X » est retire, c etait le
  piege 1). Quete nommee : « La quete qui fait la difference a ce moment-la »,
  sans pourcentage. Nouvel etat juste apres une rupture dans la zone (jusqu a
  2 jours) : « Ta serie s est arretee au jour N. Ca ne dit rien de la
  prochaine », avec le rebond (« tu repars le lendemain X fois sur 10 ») et
  le rappel du cap deja franchi. Evolution negative tournee vers l action.
- Seuil, calcul : taux ponderes, marge d erreur sur les vrais effectifs (sans
  cela 18 ruptures pesaient comme 10). Choix de la fenetre : la plus forte
  hausse de risque parmi les fenetres nettes. Mode par defaut sans resultat :
  repli sur tout l historique, signale dans la carte.
- Domino : formule en reussite (« Quand tu valides X, tes obligatoires
  suivantes tiennent A %. Quand elle manque : B % »), schema en vert, chaque
  lien montre « tient N % » quand la source est validee.
- Profil devient « Ta dynamique du moment » : 120 derniers jours seulement,
  phrases en « Ces derniers mois, tes series... », conseils « X est acquis.
  Prochaine marche : ... ».
- Maitrise de toi : verdicts sur les quetes, plus « tu te juges plus maitrise
  que tu ne l es ».
Teste : serie juste cassee, 0, 1, 2 et 5 jours ; historiques fictifs ;
domino, dynamique, maitrise ; boost x4 reverifie.

## Stats reorganisees et abonnement Pro, 19 octobre (fin d apres-midi)

### Nouvelle organisation de #Stats
Trois onglets : Vue generale, Automaticite, Insights (PRO). L onglet Tests
n existe plus.
- Automaticite : la courbe de Lally est dans le bloc jaune du score ;
  « Progression par phase » supprime (le rendu ecrit dans un objet vide si
  `#st2-phases` manque) ; « Detail par axe » est dans la carte de la toile
  d araignee ; puis Meilleur jour / Jour faible ; puis Historique des bilans.
- Insights : analyse hebdomadaire, puis les declics et la maitrise de toi
  (`#st-tests-body`, rendu par `_renderTests()` a l ouverture d Insights),
  puis Time Capsule, correlation Energie x Reussite, methodologie.
- Tout le contenu d Insights est dans `#st-insights-contenu`, precede de
  `#st-pro-verrou`.

### Abonnement Metanoia Pro (decisions de Thibs)
RevenueCat ; mensuel 2,99 EUR et annuel 19,99 EUR, 7 jours d essai gratuit ;
Insights reserve aux abonnes ; tout le reste de l app reste gratuit.
Plugin : `@revenuecat/purchases-capacitor` 13.7.4 (Capacitor 8), installe et
synchronise (`npx cap sync android`). Le plugin est appele directement par
`Capacitor.registerPlugin('Purchases')`, sans bundler.
Code (avant `stTab`, prefixe `_pro`) :
- `PRO_CFG` : cle API Android RevenueCat (`goog_A_REMPLIR`), identifiant du
  droit (`pro`), URL des conditions et de la confidentialite, prix de repli.
- `estPro()` : seule fonction a consulter pour savoir si le joueur est Pro.
  Lit le cache `ST._pro` (fin de droit respectee, 3 jours de grace hors
  ligne) ; en mode test, `ST._proTest` (bouton « Pro on/off » du panneau).
- `_proInit()` au chargement : configure RevenueCat, ecoute les changements
  de droit, lit le droit, charge l offre. `_proIdentifier()` relie l achat au
  compte Metanoia (`logIn` avec l id Supabase) a chaque connexion.
- `_proMaj(customerInfo)` : seule ecriture de `ST._pro`. Un import de
  sauvegarde efface `_pro` et `_proTest` : le statut vient de la boutique.
- Ecran `#s-pro` (Parametres > Abonnement) : `_proRendre()`. Non abonne :
  atouts, choix annuel (par defaut, badge -44 %) ou mensuel, prix et essai
  lus dans la boutique (repli sinon), bouton d essai, restauration, mentions
  legales de renouvellement. Abonne : statut, date de renouvellement ou de
  fin, « Voir mes Insights », « Gerer mon abonnement » (page Google Play).
- `_proAcheter()`, `_proRestaurer()`, `_proGerer()`. Annulation par le joueur
  : silencieuse. Echec : message, aucun prelevement. Boutique absente :
  message clair (hors mode test, ou le bouton active Pro sans paiement).
- `_proVerrou()` : Insights floute, carte cadenas avec accroches
  personnalisees (nombre de declics deja calcules, alerte en cours, zone de
  rupture masquee) ; tout tap ouvre l ecran Pro ; pastille PRO sur l onglet.
- Parametres : section « Abonnement » en tete, statut dans `#set-pro-sub`.
Teste a 360 et 393 px : verrou, tap vers l ecran Pro, achat hors boutique
(message), droit RevenueCat simule actif (deverrouillage, statut, date),
puis expire (reverrouillage), parametres.
Non teste ici : le vrai paiement (il faut le compte Google Play et RevenueCat).

### Mise en service de Pro (a faire par Thibs, dans l ordre)
1. Apres avoir dezippe le depot : `npm install` puis `npx cap sync android`
   (le module Android du plugin est dans node_modules, exclu de l archive).
2. Google Play Console : creer le compte developpeur (25 $), creer l app
   `com.metanoia_app`, envoyer un premier AAB signe sur le canal de test
   interne (les abonnements ne se creent qu apres un premier envoi).
3. Play Console > Monetiser > Abonnements : creer `metanoia_pro`, avec deux
   forfaits de base : `mensuel` (P1M, 2,99 EUR, renouvellement auto) et
   `annuel` (P1Y, 19,99 EUR). Sur chacun, une offre « essai gratuit » de
   7 jours (eligibilite : nouveaux clients). Activer.
4. Play Console > Parametres > Profil de paiement (compte marchand) rempli,
   sinon rien ne se vend.
5. RevenueCat (app.revenuecat.com) : creer le projet, ajouter l app Google
   Play (`com.metanoia_app`), et lui donner l acces au compte de service
   Google (guide RevenueCat « Google Play service credentials »).
6. RevenueCat > Product catalog : importer les deux produits ; creer
   l entitlement `pro` et y rattacher les deux ; creer l offering `default`
   (courante) avec les paquets `$rc_monthly` et `$rc_annual`.
7. RevenueCat > API keys : copier la cle publique Google (`goog_...`) dans
   `PRO_CFG.cleAndroid`. Renseigner `PRO_CFG.urlConfidentialite` (exigee par
   Google pour vendre) et `PRO_CFG.urlConditions`.
8. Tester avec un compte « testeur de licence » (Play Console > Parametres >
   Test de licence) : achats gratuits, renouvellements acceleres.

## Seuil de rupture : retour des pourcentages, 19 octobre (15 h 30)
Thibs prefere les pourcentages et les phrases preventives. Les cases
redeviennent « X % risque de casser chaque jour dans la zone / Y % le reste
du temps ». Trois niveaux d alerte :
- serie a 1 ou 2 jours de la zone : « Attention, tu vas rentrer dans une
  phase compliquee pour toi : des demain (ou dans 2 jours), ta serie entre
  dans ta zone de rupture. » (score 290) ;
- dans la zone : « Attention, tu es dans une phase compliquee pour toi :
  c est ici que tes series cassent le plus souvent. Sois vigilant, et donne
  tout pour passer ce seuil ! » (score 300) ;
- plus loin : « Ta prochaine phase compliquee : dans N jours. »
Les textes d explication donnent les deux pourcentages. Conserves : message
de rebond apres une rupture, « deja franchi K fois », quete qui fait la
difference, cap franchi (avec le pourcentage hors zone).

## Analyse de la semaine redigee par IA (option C), 19 octobre (16 h)

Principe : le telephone calcule tous les faits (aucun chiffre laisse a
l IA) ; une IA les met en mots via une fonction Supabase, une fois par
semaine ; sinon le moteur local redige la meme trame. Decision de Thibs :
option C (hybride), modele par defaut Claude Haiku 5.5, fournisseur
interchangeable.

### Cote app (dans `www/index.html`, avant `stTab`, prefixe `_hebdo`)
- Semaine analysee : la derniere semaine de programme close
  (`getWk()-1`, jours (W-1)*7+1 a W*7). Avant la premiere semaine close, les
  anciens constats de la semaine en cours restent affiches.
- `_hebdoFaits(W)` : jours (statut de chaque quete, humeur du matin,
  energie, obstacle et rechute du bilan, 140 caracteres au plus), jours
  reussis, part Accomplie, plus longue suite, moyennes des 4 semaines
  d avant, quete la plus solide et la plus fragile (obligatoire d abord),
  jour faible habituel (test z), declics actifs (seuil, domino, moteur),
  zone de rupture. Environ 5 Ko.
- `_hebdoLocal(F)` : redaction locale en 5 temps (verdict, ce qui a
  marche, ce qui a coince, ce qui change, la semaine qui vient + si/alors).
- `_hebdoObtenir(W)` : cache `ST._hebdo[W]` ({src:'local'|'ia', a, date,
  essai}), 26 semaines gardees ; demande l IA si Pro + consentement +
  session Supabase + en ligne, au plus une tentative toutes les 6 h.
- `_hebdoRendre()` dans `#st2-insights-list` (appele par `_renderTests`) :
  consentement unique en tete (`ST._hebdoIA`), carte de la semaine, mention
  « Redigee par l IA » ou « Redigee sur ton telephone », archive repliable.
  Tout texte (IA comprise) est echappe a l affichage : teste avec une
  balise piegee, rien ne s execute.
- Ecran Abonnement (abonne) : interrupteur « Redigee par l IA ».

### Cote serveur (nouveau dossier `supabase/`)
- `supabase/functions/analyse-hebdo/index.ts` : verifie la session, la
  taille de la demande, renvoie l analyse deja redigee si elle existe,
  verifie l abonnement aupres de RevenueCat (si `REVENUECAT_SECRET`),
  plafonne a 3 analyses par 7 jours et par joueur, appelle l IA, valide le
  JSON (6 cles), retire tirets longs et balises, enregistre, renvoie.
  Fournisseurs : `anthropic` (defaut) ou toute API compatible OpenAI
  (Mistral, Groq, OpenRouter, Ollama...) via `IA_URL`.
- `supabase/migrations/20261019_analyses_hebdo.sql` : table
  `analyses_hebdo` (user_id, semaine, contenu, modele, created_at), RLS en
  lecture sur ses propres lignes, ecriture par la seule cle service,
  suppression avec le compte.
Syntaxe TypeScript verifiee (esbuild). Non execute ici : il faut le projet
Supabase et une cle IA.

### Mise en service de l analyse IA (Thibs)
1. console.anthropic.com : creer une cle API (et un plafond de depense).
2. Supabase > SQL Editor : executer
   `supabase/migrations/20261019_analyses_hebdo.sql`.
3. Installer la CLI Supabase, puis dans le dossier du depot :
   `supabase login`, `supabase link --project-ref <ref du projet>`,
   `supabase functions deploy analyse-hebdo`.
4. `supabase secrets set IA_CLE=sk-ant-...` ; une fois RevenueCat en place :
   `supabase secrets set REVENUECAT_SECRET=sk_...`. Facultatif :
   `IA_MODELE` (ex. `claude-sonnet-5-5` pour un style plus riche),
   ou `IA_FOURNISSEUR=openai` + `IA_URL` + `IA_CLE` pour un autre
   fournisseur (verifier alors ses conditions d usage des donnees : le texte
   de consentement promet qu elles ne servent pas a l entrainement).
5. Cout indicatif (tarifs octobre 2026) : environ 3 000 jetons en entree et
   800 en sortie par analyse ; Haiku 5.5 moins de 0,1 centime, Sonnet 5.5
   environ 1,4 centime.

## Masquage Pro « vicieux », 19 octobre (17 h 30)
Demande de Thibs, pour les joueurs sans abonnement uniquement :
- plus de pastille PRO sur l onglet Insights ; plus de flou ni de carte
  cadenas globale (`#st-pro-verrou` reste vide) ;
- chaque module garde sa forme et son graphe, sans aucune valeur, avec une
  accroche et un bouton « Decouvrir » qui ouvre l abonnement.
Code :
- `_PRO_ACC` : accroche par module (cle = etiquette de la carte). Seuil :
  texte de Thibs « Nous avons analyse ou et quand tu echoues. Decouvre
  pourquoi, et ce que dit la psychologie ! ».
- `_dCarte` renvoie `_proTeaser` si `!estPro()` : etiquette, accroche,
  visuel passe par `_proSansValeurs` (chiffres remplaces par « .. »,
  elements `.pro-val` (noms de quetes du domino, nom du profil) remplaces,
  infobulles retirees), bouton `_proBouton()`.
- Maitrise de toi : courbe de population sans position, accroche, bouton.
- Analyse de la semaine : verdict remplace par une accroche, sections avec
  lignes grises a la place du texte.
- Time Capsule et Correlation : `_proMasquerBloc` efface les chiffres en
  place et ajoute une accroche avec bouton au-dessus (rappele apres le rendu
  synchrone de `renderStats`).
- Tout tap dans Insights ouvre l abonnement (capture inchangee).
Teste a 360 px : 8 boutons, aucun chiffre hors numero de semaine et dates
des references ; clic vers l abonnement ; une fois abonne, tout reapparait.

## Offre annuelle : cout par jour, 19 octobre (18 h)
Choix de Thibs : la carte Annuel affiche le cout par jour, plus par mois.
`_proPrix` renvoie `parJour` : prix boutique / 365, en centimes sous 1 EUR
(arrondi, 1 centime minimum), sinon avec deux decimales et la devise.
Repli `PRO_CFG.repli.annuelParJour` : « 5 centimes ». Teste : repli, boutique
a 19,99 EUR (« soit 5 centimes par jour »), boutique en USD (« 0,08 USD »).

## Onglets de #Stats : Insights au centre et en vedette, 19 octobre (18 h)
Ordre : Vue generale, Insights, Automaticite. Insights (classe `st-vedette`,
contenu `.st-vedette-in`) : pastille doree, police plus grande, reflet qui
passe toutes les 3,2 s (coupe si l appareil demande moins d animations).
Arrivee sur #Stats depuis un autre ecran : toujours la Vue generale (debut de
`nav`). Retour de l ecran Abonnement ouvert depuis Insights : on revient sur
Insights (`_proFermer`). Teste : arrivee, Insights, aller-retour Quetes,
retour d Abonnement.

## Lot du 19 octobre (18 h 10) : masquage, Lally, Insights
- Masquage contourne : `renderStats` remplissait `#st2-insights-list` avec
  les anciens constats en clair apres le masquage. Il rappelle maintenant
  `_hebdoRendre()` juste apres. Teste : Insights ouvert sans abonnement,
  rafraichissement des Stats, aucun constat brut, 8 boutons.
- Lally : la maturation utilisait l index dans `dayLog` (borne a 400
  entrees). Au-dela de 400 jours, la courbe refaisait une fausse montee depuis
  la phase 1 et les etiquettes Phase 1 / Phase 2 se chevauchaient a gauche.
  Maturation et bornes de phases sur le vrai numero de jour ; etiquette
  affichee seulement si sa phase fait 30 px au moins. Mesures : 400 jours
  parfaits finissent a 95, 30 derniers jours rates a 0 (comportement voulu :
  regularite x maturation), 4 jours sur 5 a 76, debutant parfait au jour 40
  a 70.
- Detail par axe : cases Body / Mind / Disc avec bordure de couleur 2 px et
  fond teinte.
- Insights : titre « Tes declics » et sa description supprimes ; message
  « Rien de net pour l instant » supprime.
- Nouveau bloc `#st2-attente` sous la correlation (`_attenteRendre`) :
  sablier anime, « N indicateurs attendent plus de donnees », leurs noms,
  barre de progression (indicateurs disponibles / 5), « Ils se debloquent
  d eux-memes au fil de tes journees ».

## Retour sur Quetes apres deconnexion, 19 octobre (18 h 20)
Signale par Thibs : apres une deconnexion, l app ne rebasculait plus sur
Quetes. Non reproduit en navigateur (ouverture par l engrenage, confirmation,
synchro simulee : retour a 1,2 s, un seul ecran actif, aucune erreur).
Durci quand meme : `settingsLogout` appelle `_versQuetesApresDeco()` a 0,6 s
puis 1,6 s. La fonction ne fait rien si Quetes est deja le seul ecran actif ;
sinon elle tente `nav('s-main')`, puis force l etat a la main (ecrans,
barre du bas, `renderMain`) si `nav` a echoue. Teste avec `nav` volontairement
casse : retour sur Quetes quand meme.

## Retour direct sur Insights, sans flash de la Vue generale, 19 octobre (18 h 25)
Avant : le retour de l abonnement passait par `nav('s-stats')` (qui remettait
la Vue generale) puis cliquait Insights 30 ms plus tard : un battement de cil
de Vue generale visible (captures de Thibs).
Maintenant : `_allerInsights()` pose `window._statsOngletVoulu='st-insights'` ;
`nav` lit cet onglet et l active AVANT d afficher l ecran, puis l oublie.
Utilise par `_proFermer` (origine stats), « Voir mes Insights » (ecran
abonne) et l ecran « Bienvenue dans Pro ». Arrivee normale sur #Stats :
toujours la Vue generale. Teste trame par trame (requestAnimationFrame et
MutationObserver) : 0 trame de Vue generale sur les deux chemins.

## Insights masque, version sobre, 20 octobre
Thibs trouvait la page masquee trop « putaclic / IA ». Changements (joueurs
sans abonnement uniquement) :
- un seul bandeau en tete d Insights (`#st-pro-verrou`, `.pro-bandeau`) :
  « Insights fait partie de Metanoia Pro », essai gratuit, bouton « Voir
  l offre » ;
- plus de boutons dores « Decouvrir » : une puce « Pro » discrete
  (`_proBouton()` rend `.pro-chip`) en haut a droite de chaque carte ;
- carte : nom du module en titre, texte sobre en dessous, graphe sans valeurs ;
- textes de Thibs (orthographe seule corrigee) dans `_PRO_ACC`, l analyse
  de la semaine, Time Capsule et Correlation ; « Ce qui marche sur toi » sans
  description ; « Ta dynamique du moment » : texte factuel (aucun texte fourni) ;
- module renomme « Ton auto-maitrise » partout (carte, test, ecran Pro).
Teste a 360 px : 8 puces, 0 bouton dore, bandeau ; abonne : rien de tout ca.

## Onglet Insights, version sobre, 20 octobre
Thibs trouvait la pastille doree animee trop « putaclic / IA ». L onglet
reprend la forme des deux autres (emoji + texte, soulignement si actif) ;
seuls le texte dore (`#b8862f`) et la graisse 800, meme inactif, le
distinguent. Emoji 💡. Plus de pastille, de reflet ni d animation.

## Analyse de la semaine branchee sur Groq (gratuit), 20 octobre
Decision de Thibs : API gratuite issue du depot public-apis ; l accord de
l utilisateur est donne en prenant Pro.
- Fournisseur par defaut de `supabase/functions/analyse-hebdo` : Groq (API
  compatible OpenAI, `https://api.groq.com/openai/v1`), modele
  `llama-3.3-70b-versatile`. Seul le secret `IA_CLE` est obligatoire.
  Sortie JSON forcee (`response_format: json_object`), redemande sans si le
  fournisseur refuse (400) ; quota gratuit atteint (429) : erreur, l app
  garde la redaction locale et reessaie 6 h plus tard.
- Pourquoi Groq : offre gratuite, ne conserve pas les donnees d inference
  par defaut (journaux possibles 30 jours). Mistral ecarte : son offre
  gratuite « Experiment » peut utiliser les requetes pour entrainer ses
  modeles. Limites gratuites relevees (octobre 2026) pour ce modele : environ
  1 000 requetes et 100 000 jetons par jour, soit une vingtaine d analyses
  par jour ; au-dela, passer sur un modele moins gourmand ou payant (changer
  `IA_MODELE`, ou `IA_FOURNISSEUR=anthropic`).
- App : plus de carte de consentement ; l IA est active par defaut pour les
  abonnes (`ST._hebdoIA!==false`), desactivable dans Abonnement (texte :
  envoi a un service d IA externe). Mention ajoutee aux conditions affichees
  avant la souscription.
Mise en service : console.groq.com > API Keys > creer une cle, puis
`supabase secrets set IA_CLE=gsk_...` et `supabase functions deploy
analyse-hebdo` (plus la table SQL si pas encore faite).
A faire avant publication : ecrire cette sous-traitance dans la politique de
confidentialite (exigee par Google Play).

## Bouton « Pro » du mode test, 20 octobre
Le bouton existait (« Pro on/off ») ; il affiche maintenant son etat
(« Pro : active / desactive », `#test-pro-btn`, `_testProLib`) et
`_testBasculerPro()` force l etat dans les deux sens : en mode test,
`estPro()` renvoie `ST._proTest` des qu il est defini, meme si un vrai
abonnement est actif. Redessine aussitot Insights, Stats, Parametres et
l ecran Abonnement. Hors mode test, `ST._proTest` est ignore.
Teste : 1 clic active (puces et bandeau disparaissent, analyse visible),
2e clic desactive, vrai abonnement coupe par le bouton.

## Analyse IA : chaine de secours et nouvelles consignes, 20 octobre (21 h 30)
Remplace la section « branchee sur Groq » pour la configuration (les
variables `IA_FOURNISSEUR` / `IA_URL` / `IA_MODELE` n existent plus).

### Chaine de secours (`supabase/functions/analyse-hebdo/index.ts`)
Les maillons sont essayes dans l ordre ; un maillon sans cle est saute. On
passe au suivant sur : quota epuise (429), panne (5xx), delai de 25 s
depasse, reponse non JSON, ou chiffre absent des faits.
1. Groq `openai/gpt-oss-120b` (secret `GROQ_CLE`, ou `IA_CLE`)
2. Groq `qwen/qwen3.8-27b` (meme cle, quota separe par modele, preview)
3. Cerebras `gpt-oss-120b` (`CEREBRAS_CLE`)
4. OpenRouter `meta-llama/llama-3.3-70b-instruct:free` (`OPENROUTER_CLE`)
5. Groq `openai/gpt-oss-20b` (dernier recours gratuit, plus faible)
6. Anthropic `claude-haiku-5-5` (`ANTHROPIC_CLE`, payant, facultatif)
Gemini ecarte par defaut : son offre gratuite peut utiliser les requetes
pour ses produits hors UE. `IA_CHAINE` (JSON) remplace l ordre si besoin.
Le modele qui a redige est enregistre dans `analyses_hebdo.modele` ; les
echecs de la chaine sont journalises (`console.warn`) dans les logs de la
fonction. Tous echoues : 502, l app garde sa redaction locale.
Garde-fou anti-invention (`chiffresHonnetes`) : tout pourcentage, decimal
ou nombre superieur a 31 ecrit par l IA doit exister dans les faits ; sinon
maillon suivant. « si_alors » vide s il n a pas la forme « Si ..., alors je ».
Teste sous Node avec des fournisseurs simules : 429, puis texte non JSON,
puis « 87 % » invente, puis reponse correcte retenue (OpenRouter) ;
2e demande servie depuis la base sans appel ; tout en panne : 502.

### Consignes (`supabase/functions/analyse-hebdo/consignes.ts`)
Le jeu en bref (glossaire), ce que le modele recoit, l objectif (« une chose
vraie apprise sur soi + quoi faire la semaine prochaine »), une methode en 5
etapes (fait marquant, explication tiree des faits seulement, suivi de la
priorite precedente, UNE action par ordre de priorite : zone de rupture,
quete obligatoire fragile, jour faible, consolider ; plan si/alors relie a
l obstacle ecrit), regles de fond (chiffres tels quels, pas de cause
inventee, semaine parfaite / difficile, citer ses mots, parler des actes pas
de la personne), regles de forme (60 mots par champ, formules creuses
interdites), exemples bon / mauvais, format JSON, verification finale.

### Cote app
`_hebdoFaits` ajoute `priorite_semaine_precedente` (l action de l analyse
precedente) et `semaine_precedente` (jours reussis), pour que le coach dise
si la priorite a ete tenue.

### Mise en service
Au minimum : `supabase secrets set GROQ_CLE=gsk_...` (console.groq.com).
Pour plus de marge, gratuits aussi : `CEREBRAS_CLE` (cloud.cerebras.ai),
`OPENROUTER_CLE` (openrouter.ai). Puis `supabase functions deploy
analyse-hebdo` (le dossier contient 2 fichiers, deployes ensemble).
Les noms de modeles changent souvent : les verifier dans chaque console en
cas d erreurs 404 dans les logs.

## Analyse de la semaine : 3 mois de recul (20 octobre 2026)

Une semaine seule ne dit presque rien. L analyse lit maintenant la semaine a
la lumiere des 90 derniers jours, et cherche pourquoi chaque echec a eu lieu.

### Les faits (`_hebdo90(W)`, cle `trois_mois` de `_hebdoFaits`)
Absent (null) sous 21 jours d historique. Sinon, calcule sur les 90 jours
qui finissent avec la semaine analysee (boucliers exclus) :
- `reussite_90j_pct` contre `reussite_semaine_pct`, `part_accomplie_90j_pct` ;
- `semaines` : jours reussis des 13 dernieres semaines (tendance) ;
- `par_jour_de_semaine`, `quetes` (8 au plus, 10 occurrences minimum :
  reussite sur 90 jours contre cette semaine), `humeur_du_matin` (5 jours
  minimum par humeur), `energie_du_soir` (basse 2 ou moins contre haute 4
  ou plus, avec `net` = test z) ;
- `mots_des_jours_rates` : mots des bilans (obstacle, rechute) presents
  dans 3 jours rates au moins, avec 20 points d ecart ou plus contre les
  jours reussis (mots vides ecartes, `_H_STOP`) ;
- `patterns_d_echec` (4 au plus) : signaux `_H_SIGNAUX` mesures dans les 2
  jours AVANT chaque journee (quete en partie, matin « Pas bien », soir sans
  bilan, energie 2 ou moins, secondaire passee, echec la veille), plus les
  jours de la semaine. Garde seulement si 5 occasions minimum de chaque
  cote, 15 points d ecart ou plus ET z 1,96 ou plus. Pas de bruit envoye.
- `anatomie_des_echecs_de_la_semaine` : pour chaque jour rate, quetes
  tombees, humeur, energie, obstacle, serie juste avant, dans la zone de
  rupture ou non, signaux des 2 jours avant, et lesquels sont ses patterns.
Taille des faits sur 160 jours fictifs : environ 8 600 caracteres (limite
serveur 24 000).

### Serveur
Nouvelle cle facultative `fond` (« Sur 3 mois »), forcee a vide quand
`trois_mois` est absent. Le garde-fou des chiffres couvre les nouveaux
champs. Consignes : explication des nouveaux champs ; etape 2 = pourquoi
chaque echec, d abord via l anatomie et les patterns ; comparaison a la
norme des 3 mois ; nouvelle priorite d action « couper le pattern le plus
fort » (apres la zone de rupture) ; exemples bon / mauvais « fond ».
Teste sous Node : `fond` garde avec 3 mois, vide sans, chiffre invente
rejete.

### Redaction locale (sans IA)
`coince` dit aussi pourquoi (« Mardi a ete precede d une quete validee
seulement en partie : chez toi, ce signal fait passer l echec de 3 % a
24 % »), ou a defaut signale un echec tombe en zone de rupture. `fond` :
le pattern le plus net, sinon une quete qui decroche, sinon un mot qui
revient, sinon « aucun schema fixe », puis la semaine contre la norme.
L action vise le pattern le plus fort quand la zone de rupture n est pas
proche. Espaces insecables avant « : » et « % ».

### Carte
Nouveau bloc violet « Sur 3 mois » (◷) entre « Ce qui change » et « Ta
semaine qui vient », affiche seulement s il a du contenu. Les analyses
deja en cache gardent leur forme jusqu a la semaine suivante.

## Analyse de la semaine : diagnostic IA (20 octobre 2026)

Sous la carte, pour l admin (ou en mode test) et seulement quand la
redaction est locale, une ligne rouge « Admin, IA : ... » dit pourquoi
l IA n a pas redige (`_hebdoDiag`) : pas Pro, IA desactivee dans
Abonnement, Supabase non initialise, non connecte au compte, hors ligne,
ou la reponse du serveur (« HTTP 502 : redaction », « HTTP 401 : non
connecte », « HTTP 402 : abonnement », « HTTP 429 : limite », 404 si la
fonction n est pas deployee). Bouton « Relancer » (`_hebdoRelancer`) :
redemande tout de suite, sans attendre le delai de 6 h entre deux essais.
Teste : erreur 502 simulee affichee, puis reponse IA acceptee et carte
basculee en « Redigee par l IA ».
Le serveur renvoie aussi, en cas d echec, la liste `essais` (un motif par
maillon : code HTTP du fournisseur, « JSON invalide », « chiffre absent des
faits (12 %) » avec le chiffre fautif, ou « aucune cle IA trouvee »),
affichee dans la ligne admin. `chiffresHonnetes` devient `chiffreInvente`
(renvoie le chiffre rejete). Pour copier-coller la fonction dans le tableau
de bord Supabase : `analyse-hebdo-un-fichier.ts` (consignes integrees).

## Analyse de la semaine : modeles Groq retires (20 octobre 2026)

Premier essai reel : 502, logs « llama-3.3-70b-versatile : 404 »,
« llama-3.1-8b-instant : 404 », « openai/gpt-oss-120b : 429 ». Groq a
retire les deux Llama le 16 aout 2026 (page Deprecations). Nouvelle chaine :
`openai/gpt-oss-120b` (raisonnement `low`), `qwen/qwen3.8-27b`
(raisonnement masque), Cerebras `gpt-oss-120b`, OpenRouter, `openai/gpt-oss-20b`,
Anthropic. Parametres propres au modele dans `extra`, retires si le
fournisseur repond 400. Sur 429 avec `retry-after` de 8 s ou moins : une
seconde tentative apres l attente. `max_tokens` passe de 1200 a 2000 (le
raisonnement des gpt-oss consomme des jetons avant le JSON). La cle Groq
fonctionne (pas de 401).

## Analyse de la semaine, version 2 : la voix du Systeme (20 octobre 2026)

Premier essai IA reel juge « flou, inadapte » : action tautologique (« fais
tes quetes en entier »). Causes : patterns tautologiques envoyes, IA sans
contexte sur l app ni le joueur, consignes de rapport. Refonte :

### Consignes (`consignes.ts`, reecrites)
- L IA parle comme le Systeme de Metanoia (« je »), la « main superieure ».
- « L ame de Metanoia » : texte de Thibs, tel quel (orthographe corrigee).
- Son exemple d analyse sert de modele de ton, avec deux limites : aucune
  statistique exterieure, aucune promesse de recompense.
- Methode : 2 a 4 moments (exploit, echec apres record, echec sur une
  resistance declaree, echec qui suit un schema, accident), puis le fond
  (une chose vraie sur lui, 3 mois), puis UNE action qui change une
  condition (heure, ordre, taille, ce qui precede), avec une liste de
  leviers par schema. Actions qui redisent l objectif interdites.
- Vocabulaire technique interdit (anatomie, pattern, signal, taux...).

### Sortie v2
`{verdict, moments:[{jour, type: exploit|echec|declic, texte}], fond,
action, si_alors, v:2}`. Serveur : 1 a 4 moments obligatoires, type inconnu
ramene a « declic », chiffres controles dans tous les textes.

### Faits ajoutes
- `joueur` (`_hebdoJoueur`) : reponses au questionnaire en clair (age,
  situation, sport, objectif, lecture, sommeil, ecran, resistances
  declarees, mode), jour du programme, boucliers en stock, bouclier actif.
- `trois_mois.exploits_de_la_semaine` : quete tenue cette semaine, reussie
  50 % du temps ou moins sur 90 jours (10 occurrences minimum).
- `trois_mois.rebond` : echecs suivis d un autre echec le lendemain.
- `trois_mois.heures` : heure mediane de validation de chaque obligatoire,
  habituelle contre cette semaine, glissement de 1 h 30 ou plus.
- Anatomie : `record_avant`, `serie_avant_est_un_record` (5 jours ou plus,
  au-dessus du record precedent), `resistance_concernee` (`_H_RESIST` :
  mots cles de la quete ratee croises avec les resistances declarees).
- Signaux : « en partie » et « echec la veille » retires (tautologiques),
  « validees tard » ajoute (mediane des validations obligatoires 11 h ou
  plus apres le debut du creneau).

### Carte
Bande des 7 jours dessinee par l app (✔ ✕ 🛡), puis les moments (★ Exploit,
✕ Chute, ◆ Declic, jour en titre), « Sur 3 mois », « Ta semaine qui
vient ». Les analyses v1 en cache s affichent encore avec l ancien format.
Moteur local reecrit dans le meme format et la meme voix.

### Admin : « Reecrire »
Ligne admin toujours visible pour l admin (modele utilise quand c est
l IA). « Reecrire » regenere la redaction locale puis redemande l IA avec
`forcer:true` : le serveur ignore alors son cache et la limite de 3 par
semaine, et remplace la ligne (upsert), seulement si l utilisateur est
`ADMIN_UID` (secret facultatif, sinon l UID admin de l app).
Teste sous Node : moments filtres, refus sans moment, forcer admin.

## Analyse de la semaine : les bilans du soir (20 octobre 2026)

- Correction du texte de l ame : « rate au moins une quete obligatoire »
  (et non secondaire) declenche la Sanction.
- `jours` : bilan complet (bilan fait ou non, discipline ressentie,
  resistance aux tentations, obstacle et rechute jusqu a 400 caracteres).
  La lettre a soi-meme n est jamais envoyee.
- Anatomie : `quetes_ratees_reussite_habituelle`, `bilan_du_soir` et
  `bilan_de_la_veille` (ce qui a bloque, rechute, tentations, discipline).
- `trois_mois.ses_mots_les_jours_rates_avant_cette_semaine` : les 8
  derniers bilans ecrits les soirs d echec, pour reperer ce qui revient.
- Faits passes par `_hebdoFaits0` puis garde-fou de taille 22 000
  caracteres (retire d abord les vieux bilans, puis raccourcit).
- Consignes : section « Ses bilans d abord » (ses mots priment sur les
  chiffres, les citer et y repondre, reperer une situation qui revient) et
  regle « incident » (quete reussie 75 % du temps ou plus, ratee une fois).
- Moteur local : « Tu as rate « X », que tu reussis 87 % du temps : un
  incident, pas une tendance. Ce soir-la, tu as ecrit : « ... ». »
Taille des faits sur 160 jours fictifs : environ 10 800 caracteres.

## Analyse : deux niveaux et bibliotheque de faits (20 octobre 2026)

### Deux niveaux (decision de Thibs)
- Redigee sur telephone : version allegee. Verdict, bande des 7 jours, 2
  moments au plus (l exploit, puis la chute principale : record, puis
  resistance, puis incident, puis zone, puis schema), une action. Ni « Sur
  3 mois », ni citation des bilans, ni fait exterieur, ni si/alors.
- Redigee par l IA : version complete (tout le reste, plus la bibliotheque).

### Bibliotheque de faits verifies (`bibliotheque.ts`)
29 faits sources (habitudes, plans si/alors, suivi, nouveaux departs,
echec et rechute, series, tentations, soutien social, sommeil, alcool,
ecrans, sport, froid, pornographie), chacun verifie sur sa source le 20
octobre. Fiche lisible : `bibliotheque-faits.md` (livree a part).
`choisirFaits` choisit les 6 plus utiles selon le joueur (resistances
declarees, sommeil, record, resistance touchee, rebond, heures, patterns,
noms des quetes) ; ils sont joints aux faits envoyes. Consignes : un seul
fait au plus, cite fidelement avec sa source courte, jamais d autre chiffre
exterieur. Le controle des chiffres accepte ceux de la bibliotheque (virgule
decimale geree : « 33,4 % »).

### Limite de jetons (Groq gratuit : 8 000 par minute, entree + sortie)
- Faits compacts : par jour, `quetes_accomplies` (nombre) et
  `autres_quetes` (seulement celles non accomplies). `declics` retires
  (redondants avec `trois_mois`). Garde-fou de taille a 9 000 caracteres.
  Sur 160 jours fictifs : environ 8 200 caracteres.
- `max_tokens` 1600 ; bibliotheque limitee a 6 faits.
- Fichier unique pour le tableau de bord : consignes ET bibliotheque
  integrees.

## Mode test : jours de la semaine corriges (20 octobre 2026)

En mode test, les journees avancent sans que la vraie date change : chaque
entree du journal gardait le jour reel (tout « lundi » dans la bande et les
analyses). `_dLog` renvoie desormais, en mode test seulement, une copie de
chaque journee avec le jour de la semaine recalcule depuis le calendrier de
test (`_EV_EPOQUE_TEST`, meme base que `_evDateDecalee`). Les donnees
stockees ne sont pas modifiees. Profite aussi aux declics (jour faible,
etc.) en mode test. Teste : journal force a « lundi », semaine lue mardi a
lundi, coherente avec le calendrier de test. Apres mise a jour, « Reecrire »
pour regenerer l analyse deja en cache.

## Analyse : actions faisables dans le jeu (20 octobre 2026)

Essai reel : « Reduis la quete « Prendre tous ses repas sans telephone » en
ne la faisant qu au dejeuner, en 5 minutes » et un si/alors qui reporte au
dejeuner un soir. Causes : leviers « reduire sa taille » et « version de 5
minutes » dans les consignes, aucune distinction entre quetes d action et
quetes de resistance. Consignes corrigees :
- Le Systeme impose les quetes : l IA ne change jamais une quete (pas de
  reduction, pas de duree inventee). Seul recours du jeu : valider « en
  partie » une quete d action.
- Quetes d ACTION : leviers de moment, d ordre, de preparation. Quetes de
  RESISTANCE (« sans », « pas de », « aucun ») : leviers d environnement et
  de declencheurs seulement (eloigner la tentation avant le moment a risque).
- Si/alors : declencheur concret qui arrive avant le risque, action
  immediate, jamais de report vers un moment passe ; bon et mauvais exemple.
- Un seul moment par jour (regrouper record, resistance, energie).
Moteur local : plus de « version courte » ni « version de 5 minutes » (« en
partie s il le faut ») ; quete fragile de resistance : « eloigne la
tentation avant le moment a risque ».

## Analyse : collecte par jour, contraste, comparaison (20 octobre 2026)

Methode voulue par Thibs : 1. le telephone collecte chaque jour (sac,
bilan, fatigue) ; 2. on relie aux jours rates et reussis ; 3. on compare
les quetes aux 3 mois et a la bibliotheque ; puis une solution.

### Collecte (telephone)
- `_jourInstantane` / `_jourFiger` (appele par `save`) : a la cloture d une
  journee, `dayLog[i].snap = {b: boucliers, c: cristaux de focus, r: pierres
  de renaissance, p: points, f: fatigueScore, g: getGlobalState()}`. Couvre
  toutes les facons de clore une journee. Non retroactif.
- Par jour dans les faits : `fatigue_du_systeme` (epuise, fatigue, normal,
  en forme), `etat_du_systeme`, `sac_en_fin_de_journee` (stock,
  `objets_utilises` par difference avec la veille, et pour un jour rate
  `aurait_pu_sauver_la_journee` : cristal en stock, bouclier en stock la
  veille, ou 80 points pour un bouclier 1j).
- `contraste_jours_reussis_et_rates` : energie, discipline, fatigue,
  matins « pas bien », bilans faits, tentations resistees, par groupe.
- `trois_mois.quetes` : `ecart_points` (semaine moins 90 jours) et
  `cette_semaine` (statuts groupes : « accomplie : sam dim ; ratee : mar »).

### Allegement (8 000 jetons par minute)
Champs vides retires des faits ; anatomie sans doublon avec `jours` ;
semaines limitees a 8. Sur 160 jours fictifs : environ 9 000 caracteres.
Serveur : sur un 413, la meme demande est rejouee en version courte (sans
les champs les moins utiles, 3 faits de bibliotheque).

### Consignes
Nouvelle section « Ta methode, en trois temps » (lis chaque jour, relie
aux resultats, compare), objets du sac expliques (Bouclier, Cristal de
focus, Pierre de Renaissance), etat de forme du Systeme ; un objet qui
aurait pu sauver la journee : le dire une fois, comme un conseil de jeu.
Moteur local : la chute principale mentionne un Cristal de focus ou un
bouclier qui etait dans le sac.

## Analyse : ecrire pour etre compris (20 octobre 2026)

Retour de Thibs sur deux essais reels : phrases floues (« le signal »,
« comme le montre le pattern « une energie du soir a 2 sur 5 ou moins » »),
energie du soir presentee comme cause, faux exploit (quete reussie 92 % du
temps faite « en partie »), declic vide, comparaison inventee aux autres
(« peu de participants »), fond sans direction.

### Faits rediges en clair (telephone)
- Chaque signal a une proposition en clair (`c`). `patterns_d_echec[].en_clair` :
  « Chez toi, quand la veille ou l avant-veille tu as fini la journee avec
  une energie de 2 sur 5 ou moins, la journee qui suit est ratee 36 % du
  temps, contre 13 % le reste du temps. » Le champ `signal` (etiquette) n est
  plus envoye.
- Anatomie : `ce_qui_s_est_passe_les_2_jours_avant` et
  `ce_qui_annonce_souvent_tes_echecs` (phrases completes) remplacent les
  etiquettes. Moteur local adapte.

### Consignes
Nouvelle section « Ecris pour etre compris » (regle la plus importante) :
un ami qui ne connait pas l app comprend chaque phrase ; chaque moment
raconte ce qui s est passe, ce qui l avait precede, ce que ca veut dire ;
reprendre les phrases en clair ; aucune etiquette des donnees entre
guillemets ; energie et fatigue du soir = la journee, pas la cause ;
resistances = reponses au questionnaire, pas des quetes ; exploit
uniquement depuis `exploits_de_la_semaine` ; declic seulement s il apprend
quelque chose ; aucune comparaison aux autres hors bibliotheque ; exemple
mauvais / bon. Fond en trois temps : constat, sens, direction (« Continue
ainsi » autorise s il est relie a une raison). Moments jusqu a 60 mots.
Section « Ce que tu recois » condensee (jetons).

## Analyse : echelles, quetes du lendemain, secondaires (20 octobre 2026)

- Energie du soir envoyee en clair : « 4 sur 5 (bonne) ». Contraste :
  `energie_soir_moyenne_sur_5`. Consignes : echelles sur 5 expliquees, 4 =
  bonne, jamais presentee comme une difficulte.
- Les quetes sont revelees le matin : consignes (jamais preparer une quete
  precise la veille, sauf « Vision d elite » ; preparer un creneau,
  l environnement, le materiel). Levier « jour faible » et action locale :
  bloquer la veille un creneau pour chacune des 3 obligatoires.
- Secondaires facultatives : une secondaire passee qui precede des echecs
  est un signe avant-coureur, pas une cause.
- Mots cles expliques entre parenthese la premiere fois, sans tiret bas.
  Serveur : la cle interne `k` des schemas n est plus envoyee, et
  `nettoyer` remplace un tiret bas entre deux lettres par une espace.
- Serveur : un moment « exploit » dont le jour n est pas dans
  `exploits_de_la_semaine` devient « declic ».

## Analyse : nouvelles API gratuites (21 octobre 2026)

Recherche des offres gratuites (liste communautaire free-llm-api-resources
et pages officielles, 21 octobre 2026) :
- Ajoutes a la chaine : Cloudflare Workers AI `@cf/openai/gpt-oss-120b`
  (10 000 neurones gratuits par jour, environ 34 analyses ; secrets
  `CLOUDFLARE_CLE` = jeton API Workers AI et `CLOUDFLARE_COMPTE` =
  identifiant de compte, l adresse contient `{CLOUDFLARE_COMPTE}`, maillon
  saute si l un manque) et OpenRouter `openai/gpt-oss-120b:free` avant
  Llama (meme quota gratuit de 50 par jour).
- Ecartes : Google Gemini gratuit (conditions : seuls les services payants
  sont autorises pour une app proposee a des utilisateurs de l EEE),
  Mistral gratuit (exige d accepter l entrainement sur les donnees),
  NVIDIA NIM et Cohere (essai, pas de production), Cerebras (plus qu un
  credit unique de 5 dollars avec carte).
- `urlDe` remplace les variables `{NOM}` de l adresse par les secrets.
Teste sous Node : Cloudflare saute sans compte, appele avec la bonne
adresse quand les deux secrets existent.
Export lisible des consignes et d un exemple de donnees envoyees :
`analyse-ia-prompt-et-donnees.md` (livre a part).

## Analyse : consignes reecrites par Thibs (22 octobre 2026)

`consignes.ts` remplace par le texte de Thibs (4 199 jetons avant, 3 155
maintenant), repris tel quel. Retires : le mot « Introduction » et
« [67 jetons] », ajoutes par le document Word d export. Corrections
d orthographe seulement : attends > attend, verouille > verrouille, permets >
permet, mets > met, n' est > n'est, commencer-un > commencer un, leur quetes
> leurs quetes, qu'envoies tu > qu'envoies-tu, n'a vu > n'a pas vu,
Felicites le > Felicite-le (deux fois), encourage le > encourage-le,
reussie > reussit, Ensuites > Ensuite, Utilises > Utilise, echoue > echoue
(accent), restais > restait, cite > citer, double virgule, utilises des
metaphores > utilise, « . LIS » > « 1. LIS ».
Sortie : `max_tokens` 2500 (1400 en repli apres un 413) ; champs coupes a
1200 caracteres au lieu de 600.

## Analyse : bouclier, exploits elargis, « En partie » restants (22 octobre 2026)

Decisions de Thibs :
1. Bouclier = etat a part, « sous bouclier », ni rate ni reussi. Consignes
   corrigees aux deux endroits (« met toutes les quetes « sous bouclier »
   ... ni ratees ni reussies, un etat a part »).
2. Exploits elargis (`_hebdo90`, champ `genre` et phrase `en_clair`) :
   `quete_rare` (comme avant), `record` (le jour ou la serie depasse
   l ancien record, 5 jours minimum), `serie` (semaine finie sur 7 jours
   d affilee ou plus, sans record), `xp` (gain d XP de la semaine au moins
   1,3 fois la moyenne des 4 semaines d avant et au moins 100 de plus ;
   rattache au jour du plus gros gain). 4 au plus. Consignes : la regle
   d exploit cite ces genres.
3. « En partie » restants : l instantane du jour garde `e` =
   `_quotaPartiel()` moins `weeklyPartialCount`. Par jour :
   `en_partie_restants_cette_semaine`, et pour un jour rate,
   `aurait_pu_sauver_la_journee` le propose s il en restait (sauf quete a
   deux boutons). Non retroactif.
4. Regles si/alors et quetes d action ou de resistance non remises.

## Insights, mise a jour par module (22 octobre 2026)

### Ton auto-maitrise
- Banque `_T_BANQUE` : les 36 affirmations de la Self-Control Scale complete
  (Tangney, Baumeister et Boone, 2004), le maximum publie pour cette
  echelle (impossible d aller a 40 sans inventer des questions non
  validees). Traduction libre ; les 13 de la version courte gardent leur
  traduction d avant. 12 directes, 24 inversees (`r:1`).
- `_tTirage` : 13 au hasard a chaque test, 4 directes et 9 inversees (les
  proportions de la version courte), score toujours sur 65. `_T_ITEMS`
  garde le tirage ; chaque mesure enregistre `ids`.
- 6 paliers `_T_PALIERS` (13, 23, 32, 40, 48, 57) avec icone et descriptif,
  textes provisoires a reecrire par Thibs. La comparaison a la population
  d origine (percentile) est retiree : elle ne vaut que pour les 13
  affirmations fixes. Confrontation aux quetes Discipline : note haute a 40
  et plus, basse a 31 et moins.

### Ta dynamique du moment
- Periodes 14 j, 60 j (defaut), 180 j, Tout (`ST._profPer`, `_dProfPer`),
  au lieu de 120 jours fixes. Constance calculee sur la periode. Minimum :
  30 jours d historique pour afficher la carte (7 en « Voir quand meme »),
  puis 10 jours dans la periode pour 14 j, 20 sinon (sinon message et
  puces).
- `_PROFIL_DESC` : un descriptif fixe par type (Marathonien, Phenix,
  Intermittent, Sprinteur, Batisseur), sans IA, a reecrire par Thibs.

### Seuil de rupture
- `_dRatees` : « Tes quetes obligatoires les plus ratees », periodes 7 j,
  21 j (defaut), 60 j, 180 j, Tout (`ST._ratPer`). Quetes obligatoires
  seulement (boucliers et jours off exclus), au moins 2 occurrences (1 sur
  7 j). Affiche jusqu a 5 quetes sous 65 % de reussite, de la plus ratee a
  la moins ratee ; s il n y en a aucune, les 5 plus ratees avec la mention
  « Aucune quete sous 65 % de reussite ». Ajoute sous le reglage de calcul.
- Puces partagees : `_dPuces`, filtre de periode `_dPeriode`.

### « Voir quand meme »
Bouton sous « X indicateurs attendent plus de donnees » (`_dVoirBascule`,
`window._dVoir`). Recalcule chaque indicateur en attente avec `_dForce` :
seuils minimaux abaisses (domino 3 occurrences, 1 de chaque cote ;
moteur 1 jour par type ; donjon 1 jour ; profil 7 jours) et tests
statistiques ignores. Seuil sans zone : carte avec les quetes les plus
ratees. Chaque carte forcee est precedee de « Indicatif : pas encore assez
de donnees pour que ce resultat soit fiable » et placee en fin de liste.
Indicateur sans aucune donnee : nomme dans le bloc d attente. Le bouton
devient « Masquer les indicateurs incomplets ».

### Correlation energie x reussite
- Texte du bouton info reduit a deux phrases.
- Periodes 14 j, 60 j, 180 j, Tout (defaut) au-dessus des batteries
  (`ST._nrjPer`, `_nrjPer`) : seuls les bilans de la periode comptent.
- Chaque batterie se touche (`_nrjVoir`) : encadre `#st2-nrj-detail`
  (`_nrjDetail`) avec, sur les journees de ce niveau d energie : part des
  quetes obligatoires validees (accomplie ou en partie), eau (jours validees
  sur jours avec une quete eau), secondaires (reussies sur proposees, sur
  les seuls jours qui en avaient). Boucliers et jours off exclus. Masque
  sans abonnement Pro (puces et detail vides).
Teste (Playwright 360 px, donnees fictives) : tirage 13 (4 directes),
palier affiche, anciennes mesures sans `ids` lues, periodes du profil et
des quetes ratees, « Voir quand meme » (cartes indicatives), detail energie
et periode 14 j, mode non Pro. Aucune erreur.

## Insights : etat d auto-maitrise, quetes sous 45 % (22 octobre 2026, soir)

### Ton auto-maitrise : un etat, plus un palier
`_T_PALIERS` remplace par `_T_ETATS` (5 etats, exemple de Thibs) :
l ecart entre l image que le joueur a de lui et ses quetes.
- Note percue = (score - 13) / 52 x 100.
- Taux reel = (accomplies + 0,5 x en partie) / quetes obligatoires des 60
  derniers jours (boucliers et jours off exclus), 20 quetes minimum.
- Note reelle = (taux - 40) / 60 x 100, bornee a 0..100.
- Ecart = percue - reelle : 30 et plus Surestime ; 15 a 29 Legerement
  surestime ; -14 a 14 Coherent ; -29 a -15 Legerement sous-estime ; -30 et
  moins Sous-estime. Descriptifs provisoires.
Affichage : etat, une barre 0 a 100 avec les deux reperes (rond or : ta
note ; carre vert : tes quetes), taux brut et nombre de quetes.

### Seuil de rupture : quetes les plus ratees
Seulement les quetes obligatoires sous 45 % de reussite, de la plus ratee
a la moins ratee, 5 au plus, plus de repli. Aucune : « Actuellement, aucune
quete ne dispose d un taux d echec eleve. Felicitations, et continue comme
cela ! » (texte de Thibs, « continues » corrige en « continue »).

## Audit des Insights (22 octobre 2026, soir)

### Collecte (a la source)
1. Detail des quetes efface au-dela de 120 jours (`_trimQuestDetail`) :
   « 180 j » et « Tout » ne voyaient que 120 jours de quetes. Il est
   maintenant garde en version compacte (`{n: cle, s, t}`, `_qc:1`).
   Les jours deja effaces ne reviennent pas.
2. Secondaires encore verrouillees (avant le jour 14) ecrites « fail » au
   bilan alors que le joueur ne les voit pas ; eau et secondaires non
   touchees ecrites « fail » au bilan mais « skip » sans bilan. Exclues
   avant le jour 14 (bilan et `_questDetailOf`), « skip » partout.
3. Jours de donjon notes seulement si l ecran Donjon etait ouvert ce
   jour-la : « Ce qui marche sur toi » sous-comptait. `_dDngNoterJour` est
   appele a chaque cloture de journee (`advDay`).
4. Bilan de journee off marque `dayoff:true`.

### Lecture (`_dLog`, pour tous les modules et l analyse de la semaine)
5. Jour de la semaine faux pour : journees closes sans bilan (ecrites le
   lendemain matin), bilans apres minuit, absences rattrapees (toutes a la
   date du retour). Recalcule depuis le numero de jour (`_dJourSemaine`),
   cale sur la majorite des bilans du soir. Vue generale (meilleur et pire
   jour) et heatmap passent par le meme calcul (`_dowOf`).
6. Absences rattrapees : elles portaient les quetes du jour du retour,
   comptees ratees pour ces quetes. Journee ratee, sans quetes attribuees.
   Auto-maitrise : une absence compte pour 3 obligatoires ratees.
7. Journee off (objet) et jours simules du mode test (obligatoires toutes
   « skip ») comptaient comme reussis ou rates : neutres, comme un bouclier
   (`repos`, `simule`).
8. `_dLog` mis en memoire (cle : taille du journal, dernier jour, jour
   courant, calendrier) : il etait recalcule des dizaines de fois.

### Modules
9. Seuil de rupture et analyse de la semaine : serie en cours prise comme
   le maximum de la serie du journal et de `ST.streak`. Or `ST.streak` ne
   retombe pas a 0 sur un echec (il perd 1) : apres une chute a 20 jours,
   le module annoncait « Cap franchi : 19 jours ». Serie du journal seule.
10. Rebond (Seuil, Dynamique) : « le lendemain » etait l entree suivante
    du tableau, donc parfois plusieurs jours plus tard apres un bouclier.
    Vrai lendemain.
11. Effet domino : les journees abandonnees (aucune obligatoire validee,
    tout tombe a la cloture) fabriquaient un faux domino. Exclues ; un
    statut « passe » compte comme rate. Teste : un faux domino fait
    d abandons n est plus detecte, un vrai l est.
12. Heures de validation : une quete revalidee comptait deux fois
    (`_dValUniques`, premiere validation par quete et par jour).
13. Correlation energie : bilans des jours sous bouclier (toujours
    « reussis », et pris surtout quand on est fatigue), des journees off
    (energie fixee a 3) et des sanctions faussaient les batteries.
    `_dBilans` les exclut, aussi pour l analyse de la semaine. Le detail
    commence par les journees reussies, la base des batteries.
14. Signaux d echec (analyse de la semaine) : un jour sous bouclier dans
    les 2 jours d avant comptait (« soir sans bilan »...). Ignore.
15. Quete-moteur : « meme en version courte » (on ne change pas une quete)
    devient « quitte a la valider en partie ».
16. Time Capsule : « 0 -> XP, 0 -> record » ne disait rien du chemin. Tes
    14 premiers jours face a tes 14 derniers (journees reussies, part
    « Accomplie », energie du soir, automaticite) et « Tes quetes ont
    grandi » (moyenne des 3 premieres fois et des 3 dernieres, 6 fois au
    moins, +10 % minimum).
Tests a reponse connue (Playwright) : jours de semaine recalcules (0
erreur sur 99 jours, dont noReview et bilans apres minuit decales, et
calage sur une derive de 2 jours), absence sans quetes, repos et simule
neutres, serie du journal a 0 malgre `ST.streak` a 19, bilans exclus,
doublons d heures, faux et vrai domino ; plus les tests precedents.

## Insights : la vue ne saute plus, Seuil sans zone explique (22 octobre 2026, nuit)

- `_garderVue(faire)` : a chaque bouton de periode ou de calcul (Seuil,
  quetes ratees, Dynamique, Energie, « Voir quand meme »), la carte touchee
  est reperee (`data-tag` ajoute a chaque carte, ou son id), tout est
  redessine, puis le defilement est corrige pour la remettre exactement au
  meme endroit de l ecran. Avant, les cartes changeaient de hauteur et
  d ordre (triees par importance) et l ecran sautait. Teste : position
  identique avant et apres le clic (Seuil, Dynamique, Energie).
- Seuil de rupture sans zone : la carte s affiche aussi en « Recent
  d abord » (le module passait « en attente » alors qu il avait assez de
  ruptures). Si toutes les series de la periode cassent a 3 jours ou moins
  (3 ruptures au moins) : « Pas de zone de rupture ... : tes series cassent
  toutes avant N jours », avec l explication (c est le demarrage qui coince,
  viser 2 puis 3 jours). Moins de 5 ruptures : le nombre est donne.

## Seuil : zone verifiee, quete a risque du jour (23 octobre 2026)

**Zone de rupture verifiee par permutation.** Avant, le module trouvait une "zone" meme dans des resultats tires au hasard (7 jeux sur 25) et presque toujours quand de bonnes et de mauvaises periodes se melangent (22 sur 25). Maintenant chaque zone est testee : les resultats sont rebattus 100 fois au hasard a l'interieur de chaque semaine, et la zone n'est gardee que si elle ressort nettement mieux que ces tirages (p < 0,05). Mesure sur 25 jeux par cas : hasard pur 1/25, periodes melangees 3/25, vraie fragilite a un jour donne 24/25. Sinon la carte dit "Pas de vraie zone de rupture".

**Quete a risque du jour (Pro).**
- Sur la carte de la quete obligatoire la plus menacee : badge "A risque aujourd'hui : X % (d'habitude Y %)", touche pour voir le pourquoi.
- Dans le Seuil de rupture : bloc "Ta quete a risque aujourd'hui" avec le pourquoi, un conseil, et la fiabilite.
- Calcul : taux d'echec de la quete sur 90 jours, ajuste par le jour de la semaine (de la quete et en general), la tendance des 14 derniers jours et la zone de rupture verifiee.
- Garde-fou : le modele est rejoue sur les 60 derniers jours. L'alerte ne s'affiche que s'il a fait nettement mieux que le hasard (au moins 5 alertes, 3 justes, precision au moins double du taux d'echec moyen). Sinon : rien.

Fichiers : `www/index.html` (et sa copie Android). Fonction et consignes inchangees.

## Carte gratuite, Portail Nocturne revu (24 octobre 2026)

**Carte gratuite (boutique, cartes du jour).**
- Chaque carte a 8 % de chance d'etre gratuite, une seule au plus sur les 4 (environ 28 % des jours en ont une, mesure sur 20 000 jours). Tirage separe : les autres offres du jour ne changent pas.
- Dos vert "Gratuit", face avec bouton vert "Gratuit", sans prix. Meme style que les cosmetiques, en vert.
- Contenu : 65 % des points (15 a 35), 35 % un item parmi les 6 moins chers achetables (Boite Scellee de Rang E, Potion de double points, Eclat du Veilleur, Elixir d'experience, Lettre du futur, Conseil du Sage).
- Pas de confirmation, ne compte pas pour la Faveur du marchand.

**Portail Nocturne.**
- Bandeau bleu et violet, compact, au-dessus du bloc donjon (style du donjon). L'ancien encart dans la zone evenements est retire.
- Utilise pendant le creneau : "Un portail est en approche... Une quete nocturne arrive ! Sois pret..!". La quete apparait dans le bandeau des la sortie du creneau (verification chaque minute).
- Utilise hors creneau : la quete apparait tout de suite dans le bandeau.
- (i) en haut a droite : rappel du fonctionnement, heure de sortie du creneau incluse.
- Recompenses inchangees (+400 % XP, -150 pts, echec automatique au debut du creneau suivant).

Fichiers : `www/index.html` (et sa copie Android).

## Annuler 5 secondes, carte gratuite et Portail Nocturne au design de l'app (24 octobre 2026, apres-midi)

**Bouton Annuler.**
- Des qu'une quete est traitee (Accomplie, En partie, Fail, Skip, Cristal de focus), un bouton "Annuler" apparait a droite du statut pendant 5 secondes, avec une barre qui se vide.
- Annuler remet tout comme avant : XP, points, integrite, quota "En partie", donjon, compteurs.
- Une seule annulation a la fois : traiter une autre quete rend la precedente definitive.
- Les messages a la guilde ("a complete ...") partent seulement apres les 5 secondes, donc jamais pour une action annulee.
- Valable aussi pour la quete du Portail Nocturne.

**Carte gratuite.** Les points ont maintenant leur cadre SVG comme les autres cartes (pile de pieces et piece a croix verte), nom "+N points".

**Portail Nocturne.**
- Scene illustree : ciel etoile anime, lune, collines, portail lumineux a droite.
- En approche : portail pale qui pulse, avec seulement "Un portail est en approche..." et "Une quete nocturne arrive ! Sois pret..!".
- Ouvert : la quete est une vraie carte de quete (icone, ruban "Quete nocturne +400% XP", tag Nocturne, +80 XP, boutons Accomplie et Fail), dans le bloc.
- Apres reponse, la carte reste affichee avec son statut jusqu'a la fin de la journee.

Fichiers : `www/index.html` (et sa copie Android).

## Donjon : alerte si une quete obligatoire est deja en Fail (24 octobre 2026, 15h)

Quand on entre dans un donjon qui commence le jour meme alors qu'une quete obligatoire est deja en Fail, cet echec compte dans le donjon : une cible "7 sur 7" devient impossible et passe en "Manque" des l'entree, avec les recompenses qui vont avec.
- Maintenant, un message previent ("Quete obligatoire en Fail"), nomme la ou les quetes et propose de revenir demain. Boutons "Retour" et "Lancer quand meme".
- Ce message remplace la confirmation habituelle, pour ne pas enchainer deux alertes.
- Pas de message si le donjon commence de toute facon demain (l'alerte "La Porte s'ouvre demain" s'affiche deja dans ce cas).
- Les jours de De du Destin, l'eau et les secondaires en Fail comptent aussi (elles sont obligatoires ce jour-la).

Fichiers : `www/index.html` (et sa copie Android).

## Balayage entre les menus, au doigt (24 octobre 2026, soir)

Avant : un geste franc changeait d'onglet d'un coup, sans transition.

Maintenant, comme les grandes applis :
- L'ecran suit le doigt, l'ecran voisin arrive a cote. Tant que le doigt n'est pas leve, rien n'a change.
- Au lacher : on termine le mouvement si on a depasse 40 % de la largeur, ou sur un geste vif dans ce sens. Sinon l'ecran revient en place. Un geste vif dans l'autre sens annule.
- Animation de fin qui reprend la vitesse du doigt (140 a 320 ms).
- Barre du bas fixe : la pastille doree glisse d'un onglet a l'autre, les icones passent progressivement du gris au blanc.
- Bords (Quetes a gauche, Social a droite) : effet elastique, retour en place.
- Chaque menu garde sa position de defilement ; au lacher, l'ecran arrive exactement a sa place (0 pixel d'ecart mesure).
- Defilement vertical intact : le navigateur le gere seul (touch-action: pan-y), sans attendre le code.
- Ne demarre pas : geste surtout vertical, plusieurs doigts, champ de saisie, zone qui defile elle-meme a l'horizontale, fenetres ouvertes, tutoriel. Appel systeme, deuxieme doigt, appli mise en arriere-plan ou changement d'ecran par le code : remise en place propre.

Performance :
- Pendant le geste, chaque image ne fait que deplacer deux ecrans (translation GPU, sans rendu ni mise en page).
- Les deux ecrans voisins sont prepares a l'avance quand l'appli est au repos, puis mis en veille (content-visibility: hidden) : ils ne coutent rien au repos (aucun dessin, verifie) mais gardent leur mise en page. Demarrer un geste passe de 80 a 150 ms a 15 a 25 ms sur un telephone 4 fois plus lent.
- Mesures (telephone simule 4 fois plus lent) : 60 images par seconde pendant le geste (p95 16,8 ms), quelques images lentes seulement au tout debut. Telephone normal : preparation 3 a 5 ms.

Au passage : la courbe d'XP des Stats devenait vide (erreur NaN) des qu'un seul jour de l'historique n'avait pas de valeur d'XP. Ces jours sont maintenant ignores.

Fichiers : `www/index.html` (et sa copie Android).

## Audit de fluidite et de legerete (24 octobre 2026, nuit)

Objectif : meme rendu, moins de calcul. Aucune animation retiree ni simplifiee. Chaque dessin modifie a ete compare pixel par pixel avec l'original, images figees au meme instant.

Temps de calcul du processeur principal par seconde, appli au repos, telephone simule 4 fois plus lent :

| Ecran | Avant | Apres |
|---|---|---|
| Quetes | 219 ms | 4 a 16 ms |
| Identite | 586 ms | 1 a 2 ms |
| Boutique | 312 ms | 0 a 5 ms |
| Stats | 214 ms | 5 a 10 ms |
| Social | 210 ms | 3 a 6 ms |

Ce qui coutait, et ce qui a change :
- Animations SVG des ecrans jamais affiches (victoire de boss, montee de rang, lettre) : Chrome les recalculait a chaque image, en permanence (environ 190 ms par seconde). Elles sont en pause des qu'elles sortent de la vue, et repartent quand elles y reviennent.
- Monstre d'Identite : ses particules sont animees par la carte graphique au lieu du SVG. Rendu identique (seul l'anticrenelage differe, d'un sous-pixel).
- Halo des cartes de la Boutique, bordure doree de l'XP : l'animation deplacait un fond, redessine a chaque image. C'est maintenant un calque qui glisse. Identique au pixel.
- Lueur des pastilles de rang Epique et Legendaire : ombre animee remplacee par deux anneaux en fondu. Identique.
- Titre equipe : son dessin anime tourne dans un fil a part, et s'arrete quand l'en-tete sort de la vue ou que l'appli passe en arriere-plan (254 a 28 ms par seconde, 6 ms en-tete hors vue). Le titre n'est plus reecrit s'il n'a pas change.
- Carte du donjon repliee : ses animations cachees sont en pause (245 a 0 ms).
- Flammes "gain majore" : le flou de leur lueur etait anime. Ce sont maintenant quatre copies de la flamme a lueur fixe, en fondu (247 a 12 ms pour six flammes). Compare image par image sur tout le cycle : meme rendu.
- Ecrans voisins prepares pour le balayage : animations en pause tant qu'ils sont caches.
- Particules du questionnaire d'accueil : la boucle tournait jusqu'a la fermeture de l'appli, meme questionnaire termine, et chaque reconfiguration en ajoutait une. Elle s'arrete des que le questionnaire se ferme.
- Changement d'onglet : plusieurs mesures forcaient le navigateur a mettre en page le nouvel ecran deux fois (barre du bas, liste de guilde mesuree sur tous les ecrans, animations mises en pause une par une). Identite 47 a 12 ms, Quetes depuis Social 69 a 24 ms, Stats 75 a 19 ms.
- Sons : le bruit blanc (changement d'onglet, impacts) etait retire au hasard a chaque son. Il est tire une fois et reutilise. Meme son.
- Defilement d'Identite : 80 images lentes sur 383, maintenant 0.

Laisse tel quel, volontairement :
- Demarrage (premier affichage vers 220 ms, quetes pretes en 520 a 740 ms sur telephone lent) : le gagner demanderait de decouper `index.html` en plusieurs fichiers.
- Clignotement des boutons de connexion du Social : il ne dure que juste apres le tutoriel.

Fichiers : `www/index.html` (et sa copie Android).

## Balayage, Annuler, carte gratuite, Portail Nocturne (24 octobre 2026, nuit)

### Balayage : l'ecran qui traversait
Cause : quand le doigt se levait juste apres un retour brusque dans l'autre sens, aucune image n'avait encore montre le nouveau voisin. Or l'animation de fin part de la derniere position affichee : l'ecran courant repartait de son ancienne place, le nouveau voisin de la sienne, et ils se chevauchaient pendant toute l'animation, le voisin passant devant.
Correctif : la position reelle du doigt est prise en compte avant de lancer l'animation de fin.
Verifie image par image sur 30 gestes "aller puis retour vif" tires au hasard : 223 images avec chevauchement avant, 0 apres. Et 0 sur 30 gestes quelconques.

### Balayage : saccades a vitesse normale
Mesure en enchainant quatre balayages a 0,45 s d'intervalle, telephone 4 fois plus lent. Trois causes :
1. L'ecran suivant n'etait jamais pret : chaque sauvegarde repoussait sa preparation de 1,5 s. Il se construisait donc pendant le geste (arret de 60 a 170 ms). Maintenant, il se prepare pendant l'animation de fin du balayage precedent (elle tourne sur la carte graphique, le processeur est libre), et une sauvegarde ne repousse plus une preparation deja prevue.
2. Un doigt pose pendant l'animation de fin etait ignore : le balayage suivant ne partait pas. Maintenant l'animation se termine aussitot et le nouveau geste part.
3. Au premier mouvement du doigt, une classe posee sur toute la page faisait recalculer les styles de l'appli entiere (11 a 18 ms). Remplacee par trois retouches ciblees.
Resultat : debut de geste 49 a 21 ms. Plus aucune image au-dessus de 33 ms pendant que le doigt glisse (avant : une par balayage, de 50 a 170 ms).

### Annuler : verification
Teste par execution : Accomplie, En partie, Fail sur une obligatoire (avec perte d'integrite), eau. Apres Annuler, tout l'etat du joueur revient a l'identique : XP, points, integrite, donjon, quota "En partie", compteurs, journal. Aucune difference sur l'ensemble des donnees.
Cinq cycles Accomplie puis Annuler, puis Accomplie : exactement le meme resultat qu'une seule validation. Pas de cumul.
Deux failles trouvees et corrigees :
- Faveur du Destin : l'objet arrive 0,7 s apres la validation. En annulant avant, il arrivait quand meme, et revalider en donnait un autre (3 objets en 3 essais). Maintenant il n'est accorde que si la validation tient toujours. Et l'objet est fixe pour la journee : annuler puis revalider redonne le meme.
- Bonus rare (+50 % sur la derniere obligatoire, 1 chance sur 10) : annuler puis revalider le retirait au sort (3 bonus en 40 essais). Le tirage est fixe par jour et par quete : toujours 1 chance sur 10 (9,4 % mesure sur 3 000 jours), mais on ne peut plus le retenter.

### Carte gratuite : ligne de gain alignee
Elle n'avait pas de ligne de prix : son nom ("+20 points") tombait 12 px plus bas que celui des autres cartes, et son cadre d'icone etait plus haut. Elle a maintenant une ligne de prix invisible (toujours aucun prix affiche). Le bas de chaque carte (bouton, "Achete", "Recupere") a la meme hauteur dans tous les etats, et la bordure plus epaisse des cartes vertes et cosmetiques est compensee.
Mesure : icone, nom, prix et bouton aux memes positions sur les quatre cartes, au centieme de pixel, carte prise ou non.
Effet visible : une carte achetee garde la disposition d'avant achat (son icone ne grandit plus de 11 px).

### Portail Nocturne : texte du (i)
Ton texte, avec trois corrections d'orthographe : "t'ouvres" devient "t'ouvre", "reussit-la" devient "reussis-la" (sans accent sur le a), "Echoues" devient "Echoue".

Fichiers : `www/index.html` (et sa copie Android).

## Retours de Thibs sur le patch precedent (24 octobre 2026, 21h)

### Carte gratuite : gain a la hauteur du prix voisin
Le gain ("+20 pts") prend maintenant la place du prix, et copie la ligne de prix de la carte voisine de la meme rangee : prix simple (12 px) ou prix barre puis prix remise (15 px, la ligne barree restant invisible). Meme hauteur, meme taille de police. Le nom de la carte points devient "Points" (a changer si tu preferes un autre mot). Carte objet : nom de l'objet, ligne de prix invisible.
Mesure : nom, gain et bouton aux memes positions que la voisine, au dixieme de pixel, avec et sans remise.

### Balayage : plus de changement de voisin en cours de geste
Le geste reste fixe sur l'ecran voisin choisi au depart. Revenir franchement dans l'autre sens ne fait plus apparaitre l'autre voisin : au-dela du point de depart, l'ecran resiste (effet elastique) puis revient en place au lacher. C'etait ce changement de voisin en cours de geste qui donnait l'ecran qui traverse. Pour aller de l'autre cote, on relance un geste. Seule exception : parti vers un bord (Quetes a gauche, Social a droite), un retour franc prend le voisin de l'autre cote.

### Balayage : fluidite
- La copie de la barre du bas n'a plus de flou d'arriere-plan pendant le geste : la carte graphique le recalculait a chaque image sous un contenu qui bouge. Son fond est opaque a 96 %, la difference ne se voit pas.
- Ralentir l'animation de fin n'aiderait pas : elle tourne deja sur la carte graphique. Ce qui peut accrocher, c'est la phase ou le doigt est pose, ou chaque image passe par le processeur principal.

### Changement d'onglet : plus d'ecran a moitie vide
Deux causes :
- Animations d'entree (fondus, glissements) rejouees a chaque arrivee sur un onglet : l'ecran apparaissait d'abord a moitie vide. Elles sont menees a leur fin d'un coup a l'arrivee, et des la preparation des ecrans voisins. Seules les animations courtes et finies sont concernees, pas les animations en boucle ni la barre du bouton Annuler.
- Heatmap des Stats : elle etait dessinee un moment apres le reste (cadre vide pendant une image). Elle est dessinee tout de suite, et seulement quand l'historique a change.
Verifie image par image : Stats et Identite passent d'un ecran complet a l'autre en une seule image.

Fichiers : `www/index.html` (et sa copie Android).

## Balayage au doigt coupe, prototype "ecrans en bande" (25 octobre 2026)

Le balayage en JavaScript (l'ecran deplace par le code a chaque image) est coupe : pas assez fluide sur telephone, et bugge au changement de sens. La navigation par la barre du bas reste comme avant.

Prototype a tester, dans Parametres > Preferences > "Ecrans en bande (prototype)" (l'app redemarre ; meme reglage pour revenir) :
- Les cinq ecrans sont poses cote a cote dans une bande que le telephone fait defiler lui-meme, avec un aimant par ecran (scroll-snap). Le doigt est suivi par la carte graphique, sans code a chaque image, exactement comme le defilement vertical.
- Chaque ecran a son propre defilement vertical, garde quand on change d'ecran.
- Une seule barre du bas : la pastille doree et les icones avancent avec la bande, elles aussi sans code (animations liees au defilement ; petit code de repli si le telephone est trop ancien).
- Appui sur un onglet : la bande glisse jusqu'a l'ecran. Parametres et autres fenetres s'ouvrent par-dessus.
- Mesure (telephone 4 fois plus lent) : pendant quatre balayages enchaines, une seule tache au-dessus de 16 ms, contre une par balayage avant. Au repos, meme cout qu'en mode normal.
- C'est un prototype : le reglage est garde sur le telephone (pas dans le profil), et des details peuvent clocher ailleurs (fonctions qui remontent en haut de page, par exemple). S'il convient, la refonte complete suit.

Fichiers : `www/index.html` (et sa copie Android).

## Ecrans en bande dans toute l'appli (25 octobre 2026)

Le prototype devient le fonctionnement normal. Le reglage "Ecrans en bande (prototype)" disparait des Parametres. Le balayage en JavaScript du 24 octobre (et ses ecrans "tiedes") est retire du code : les sections "Balayage entre les menus, au doigt" et suivantes plus haut decrivent un fonctionnement qui n'existe plus.

Fonctionnement :
- Les cinq ecrans principaux sont poses cote a cote dans une bande que le telephone fait defiler lui-meme, avec un aimant par ecran. Le doigt est suivi par la carte graphique, sans code a chaque image.
- Chaque ecran a son propre defilement vertical, garde quand on change d'ecran. Second appui sur l'onglet affiche : retour en haut de l'ecran.
- Une seule barre du bas ; pastille et icones avancent avec la bande, elles aussi sans code.
- Les autres ecrans (Parametres, bilan, accueil, blocage, titres...) s'ouvrent par-dessus. L'ecran de fin de journee garde la barre du bas devant lui, comme avant.
- Ecrans d'a cote remis a jour au repos apres chaque changement d'etat, un par un, jamais pendant qu'un doigt est pose ou que la bande bouge. Juste apres le lancement, si un doigt se pose avant qu'un voisin soit pret, il est rendu tout de suite.
- Ecrans hors de vue : leurs animations en boucle sont en pause (les animations finies, comme la barre du bouton Annuler, vont a leur terme).
- Tutoriels : cibles prises dans l'ecran affiche ; pendant un tutoriel, la bande revient a l'ecran en cours si on la fait glisser.
- Fenetres a choix : l'ecran et la bande sont bloques tant qu'elles sont ouvertes.

Les gels au debut du geste, trois causes trouvees et corrigees :
1. Le curseur du creneau (Parametres) posait sur toute l'appli, des la premiere ouverture des Parametres, un ecouteur de mouvement de doigt "bloquant" : le telephone devait attendre le code avant chaque mouvement, partout. Des que le code etait occupe, le defilement gelait. L'ecouteur n'existe plus que pendant qu'on fait glisser le curseur. Verifie : aucun ecouteur bloquant apres ouverture des Parametres.
2. L'ecran Stats interdisait le glissement horizontal parti de chez lui (reglage "pan-y" ecrit dans sa balise). Retire.
3. Pendant un glissement, le navigateur met a jour toutes les animations de la page a chaque image : celles des ecrans hors de vue sont maintenant en pause. Calcul pendant quatre glissements enchaines (telephone 4 fois plus lent) : mise a jour des styles 109 a 73 ms par seconde, preparation du dessin 89 a 48.

Mesures (telephone 4 fois plus lent) : fin d'un glissement (l'ecran pose devient actif) 6 a 9 ms ; au repos, 1 a 8 ms par seconde sur chaque ecran, comme avant.

Verifie par execution : glissements dans les deux sens et depuis chaque ecran, retour brusque, appui sur les onglets, memoire de defilement, rotation, Parametres, bilan, fin de journee, accueil, titres, tutoriel principal (7 etapes, dont le passage au Social) et tutoriel d'Identite, nouveau profil (questionnaire puis tutoriel), validation et Annuler, fenetres a choix, carte gratuite.

Fichiers : `www/index.html` (et sa copie Android).

## Un ecran par geste, glissement allege, mesure de fluidite (25 octobre 2026, nuit)

Retours de Thibs : un long glissement allait directement de Quetes a Stats ; l'animation du glissement ne se voyait jamais en entier (10 images par seconde environ, gel au tiers ou a la moitie de l'ecran suivant).

Un ecran par geste :
- L'aimant du navigateur (scroll-snap) est coupe. Sur un glissement long et vif, l'ecran suivant etait deja sous le doigt au lacher, puis l'elan en sautait un ou deux de plus, malgre le reglage cense l'interdire. La section precedente parle d'un aimant par ecran : il n'existe plus.
- Au lacher, c'est le code qui choisit : l'ecran de depart, ou son voisin dans le sens du geste (geste vif, ou plus de 40 % de l'ecran parcouru). Un elan dans l'autre sens ramene a l'ecran de depart. La bande est bloquee le temps du trajet ; si l'elan l'a deja emportee plus loin, elle revient. Elle ne s'arrete jamais entre deux ecrans.
- Un doigt qui se repose pendant le trajet la rattrape ; un appui sur un onglet remplace le trajet en cours ; une fenetre ouverte pendant le trajet garde la bande bloquee.

Glissement allege, trois choses que la carte graphique refaisait a chaque image :
1. L'ombre portee de la figure d'Identite etait un filtre pose sur la figure entiere, particules animees comprises : recalculee a chaque image tant qu'Identite etait visible. C'est maintenant une copie de la figure passee au noir, floutee et posee dessous, dessinee une seule fois. Rendu compare au pixel avec l'ancien : ecart maximal 11 sur 255, invisible.
2. Les onglets de Stats avaient un flou d'arriere-plan. Il obligeait a redessiner tout l'ecran une fois de plus a chaque image, sur tous les menus et pas seulement sur Stats. Retire, fond un peu plus couvrant a la place (ecart maximal 8 sur 255).
3. Decor anime : seul l'ecran affiche joue le sien. Avant, l'ecran voisin animait aussi (la Boutique tournait pendant qu'on etait sur Identite), et un ecran relancait son decor au moment ou il entrait dans la vue, en plein geste. Maintenant l'ecran qui arrive glisse avec son decor fige, qui repart des qu'il est pose.

Mesure : carte graphique simulee par le processeur de l'environnement de test (pas un vrai telephone), ecran en densite de telephone : travail de la carte par image sur Identite 25 ms avant, 19 ms apres, et moitie moins de dessin a refaire en arrivant sur Identite. Ce n'est pas une mesure de ton telephone : d'ou le reglage ci-dessous.

Mesure de fluidite (nouveau reglage, Parametres, Application & Sauvegardes) :
- Apres chaque glissement entre menus, un encadre en haut de l'ecran affiche la version du WebView, la definition de l'ecran, le nombre d'images par seconde, la pire image, et ce qui a bloque (code ou dessin) pendant le glissement et juste apres.
- A faire : l'activer, glisser plusieurs fois Quetes, Identite, Boutique et retour, puis envoyer une capture de l'encadre. S'il reste un gel, ces chiffres disent ou il est.
- Desactive, rien ne tourne.

Verifie par execution : quatre vitesses de geste du lent au tres vif, et trois gestes longs et vifs de suite, toujours l'ecran voisin ; doigt repose, appui sur un onglet et fenetre ouverte pendant le trajet ; decor en pause sur les ecrans non affiches et relance a l'arrivee ; encadre de mesure ; et toute la serie precedente (glissements, retour brusque, onglets, memoire de defilement, rotation, Parametres, fin de journee, accueil, questionnaire, Annuler, carte gratuite).

Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`. Fonction Supabase et prompts inchanges.

## Un menu par geste, quelle que soit la force du lacher (25 octobre 2026, matin)

Retour de Thibs : doigt pose, le glissement est parfait a toutes les vitesses. Au lacher, un geste fort faisait encore defiler plusieurs menus (de Social a Quetes d'un coup, et inversement). Encore des pertes d'images par moments.

Cause : la solution de la nuit bloquait la bande au lacher et l'amenait elle-meme a l'ecran voisin. Sur ton telephone, ce blocage n'arretait pas l'elan du telephone : la bande partait quand meme, et au bout d'1,2 seconde le filet de securite la relachait en plein elan, qui allait jusqu'au bout. Ce blocage est retire (la description "La bande est bloquee le temps du trajet" de la section precedente ne vaut plus).

Maintenant :
- L'aimant du telephone revient, mais il n'existe que sur l'ecran pose et ses deux voisins. Un elan, meme tres fort, ne trouve aucun aimant plus loin : il s'arrete forcement sur l'ecran voisin. Avant, avec un aimant sur chacun des cinq ecrans, l'elan s'arretait sur celui le plus proche de sa course, deux ou trois ecrans plus loin, malgre le reglage cense l'interdire.
- Les aimants se replacent a chaque arret de la bande, et avant chaque appui sur un onglet (l'ecran vise doit avoir le sien).
- Le lacher, l'elan et la fin du trajet sont faits par le telephone lui-meme, sans code : c'est aussi ce qui doit rendre la fin du glissement plus fluide (le trajet de la nuit etait mene par le code).

Verifie par execution, sur 56 gestes partis de chacun des cinq ecrans, dans les deux sens, du glissement lent au lacher extremement brutal, et un glissement d'un ecran et demi doigt pose : tous finissent sur l'ecran voisin. Meme serie avec l'aimant sur les cinq ecrans (l'ancien fonctionnement) : 34 gestes sur 68 sautaient des ecrans, ce qui montre que le test reproduit bien le probleme. Et toute la serie precedente.

Pertes d'images : pour savoir ou elles sont sur ton telephone, il me faut l'encadre du reglage "Mesure de fluidite" (Parametres, Application & Sauvegardes), capture prise juste apres un glissement saccade.

Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`. Fonction Supabase et prompts inchanges.

## Elan du lacher borne a l'ecran voisin, bande allegee (25 octobre 2026, midi)

Video de Thibs (21 s, enregistrement qui ne garde que les images reellement affichees), analysee image par image :
- Doigt pose : 60 images par seconde, parfait.
- Au lacher, a chaque fois : image figee de 0,6 a 1,1 seconde. Pendant ce temps la bande continuait sans etre affichee jusqu'a l'ecran d'apres le voisin (Stats en allant vers la Boutique, Social en allant vers Stats), puis revenait en douceur (60 images par seconde) sur le voisin. Les pertes d'images, c'est ce lacher fige.

Cause probable : la bande remplissait exactement l'ecran. Le moteur traite alors un tel element comme la page elle-meme, et dans une appli Android, l'elan du lacher de la page ignorait les aimants et n'etait pas affiche. Le navigateur de test ne fait pas ca, d'ou des tests qui passaient.

Corrections :
1. Bande 1 pixel moins haute que l'ecran (le pixel manquant est sous la barre du bas, invisible) : elle n'est plus traitee comme la page.
2. Seuls l'ecran pose et ses deux voisins sont dans la bande ; les autres en sont sortis et poses tres loin, hors de portee (ils gardent contenu et defilement). L'elan, meme s'il ignorait les aimants, bute physiquement sur l'ecran voisin, au bout de la bande. A chaque arret, la fenetre se recentre (3 a 5 ms, telephone 4 fois plus lent, rien ne bouge a l'ecran). Pastille et icones de la barre suivent la fenetre.
3. Effet secondaire : couches graphiques 105 a 55, memoire graphique equivalente a un ecran de telephone 216 a 84 Mo. Les ecrans lointains ne sont plus dessines.

Changement visible : un appui sur un onglet a plus d'un ecran (Quetes vers Stats par exemple) passe directement a l'ecran, sans faire defiler ceux entre les deux. Un onglet voisin glisse comme avant.

Verifie par execution : 56 gestes du lent au lacher extremement brutal, depuis chaque ecran et dans les deux sens, tous sur l'ecran voisin ; meme serie aimants coupes : la bande ne depasse jamais l'ecran voisin (position relevee toutes les 50 ms) ; pastille et icones justes apres glissements et appuis ; memoire de defilement, rotation, Parametres, fin de journee, accueil, questionnaire, Annuler, carte gratuite.

Si le lacher reste fige : refaire une video avec le reglage "Mesure de fluidite" active (Parametres, Application & Sauvegardes), l'encadre apparaitra dans la video.

Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`. Fonction Supabase et prompts inchanges.

## Glissement horizontal mene par le code (25 octobre 2026, apres-midi)

Deuxieme video de Thibs, analysee image par image :
- Glissement tres lent : 60 images par seconde du debut a la fin, arrivee comprise.
- Glissement a vitesse normale : 4 ou 5 images fluides (le temps que le doigt touche l'ecran), puis image figee de 0,9 a 1,2 seconde, puis l'ecran voulu apparait d'un coup. Pendant le gel, l'appli continue d'afficher des images (les decors animes bougent) : seule la bande ne bouge plus.

Conclusion : dans l'appli Android, l'elan que le telephone donne a la bande au lacher n'est pas affiche, que la bande soit traitee comme la page ou non. En revanche, tout trajet mene par le code (l'arrivee apres un glissement lent, par exemple) est affiche parfaitement.

Correction : le glissement horizontal est maintenant mene par le code du debut a la fin.
- Le telephone ne fait plus que le defilement vertical des ecrans (touch-action pan-y) ; il n'y a donc plus d'elan natif au lacher.
- Doigt pose : la bande suit le doigt image par image.
- Au lacher : la bande file vers l'ecran choisi (l'ecran de depart ou son voisin, jamais plus loin, memes regles qu'avant) en partant a la vitesse du doigt, puis ralentit jusqu'a l'arret (160 a 360 ms).
- Un doigt qui se repose pendant le trajet rattrape la bande ; un appui bref la laisse finir son trajet.
- Pas de glissement sur les fenetres ouvertes par-dessus (Parametres...), ni sur le curseur du creneau ou les zones de signature, ni quand une fenetre a choix est ouverte. Pendant un tutoriel, la bande revient a l'ecran en cours.
- Plus d'aimant du navigateur (scroll-snap) : c'est le code qui pose la bande sur un ecran.

Verifie par execution : 56 gestes du lent au lacher extremement brutal (y compris un seul mouvement de 345 px), depuis chaque ecran et dans les deux sens, tous sur l'ecran voisin ; trajet image par image (la vitesse au lacher se prolonge sans a-coup) ; aucune image longue au lacher, telephone 4 fois plus lent ; defilement vertical, y compris en biais ; pas de glissement sur les Parametres ; doigt repose et appui bref pendant le trajet ; pastille et icones de la barre ; memoire de defilement, rotation, fin de journee, accueil, questionnaire, Annuler, carte gratuite.

A surveiller : le suivi du doigt est maintenant fait par le code et non plus par le telephone. S'il parait moins net qu'avant, ou s'il reste une saccade : video avec le reglage "Mesure de fluidite" active (Parametres, Application & Sauvegardes).

Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`. Fonction Supabase et prompts inchanges.

## Trajet du lacher toujours anime (25 octobre 2026, 13h)

Videos de Thibs (Metanoia et Twitter pour comparaison), analysees image par image :
- Doigt pose : la bande suit le doigt, et la pastille de la barre du bas suit exactement la bande (25,6 % de l'ecran parcouru, pastille avancee de 25,7 %).
- Au lacher : la bande sautait d'un coup a l'ecran d'arrivee, en une seule image. D'ou l'impression d'animation trop rapide et de barre qui suit mal (elle saute avec la bande).
- Twitter, au lacher : la page continue a la vitesse du doigt et ralentit sur 17 images environ (0,28 s).

Cause : le telephone demande moins d'animations (reglage d'accessibilite "Supprimer les animations", ou echelle d'animation coupee dans les options developpeur). Le code respectait ce reglage et faisait donc le trajet du lacher en une image. Reproduit a l'identique en simulant ce reglage : saut de 245 px en une image au lacher.

Correction : le trajet du lacher et le glissement d'un onglet voisin sont toujours animes, quel que soit ce reglage (c'est la suite du geste du doigt, pas une decoration). Meme simulation apres correction : la bande continue a la vitesse du doigt puis ralentit sur 19 images (0,32 s), comme Twitter. Le reglage reste respecte ailleurs (retour en haut d'un ecran). L'encadre "Mesure de fluidite" indique maintenant si le telephone demande moins d'animations.

Verifie par execution, avec et sans ce reglage : 56 gestes du lent au lacher extremement brutal, tous sur l'ecran voisin ; trajet image par image au lacher et a l'appui sur un onglet voisin ; pastille et icones de la barre ; et toute la serie precedente.

Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`. Fonction Supabase et prompts inchanges.

## Vision d'elite refaite, bouton retour, heatmap, Parametres, Faveur (26 octobre 2026)

Vision d'elite (icone de l'objet dans Quetes) :
- Nouveau design dans l'esprit du donjon ouvert : feuille sur fond nuit violette etoilee, illustration de l'objet Vision d'elite qui flotte, titre "Les quetes de demain" et numero du jour.
- Non-negociables en trois affiches de parchemin epinglees, chacune avec la creature du donjon de sa famille (golem pour Body, spectre pour Mind, bouclier pour Discipline), l'etiquette de couleur, le nom de la quete et son XP.
- Hydratation (serpent) et secondaires (chauve-souris, etiquette Facile, Moyenne ou Difficile) en bandeaux de parchemin. Mention finale : ce qui est montre sera exactement joue demain (c'est deja le cas dans le code).
- Bug corrige : glisser vers le bas dans la feuille faisait defiler l'ecran de derriere. Le geste reste dans la feuille (elle descend et se ferme au-dela de 110 px), le fond sombre n'accepte plus aucun defilement. Corrige pour toutes les feuilles du bas qui se ferment en glissant (inventaire, infos de la Boutique...).
- Un glissement horizontal sur une fenetre posee par-dessus un ecran ne fait plus glisser la bande.

Confirmation d'achat : la ligne "+ Faveur -x %" n'apparait plus (le prix affiche tient deja compte de la Faveur). La ligne de reduction du marchand reste.

Parametres : ouvrir un sous-menu faisait apparaitre Quetes un instant. Le sous-menu apparaissait en fondu depuis la transparence, alors que les Parametres etaient deja retires. D'une fenetre a l'autre, la bascule est maintenant nette, sans fondu.

Heatmap (Stats) : elle defile seule tant qu'elle peut aller dans le sens du geste ; arrivee au bout, le geste suivant change d'ecran. Meme regle pour tout bloc qui defile a l'horizontale dans un ecran.

Bouton retour d'Android : il ne quitte plus l'appli d'office. Dans l'ordre :
1. fenetre de confirmation ouverte : Annuler ;
2. fenetre posee par-dessus (Vision d'elite, inventaire, infos et marchand de la Boutique, choix du donjon, chat de guilde...) : fermee ;
3. sous-menu des Parametres : retour aux Parametres ; Parametres, abonnement, lettre, bilan du soir : retour a Quetes ;
4. Identite, Boutique, Stats, Social : retour a Quetes ;
5. sur Quetes, ou sur un ecran qu'on ne doit pas quitter ainsi (sanction, questionnaire, ceremonies, fin de journee) : l'appli passe en arriere-plan, comme avant, et reprend ou elle en etait. Pendant un tutoriel, retour ne fait rien.
Cote Android, `MainActivity.java` transmet l'appui a l'appli (fonction _retourAndroid) ; verifie a la compilation contre des classes simplifiees, la vraie compilation se fait dans GitHub Actions.

Verifie par execution : Vision d'elite en 393 et 360 px de large, avec et sans quetes revelees ; gestes dans la feuille (haut, bas, travers) sans effet sur l'ecran de derriere ; heatmap au debut et au bout ; sous-menu des Parametres opaque des l'ouverture ; bouton retour sur chacun des cas ci-dessus et sur les huit fenetres fixes de l'appli ; et toute la serie precedente (glissements, barre, memoire de defilement, rotation, questionnaire, Annuler, carte gratuite).

Fichiers : `www/index.html` (et sa copie Android), `android/app/src/main/java/com/metanoia_app/MainActivity.java`, `LISEZMOI.md`. Fonction Supabase et prompts inchanges.

## Nouvelles couleurs de l'appli : themes retenus (2 novembre 2026)

Demande de Thibs : l'appli est trop fade, proposer des templates plus "appli pro du store" en gardant la DA. Six themes ont ete essayes sur la vraie appli (Parchemin, Bannieres, Nuit, Or royal, Eclat, Arcane). Retenus pour l'instant, choix final non fait :
- **Arcane** : sombre, violet nuit etoile, or et lilas, dans la lignee de Vision d'elite et du marchand. La carte du donjon reste brune.
- **Or royal** : parchemin, double cadre d'or autour des cartes, titres de section en Cinzel, onglet actif bordeaux et or.
- **Eclat** : clair et vif, une couleur par famille de quetes (cartes teintees, icones pleines), chiffres en couleur, accents orange.

Brouillons dans `design/themes/` : une feuille de styles par theme (`arcane.css`, `royal.css`, `eclat.css`, a activer par `data-theme` sur la balise html) et une planche de captures par theme. Rien n'est branche dans l'appli.

A savoir avant de choisir : Arcane (comme tout theme sombre) n'est propre que sur les cinq menus. Beaucoup de couleurs claires sont ecrites en dur ailleurs (Insights, inventaire, Pro, questionnaire, ceremonies, sanction) : il faudra une reprise ecran par ecran. Or royal et Eclat s'appliquent a toute l'appli sans ce travail.

Fichiers : `design/themes/` (nouveau), `LISEZMOI.md`. `www/index.html` inchange, fonction Supabase et prompts inchanges.

## Mise au point du 15 novembre 2026 (fin de la longue discussion du 24 octobre)

Relecture de la liste des points ouverts, avec le contexte de cette discussion :
- **Glissement entre menus et fluidite : regle.** Les trois videos du 25 octobre ont ete analysees image par image ; le glissement est mene par le code et le trajet du lacher toujours anime. Retour de Thibs ensuite : "Top". Il ne reste qu a **retirer le reglage "Mesure de fluidite"** (Parametres, Application & Sauvegardes) avant la publication.
- **`d.absent` : point clos**, il est ecrit au rattrapage des journees d absence (voir l audit de l ecran Stats plus haut).
- **Oublie de la liste des points ouverts : la refonte du questionnaire d accueil**, annoncee par Thibs comme prochaine etape le 20 octobre. Rien n est commence.
- **Bouton retour d Android :** `MainActivity.java` a ete modifie le 26 octobre et verifie seulement contre des classes simplifiees. Si un APK construit apres le 26 octobre a ete installe et que retour ferme bien les fenetres, c est valide ; sinon, surveiller la premiere compilation.
- **Questions laissees sans reponse le 27 octobre :** l appui sur un onglet a plus d un ecran passe directement a l ecran sans faire defiler ceux du milieu (a valider) ; idee non demandee : ouvrir la heatmap sur les jours les plus recents.
- **Verifie dans le code ce jour :** `PRO_CFG.cleAndroid` vaut toujours `goog_A_REMPLIR`, `_DEMO_ON` vaut toujours `true`, le libelle "Sync auto activee" est toujours sans accent, les sous-onglets Guilde et Classements ne se balaient toujours pas.

Fichiers : `LISEZMOI.md` seulement.

## Ce qui reste, etat au 18 octobre 2026

### Avant le depot sur le Play Store

- **Phase 8, le depot lui-meme.** Rien n est commence.
- **Retirer la derogation des comptes de developpement** posee dans
  `garde_partage` le 16 octobre (voir « La garde anti-triche »). A retirer
  avant une ouverture publique, comme `_DEMO_ON`.
- **Politique de confidentialite.** Obligatoire pour la fiche Play Store,
  inexistante. A ecrire avant de soumettre.
- **Questionnaire de classification d age.** Le plan d acquisition vise 12+,
  mais le questionnaire d entree propose « Resister a la pornographie » comme
  difficulte, les sanctions imposent un effort physique reel, et le chat de
  guilde est du contenu genere par les utilisateurs. Recommandation du plan :
  repondre honnetement et accepter le resultat, probablement 16+ ou plus.
  Non verifie contre le questionnaire reel de Google.

### Taches app issues du plan d acquisition, a valider par Thibs

Proposees le 15 octobre dans la conversation marketing, aucune n est
decidee ni commencee :

- **Ecran d avertissement vers le jour 12**, qui previent que la periode
  sans sanction se termine au jour 15. Argument : un joueur qui decouvre
  quarante pompes au jour 15 sans prevenance laisse une note d une etoile.
- **Test silencieux par cinq personnes** de la cible avant le 1er novembre,
  en notant chaque hesitation de plus de cinq secondes dans l entree en jeu.
- **Captures de store** : sept ecrans dans l ordre du plan, quetes du jour,
  rang, sanction, heatmap, guilde, donjon, lettre.
- **Mesure de retention** dans Supabase par `prog_day` et `updated_at`, sans
  outil ajoute.

Contraintes techniques que le plan prend pour acquises et qu il faut
garder en tete : AUCUN projet iOS (pas de dossier `ios/`, pas de
`@capacitor/ios`), et AUCUNE infrastructure de traduction (`lang="fr"`,
libelles en dur). Toute promesse App Store ou anglais est fausse tant que
ces deux chantiers n existent pas. Pour iOS, la mesure du 7 octobre comptait
49 `backdrop-filter` dont 13 prefixes `-webkit` et 44 `background-clip:text`
dont 22 prefixes : sous Safari les non prefixes tombent. Chiffres a
remesurer avant d ouvrir le chantier.
- **Retirer les guildes et chasseurs de demonstration.** Decision de Thibs le
  16 octobre : on les GARDE tant que l application n est pas publique, ils
  servent aux essais. Interrupteur unique `_DEMO_ON`, qui retire du meme coup
  les chasseurs des classements et les membres factices de guilde. C est le
  dernier correctif avant le depot, a ne pas oublier.
- **La cle de PUBLICATION** n existe pas encore et ne devra jamais etre
  versionnee : secrets GitHub.

### Chantiers demandes par Thibs, pas encore commences

- **Reequilibrage des recompenses.** Thibs a demande le 16 octobre la liste
  propre de trois systemes pour les retravailler : completion d un donjon,
  recompense de saison (quoi, et quels rangs concernes), evenement Clear
  (boite scellee offerte en cas de refus d utilisation). La liste lui a ete
  fournie ; les nouvelles valeurs restent a arbitrer PAR LUI. Ne rien
  modifier sans son accord explicite.
- **Le site sur metanoia-app.com.** Domaine achete chez IONOS le 16 octobre
  pour un an, echeance 16/10/2027, contrat 300461449. Hebergement statique
  gratuit prevu, un enregistrement A ou CNAME suffira.
- **La strategie marketing** a ete deplacee dans une autre conversation.

### Questions ouvertes cote serveur

Un audit du systeme de sanction a ete mene le 16 octobre cote client, et six
requetes d audit ont ete remises a Thibs pour la moitie serveur. **Ses
reponses ne sont jamais revenues** : ces points restent donc non verifies et
ne doivent pas etre presentes comme acquis.

1. La vue `classement` ecarte-t-elle reellement `suspect = true` ?
   `pg_get_viewdef('public.classement'::regclass, true)`
2. Les declencheurs sur `profiles` sont-ils actifs, et dans quel ordre
   alphabetique ? Un BEFORE qui `return null` annule l UPDATE en silence.
3. Qui est marque aujourd hui, et que contient `fraude_journal` ?
4. Les courriels de la garde partent-ils ? `net._http_response`, code 200.
5. Le joueur peut-il lire sa propre colonne `suspect` ? Politiques sur
   `profiles`. Si la colonne manque de la reponse, le client conserve
   desormais son etat au lieu de conclure a une rehabilitation.
6. Les definitions de `guard_profile_progress`, `metanoia_annuler_triche` et
   `metanoia_blanchir`.
7. Point 11 de l audit de securite, jamais verifie : le client ecrit en
   direct sur `profiles` et `guild_messages` seulement, tout le reste passe
   par des RPC, donc tout le controle est dans le corps SQL. A trancher :
   `guild_messages` insert (le client fixe `user_id`, `pseudo`,
   `guild_id`), `guild_request_decide` (`p_by` fourni par l appelant),
   `guild_promote` / `guild_kick` / `guild_set_role` (role de l appelant),
   `save_push` (devenu inutile depuis le retrait du Web Push, a supprimer
   cote serveur), `guild_trade_create` (liste blanche de `p_kind`), les
   lectures de guilde bornees par un `guild_id` du navigateur, et le canal
   temps reel. Requete, avec les parentheses qui manquaient dans le document
   d audit (sans elles, le `or` ramenait `save_push` de tout schema) :

   ```sql
   select p.proname, pg_get_functiondef(p.oid)
   from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname = 'public'
     and (p.proname like 'guild%' or p.proname = 'save_push');

   select tablename, policyname, cmd, qual, with_check
   from pg_policies where schemaname = 'public'
     and tablename like 'guild%'
   order by tablename, policyname;
   ```

**Un point me gene particulierement** : un commentaire du client affirme que
l XP publique d un compte marque est GELEE, et je n ai trouve aucun
mecanisme qui le fasse. Soit c est vrai cote serveur, soit le commentaire
ment. Non tranche.

### Points de conception laisses de cote

- Pas de fil d Ariane ni de bouton retour dans l enchainement des profils :
  chaque feuille remplace la precedente. Limite assumee le 16 octobre.
- L ecran de resultat de fin de saison n a jamais ete vu en conditions
  reelles. Un bouton d essai existe dans le panneau de test, mais le vrai
  declenchement sur un changement de saison reste a observer.
- Le commentaire perime qui justifie le filtre `d.disc !== undefined` dans
  les zones de Flow attend toujours une reecriture. Sans consequence.

### Rappel administratif

Le renouvellement automatique de metanoia-app.com chez IONOS n a pas pu etre
desactive le 16 octobre : le domaine etait encore en cours de traitement
chez le registre. A refaire, sur la ligne `metanoia-app.com` et non sur le
contrat conteneur. Et a poser en alerte d agenda vers septembre 2027, un
mois avant l echeance : perdre le nom apres le lancement coute bien plus
cher que le renouvellement.

### Ce qui a ete regle et ne doit plus etre reouvert

Ces points figuraient ici comme ouverts et ont ete traites le 16 octobre :
l envoi d un courriel au joueur marque (chaine Resend plus pg_net, domaine
verifie), les deux chemins de rehabilitation d un compte marque qui
existaient deja (`metanoia_annuler_triche` et `metanoia_blanchir`, j avais
affirme a tort qu il n y en avait aucun), l erreur
`operator does not exist: text = integer` de `user_public_profile`, et le
classement de Saison, casse par une faute de frappe entre `xp_season` et
`season_xp` puis par le gel anti-triche du compte de Thibs.

## Cle de signature

`android/keystore/debug.keystore` est une cle de DEBOGAGE fixe, versionnee
expres : sans elle, chaque machine et chaque run GitHub en genere une au
hasard, donc une empreinte SHA-1 differente a chaque fois, et Google Sign-In
refuse la connexion. Elle ne protege rien (mot de passe « android », comme la
cle de debogage par defaut d'Android, identique chez tout le monde).

    SHA-1 : 4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97

La cle de PUBLICATION, elle, ne doit JAMAIS etre versionnee : elle ira dans
les secrets GitHub a la phase 8.

## Questionnaire d accueil : maquette cliquable (15 novembre 2026)

Demande de Thibs : un questionnaire immersif qui cree le declic, interactif,
illustre et anime, avec des etudes qui montrent la version qu il peut
devenir, sans etre trop long. Maquette HORS de l app, a tester sur
telephone avant integration. `www/index.html` n est pas touche.

Fichiers : `design/questionnaire/source.html` (code), `maquette.html` (page
assemblee, polices et phenix integres), `assembler.py`, `phenix.webp`
(detoure depuis `store/icone-play-512.png`). Les monstres viennent de la
vraie `_monsterSVG`, extraite du fichier.

Parcours (environ 3 a 4 minutes), une palette par acte :
- Ouverture : phenix qui nait, pitch de Thibs, « Je veux changer » ;
  puis « Comment ca marche » (3 tuiles) et le texte d accueil de Thibs.
- Acte I Qui tu es : age, situation. Interlude « 66 jours » (courbe
  d automaticite, Lally 2010).
- Acte II Ton corps : sport, objectif, acces (+ sport collectif et jours,
  alerte prise de masse). Interlude OMS 150 min et Pearce 2022.
- Acte III Ton esprit : mental, ecrans (curseur, telephone qui se
  remplit, heures par semaine et jours par an), sommeil. Interlude selon
  les reponses (Van Dongen ou Hirshkowitz, Allcott).
- Acte IV Tes demons : 8 cartes qui se retournent sur un monstre nomme.
  Interlude Hofmann 2012, Gollwitzer 2006, Fernandez 2023 si pornographie.
- Acte V Qui tu peux devenir : frise J1, J21, J66, J180 tiree des
  reponses, phenix qui grandit, rangs estimes a 28 XP par journee tenue.
- Acte VI Le serment : pourquoi, calibration, programme, contrat signe
  par appui long de 1,6 s sur un sceau, ecran final.

Donnees : memes champs que `ST._ob` et `ST.myWhy`, memes valeurs.
Calcul du programme copie de `_obCalcScore` / `_obCalcProg` : 0 ecart sur
3 000 profils compares a la vraie fonction. Etudes : uniquement des faits
de `bibliotheque.ts`, textes repris tels quels.

Textes de Thibs repris tels quels : pitch (« proposes » corrige en
« propose »), texte d accueil, titres et sous-titres des questions,
alerte prise de masse, sous-titre du pourquoi, contrat et sa mention, et
descriptions des programmes. Textes ecrits par Claude, A VALIDER : tuiles
« Comment ca marche », echos « Le Systeme note », noms des demons,
phrases personnalisees des interludes, frise du miroir, ecran final.
Changement a valider : signature dessinee remplacee par l appui long.

Verifie par execution (Chromium, 360 x 740 et 393 x 852) : parcours
complet sans erreur, donnees collectees conformes, retour arriere qui
garde la selection, aucun debordement horizontal, 0 cadratin.
Non fait : integration dans l app, reconfiguration (`ST._obReconfig`).

### Version 2, apres les retours de Thibs (16 novembre 2026)

Retours : fond a bulles et braises flottantes « cheap », DA trop « IA »,
trop de texte, allegories des difficultes (monstres, « Chauve-souris de
Minuit ») a retirer, et etudes qui culpabilisent (norme de sommeil).

- DA refaite a plat : un aplat de couleur vive par acte (bordeaux, violet,
  orange, bleu, framboise, jaune, bordeaux), facettes STATIQUES reprises
  du phenix low-poly dans deux coins, cartes blanches a relief franc,
  boutons « 3D a plat », titres Sora 800. Plus de flou, de degrade, de
  verre, de braises ni de grain. Cinzel garde pour METANOIA et le nom du
  programme.
- Moins de texte : tuiles « Comment ca marche » sans sous-titre, echos
  « Le Systeme note » retires, frise du miroir en une ligne par etape.
- Acte IV renomme « Tes freins » : cartes simples, sans monstre ni nom.
  `_monsterSVG` n est plus embarquee.
- Etudes : plus aucune norme (OMS, 7 a 9 h, dette de sommeil retirees).
  Chaque carte = un chiffre ou un titre, une phrase, une action a faire,
  la source. Retenus : Lally 66 jours et l oubli, Milkman +51 %, Bond
  heure fixe (ou Wing amis si sport collectif), Allcott +60 min (ou
  Singh habitudes du matin sous 1 h d ecran), Kushlev Ne pas deranger,
  Hofmann, Gollwitzer, Fernandez 7 jours si pornographie.
- Calibration : pourcentage qui monte et quatre lignes cochees, au lieu
  du radar.
- Curseur des ecrans : « Chaque heure reprise, c est 365 h par an pour
  toi » au lieu des jours par an.

Verifie par execution a 360 x 740 et 393 x 852 : parcours complet sans
erreur, memes donnees qu avant, 0 cadratin.

### Ecran « Comment ca marche » (16 novembre 2026, 16 h 25)

Demande de Thibs : le texte « Bienvenue. Tu as decide de changer... » est
retire de cet ecran (dans la maquette seulement ; `_obShowIntro` de l app
le garde tant que la maquette n est pas integree). Les trois tuiles sont
reliees par un fil flechee qui se trace de haut en bas : tuile, fil,
tuile, fil, tuile, puis le bouton « Compris », environ 2,4 s en tout,
avec un petit son et une vibration a chaque tuile. Le fil est aligne au
pixel sur l axe des icones. Verifie : captures a 0,5 s, 1 s, 1,5 s,
2,4 s et 3 s, parcours complet sans erreur a 360 x 740.

### Retouches du 16 novembre 2026, 16 h 30

- Fin du parcours : les trois derniers ecrans (calibration, programme et
  serment, ecran final) reviennent a la version 1, preferee par Thibs :
  radar et phenix, nom du programme en Cinzel dore, contrat parchemin,
  sceau rouge a maintenir, « Bienvenue, chasseur ». Fond a plat conserve
  (pas de bulles). Styles isoles sous `.v1` et suffixes `-v1`.
- « Comment ca marche » : fleches centrees sous les cartes (ecart mesure
  0 px) et passees a l or du theme `#D9A84E`, comme l accent de l ecran
  d ouverture (orange retire).
- Acte V : tous les sons retires (etapes, fin, bouton), vibrations
  gardees.
Verifie : parcours complet sans erreur a 393 x 852, 0 cadratin.

### Retouches du 16 novembre 2026, 16 h 40

- Acte V : rangs retires de la frise (ils induisaient le nouveau en
  erreur), mention de source reduite a « Jour 66 : Lally et al., 2010 ».
  Animation refaite en UNE boucle continue : le rail descend, chaque
  etape s allume quand il l atteint, le phenix se colore progressivement,
  et le defilement suit sur une courbe douce. Plus de sauts par etape.
  Si le joueur touche l ecran, le defilement automatique s arrete.
  Mesure sur un ecran de 560 px de haut : pas maximal 2 px par image,
  aucun retour en arriere, arrivee exacte en bas.
- « Comment ca marche » : fleches remplacees par une simple ligne fine
  blanche a 55 %, centree. Nouveaux contenus des trois cartes, d apres
  Thibs : « Réponds au formulaire de départ pour un programme adapté »,
  « Ton programme est créé en fonction de tes réponses », « Commence à
  changer, gratuitement ». Icones formulaire, engrenage, flamme.
- Sons : le son de « montee » (`son('grand')`, joue au bouton « Je veux
  changer » puis au programme et a la signature) est retire de TOUT le
  formulaire. Le petit son des cartes reste, sauf sur la premiere carte
  de « Comment ca marche ». Interpretation a confirmer par Thibs.
Verifie : parcours complet sans erreur a 393 x 852, 0 cadratin.

## Bibliotheque de sons de clic (16 novembre 2026)

Demande de Thibs : le son actuel fait trop jeu video. Page de test
`design/sons/bibliotheque-sons.html` (publiee aussi en page claude.ai) :
13 sons generes par Web Audio, sans fichier, avec volume, bouton
« Choisir » et quatre cartes plus un bouton d essai pour les entendre en
situation. Sons : 1 Tic doux, 2 Bois, 3 Pop feutre, 4 Goutte, 5 Cristal,
6 Marimba, 7 Corde pincee (Karplus-Strong), 8 Clavier, 9 Pression,
10 Papier, 11 Cloche douce (FM), 12 Deux notes, 13 Actuel (pour
comparer). Niveaux egalises par rendu hors ligne : crete 0,22 a 0,42,
sauf « Actuel », garde a son vrai niveau (0,02). En attente du choix de
Thibs (un son, ou un pour les cartes et un pour les boutons).

### Textes, aucun defilement, barre de progression (16 novembre 2026, 17 h)

- Textes de Thibs repris tels quels. Ouverture : « Parfois, tu galères à
  tenir une bonne habitude. On te propose d'en tenir plusieurs, et à long
  terme. » Cartes : « Tu réponds au formulaire, pour créer un programme
  adapté », « Ton programme est créé, en fonction de tes réponses », « Tu
  peux enfin commencer à changer, et ce gratuitement. »
- Regle de Thibs : AUCUN defilement pendant le formulaire (retention).
  `ajuster(e)` reduit l ecran par zoom CSS (qui refait la mise en page)
  jusqu a ce que tout tienne, plancher 70 % ; rejoue a l ouverture du
  sport collectif et au redimensionnement. Freins passes en grille
  compacte de 2 colonnes, cartes d etude resserrees.
  Mesure, parcours complet : a 393 x 852, un seul ecran reduit
  (strategie avec 3 etudes, 90 %) ; a 360 x 640, tous les ecrans tiennent,
  le plus reduit a 70 % (strategie). Debordement 0 partout.
- Barre de progression : une seule barre, non lineaire. Position =
  1-(1-x)^1.6, x = etape / 17 sur 18 etapes (`ETAPES`) : 20 % du parcours
  donnent 30 % de barre, la moitie 67 %, 80 % donnent 92 %. Elle avance
  vite au debut et rend l avance a la fin. Calibration et miroir la font
  avancer en continu (`progressionSous`).
Verifie : parcours complet sans erreur a 360 x 640 et 393 x 852, 0 cadratin.

### Son retenu : « Bois » (16 novembre 2026, 17 h)

Choix de Thibs : n° 2 de la bibliotheque. `son()` de la maquette ne joue
plus que lui, pour tous les gestes (choix, boutons, etudes) : triangle
880 vers 700 Hz sur 60 ms, plus un bruit filtre en bande a 1,4 kHz sur
15 ms. Le tampon de bruit est cree une fois et reutilise. Rendu hors
ligne : crete 0,32, 48 ms. Les anciens sons carres et « montee » ont
disparu du code. A reprendre tel quel a l integration (l app a son
propre `SND`).

### Son entendu deux fois (16 novembre 2026, 17 h 05)

Signale par Thibs : pendant une transition, le son repartait une seconde
fois. Deux causes. Les quatre ecrans d etudes jouaient un son a leur
ARRIVEE, juste apres celui du bouton qui y menait : retire. Et un second
appui pendant la transition rejouait le son meme si la navigation etait
ignoree : `son()` se tait desormais pendant `EN_TRANSITION` et a moins de
150 ms du son precedent.
Verifie en comptant les sons reellement joues : un seul par geste, y
compris vers un ecran d etude et sur un double appui rapide (carte comme
bouton). Seules exceptions voulues : les deux cartes de « Comment ca
marche » et les quatre lignes de la calibration.

## Questionnaire d accueil INTEGRE dans l app (16 novembre 2026, 17 h 10)

Demande de Thibs : integrer la maquette validee sans rien endommager.

Architecture choisie pour ne toucher presque rien du gros fichier :
- `www/accueil.js` (nouveau, 58 Ko) : le questionnaire entier, dans une
  fonction fermee qui n ajoute qu UN nom global, `window.NOB`. Il dessine
  dans une Shadow DOM accrochee a `#s-ob` : ses styles ne sortent pas,
  ceux de l app n entrent pas, ses identifiants (`go`, `app`, `scene`...)
  ne peuvent pas entrer en collision avec ceux de l app. Feuille de
  style injectee depuis le module (pas de flash sans style).
- `www/accueil-phenix.webp` (nouveau, 20 Ko) : le phenix detoure.
- `www/index.html`, trois retouches seulement : la balise
  `<script src="accueil.js">` apres `supabase.js`, et dans `buildOB()`
  les particules de l ancien questionnaire coupees puis
  `if(window.NOB&&NOB.demarrer&&NOB.demarrer())return;` avant
  `_obShowIntro()`. L ANCIEN PARCOURS EST INTACT et sert de repli si le
  module manque. Reference structurelle : 6 balises `<script`, 4 blocs
  inline.
- `design/questionnaire/integrer.py` regenere `www/accueil.js` depuis
  `design/questionnaire/source.html` (la maquette). Toute retouche du
  questionnaire se fait dans la source puis on relance le script.

Ce qui n a PAS change, par construction :
- Memes champs et memes valeurs dans `ST._ob` (age, situation, sportLevel,
  physGoal, sportAccess, collectifSport, collectifJours, mindLevel,
  screenHours, sleep, resistances, prog) et `ST.myWhy`. Memes defauts :
  `sportAccess` vide devient `[1]`, `screenHours` vaut 3 si on ne touche
  pas au curseur.
- Le programme est calcule par les VRAIES `_obCalcScore` / `_obCalcProg`
  (la copie de la maquette est supprimee).
- La fin appelle le vrai `_obFinish()` : score, mode, `ST.answers`,
  `_secStart`, `_startMult`, `genWeek()`, navigation, tutoriel.

Reconfiguration depuis les Parametres (`ST._obReconfig`) :
- commence a l age, reponses pre-remplies, saute les ecrans d etudes et
  le miroir, et finit au pourquoi (pre-rempli, validable vide) puis
  `_obFinish()`, comme l ancien parcours ;
- bouton « Annuler » en haut a droite, qui appelle `cancelReconfig()` ;
- le module travaille sur une COPIE de `ST._ob` : annuler laisse les
  reponses intactes (l ancien parcours les modifiait en direct).

Verifie dans l application reelle (serveur local + Chromium) :
- nouveau joueur, parcours complet a 393 x 852 et 360 x 640 : `onboarded`,
  `ST._ob`, `ST.myWhy`, mode Discipline (score 12, recompte a la main),
  `ST.answers`, `weekPlan` genere, ecran `s-main` actif, tutoriel lance,
  questionnaire retire du DOM ;
- reconfiguration : ordre des ecrans conforme, jour 23 et 1234 XP
  conserves, quetes regenerees, retour sur `s-main` ;
- annulation apres avoir change une reponse : retour sur `s-settings`,
  `ST._ob` inchange ;
- seules erreurs de console : les appels reseau refuses par le bac a
  sable. `node --check` sur `accueil.js` et les quatre blocs, lxml,
  0 cadratin.
- Copie Android : `npx cap copy android` impossible ici (pas de
  node_modules) ; les trois fichiers ont ete copies a la main dans
  `android/app/src/main/assets/public`, identiques a `www/` (seuls
  `cordova*.js` en plus, comme avant). Un `npx cap sync android` chez
  Thibs refera la meme chose.

Non teste ici : le rendu sur le vrai telephone (Shadow DOM, zoom et
vibrations sont supportes par la WebView Android recente).

## Compilation : nom d archive modifie par le telephone (16 novembre 2026)

Le telephone de Thibs enregistrait le telechargement sous
« metanoia-depot (2).zip » ; la chaine GitHub ne cherchait que
« metanoia-depot.zip » et s arretait en 7 s. `android.yml` accepte
desormais tout `metanoia-depot*.zip` (le plus recent est renomme le temps
de la compilation) et se declenche aussi sur ces noms. YAML valide,
logique testee en shell sur un faux « metanoia-depot (2).zip ».
ATTENTION : le workflow qui tourne est celui de `.github/workflows/` a la
RACINE du depot GitHub, pas celui de l archive : il faut le recopier la-bas.

## Apres une deconnexion, les cadenas recouvraient tout (16 novembre 2026, 18 h)

Signale par Thibs sur l appareil : deconnecte, l app montrait les ecrans
verrouilles Identite, Statistiques et Marche Nocturne les uns apres les
autres, onglet Quetes allume, plus rien d accessible. Present AVANT
l integration du questionnaire : meme resultat sur l archive du
15 novembre, donc rien a voir avec `accueil.js`.

Cause : `_lockedContent()` pose le cadenas en `position:fixed;inset:0;
z-index:40`. Avant la bande d ecrans (25 octobre) un ecran inactif etait
masque ; dans la bande, les cinq ecrans sont dessines et un element fixe
SORT de son ecran, meme range a -20 000 px. Retour a J1 par la
deconnexion : trois onglets se reverrouillent, leurs cadenas couvrent la
fenetre entiere et se succedent au gre des rendus. Le meme piege attendait
tout nouveau joueur a J1.

Correctif, CSS seulement plus trois `scrollTop=0` :
- `html.bande [id^="lock-overlay-"]>div{position:absolute!important}` : le
  cadenas reste dans son ecran et glisse avec lui ;
- un ecran verrouille ne defile pas sous son cadenas (`:has`, overflow
  cache) et repart en haut quand le cadenas s affiche.
Verifie dans l app (deconnexion simulee) : Quetes visible apres le retour
a J1, puis Identite, Boutique et Stats montrent chacune leur cadenas plein
ecran (0,0 393 x 851) a leur place, et les autres restent hors champ.

Second defaut trouve dans la meme fonction, corrige : le message dit « ton
questionnaire est conserve », mais `_resetApresDeconnexion` ne gardait que
`answers`, `multiAnswers`, `myWhy` et `_obUpdatedAt`. Perdus : `_ob` et
les reglages que `genWeek` lit (`_physGoal`, `_hasSalle`, `_hasVelo`,
`_secStart`, `_startMult`, `_obMode`, plus `_obScore`, `_hasSport`) :
apres une deconnexion, les quetes repartaient sur le profil par defaut.
Ils sont desormais conserves. Verifie : valeurs identiques avant et apres,
jour bien remis a 1.

Structure : 6 balises `<script`, 4 blocs inline, `node --check` et lxml
passent, 0 cadratin. Copie Android a jour.

## Refonte visuelle de toute l app : maquette a 3 pistes (16 novembre 2026, 18 h 40)

Demande de Thibs : l app fait trop « IA », trop « Claude ». Choix : rester
dans la DA du questionnaire valide, et comparer 2 ou 3 pistes sur les
5 menus. `design/refonte/maquette.html` (source `source.html`), publiee en
page claude.ai : selecteur de piste A / B / C, barre du bas qui change de
menu, contenus realistes repris des vrais ecrans au jour 24.

Socle commun : Sora 800 serre, une couleur par menu (Quetes orange
#FF5A1F, Identite violet #6C2BD9, Boutique framboise #E0115F, Stats bleu
#0B7CFF, Social vert #13A05B), icones dessinees au trait (plus aucun emoji),
cartes a relief franc, boutons « 3D a plat », phenix en badge.
- A, aplats : tout le fond de la couleur du menu, cartes blanches,
  facettes du phenix dans les coins (le questionnaire tel quel).
- B, clair : fond creme, bandeau de couleur arrondi en tete de menu,
  cartes blanches filetees, couleur en accent.
- C, nuit : fond #170A12, cartes prune, accents vifs du menu.
`www/index.html` n est pas touche. Verifie : 15 ecrans captures a 393 et
360 px, aucun debordement horizontal, aucune erreur, 0 cadratin.
En attente du choix de Thibs (une piste, ou un melange).

### Correction de cap : seulement couleurs et polices (16 novembre 2026, 18 h 50)

Thibs ne veut PAS de reagencement : les 3 pistes de `design/refonte/` sont
ecartees. Il garde menus, categories et agencements, et veut seulement
des couleurs et des polices plus pro, moins « IA / Claude ».

Proposition : `www/theme.css` (copie dans `design/theme-net.css`), une
couche posee par-dessus le style existant, PAS ENCORE BRANCHEE (aucune
balise dans `index.html`). Elle change :
- le fond ivoire et le grain papier pour un gris neutre #F2F2F5 ;
- l or et le terracotta des actions (Accomplie, pastille de la barre,
  boutons dores, donjon) pour le bordeaux du logo #4D102F, et les accents
  (XP, prix) pour l orange du phenix #E8650F ;
- les titres Cinzel et Playfair pour Sora, en redirigeant ces deux
  familles vers les fichiers Sora (aucune ligne de code touchee) ;
- les degrades dores ecrits en dur, rattrapes par leur texte exact.
Apercu : captures des 5 menus au jour 24, avant / apres, Chromium.
Pour l activer : `<link rel="stylesheet" href="theme.css">` APRES
`fonts.css` (les @font-face doivent venir apres pour l emporter).

### Touches de couleur par menu (16 novembre 2026, 19 h)

Retour de Thibs : le theme Net plait, mais le gris est monotone. Ajout
dans `theme.css`, toujours sans rien deplacer, d une couleur vive par
menu (celles du questionnaire) : Identite violet #7C3AED, Marche
framboise #E0115F, Stats bleu #0B7CFF, Reseau vert #13A05B.
- pastille de tete en couleur pleine, petit trait de couleur sous le titre ;
- Identite : carte « Titre equipe » teintee, barre Communs / Epiques /
  Legendaires en degrade violet ;
- Marche : carte « Ta bourse » en degrade framboise, onglet actif colore ;
- Stats : onglet actif bleu, liseres de couleur sur les 4 chiffres cles,
  intitules de section avec un repere bleu ;
- Reseau : liseré vert sur la carte d accueil, bouton et sous-onglet
  actif verts.
Quetes reste au bordeaux du logo. Toujours pas branche dans `index.html`.

### Modules plus epais (16 novembre 2026, 19 h 05)

Retour de Thibs : les modules fins et nombreux font « IA ». Ajout dans
`theme.css` : blocs a relief franc (ombre pleine de 4 px sous la carte,
filet de 1,5 px), coins a 20 px, plus de marge interne et entre les blocs,
noms de quetes et de titres en 15 / 14,5 px gras, chiffres cles des Stats
en 24 px, boutons de quete plus hauts (36 px). Concerne : cartes de
quetes, cartes et chiffres des Stats, titres d Identite, bourse du
Marche, carte d accueil du Reseau, bloc d humeur.
Verifie : boutons de quete sans coupure a 360 et 393 px (padding reduit
sous 375 px). A 340 px, la rangee Accomplie / En partie / Fail deborde
encore de quelques pixels : ecran tres rare, a traiter si besoin.
Toujours pas branche dans `index.html`.

### Theme Net BRANCHE dans l app (16 novembre 2026, 19 h 45)

Thibs a installe l APK et ne voyait rien : normal, `theme.css` n etait pas
encore lie. Ajout dans `index.html` de
`<link rel="stylesheet" href="theme.css">` juste APRES `fonts.css` (une
seule ligne, plus un commentaire). Retirer cette ligne rend l app comme
avant. Verifie dans l app : les 5 menus, Parametres, bilan du soir, choix
du donjon et questionnaire d accueil (non touche : il vit dans sa Shadow
DOM), aucune erreur. Copie Android a jour (`index.html`, `theme.css`).
Structure : 6 balises `<script`, 4 blocs inline, lxml valide, 0 cadratin.

## Quetes secondaires a swiper : decisions et maquette (16 novembre 2026, 21 h)

Idee de Thibs : les secondaires ressemblent a des obligatoires (on ne
choisit rien). Les rendre swipables, sans trahir l ame de l app (un
Systeme qui dirige). Recherche faite avant de trancher :
- Patall, Cooper et Robinson 2008 (41 etudes) : le choix augmente la
  motivation, l effort et la performance, effet maximal avec 2 a 4 choix
  successifs, rendement decroissant au-dela de 5.
- Chernev et al. 2015 (99 observations) : la surcharge de choix croit
  avec la difficulte de la decision, l incertitude des preferences et un
  objectif de moindre effort. Defilement infini ecarte.
- Jang, Reeve et Deci 2010 (133 classes) : autonomie et cadre sont
  complementaires.
- Hearthstone : 1 reroll de quete par jour ; mais un reroll de quete
  difficile y donne toujours une facile, a NE PAS reproduire.
- Read, Loewenstein et Kalyanaraman 1999 : choisir a l avance donne des
  choix plus vertueux. Ecarte par Thibs : demander un choix la veille,
  apres un bilan deja long, ferait perdre des joueurs.
- Choix lie a l integrite : seulement en bonus, jamais en retrait.

Decisions de Thibs :
- swipe vers la DROITE pour remplacer une secondaire ;
- 1 swipe par jour au total, 2 si integrite >= 80 ;
- la remplacante a la MEME difficulte, et n est jamais une quete deja
  affichee ;
- une quete ecartee 3 fois revient imposee, non swipable, avec le
  Boost x4 existant ;
- pas de choix la veille.

Maquette `design/secondaires/maquette.html` (source `source.html`),
publiee en page claude.ai, dans le style du theme Net : pile avec deux
cartes qui depassent derriere, geste suivi au doigt, tampon « Nouvelle
quete », carte qui resiste (effet elastique) vers la gauche ou quand il
n y a plus de swipe, compteur « 2 swipes / 1 swipe / Plus de swipe »,
carte imposee avec bandeau bordeaux et gains x4. Verifie (Chromium,
393 et 360 px) : petit geste et geste a gauche sans effet, 2 swipes a
integrite 90 puis refus, 1 seul a integrite 60, carte imposee immobile,
difficulte conservee, aucune erreur. Pas encore integre dans l app.

Ajout demande par Thibs (meme soir) : pendant le glissement, la
remplacante apparait sous la carte et devient lisible avant le seuil de
lacher ; relacher avant le seuil annule sans rien consommer.
Garde-fous : la remplacante est tiree UNE fois par emplacement et reste
fixe (annuler ne retire rien, sinon ce serait un reroll infini) ;
regarder ne compte ni comme swipe ni comme fuite ; sans swipe restant
ou sur une quete imposee, rien n apparait dessous. Code : `ETAT.suivantes`
et `tirerSuivante(i)`, `reveler(k)` dans `brancher()`. Verifie : apercu
lisible a 110 px, annulation sans effet, swipe reel = la quete vue.
Bug evite : `pile.querySelector('.qcard')` visait la carte du dessous,
remplace par `':scope>.qcard'`. A reprendre tel quel a l integration.


## Quetes secondaires a swiper : integration dans l app (16 novembre 2026, 22 h)

Demande de Thibs : « Go dans l App. Verifier qu il n y ait pas de probleme
entre pouvoir swiper une secondaire et swiper d un ecran a un autre ».

Fichier modifie : `www/index.html` (copie dans
`android/app/src/main/assets/public/`). Rien d autre dans l app.

Regles (celles de la maquette) : swipe vers la DROITE ; 1 par jour, 2 si
`ST.integrity` >= 80 ; remplacante de meme type (`se`, `sm`, `sh`), jamais
un doublon (`_dKey`), jamais d une famille deja prise (`_FAMILLES_G`) ;
remplacante tiree une fois et gardee dans le programme du jour
(`t.secs[i]._suiv`), visible dessous pendant le glissement ; relacher avant
le seuil (38 % de la largeur, ou geste rapide) annule sans rien consommer.
Non swipables : quete traitee, creneau ferme, Hard Mode, quete boostee du
jour (sinon la remplacante heritait du boost par l id de l emplacement),
quete imposee. La remplacante garde l id de l emplacement (`se3`...), donc
le bilan et les statistiques ne voient aucune difference.

Quete fuie : `ST._secFuites[_dKey(nom)]` compte les swipes. A 3, la quete
part dans `ST._secImposee` pour le lendemain et le compteur repart a 0.
`_secAppliquerImposee(t)` la pose au premier rendu du jour, a la place de la
secondaire de meme difficulte (ou en plus s il n y en a pas), avec
`_imposee:true`. `_estBooste` la compte boostee (x4, sauf Hard Mode et De du
Destin, meme regle de non-cumul) ; bandeau « Elle revient, Boost x4 » et
texte dedie dans `buildQ`. En Mode Minimum, elle attend.

Etat ajoute : `ST._secSwipes {day,n}`, `ST._secFuites`, `ST._secImposee`,
`ST._secSwipeVu` (l astuce sous la carte disparait apres le premier swipe).

Fonctions : `_secQuota`, `_secRestants`, `_secSwipable`, `_secFamille`,
`_secSuivante`, `_secAppliquerImposee`, `_secCarte`, `_secJeton`,
`_secBrancher`, `_secPartir`, placees juste apres `_estBooste`. Rendu dans
`renderMain` : chaque secondaire est enveloppee dans `.sec-pile`, compteur
`.sec-jeton` dans le libelle « Quetes secondaires ». L empreinte de rendu
contient desormais le nom des secondaires et le nombre de swipes restants
(un swipe garde l id, l ancienne empreinte ne voyait rien).
`_FAMILLES` etait locale a `_genWeekRaw` : sortie en `_FAMILLES_G` globale,
la locale pointe dessus, contenu identique.

Conflit avec la bande d ecrans : le geste de bande (`_bandeInit`) note s il
part d une `.sec-pile` ; vers la droite il laisse la main a la carte
(`g.mode=2`), vers la gauche il change d ecran comme partout. Cote carte,
un geste vers la gauche ou vertical est abandonne aussitot. Les Quetes sont
le premier ecran, donc vers la droite la bande n avait de toute facon nulle
part ou aller.

Verifie dans l app (Chromium 393 px, vrais evenements tactiles CDP,
`design/secondaires/test_app.js`) : apercu lisible a 120 px sans que la
bande bouge ; annulation sans effet ; swipe 1 et 2 a integrite 90 avec meme
difficulte ; 3e refuse avec message ; integrite 60 = 1 seul ; glissement a
gauche sur une secondaire = passage a Identite ; defilement vertical
intact ; 3e fuite = quete imposee le lendemain, +12 XP au lieu de 3, non
swipable ; aucune erreur. 6 balises script, 4 blocs, `node --check` ok,
0 tiret long.

Non teste : vrai telephone. A verifier sur l APK : le glissement d une
secondaire, puis un glissement a gauche dessus pour changer d ecran.


## Secondaires : carte flottante et verrou anti-glitch, « Obligatoires » (17 novembre 2026)

### Carte restee de travers
Signale par Thibs sur l appareil : commencer un swipe, toucher ailleurs, la
carte reste decalee sans doigt dessus. Reproduit (Chromium, vrais evenements
tactiles) : un SECOND doigt pose sur la meme pile relancait `pointerdown`,
qui remettait `actif` et `sens` a zero ; son lacher sortait par
`sens===null` sans remettre la carte ; le premier doigt etait ensuite
ignore. Autre defaut du meme code : un `pointercancel` au-dela du seuil
VALIDAIT le swipe au lieu de l annuler.

Correctif : le geste n est plus porte par chaque pile mais par un etat
global unique, `_SEC_G` (`pid`, pile, sens, dx), et des ecouteurs poses une
fois sur le document en phase de capture (`_secGardes`). Regles :
- un seul geste de swipe a la fois dans toute l app ; tant qu il existe,
  tout autre doigt est ignore (`pointerdown` stoppe) et AUCUN clic ne passe,
  nulle part (boutons de la carte de devant, de dessous, d une autre quete,
  d une obligatoire) ;
- `_SEC_VERROU` prolonge ce blocage 350 ms apres un lacher (clic fantome) et
  pendant le vol de la carte jusqu au redessin (`_secPartir`, 700 ms) : pas
  de second swipe ni de clic sur la carte qui arrive ;
- interruption (`pointercancel`, perte de capture sans lacher, appli en
  arriere-plan, `blur`, `pagehide`, pile redessinee en plein geste) : la
  carte revient TOUJOURS en place, jamais de swipe (`_secAnnuler`,
  `_secRemettre`) ;
- refus de derniere minute dans `_secPartir` : la carte revient et le
  redessin est force (l empreinte de rendu sur `#ql-nn` pouvait ne pas
  changer, la carte restait alors decalee).

### Boutons de la carte de dessous
Ils sont maintenant affiches (ceux de la quete reelle : Accomplie et Skip
pour une secondaire). Morts par trois verrous : `inert` sur `.sec-dessous`,
`onclick` retires (ils visaient `apercu-i`), boutons `disabled`, plus
`pointer-events:none` sur tout le bloc. Revelee, la carte de dessous prend
sa vraie hauteur (boutons compris) ; au repos, celle de la carte de devant.

Verifie (`design/secondaires/test_glitch.js`, `trig` espionne) : second
doigt sur la carte, sur un bouton de dessous, sur une autre secondaire, sur
une obligatoire ; deux piles swipees en meme temps ; swipe valide puis tape
et nouveau swipe immediats ; bouton tenu pendant un swipe ; annulation
systeme au-dela du seuil ; arriere-plan ; redessin en plein geste. Aucune
carte decalee, un seul swipe consomme par geste, aucun appel a `trig` sauf
la tape normale finale. Ancienne serie `test_app.js` toujours bonne.
Piege de test : en CDP, `touchEnd` liste les doigts LEVES, pas ceux qui
restent.

### « Non-negociables » devient « Obligatoires »
Demande de Thibs. Textes visibles seulement : titre de section des Quetes,
editeur d arc, objectif des monstres, Vision d elite, Eclipse, Parametres
(sanctions), description du programme Discipline (app et questionnaire,
`accueil.js` regenere par `integrer.py`), condition de donjon « NN
d affilee » devenue « Obligatoires d affilee » (pastille courte « Oblig. »)
et repli « Quete NN ». Noms internes (`nn`, `isNN`, `slbl-nn`...) et
commentaires inchanges.

Fichiers : `www/index.html`, `www/accueil.js` (et leur copie Android),
`design/questionnaire/source.html`, `design/secondaires/test_glitch.js` et
`test_base.js`, `LISEZMOI.md`.

## Secondaire boostee : swipable, boost jamais transmis (17 novembre 2026, 18 h 45)

Decision de Thibs : une secondaire boostee doit pouvoir se swiper (le refus
« Quete boostee par le Systeme : impossible de l ecarter » frustrait), mais
le joueur ne doit jamais croire qu un swipe peut faire apparaitre une carte
boostee. Remplace la regle du 16 novembre sur ce point.

- `_secSwipable` n exclut plus le boost. Restent non swipables : quete
  traitee, creneau ferme, Hard Mode, quete IMPOSEE (3 fuites).
- Le boost suit la QUETE et non plus l emplacement : `ST._boost` porte
  maintenant `k` (`_dKey` du nom) et `_estBooste` exige id ET cle. La
  remplacante garde l id de l emplacement (`se3`...) mais n est jamais
  boostee, et le boost est perdu pour la journee. Ancien cache sans `k` :
  la quete en place au premier appel fait foi, et `_secPartir` fige la cle
  avant tout remplacement.
- La carte de dessous n affiche ni ruban, ni texte « taux d echec eleve »,
  ni gains x4 : seule la carte de devant peut etre boostee.

Verifie (`design/secondaires/test_boost.js`) : boostee swipable, x4 et
ruban devant, +3 XP dessous ; apres swipe, remplacante a +3 XP sans ruban,
swipe compte ; swipe d une carte normale sans boost ; ancien cache sans cle,
meme resultat. `test_glitch.js` et `test_app.js` toujours bons.

Fichiers : `www/index.html` (et sa copie Android),
`design/secondaires/test_boost.js`, `LISEZMOI.md`.

## Jour de quete imposee : 0 swipe ; Insights refait en sobre (17 novembre 2026, soir)

### 0 swipe le jour d une quete imposee
Decision de Thibs : la quete imposee reste non swipable, et le jour ou elle
revient, AUCUNE secondaire ne se swipe. `_secJourImpose()` (une secondaire
du jour porte `_imposee`) met `_secRestants()` a 0. Le compteur n affiche
plus jamais un swipe impossible : s il n y a aucune carte swipable (quete
imposee, quetes deja traitees...), il affiche « 0 swipe » (avant : « Plus de
swipe »). Les autres cartes portent `data-bloque="jourimpose"` : elles
resistent au doigt avec le message « Une quete revient imposee aujourd hui :
pas de swipe. ». Ni carte de dessous, ni astuce ce jour-la. L ancienne
raison `boost` de `data-bloque` est retiree (le boost se swipe depuis
18 h 45). Verifie : `design/secondaires/test_impose.js`, plus les trois
autres tests.

### Insights, version sobre
Demande de Thibs : trop aguicheur, « putaclic », trop « IA ». Refait dans le
langage du reste de l app : cartes blanches epaisses (filet de 1,5 px,
relief plein, coins de 20 px), Sora, bleu des Stats (#0B7CFF, #0656B8,
#E6F1FF) en accent, bordeaux du logo pour les boutons d action, plus aucun
dore, plus d italique ni d emoji decoratif. Toute l analyse est conservee.

- Nouvelle feuille `www/insights.css`, liee juste avant `</head>` (retirer
  la ligne rend l onglet comme avant), bornee a `#st-insights`.
- `_dCarte`, `_tCarte` et `_proTeaser` produisent des classes (`ins-carte`,
  `ins-tag`, `ins-titre`, `ins-visuel`, `ins-sens`, `ins-alerte`) au lieu de
  styles en ligne. « Ce que ca veut dire » devient un encart gris a part.
  Une alerte : filet rouge en haut de carte et etiquette rouge.
- Profil et auto-maitrise : le bandeau brun et son emoji deviennent un bloc
  clair `ins-resultat`. Description du profil sans italique.
- Palette remplacee dans le code des Insights seulement (de `_tCarte` a
  `_proPlugin`, `_proAccroche` a `_hebdoSemaineClose`, `_hebdoBande` a
  `stTab`, `_nrjMajTexte` a `renderStats`, et le HTML du volet) : dore vers
  bleu, gris chauds vers gris neutres, vert et rouge alignes sur le theme.
  L ecran Abonnement n est pas touche.
- Emojis retires : etoile des etiquettes, eclair de l analyse, horloge de la
  Time Capsule, sablier, etincelles « Redigee par l IA », cheval de
  l auto-maitrise, cadenas emoji de la puce Pro (« Pro » seul) ; le cadenas
  dore du bandeau Pro devient un cadenas blanc sur bleu.
- Periodes et calcul : controle segmente (gris, choix actif blanc a filet
  bleu). Correlation energie : barres nettes, sans illustration de flamme.

Verifie (Chromium, 140 jours simules, `design/insights/test_captures.js`) :
avec et sans Pro, a 360 et 393 px, test d auto-maitrise fait, « Voir quand
meme » actif : aucune erreur, aucun debordement visible. Piege de capture :
l ecran de titre debloque pose un voile dore `.flash` sur tout l ecran,
a masquer avant de juger les couleurs.

Fichiers : `www/index.html`, `www/insights.css` (nouveau, et leur copie
Android), `design/secondaires/test_impose.js`, `design/insights/`,
`LISEZMOI.md`.

## Titre legendaire « Souverain Absolu » refait (17 novembre 2026, 23 h)

Signale par Thibs : equipe dans #Quetes, le titre ne s anime pas. Cause
probable, mesuree en Chromium : sur le telephone de Thibs,
`prefers-reduced-motion` est actif (economie de batterie, constate le
10 octobre), et la regle globale coupe toutes les animations CSS. Il ne
reste alors que le canevas de l en-tete. Celui du Souverain etait invisible
sur le fond clair : jaune pale a 5 a 24 % d opacite, et sa couronne cachee
derriere la pastille de rang. Les autres legendaires ont un canevas qui se
voit (Inarretable, ses trainees), d ou l impression que seul celui-ci etait
fige. Meme sans mouvement reduit, son retournement de lettres ne durait
qu un instant toutes les 5,6 s, et son degrade jaune clair se lisait mal.

Refonte, « le sacre » :
- Canevas (tourne aussi sous mouvement reduit) : halo d or qui respire
  derriere le titre, rayons de gloire qui tournent lentement, onde du sacre
  toutes les 4,2 s (anneau d or qui s evase avec une gerbe d etincelles),
  poussiere d or qui monte, eclats a quatre branches qui scintillent autour
  du titre. Or sature et opaque, lisible sur le fond clair.
- Lettres (`_chSacre`, remplace `_chCrown`) : un frisson d or part du centre
  vers les bords, puis une vague souleve chaque lettre avec un eclat, et le
  mot se repose. Cycle de 4,2 s, decalage par distance au centre (`--a`).
- Degrade or profond (#8C5A06 a #F0BA3A). Dans l en-tete, sans le reflet
  blanc : les lettres decoupees portent chacune un morceau FIXE du degrade,
  et le reflet restait fige sur le « i », qui paraissait efface. `.eq-title`
  garde son reflet anime.

Verifie (Chromium 393 px, avec et sans mouvement reduit,
`design/test_titre_legendaire.js`) : canevas en fil de travail, 15 lettres,
animation `_chSacre`, aucune erreur ; captures image par image.
Apercu : `souverain-absolu.gif` (livre a part).

A trancher par Thibs : sous mouvement reduit, la choregraphie des lettres
de TOUS les titres est coupee par la regle globale. Les emblemes de guilde
ont ete rendus « toujours animes » le 11 octobre ; les titres pourraient
suivre (exception a la regle pour `#title-text.tch .tl`).

Fichiers : `www/index.html` (et sa copie Android),
`design/test_titre_legendaire.js`, `LISEZMOI.md`.

## Maquette des titres, a revoir avant d installer (17 novembre 2026, 22 h 30)

Demande de Thibs : voir les animations des titres sur son telephone sans
reinstaller l APK. Page claude.ai « Metanoia · Titres »
(slug `eebff9b3-56df-4ce5-8eef-72e2d32628fc`, privee), publiee depuis
`design/titres/maquette/`.

Fidelite : la page est FABRIQUEE depuis le vrai code par
`design/titres/generer.py`, jamais retouchee a la main. Il prend dans
`www/index.html` l en-tete de #Quetes tel quel (gestes retires), les regles
CSS qui peuvent le toucher (filtrees par selecteur : en-tete, pastille,
titre, lettres, XP, `:root`, base ; les autres visent des elements absents),
leurs `@keyframes`, et 21 morceaux de code extraits par equilibrage
d accolades : listes de titres, `_getTitleRarity`, `_TITLE_FX`, les deux
`_*FxSlug`, `_applyTitleCosmetics`, le fil de dessin `_fx*`, la decoupe
`_titleSplit*`. `fonts.css`, `theme.css` et `fonts/` sont copies. Gabarit de
la page (selecteur, interrupteur) : `design/titres/gabarit.html`.

Interrupteur « Economie de batterie » : les regles des blocs
`prefers-reduced-motion` de l app sont recopiees sous `html.rm`. La page dit
aussi si le telephone demande deja moins d animations ; dans ce cas
l interrupteur ne peut pas les rallumer, et c est exactement l etat de l app.
Piege evite : apres `_titleUnsplit`, `_titleCosmetiquesIntactes` repond
« intact » ; la page efface `hdr.dataset.fxNom` avant chaque choix.

Verifie : pour les 18 titres (5 legendaires, 10 epiques, 3 de la Boutique),
classe, animation des lettres, duree et police identiques entre l app et la
maquette ; interrupteur : animation coupee puis rendue ; aucune erreur.

Mise a jour apres une retouche des titres dans l app :
`python3 design/titres/generer.py`, puis republier les fichiers de
`design/titres/maquette/` sur le meme slug.

Fichiers : `design/titres/` (nouveau), `LISEZMOI.md`. `www/` inchange.

## Titres « Ce qui Demeure » et « Autodidacte » refaits (17 novembre 2026, 23 h 30)

Demande de Thibs : du spectaculaire comme le Souverain Absolu. Pour Ce qui
Demeure, des rochers, du brut, que ca tremble ; pour Autodidacte, plus de
fond « moche » ni de billes, quelque chose en lien avec le titre.

Seul le CANEVAS change (il tourne aussi en economie de batterie), plus le
degrade des lettres, assombri pour rester lisible sur le fond clair. Les
choregraphies de lettres (`_chRocJump` + `_chQuake`, `_chAsh`) sont
gardees, elles collaient deja au theme.

Ce qui Demeure, « l eboulement » (cycle 4,8 s) : une strate rocheuse au pied
de l en-tete ; quatre blocs (dont un gros) annonces par leur ombre, qui
tombent en accelerant avec des trainees, s ecrasent, rebondissent, fendent
le sol (fissures qui s etendent puis s effacent), projettent des eclats et
un nuage de poussiere, avec une onde de choc au sol et tout le dessin qui
tremble a chaque impact. Les blocs restent poses puis s effritent avant le
cycle suivant. Degrade : pierre sombre #4A3726 a #B08C5E.

Autodidacte, « le grimoire » (cycle 5,6 s, celui de `_chAsh`) : un livre
ouvert derriere le titre (dos creuse, coins releves, tranche), une page qui
tourne, une ligne d encre qui s ecrit seule ; douze signes du savoir
(∑ ∫ π √ ∞ λ Δ φ α Ω ∂ θ ℵ ?) apparaissent autour du mot puis sont aspires
dedans avec une trainee d encre ; quand les lettres renaissent, eclat de
lumiere, rayons et anneau. Plus aucune bille. Degrade : le lilas pale du
milieu (#c4b0ff) passe a #9d7bf0.

Les deux dessins sont SANS ETAT : chaque cycle est tire de son numero
(`R(s)`), le rendu ne depend que de t, donc identique dans le fil de
travail et sur le fil principal.

Verifie : `node --check` des quatre blocs, captures image par image dans la
maquette, aucune erreur ; maquette regeneree (`design/titres/generer.py`)
et republiee sur le meme slug.

Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

## Titres « Inarretable » et « L Arme Parfaite » refaits, sol de « Ce qui Demeure » (17 novembre 2026, 23 h 45)

Meme principe que les precedents : seul le canevas change (il tourne aussi
en economie de batterie), dessin SANS ETAT tire du numero de cycle, degrade
des lettres assombri pour rester lisible. Choregraphies de lettres gardees.

Inarretable, « la charge » (cycle 3,4 s, `_chSprint`) : lignes de vitesse
permanentes ; trois murs de pierre maconnee se dressent en travers de
l en-tete, tremblent quand la comete approche ; une comete de feu (tete
incandescente, queue effilee, langues de flamme, etincelles en trainees)
part de la gauche et les traverse sans ralentir, chaque mur eclate en
morceaux bordes de braise ; sillage de chaleur apres le passage. Degrade :
le milieu jaune pale (#ffd08a) passe a #F29A3C.

L Arme Parfaite, « la frappe parfaite » (cycle 4,4 s, `_chLock`) : regles
graduees en haut et en bas avec curseurs dores ; un laser de mesure balaie
le titre pendant qu une lecture « ±4,750 » converge vers « ±0,000 » ;
quatre crochets de visee se referment, cercle pointille qui tourne, eclair
blanc et « VERROUILLE » ; puis une lame tranche l en-tete en diagonale
(coeur blanc, halo acier), gerbe d etincelles, flash. La coupure s efface en
0,5 s, sans laisser de bande terne. Degrade : acier #2E6F82 a #B8862F.

Ce qui Demeure, retour de Thibs (les fissures « faisaient SVG ») : les
fissures sont des fentes EFFILEES (larges a l impact, en pointe au bout),
avec une levre claire dessous et des ramifications qui plongent dans la
roche ; la strate a un bord eclaire irregulier et des galets enchasses ;
les eclats projetes sont des triangles irreguliers au lieu de carres.

Verifie : `node --check`, captures image par image dans la maquette, 18
titres sans erreur ; maquette regeneree et republiee sur le meme slug.

Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

## Inarretable : le sommet ; Souverain sans anneau (17 novembre 2026, 23 h 55)

Retours de Thibs : l anneau qui s evasait dans le Souverain Absolu ne va
pas avec la DA du titre, il est RETIRE (section « onde du sacre » du
canevas, anneau et gerbe d etincelles). L Arme Parfaite est validee.
Inarretable « la charge » (murs et comete) ne faisait pas assez stylé : il
est remplace.

Inarretable, « le sommet » (cycle 6,8 s, deux sprints des lettres) : une
chaine lointaine sur toute la largeur ; une grande montagne enneigee derriere
la fin du titre (face eclairee, versant a l ombre, arete doree par le
soleil) ; un grimpeur (silhouette avec sac rouge) gravit l arete en penchant
en avant, atteint le sommet, plante son drapeau orange qui se deploie au
vent, puis le brandit bras leve ; eclat de lumiere au moment ou il plante,
lever de soleil et rayons derriere le sommet qui s intensifient ; nuages qui
passent au pied, neige soufflee depuis la crete. Les hauteurs sont ramenees
sous le bord (`Y()`) pour que le drapeau reste toujours visible.

Verifie : `node --check`, captures image par image, 18 titres sans erreur
dans la maquette, regeneree et republiee sur le meme slug.

Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

## Ce qui Demeure : « apres la bataille » (17 novembre 2026, 23 h 59)

Demande de Thibs : changer de DA, plus de rochers qui tombent. Remplace
entierement « l eboulement » (et ses fissures). Choregraphie des lettres
gardee (`_chRocJump` + `_chQuake`), degrade pierre garde.

Canevas, cycle de 9,6 s (deux bonds des lettres), sans etat :
- ciel de fin de combat, lueur rouge basse ; trois colonnes de fumee qui
  montent au loin ; collines ; corbeaux qui tournent ;
- au loin, sur une butte sous la fin du titre, un chevalier (heaume a
  panache rouge, bouclier a croix, epee plantee) titube, tombe a genoux en
  lachant son epee, puis s ecroule face contre terre, avec un nuage de
  poussiere. Sa banniere rouge, plantee pres de lui, reste debout et
  continue de flotter : ce qui demeure. Il reapparait debout au cycle
  suivant (fondu) ;
- premier plan, champ de bataille termine : bannieres dechirees (bleue et
  rouge) qui flottent, epees plantees, lances inclinees, un bouclier couche
  et un heaume au sol, flammeches qui montent.
La pose est parametree (`k1` genoux, `k2` chute qui pivote sur le genou),
echelle 1,18 pour qu il reste lointain et ne couvre pas le titre.

Verifie : `node --check`, captures sur un cycle complet (debout, a genoux,
au sol, retour), 18 titres sans erreur ; maquette regeneree et republiee.

Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

## L Arme Parfaite : un decor, « la cour d entrainement » (18 novembre 2026, 0 h 05)

Nouvelle regle de Thibs : un titre LEGENDAIRE se reconnait a son animation
ET a son decor de fond, comme Inarretable (la montagne) et Ce qui Demeure
(le champ de bataille). Restent a faire, plus tard : Autodidacte (a
ameliorer) et Souverain Absolu.

L Arme Parfaite garde le laser de mesure, la lecture qui converge, les
crochets de verrouillage et la lame qui traverse l en-tete. Les regles
graduees du haut et du bas sont retirees (elles chargeaient le decor).
Decor ajoute :
- aube : ciel bleu-acier vers or, soleil bas a droite, deux chaines de
  montagnes bleutees, bancs de brume qui glissent ;
- une palissade de pieux et le sol clair d une cour ; un ratelier d armes
  a gauche (epees, lance, hache) ;
- un escrimeur (bandeau dore au vent) en garde face a un poteau de paille :
  au moment ou la lame traverse l en-tete, il tranche le poteau d un geste
  (arc lumineux), un trait blanc et des brins jaillissent, le haut du poteau
  glisse le long de la coupe et tombe au sol ; le poteau se refait au cycle
  suivant (fondu).

Verifie : `node --check`, captures sur un cycle complet, 18 titres sans
erreur ; maquette regeneree et republiee.

Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

## Autodidacte : « le savant » ; canevas des titres net en haute densite (18 novembre 2026, 0 h 15)

Idee de Thibs : un homme face a nous, au centre, qui lit ; il retire le
livre et des instruments apparaissent et tournent autour de lui. Remplace
« le grimoire ». Choregraphie des lettres (`_chAsh`) gardee.

Canevas, cycle de 11,2 s, sans etat :
- une bibliotheque : deux rayonnages de livres (dos de couleurs sourdes,
  filets dores), une lueur chaude et violette derriere lui, poussiere
  doree dans la lumiere ;
- l homme en buste, face a nous, sous le titre : robe violette a col dore,
  chemise claire, cou et visage modeles, oreilles, cheveux bruns, barbe
  courte, sourcils, nez, bouche. Il lit, paupieres baissees, un livre de
  cuir a ornements dores tenu devant le bas du visage ; il l abaisse et le
  referme, ouvre les yeux, qui s allument en violet ; souffle de lumiere ;
- huit instruments apparaissent un a un (scintillement) et tournent autour
  de lui en orbite, devant et derriere (profondeur, taille, halo, trainee) :
  astrolabe aux cercles qui tournent, lunette a trois tubes, compas a
  pointes qui s ouvre, sablier dont le sable coule puis se retourne, globe
  aux continents qui defilent, plume, engrenage qui tourne, fiole au liquide
  violet qui bouillonne ; ils se resserrent vers lui et disparaissent quand
  il reprend sa lecture.
Limite connue : la ligne « 0 XP » de l en-tete passe sur son visage (le
texte est au-dessus du canevas, et l en-tete n a pas d autre place au
centre).

Canevas haute densite, pour TOUS les titres : il etait a la taille CSS de
l en-tete, donc flou sur telephone (densite 2,6 a 3). `_FXV.d` = densite de
l ecran plafonnee a 2 ; le fil de travail (`D`) et le fil principal
dimensionnent le canevas en pixels physiques et posent
`setTransform(d,0,0,d,0,0)` avant chaque dessin, qui reste ecrit en pixels
CSS (`w`, `h` inchanges). Verifie sur les deux chemins (fil de travail et
fil principal sans OffscreenCanvas) : 722 x 176 pour un en-tete de 361 x 88.

Menage : `mq3.png`, une capture de test egaree a la racine du depot depuis
la maquette des titres, est supprimee ; le test ecrit desormais dans /tmp.

Verifie : `node --check`, captures a densite 3 sur un cycle complet,
18 titres sans erreur ; maquette regeneree et republiee.

Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `design/titres/test_maquette.js`,
`LISEZMOI.md` ; `mq3.png` supprime.

## Souverain Absolu : « le duel et le trone » (18 novembre 2026, 0 h 05 ; l heure « 0 h 45 » notee d abord etait fausse)

Demande de Thibs : un combat entre deux personnes, le heros court sur
l autre, le tue, puis monte sur son trone ; realiste, beau, spectaculaire,
symbolique, avec de l aura. Remplace « le sacre » (halo, rayons, poussiere).
Choregraphie des lettres (`_chSacre`) et degrade or gardes.

Canevas, cycle de 12 s, sans etat (l ancien utilisait `this._m`, retire) :
- decor (allege le 18 novembre, voir plus bas) : salle du trone, grande
  verriere en ogive derriere le trone (vitraux en losanges, rosace),
  faisceaux de lumiere, deux bannieres bordeaux a couronne d or, dallage
  en perspective, tapis rouge jusqu a l estrade de trois marches ;
- trone vu de face a `TX=.715w` : dossier en ogive dore, velours, montants
  a fleurons, accoudoirs, coussin ;
- personnages de profil (`perso`) : squelette a angles (hanche, buste,
  cuisses, tibias, bras, avant-bras, epee), membres effiles (`seg`),
  cuirasse, tassettes, ceinture, cape qui flotte selon la vitesse, ombre au
  sol. Heros en armure doree et cape bordeaux, tete nue (cheveux, barbe) ;
  chevalier noir a heaume cornu et fente rouge ;
- ph 0 a .14 : le heros charge, le chevalier noir arme son coup ;
  .15 : parade haute, gerbe d etincelles ; .20 : parade basse, etincelles ;
  .25 : le heros arme et frappe un revers, trainee doree courte et eclair ;
  le chevalier recule, son epee lui echappe, il tombe a genoux puis a la
  renverse (pivot sur le genou) et se dissout en cendres ;
- .375 a .44 : le heros leve son epee, rayon de lumiere sur la lame ;
- .45 a .685 : il remonte le tapis et gravit les marches ;
- .67 a .73 : il se tourne vers nous (pincement horizontal) et s assoit,
  vu de face : surcot bordeaux, epee plantee entre les pieds, mains sur
  le pommeau ;
- .715 a .95 : le sacre : la verriere s illumine, aura et 16 rayons
  derriere lui, une couronne descend et se pose sur sa tete (eclat), ses
  yeux brillent un instant, reflet qui parcourt la lame, poussiere d or ;
- fondu de tous les personnages en fin de cycle.
Pas d anneau qui s elargit (demande du 17 novembre).
Limite connue : le dossier du trone et la verriere passent derriere la fin
du titre (« lu ») ; le duel passe sous la barre d XP et « 0 XP ».

Verifie : `node --check`, lxml, 0 tiret long ; images a 0 / 1 / 2,2 /
3,1 / 3,3 / 4 / 4,8 / 6 / 7,6 a 9,7 / 11,6 / 11,9 s ; fil de travail
en mouvement reduit (mode `w`) sans erreur ; maquette regeneree,
18 titres sans erreur, republiee.

Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

### Souverain Absolu : decor allege et brume (18 novembre 2026, 0 h 15)

Demande de Thibs : garder toute l animation (combat, marche, trone), mais
alleger le decor, le rendre secondaire et un peu mysterieux.
- le dallage quadrille est retire : sol en degrade doux, reflet de lumiere
  de la verriere sous le trone ; le tapis rouge apparait en fondu, sans
  filets dores ;
- sept colonnes fines remplacees par trois grosses (`.07`, `.40`, `.95` de
  la largeur) dont le haut s efface ; voutes retirees ; mur plus clair ;
- brume : un voile laiteux sur tout le decor (pose apres le trone, avant
  les personnages, qui restent nets) et sept nappes qui derivent lentement
  au sol et a mi-hauteur.
Personnages, choregraphie et sacre inchanges.
Verifie : `node --check`, lxml, 0 tiret long, fil de travail en mouvement
reduit sans erreur, maquette regeneree et republiee.
Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

### Chutes realistes des antagonistes (18 novembre 2026, 0 h 20)

Retour de Thibs : en tombant, les antagonistes de Souverain Absolu et de
Ce qui Demeure gardaient un pied en l air a 90 degres.
Cause commune : on faisait tourner tout le corps agenouille autour du
genou ; le tibia, pose a plat au sol, tournait avec lui et pointait vers
le ciel.
- Souverain Absolu : plus de rotation (`chute=0`). La pose a genoux
  s interpole (ph .338 a .385) vers une vraie pose couchee sur le dos :
  buste a l horizontale (-1,57), hanche au ras du sol, une jambe tendue et
  le genou un peu releve, l autre repliee a plat, bras etendus. Le heaume
  (et sa corne) suit l inclinaison du buste.
- Ce qui Demeure : la chute en avant autour du genou est gardee, mais les
  deux tibias tournent a l inverse (`pied`, angle -k2*1,42) : les pieds
  restent a plat derriere lui et il finit allonge face contre terre.
Verifie : images de chaque chute, `node --check`, lxml, 0 tiret long,
fil de travail en mouvement reduit sans erreur, maquette republiee.
Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

### Legendaires : pause de 10 s sur la scene finale (18 novembre 2026, 0 h 30)

Demande de Thibs : que les titres ne relancent pas leur boucle trop vite ;
rester environ 10 s sur la scene finale.
Mecanisme, identique pour les cinq : `A` = phase de la scene finale,
`tc=t%(P+10)` ; `ph` avance normalement jusqu a `A`, reste fige a `A`
pendant 10 s, puis joue la fin (fondu) et la boucle repart. Tout ce qui
depend de `t` (vent, drapeaux, nuages, brume, aura, orbite des
instruments, poussiere) continue de bouger pendant la pause.

| Titre | Cycle avant | `A` | Scene tenue | Cycle apres |
|---|---|---|---|---|
| Inarretable | 6,8 s | .90 | grimpeur au sommet, drapeau plante, soleil leve | 16,8 s |
| Ce qui Demeure | 9,6 s | .86 | chevalier tombe, banniere debout | 19,6 s |
| Souverain Absolu | 12 s | .90 | roi couronne sur son trone, aura | 22 s |
| L Arme Parfaite | 4,4 s | .73 | apres le coup : poteau tranche, haut tombe | 14,4 s |
| Autodidacte | 11,2 s | .70 | livre baisse, yeux allumes, instruments en orbite | 21,2 s |

Souverain Absolu : `cyc` (graine des cendres) suit la nouvelle periode.
Les choregraphies de lettres (CSS) gardent leur propre rythme.
Verifie : images avant, pendant et apres la pause pour les cinq titres,
`node --check`, lxml, 0 tiret long, fil de travail en mouvement reduit
sans erreur, maquette regeneree et republiee.
Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

### Barre d XP lisible ; Ce qui Demeure recadre, volee de fleches (18 novembre 2026, 18 h 40)

Retour de Thibs (captures sur telephone) : sur tous les legendaires sauf
Inarretable, la barre d XP et ses infos se lisent mal sur le decor.
Consigne : ne rien changer aux animations ni a la structure des titres.
- CSS seul, borne a `.hdr.has-legendary:not([data-fx-nom="Inarrêtable"])` :
  piste de la barre sur fond creme a 62 % avec un liseré creme et une
  ombre legere ; ligne d infos (`.xp-row`) sur une petite plaque creme
  (80 %, flou 3 px) a la largeur du texte, texte plus fonce. Aucun
  `::before`/`::after` : la Bordure Doree et l Aura de Feu de la boutique
  les utilisent deja sur `.xp-wrap`.
- Ce qui Demeure : tout le paysage (fumees, collines, chevalier, premier
  plan, braises) descend de 9 % de la hauteur (`ctx.translate(0,h*.09)`) ;
  le ciel couvre toute la hauteur. Le bas du premier plan est un peu rogne.
- Ce qui Demeure : 8 fleches arrivent de la gauche (ph .08 a .255, avant la
  chute du chevalier), se plantent dans le sol en vibrant, soulevent un peu
  de poussiere et restent plantees pendant la pause de 10 s ; fondu avec
  la scene a ph .95.
Verifie : captures des cinq titres dans l app, vol et impact des fleches,
`node --check`, lxml, 0 tiret long ; maquette regeneree, republiee.
Fichiers : `www/index.html` (et sa copie Android),
`design/titres/maquette/index.html`, `LISEZMOI.md`.

## Boutique : moins de vide sous les cartes (18 novembre 2026, 18 h 50)

Retour de Thibs : trop d espace entre le bas des cartes du Marche et la
barre de navigation. Cause : le conteneur de `#s-rewards` avait 100 px de
marge interne en bas, en plus des 83 px de `.screen` (qui degagent deja
la barre de navigation). Passe a 8 px (`padding:14px 16px 8px`).
Vaut pour les trois onglets (Marche, Permanent, A venir) : mesure au
defilement maximal, le bas du contenu reste au-dessus de la barre
(Marche 785, Permanent 750, A venir 729 pour une barre vers 785).
Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`.

## Sanctions evolutives et personnalisees : MAQUETTE, non integree (20 novembre 2026)

Idee de Thibs : que le volume et la difficulte des sanctions montent avec
le temps (ne pas tomber sur 156 pompes des la fin de la periode sans
sanction) et s adaptent au questionnaire, sans devenir trop faciles.
Rien n est change dans l app : `buildSanction` est intact.

Maquette interactive : `design/sanctions/maquette.html`, publiee sur
claude.ai (slug `869d36bc-2970-4073-aaf4-50289c45e77a`, privee,
https://claude.ai/artifact/Hd7r7qzam1WApoMoHNc2gy). Elle reprend
`calcScore`/`calcProg` du questionnaire et le calcul actuel de
`buildSanction` pour comparer.

Regles proposees (a valider par Thibs) :
- 5 paliers par jour de jeu : Initiation 15-24 (x .35), Apprentissage
  25-39 (x .5), Rodage 40-59 (x .65), Exigence 60-89 (x .8), Plein regime
  90+ (x 1). Remplace le x .5 / x 1 actuel (bascule au jour 30).
- UNE SEULE sanction, comme aujourd hui (decision de Thibs le 20 novembre,
  la premiere version en donnait une par quete ratee : trop laborieux) :
  1 obligatoire ratee -> sanction de son domaine (body -> physique,
  mind -> intellectuelle, discipline -> ciblee sur la premiere resistance
  declaree, ordre : reseaux, lever, concentration, junk food, alcool,
  sortir, engagements, pornographie ; aucune -> mode avion) ;
  plus d une -> sanction physique.
- Cumul sur la sanction physique : x 1,6 si 2 ratees, x 2,2 si 3 (actuel :
  x 2 et x 4). Jours rates d affilee : + 15 % par jour, plafond + 30 %.
- Paliers valides par Thibs le 20 novembre.
- Personnalisation, bornee entre 70 et 120 % : sportLevel (1,15 / 1 / .75),
  age (30+ : .9), sommeil < 6 h (.9) pour le physique ; mindLevel
  (1,1 / 1 / .75) pour le mental ; temps d ecran (<=2 h 1,1 ; 3-4 h 1 ;
  5-6 h .85 ; 7 h+ .7) pour les sanctions d ecran ; programme Foundation
  .85, Standard 1, Discipline 1,15 pour tout.
- Exercice : masse -> pompes, secher -> burpees, endurance -> course si
  dehors possible (sinon burpees), bouger plus -> squats ; course seule
  cochee -> course. Etudiant -> revision, sinon lecture.
- Planchers et plafonds par sanction (ex. pompes 15 a 150, lecture 10 a
  80 pages, reseaux 4 a 16 h) : ca reste une sanction.
Exemples (profil de la maquette) : jour 16, 3 obligatoires ratees, sport
irregulier : 35 pompes au lieu de 60 a 100. Jour 100, sportif regulier :
101 pompes au lieu de 120 a 200. Jour 20, mind seule ratee : 24 min de
revision. Jour 50, discipline seule ratee : 6 h sans reseaux.
Le panneau « Pourquoi ce dosage » et les reglages sont un outil de
maquette : le joueur ne les voit pas, il ne voit que l ecran de sanction.

Fichiers : `design/sanctions/maquette.html` (nouveau), `LISEZMOI.md`.

## Bug : l evenement du jour disparait apres « Comment te sens-tu ? » (21 novembre 2026)

Note de Thibs : il repond au bloc « Comment te sens-tu ? » a 5 h 56 (son
creneau commence a 7 h) ; a la fin du message, le bloc Evenement du jour
(Double XP) disparait aussi. Son hypothese (reponse hors creneau) etait
juste. Reproduit dans l app.
Cause : l ecran principal etait reste affiche depuis la veille, dans le
creneau. A 5 h 56, le creneau est ferme, mais rien ne redessinait l ecran :
le retour au premier plan par `appStateChange` (Capacitor) ne faisait
qu un `_reveillerAffichage`, sans `renderMain` ; et la minuterie de 60 s
ne redessinait pas au changement de creneau. La reponse appelait
`renderMain`, qui appliquait enfin la regle « evenements seulement pendant
le creneau » (`getTodayEvent` renvoie null hors creneau) : l evenement
disparaissait. Il revient a l ouverture du creneau.
Corrections :
- minuterie de 60 s : redessine l ecran principal quand `isOpen()` change
  (`window._creneauVu`) ;
- `appStateChange` actif : `renderMain` si l ecran principal est affiche ;
- `morningCheck` refuse hors creneau (redessin, aucune recompense).
Verifie (horloge simulee) : ecran ouvert a 22 h 30, retour a 5 h 56 ->
au tic suivant, check-in et evenement masques ensemble ; a 7 h, les deux
reviennent ; ouverture directe a 5 h 56 : rien d affiche.
Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`.

## Ecran principal : espace donjon -> quetes resserre, outils sur la ligne Obligatoires (21 novembre 2026)

Retour de Thibs : trop d espace entre le bloc donjon et les quetes.
Trois variantes montrees en images, rendues dans l app (A : lettre gardee
sous le donjon, B : outils au bout de la ligne « Obligatoires »,
C : bandeau). Choix final de Thibs : B, avec un fond plus vif.
Cause de l espace : la barre d outils (`#hdr-tools-bar`, 48 px avec la
lettre), la phrase d ambiance vide (`#narrative-text`, `min-height` 18 px
plus marges) et 22 px de marge au-dessus de « Obligatoires ».
- `#narrative-text`, `#projection-zone`, `#progression-card` vides :
  `display:none`. `.slbl.slbl-nn` : `margin-top:14px`.
- `_refreshToolsBar` remplit desormais `#nn-outils`, un `span` ajoute au
  bout de `.slbl-nn` ; classe `a-outils` sur la ligne quand il y a un outil
  (grille `auto 1fr auto`, le trait passe avant les outils par `order`).
  `#hdr-tools-bar` reste dans le DOM, vide et cache.
- Couleur propre a chaque outil, tuiles de 32 px : Lettre au futur
  (`.tool-lettre`) degrade orange vif `#F08A4B -> #D2552B` ; Vision d elite
  (`.tool-vision`) violet `#8B6CF0 -> #5636C4`. Un nouvel outil devra avoir
  sa classe et sa couleur.
Ecart bas du donjon -> premiere quete : 123 px avant ; 51 px sans outil,
73 px avec un ou deux outils. Clic sur la lettre : ouvre bien `s-letter`.
Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`.

## Parametres : vide du bas retire ; Metanoia Pro : 5 swipes (21 novembre 2026)

- Parametres : `#s-settings` sans marge basse de `.screen` (pas de barre de
  navigation sur cet ecran) et `.set-wrap` a 14 px + zone de geste en bas.
  « METANOIA » finit a 14 px du bas de l ecran au defilement maximal.
- Metanoia Pro, demande de Thibs : « jusqu'à 5 swipes disponibles » pour les
  quetes secondaires. `_secQuota()` renvoie 5 si `estPro()`, sinon 1, ou 2
  avec une integrite de 80 ou plus (inchange). Le tirage et le taux
  d apparition des secondaires ne changent pas ; chaque swipe tire sa
  remplacante comme avant. Jour de quete imposee : toujours 0 swipe.
- Nouveau garde-fou : une quete ecartee aujourd hui ne revient pas le meme
  jour (`ST._secEcartees` {day, k}) ; sans lui, 5 swipes pouvaient ramener
  la meme quete et lui compter 3 fuites en une journee.
- Ecran du plan Pro : atout ajoute a `_PRO_ATOUTS`, « Jusqu'à 5 swipes
  disponibles », detail « Pour les quêtes secondaires : plus de choix chaque
  jour où elles apparaissent. »
Verifie : `design/secondaires/test_pro.js` (std, integrite 90 : 2 swipes ;
Pro : 5 swipes, le 6e refuse, compteur 5 -> 0, aucune quete revue dans la
journee), capture de l ecran Pro, mesure des Parametres.
Fichiers : `www/index.html` (et sa copie Android),
`design/secondaires/test_pro.js` (nouveau), `LISEZMOI.md`.

## Constellation des traits : maquettes de refonte (21 novembre 2026, non integrees)

Demande de Thibs : « une réelle constellation d'étoiles cohérente, jolie et
impressionnante », pro, dans le style de l app, carte blanche.
Premiere piste (abandonnee pour cette approche) : habillages CSS de la
constellation actuelle (nuit, aube, rosace + rayons, ombre retiree).
Maquettes : `design/constellation/modeles.js`, injecte dans l app reelle
par `design/constellation/capturer.js` (lit les vrais TRAITS et
ST.earnedFragments ; chaque trait reste cliquable et ouvre le vrai panneau
des fragments via `_idSelectTrait`). Chaque trait = 3 etoiles (ses 3
fragments) : etoile allumee = fragment obtenu, lien plein entre deux
etoiles allumees, eclat a 4 branches et halo quand le trait est complet.
1. Ciel de nuit : 10 asterismes en couronne sur un ciel bordeaux, voie
   lactee, noms en petites capitales, compte au centre.
2. Carte celeste : meme disposition sur fond creme, cercles gradues et
   graduations d astrolabe, encre bordeaux et etoiles or.
3. Le Chasseur : une seule grande constellation, la silhouette du joueur
   (capuche = Esprit Éveillé, regard = Focus Profond, epaules = Corps
   Dominant, coeur = Résilience, bras = Corps Engagé / Discipline Brute,
   ceinture = Rigueur, robe = Équilibre, socle = Fondation, baton =
   Momentum) ; squelette en pointilles, chaque trait complet s allume.
Rien n est change dans `www/` par ces maquettes.
A GARDER EN RESERVE (demande de Thibs, 21 novembre) : le modele « 1. Ciel
de nuit », au cas ou il change d avis. Pour le revoir : lancer le serveur
sur `www/` (port 8777) puis `node design/constellation/capturer.js` ; le
code est `ronde(NUIT,false)` dans `design/constellation/modeles.js`.

## Constellation des traits : la rosace, integree (21 novembre 2026)

Choix de Thibs : la rosace (version C des habillages), avec les rayons de
la version B rendus plus legers, et sans le halo sombre de la silhouette.
- `_TRAIT_COUL` (apres `TRAITS`) : une couleur par trait, dans l ordre des
  secteurs. Fondation #E0612F, Discipline Brute #E8A33A, Résilience
  #C9842E, Rigueur #2F8A47, Corps Engagé #2E7C86, Corps Dominant #4D5FB8,
  Esprit Éveillé #7A3E9E, Focus Profond #A8285A, Équilibre #C2413A,
  Momentum #D07A3C.
- `_idTraitNodes` : anneau (progression et anneau complet) dans la couleur
  du trait, disque ivoire, variable `--tc` sur le bouton.
- Bloc CSS « ROSACE DES TRAITS » (apres `.id-fragpanel`) : rosace en
  `conic-gradient` sur `.id-const::before`, tournee de -18 deg pour centrer
  chaque secteur sur son noeud, plombs de vitrail, opacite .3 ; rayons
  blancs legers sur `.id-aura` (fond en ligne ecrase par `!important`),
  rotation de 60 s, coupee en mouvement reduit ; lueur claire au centre
  (`.id-const::after`) ; `.idmon-backlight` cache, ombre portee a .12 ;
  medaillons sans filtre sepia ; anneau de selection dans `--tc`.
- `_idFragPanelHtml` : medaillon en couleur (`_TRAIT_SVG`) dans une case
  teintee de la couleur du trait, barre et compteur dans cette couleur,
  liseré haut du panneau en `--tc`. Coches et badge « COMPLET » restent
  verts (sens de reussite).
Verifie : captures dans l app (6/10 sans selection, trait a 0/3
selectionne, 10/10 avec trait complet selectionne), mouvement reduit,
`node --check`, lxml, 0 tiret long.
Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`.

## Objets actifs sur la ligne Obligatoires ; rappel de l effet avant usage (21 novembre 2026)

Demandes de Thibs : afficher dans les « petits carres » (tuiles de
`#nn-outils`) les objets actifs (potion de double points, Conseil du
Sage...) ; dans le sac, rappeler l effet de l objet avant de confirmer
« Utiliser ».
- `_refreshToolsBar` : une tuile par objet actif, chacune sa couleur et le
  dessin de l objet (`_FULL_SVG_ITEMS`) : Élixir d expérience
  (`_shopXpBoostDay`, sarcelle), Potion de double points (`_shopDoublePts`,
  rose), Conseil du Sage (`_shopChooseSecondary`, or : RETIRE le meme jour, voir la section suivante), Talisman d Émotion
  (`_talismanDay`, bleu), Plume de Sagesse (`_plumeSerie`, ciel), Bouclier
  (`isShielded()`, acier). Un appui (`_outilInfo`) rappelle l effet en
  toast. `#nn-outils` passe a la ligne au-dela de 230 px.
- `_shopUseItem` : les objets du sac ne stockent pas leur description ; elle
  est reprise du catalogue (`_DAILY_POOL`, par `effect`) et affichee dans
  un encadre « Effet en appuyant sur Utiliser » de la confirmation.
  Vision d élite, Lettre du futur et Pierre de Renaissance n avaient aucune
  confirmation (classees a tort « interface propre ») : elles passent
  maintenant par ce rappel. Restent sans rappel les objets qui ouvrent leur
  propre ecran : Éclipse, Clé du Néant, Boîtes scellées.
Verifie : sac -> Utiliser sur la potion -> rappel « ×2 points pendant
24h » -> confirmation -> tuile rose sur la ligne ; appui -> toast ; 3 et 7
objets actifs.
Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`.

## Conseil du Sage et Éclipse : actions en attente avec pastille ; Éclipse sur les obligatoires (21 novembre 2026)

Retour de Thibs : Conseil du Sage utilise puis liste fermee sans choisir =
rien ne se passe et l objet est perdu. Avec le code actuel, l objet restait
dans le sac a la fermeture (verifie) ; la demande est de toute facon
satisfaite par le nouveau fonctionnement :
- a la confirmation « Utiliser », l objet est consomme et devient une
  action en attente (`ST._attente` {sage, eclipse}, helpers `_attente`,
  `_attenteAjout`). Tant que le choix n est pas fait, une tuile de sa
  couleur reste au bout de la ligne « Obligatoires » avec une pastille
  rouge du nombre d actions (`.tool-badge`, hors de la tuile, sans decaler
  les autres) ; un appui rouvre le choix. Fermer sans choisir ne perd rien.
  L attente ne s eteint pas au changement de jour.
- Éclipse : agit desormais sur les quetes OBLIGATOIRES (chemin des
  secondaires coupe dans `_openEclipseReroll`), passe par le rappel
  d effet, tuile indigo. Description du catalogue : « Remplace une quête
  obligatoire du jour par une autre du même domaine. »
- Bug trouve : `gBodyGym` n existe pas, l Éclipse echouait sur toute quete
  body (« Impossible de générer une nouvelle quête »). La remplacante est
  maintenant tiree d une semaine generee par `_genWeekRaw` pour ce joueur
  (meme domaine, nom absent du jour), l etat `ST` etant photographie puis
  restaure a l identique (cles et XP inchanges, verifie).
- Une quete obligatoire deja traitee ne peut plus etre remplacee (grisee
  dans la liste) : sinon un fail se rachetait.
- RETRACTATION : le 21 novembre (section precedente), la tuile « Conseil du
  Sage » annoncait « +50 % d'XP sur tes quêtes secondaires aujourd'hui ».
  C etait faux : `ST._shopChooseSecondary` n est ecrit nulle part, ce bonus
  (lignes de calcul d XP) est du code mort. La tuile fausse est retiree ;
  le bonus n a pas ete active (ce serait un changement d equilibrage).
Verifie (`/tmp`, scenario complet) : Sage -> rappel -> liste -> fermeture
-> sac vide, attente 1, tuile + pastille ; Éclipse idem ; appui tuile
Éclipse -> « Séance push » remplacee par « Séance au choix » (body) ;
appui tuile Sage -> choix -> attentes a 0, plus de tuile.
Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`.

## Quetes : message de validation retire ; donjon replie en haut, complet en bas (23 novembre 2026)

Demandes de Thibs :
- Message « Toutes les quêtes ont été validées. Bravo et à demain ! »
  retire (vue simplifiee `renderMainDone` et `_updateSimplifiedCd`).
- Donjon : en haut de l ecran, seulement la version repliee ; un appui fait
  defiler jusqu au bloc complet, desormais en bas, sous les quetes
  secondaires et juste avant le bilan (`#boss-zone-bas`, titre « Donjon »).
  `_renderDungeonCard(mode)` : 'haut' = replie, clic `_dngAllerBas` (fleche
  ▾), 'bas' = deplie, sans clic, sans fleche ; sans argument : ancien
  comportement (`_toggleDungeon`). `_dngZoneBas()` remplit la zone du bas,
  appelee apres chacun des trois rendus du haut. Le bas n existe que s il
  y a un donjon en cours (sinon la carte « Choisir un donjon » reste seule
  en haut).
Verifie : donjon lance, haut replie (clic -> `_dngAllerBas`), bas deplie
(579 px), appui -> defilement jusqu au bloc complet ; message absent.
Erreur faite puis corrigee AVANT livraison : l appel `_dngZoneBas()` insere
entre un `if` et son `else` cassait tout le script (detecte par
`node --check` et le test).
Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`.

### Donjon replie compact (23 novembre 2026, 12 h)

Question de Thibs : le bloc ferme n etait-il pas plus petit ? Non : mesure,
158 px avant comme apres (ligne du coffre + anneaux 69 px + bouton). A sa
demande, la ligne du coffre ne bouge pas ; en mode 'haut' seulement, la
rangee des conditions devient une ligne de pastilles (anneau 22 px au lieu
de 34, valeur et libelle a cote, ✓ / ✗ en texte) et le bouton de
reclamation passe a 7 px de marge interne. 158 -> 118 px (un objectif).
Le bloc complet du bas est inchange.
Fichiers : `www/index.html` (et sa copie Android), `LISEZMOI.md`.

## Quetes secondaires : tampon « Nouvelle quete » sur la bonne carte (23 novembre 2026)

Constat de Thibs : pendant le swipe, le tampon « Nouvelle quete » s affichait sur la carte qui part, ce qui n a pas de sens.

- Dans `_secBrancher`, le tampon est maintenant accroche a la carte de dessous (`.sec-dessous`), celle qui arrive, au lieu de la carte de devant.
- Position : `#ql-sec .sec-tampon` passe de `top:14px` a `top:-11px`. Il chevauche le bord haut de la carte comme le ruban « Boost », sans masquer l icone ni le titre.
- Son opacite suit toujours le geste ; au lacher valide, `_secPartir` le met a 1 sur la carte qui prend la place.
- Verifie en navigateur a mi-geste (capture) : tampon sur la carte revelee, aucune erreur, 4 blocs `node --check` OK, 0 tiret long.

## Autonomie et « Systeme » : synthese de la reflexion (23 novembre 2026), A TRANCHER PLUS TARD

Question de Thibs : l app impose une ligne de conduite (le Systeme), alors que la psychologie insiste sur l autonomie. Faut-il revoir l app ? Rien n est implemente, rien n est decide.

**Ce que dit la recherche**
- En theorie de l autodetermination, l autonomie = adherer a ce qu on fait, pas tout choisir soi-meme. Suivre le plan d un coach peut etre autonome si on en comprend le sens.
- Cadre et soutien a l autonomie sont complementaires, pas opposes (Jang, Reeve et Deci 2010 ; meta-analyse 2025, Educational Psychology Review).
- Se lier volontairement les mains est un acte autonome : « dispositif d engagement » (Bryan, Karlan et Nelson 2010). Ulysse attache au mat. Telecharger Metanoia, c est ca.
- Le vrai risque : l introjection (obeir par culpabilite, « je dois ») au lieu de l integration. Trois leviers contre (Deci et al. 1994) : donner une raison qui a du sens, reconnaitre ce que la personne ressent, laisser des choix.
- Les recompenses (XP) ne nuisent a la motivation que sur des taches deja tres interessantes (Deci, Koestner et Ryan 1999). Pour des pompes ou du temps sans ecran, ce n est pas le probleme ; la culpabilite et la menace, si.

**Ce que l app fait deja dans ce sens**
- Adhesion de depart : questionnaire et « Mon pourquoi ».
- Raison : etude affichee sous chaque quete.
- Emotions reconnues : « Comment te sens-tu ? ».
- Choix dans le cadre : swipes, Conseil du Sage, Eclipse, quetes personnelles, choix du creneau.

**Pistes proposees (a trancher)**
1. Pacte explicite signe a la fin du questionnaire (sanctions comprises), rappele a l ecran de sanction : « Tu as accepte ce pacte le jour 1. »
2. Ton des sanctions : une consequence prevue, pas une punition morale (« Le pacte s applique » plutot que « Tu as echoue »).
3. Choix encadres dans les obligatoires : deux variantes du meme domaine, le Systeme fixe le domaine et l exigence.
4. Autonomie progressive (piste la plus forte) : le Systeme rend des cles avec les rangs (plus de quetes perso, de choix, de reglages). Recit : « Le Systeme existe pour te rendre capable de te passer de lui. »
5. Verifier la solidite des chiffres cites sous les quetes : une raison fragile se retourne contre l app.

Phrase directrice proposee : le Systeme ne dicte pas ce que l utilisateur doit vouloir, il l aide a tenir ce qu il a choisi de vouloir.

## Marchands : histoires, repartition des objets, scenes animees (23 novembre 2026), INTEGRES DANS L APP le meme jour (voir la fin du document)

Maquette publiee : https://claude.ai/artifact/Jb4wfmk7qDJgb8Pf7z4TXh (slug `8e6d1339-02c1-4c16-8871-3fdac6f668e4`, version `1795440827-acbe` depuis le 23 novembre, 14 h 33). Les mentions « l app n est pas modifiee » de cette section et des revues qui suivent datent d avant l integration de 14 h 35.

Choix de Thibs : carte blanche sur les identites ; ton « francais actuel, saveur medievale » ; la Boite Scellee E chez aucun marchand, une boite (D a S) ou la Cle du Neant par marchand ; maquette d abord.

**Constat avant refonte** : la repartition `_MERCHANT_ITEMS` etait incoherente (Forgeron avec auras et titres, Sage avec le Portail Nocturne, effets `shield_1/3/5` inexistants dans `_DAILY_POOL`, textes citant des objets vendus par d autres).

**Les six marchands** (meme ordre de cycle, memes index 0 a 5) :

| # | Marchand | Histoire | Scene animee | Objets |
|---|---|---|---|---|
| 0 | Enguerrand le Forgeron | forgeron du comte de Montfaucon, survit a l incendie du chateau, jure de ne plus forger d arme qui tue | forteresse en ruine fumante, de jour (refaite le 23 novembre, voir plus bas) | Pierre de Renaissance, Aura de Feu, Aura de l Ombre, Boite A |
| 1 | Alienor l Alchimiste | Montpellier muree pendant la Grande Peste, sauvee du bucher par ceux qu elle a soignes | ville muree la nuit, sa tour, vapeurs ; bucher au loin, etabli a deux alambics, curieux derriere une charrette (23 novembre) | Elixir d experience, Potion de double points, Talisman d Emotion, Mystere Systemique, Boite C |
| 2 | Anselme l Ecrivain (ex-Frere Anselme l Enlumineur, 23 novembre) | ecrit et enlumine son livre pendant les dix ans du siege du Mont | le Mont fortifie au couchant, flotte qui s eloigne, navire qui coule, dauphins (23 novembre) | Bordure Doree, Sceau du Monarque, Plume de Sagesse, Titre temporaire Epique, Boite B |
| 3 | Melisende l Astrologue | etudie les astres en cachette a Chartres, predit l eclipse le jour de son proces | grenier ouvert en arche au-dessus de Chartres, nuit etoilee, constellations, comete en feu (23 novembre) | Vision d elite, Prediction, De du Destin, Eclipse, Boite S |
| 4 | Gaucher le Mercenaire | laisse pour mort a Crecy, se releve a l aube | aube a Crecy : cavalerie qui charge sous les volees de fleches, ville au loin a droite (23 novembre) | Pacte du Mercenaire, Portail Nocturne, Titre temporaire Legendaire, Cristal de focus, Boite D |
| 5 | Bertrand le Sage | seigneur qui renonce a tout, chandelle allumee quarante hivers au-dessus du col | chemin enneige vers le col au crepuscule, grotte et chandelle, loup qui hurle, lune qui se degage (23 novembre) | Conseil du Sage, Lettre du futur, Eclat du Veilleur, Reset Integrite, Cle du Neant |

Equite : 5 objets chacun (4 pour le Forgeron, qui a deux des objets les plus chers). Valeur totale au prix de base : 725 a 1 205 pts par marchand.

**Page marchand** : en-tete = scene canvas (236 px, environ 30 images/s, s arrete seule a la fermeture, image fixe si « reduire les animations ») avec la figure SVG posee devant ; label « Marchand itinerant » ; la carte « Specialite » est remplacee par « Ses marchandises » (liste lue dans `_MERCHANT_ITEMS` et `_DAILY_POOL`). Badge « Present au marche » eclairci pour le fond sombre.

**Figures SVG** : 1 (ex-Marchand de Reves) devient l Alchimiste a la fiole fumante ; 3 (ex-Voyant) devient l Astrologue a l astrolabe tournant ; les quatre autres sont gardees (le halo de fond est retire dans la scene seulement).

**Fichiers** (`design/marchands/`) :
- `src_data.py` -> `src_data.js` : textes et repartition (ne pas reformuler les textes sans Thibs) ;
- `src_scenes.js` : `_MERCH_FX[i](ctx,w,h,t)` et `_merchSceneStart` ;
- `src_svg.js` : figures 1 et 3 ;
- `appliquer.py` : integre le tout dans `www/index.html` (ancres verifiees, controle objets/catalogue, 0 tiret long) ;
- `generer.py` : fabrique `maquette/` depuis le vrai code de `index.html` (a lancer apres `appliquer.py`).

**Pour integrer apres validation** : `python3 design/marchands/appliquer.py`, puis copie Android. Verifie le 23 novembre : 4 blocs `node --check` OK, 0 tiret long, 6 pages marchand, la Boutique et la liste des marchands s ouvrent sans erreur.

### Revue un par un : Enguerrand refait (23 novembre 2026, 13 h)

Retours de Thibs sur la maquette : chateau mal emboite dans la colline, element principal a mettre a GAUCHE (les autres marchands l ont a droite), aucune animation visible, et nouvelle DA : forteresse de bois et de pierre, de jour, montagnes vertes et fleuries, nuages, montgolfieres, oiseaux, tout anime.

- **Animations invisibles : cause.** `_merchSceneStart` affichait une image fixe quand le telephone demande moins d animations, et l economie de batterie de Thibs l active. Decision de Thibs : les scenes des marchands tournent TOUJOURS, comme les emblemes et les decors des titres. Verifie en emulant le mouvement reduit : les images different d un instant a l autre.
- **Scene 0 reecrite** (`_MERCH_FX[0]`, `design/marchands/src_scenes.js`). Decisions de Thibs : ruines fumantes (pas de flammes), montgolfieres. Ciel de jour, soleil, cinq nuages qui derivent, deux chaines de montagnes bleu-vert, trois montgolfieres a fuseaux qui derivent et se balancent, deux vols d oiseaux en V aux ailes battantes. A gauche, sur une butte : tour de pierre intacte avec hourd de bois, toit conique en bardeaux et fanion rouge qui flotte ; donjon de pierre a l etage de colombage a demi brule, poutres calcinees ; tour droite effondree et eboulis ; courtine crenelee, lierre, palissade de pieux dont deux tombes ; deux panaches de fumee pousses vers la droite. Emboitement : la butte est dessinee APRES les murs et recouvre leur base, avec une levre d herbe et des rochers au pied. Premier plan : pre, 70 fleurs qui ondulent (aucune devant le marchand), herbes hautes, trois papillons.
- Fond sous la scene (`SOL[0]` dans `appliquer.py`) : `#14301c`, vert sombre, pour que le fondu du pre soit continu.
- Verifie : `node --check`, captures a 360 et 393 px, aucune erreur, 0 tiret long. Maquette regeneree depuis une COPIE du depot (`appliquer.py` puis `generer.py` dans /tmp), republiee. `www/index.html` toujours inchange.
- **Decor enrichi (14 h 23, demande de Thibs : trop vide)** : un lac entre les collines a droite (berge, degrade du ciel, rides qui glissent, scintillement) ; six arbres feuillus (`arbre(...)`, couronne en quatre masses, eclairee a droite, qui se balance au vent, ombre au sol), quatre au bord du lac et deux grands aux coins du premier plan ; un petit cimetiere sur le pre a droite (`croix(...)`) : six croix de pierre penchees, contour sombre, face claire, mousse, ombre au sol, dessinees apres les fleurs pour rester lisibles.
- **Figure d Enguerrand refaite** (demande de Thibs : quitter l aspect « Solo Leveling », revenir a un marchand itinerant, en lien avec son histoire). Plus de capuche ni d embleme violet : visage nu, cheveux courts, barbe, tunique verte, tablier de cuir, ceinture et bourse ; sac a dos avec paquetage roule rouge, poele et tenailles accrochees ; enclume d acier bien en vue sur sa souche, a droite. Le bras droit leve le marteau et frappe l enclume toutes les 2,4 s, gerbe d etincelles a l impact (SMIL, donc anime meme en mouvement reduit). Code : troisieme morceau de `src_svg.js`, pose par `appliquer.py` a la place de la figure 0. La meme figure sert aussi dans la liste des marchands de la Boutique (44 x 53 px). Verifie : frappe et etincelles a 1,66 s, aucune erreur.

### Revue un par un : Alienor refaite (23 novembre 2026, 13 h 05)

Demandes de Thibs : un bucher en feu au loin, sa figure dans la facture d Enguerrand, un ou deux alambics en marche dans le decor, des passants qui l observent caches derriere une charrette.
- **Figure** (premier morceau de `src_svg.js`, figure 1) : visage nu, coiffe de lin, tresse auburn sur l epaule, robe sarcelle, tablier de lin tache, ceinture de trois fioles, bourse ; hotte d osier avec herbes en fleur et pot de terre accroche. Bras droit leve tenant une fiole verte qui bouillonne (bulles), luit et fume (trois volutes de couleur), avec un leger balancement. Tout en SMIL.
- **Scene** (`_MERCH_FX[1]`) : la lune passe au centre haut. Bucher sur une butte a gauche, au-dessus des toits : poteau, fagots, sept langues de flamme qui vacillent, lueur sur la butte, fumee, etincelles. Premier plan a gauche : etabli eclaire par un brasero ; alambic de cuivre (cucurbite, chapiteau, bec) dont une goutte tombe dans un recipient de verre qui se remplit lentement, vapeur au chapiteau ; seconde cornue de verre violette sur une chandelle, bulles. A droite : charrette (sacs, tonneau, roue a huit rayons, brancard) ; deux curieux encapuchonnes montent la tete derriere les sacs et le tonneau, epient (yeux qui bougent) puis replongent, chacun a son rythme (cycle de 7 s, decales).
- Retour de Thibs (13 h 18) : le bucher « volait ». La butte avait presque la couleur du ciel. Elle est maintenant en silhouette plus sombre que le ciel (`#0b1630`), plus large, avec son bord eclaire par le feu ; neuf spectateurs en silhouette, eclaires d un cote, se tiennent sur la crete autour du bucher et se balancent un peu.
- Retour de Thibs (13 h 29) : les spectateurs volaient aussi. Leur hauteur venait d une approximation (parabole) alors que la crete est faite de deux courbes de Bezier qui descendent plus vite. `crete(x)` calcule maintenant la vraie cote de la crete (recherche du parametre par dichotomie) et chaque spectateur y est pose, 1,5 px enfonce. Verifie sur capture zoomee.
- Verifie : captures a 393 px a trois instants, aucune erreur, 0 tiret long ; maquette regeneree depuis une copie du depot et republiee.

### Revue un par un : Gaucher refait (23 novembre 2026, 13 h 10)

Demandes de Thibs : sa figure dans la facture d Enguerrand et d Alienor ; decor : une cavalerie qui charge sous une pluie de fleches, animee ; un corbeau qui finit par se poser sur son heaume ; une ville au loin a droite, visible.
- **Figure** (quatrieme morceau de `src_svg.js`, posee par `appliquer.py` APRES la figure 3, dont l ancre de fin est le commentaire de la figure 4) : bassinet a nasal, coiffe de mailles, visage nu avec une cicatrice et une barbe de quelques jours, cotte de mailles (motif `mc-maille`), surcot dechire a croix rouge passee, ceinture, bras bande, bouclier bleu et or sur le dos perce de trois fleches brisees, mains sur la garde d une epee plantee en terre.
- **Le corbeau** (SMIL, cycle de 16 s, dans la figure pour se poser exactement sur le heaume) : invisible 1 s, arrive du haut a droite en battant des ailes, se pose sur le sommet du heaume vers 4,8 s, ailes repliees, y reste jusqu a 13,4 s, puis repart vers la gauche et disparait. Origine du dessin = ses pattes ; ailes pivotant a leur racine.
- **Scene** (`_MERCH_FX[4]`) : aube, soleil bas a gauche. Ville muree a droite sur sa colline : remparts crenneles, quatre tours, maisons, clocher, fenetres allumees, fumees. Deux rangs de cavaliers au galop de gauche a droite (jambes en cycle de galop, rebond, housses de couleur, lances couchees, fanions, poussiere), le rang proche plus grand et plus sombre. Trois volees de 16 fleches tirees depuis la ville, en cloche, orientees selon leur trajectoire. Corbeaux qui tournent au loin, trois bannieres dechirees et des fleches plantees au premier plan (aucune devant le marchand).
- Defaut trouve et corrige avant livraison : les chevaux heritaient de l opacite de la poussiere dessinee juste avant (`globalAlpha`), ils etaient presque invisibles.
- Verifie : captures a 393 px, trajet du corbeau a 2 / 3 / 4,2 / 8 / 14 / 15 s, aucune erreur, 0 tiret long ; maquette regeneree depuis une copie du depot et republiee.
- Ralenti a la demande de Thibs (13 h 15) : galop 9 -> 5,5, cavaliers deux fois plus lents (rang lointain .07 -> .035 w/s, proche .1 -> .05), fleches : une volee toutes les 3 s au lieu de 1,2 s, vol de 6,3 s au lieu de 2,5 s.
- Fleches recolorees (13 h 16, elles avaient la couleur des oiseaux) : fut de bois `#8a6440`, pointe d acier `#d8dee4`, empennage creme `#f2ead6` ; fleches plantees du premier plan assorties (`#6a4a2e`, `#e2d8c0`).
- **Scene recomposee (14 h 29, Thibs : plan actuel pas aime, trop de fleches)** : `_MERCH_FX[4]` reecrite. Gaucher au premier plan d un champ de bataille. Au fond : la ville a droite (inchangee) et, devant elle, huit archers de l envahisseur en silhouette qui bandent leur arc et tirent toutes les 4,2 s ; une charge de sept cavaliers part de la gauche vers eux et s efface dans la poussiere avant de les atteindre. Volees reduites a huit fleches, rapides et presque tendues, qui se plantent dans le sol autour de la charge ; celles de la volee precedente restent plantees et s effacent lentement. Premier plan (34 % de la hauteur) : sol boueux avec flaques qui refletent le ciel et ornieres, deux pans de mur effondres avec gravats, roue de chariot brisee, quatre lances couchees, quatre epees plantees, trois boucliers, deux heaumes, banniere tombee, fleches plantees (aucune devant Gaucher), trois fumees et des braises. Le corbeau sur son heaume est inchange.

### Revue un par un : Anselme refait (23 novembre 2026, 13 h 35)

Demandes de Thibs : le Mont en monastere-forteresse (remparts, tours) plutot qu en chateau fort classique ; une flotte qui s eloigne au loin ; un navire qui coule dans un plan assez proche ; des drapeaux qui flottent sur le Mont ; des poissons ou des dauphins qui sautent ; sa figure dans la facture des autres, en accentuant le livre et la plume.
- **Figure** (cinquieme morceau de `src_svg.js`, posee par `appliquer.py` apres la figure 1, dont l ancre de fin est le commentaire de la figure 2) : moine tonsure, yeux baisses sur son livre, coule brune et capuchon rabattu, cordon a trois noeuds, encrier a la ceinture, besace de rouleaux. En vedette : un grand livre d heures ouvert tenu devant lui (couverture bordeaux, lettrine rouge et or, miniature bleue et or, bordures, texte) et une longue plume blanche. La plume suit l ecriture : deux lignes s ecrivent sur la page droite (6 s), avec un leger tremblement de la main ; l or scintille en trois points (SMIL).
- **Scene** (`_MERCH_FX[2]`, reecrite) : couchant, soleil a gauche et son scintillement, vaguelettes qui derivent. Le Mont a droite : rocher, village en gradins, remparts crenneles au pied avec quatre tours rondes a machicoulis et porte, seconde enceinte a mi-hauteur avec deux tours, abbaye sur soubassement a contreforts (fenetres allumees), nef, clocher, fleche et sa lueur ; cinq drapeaux qui flottent (or, bleu, creme, rouge, or). Cinq navires qui s eloignent vers l horizon en retrecissant (cycle de 46 s, decales). Premier plan a gauche : un navire (voile a croix rouge) gite, s enfonce par l avant et coule sur 26 s ; sa voile arrachee, remous, ecume, bulles et debris de bois ; il reapparait en fondu. Trois dauphins qui sautent en arc avec eclaboussures, petits poissons qui bondissent. Mouettes gardees, rivage rocheux au premier plan.
- Verifie : captures a 393 px, naufrage rendu a 3 / 8 / 12 / 16 / 20 / 24,5 s, plume a 1 / 2,6 / 4 / 5 s, aucune erreur, 0 tiret long ; maquette regeneree depuis une copie du depot et republiee.
- **Retractation et changement de registre (13 h 41).** Thibs : « tu lui as dessine des cornes ». Vrai : les deux meches de la couronne de tonsure pointaient vers le haut de chaque cote du crane et se lisaient comme des cornes. Decision de Thibs : plus de frere, plus de sacre, un ecrivain dans une forteresse ; l abbaye du Mont est gardee.
  - Figure refaite : cheveux bruns, barbe courte, beret vert, plume derriere l oreille, pourpoint bordeaux a boutons dores et col blanc, ceinture a boucle et encrier, chausses et bottes ; besace de rouleaux, livre et plume qui ecrit inchanges.
  - Textes (`src_data.py`, consigne de Thibs : garder l histoire, retirer le sacre) : nom « Anselme l'Écrivain », titre « L'écrivain du Mont assiégé » ; « jusque sur la tonsure » devient « jusque dans la barbe » ; « Dans le scriptorium de l'abbaye, un jeune moine nommé Anselme continuait d'enluminer un livre d'heures » devient « Dans une tour de la forteresse, un jeune écrivain nommé Anselme continuait d'écrire et d'enluminer son livre » ; « les feuilles d'or des reliquaires » devient « l'or de sa propre bague ». Le reste est inchange.
  - Sol du premier plan (on le discernait mal) : un quai de pierre de la forteresse, eclaire par le couchant, rangs de dalles, bitte d amarrage et cordage, rouleau de corde, caisse.
  - Retour de Thibs (13 h 47) : les drapeaux ne touchaient pas les tours, et le naufrage faisait amateur (petites bulles). Chaque hampe part maintenant du parapet de sa tour (hauteur de la tour + crenelage). Naufrage reecrit : coque a bordages, chateau arriere et sabords, beaupre, haubans ; le navire gite puis plonge par la proue en se cabrant ; le mat se brise a mi-hauteur vers 11 s et sa partie haute tombe avec la voile dechiree et trouee. Plus aucune bulle en points : anneaux de remous qui s elargissent, bande d ecume irreguliere le long de la flottaison, deux gerbes d embruns quand la proue plonge, nappes d ecume douces qui s etalent, epaves (planches, tonneau, cordage) qui derivent a plat.
  - Demande de Thibs (14 h 02) : quelques caisses sur le quai, basses pour ne rien cacher ; un canon sur la forteresse qui vise les bateaux, dont le boulet finit en mer. Six caisses et un tonneau, 3 a 5 % de la hauteur de scene. Canon sur le rempart entre les deux tours de gauche, pointe vers la flotte ; toutes les 8 s : recul, eclair et fumee a la bouche, boulet en cloche (2 s), gerbe d eau a l impact pres des navires, embruns et anneau.
  - Retour de Thibs (14 h 05) : plus de cloche. Fut presque horizontal, a peine incline vers le bas (-0,14 rad) ; la bouche est calculee apres rotation ; le boulet file droit dans l axe du fut en 0,55 s, a peine infle par la pesanteur, avec une trainee, et s ecrase dans l eau pres de l horizon, au milieu de la flotte (gerbe plus petite, a cette distance). Melisende validee par Thibs (« excellent travail »).
  - Retour de Thibs (14 h 06) : le canon flottait au-dessus du rempart. Il repose maintenant sur le chemin de ronde (pied au niveau du haut du mur), derriere un parapet redessine devant lui qui cache l affut et les roues ; le fut sort par une embrasure entre deux merlons. La bouche du canon et le tir suivent.

### Revue un par un : Melisende refaite (23 novembre 2026, 13 h 45)

Demande de Thibs : un grenier tres ouvert, l ouverture en forme d arche, qui surplombe les toits de Chartres ; quelques tables d astrologie (globe, carte, outils), du foin, des toiles d araignee ; Melisende et son telescope pointe vers le ciel au milieu ; une nuit parfaite, sans pollution lumineuse, etoiles et cometes. Animations : constellations qui se tracent, comete en feu, araignee qui remonte son fil, globe qui tourne. Sa figure dans la facture des autres.
- **Figure** (deuxieme morceau de `src_svg.js`, figure 3) : cheveux sombres, diademe d argent a etoile, robe bleu nuit semee d etoiles qui scintillent, cape, ceinture d argent, astrolabe dont le reseau tourne. Elle a l oeil a l oculaire d une grande lunette de laiton sur trepied de bois, pointee vers le haut a droite ; une main regle l oculaire (qui coulisse), l autre tient le tube ; la lentille luit.
- **Scene** (`_MERCH_FX[3]`, reecrite, l eclipse disparait) : murs de planches et chevrons ; une grande arche dont le ciel est decoupe par `clip` (l arche se trace par `arche()`, `arche(true)` pour l ajouter au chemin du mur en `evenodd`). Dans l arche : voie lactee en nuees et 260 etoiles fines, 170 etoiles, neuf etoiles brillantes a croix, deux cometes lointaines figees ; quatre constellations qui se tracent segment par segment, une toutes les 9 s, puis s effacent ; une comete en feu qui traverse toutes les 11 s ; en contrebas les toits de Chartres (fenetres allumees) et la cathedrale, ses deux fleches differentes, sa rose qui luit. Dans le grenier : encadrement de poutres, toiles d araignee dans les deux coins hauts et dans l angle de l arche, araignee qui descend sur son fil, s arrete, puis remonte en agitant les pattes (12 s) ; plancher, deux meules de foin et brins epars ; table de gauche : globe qui tourne (continents et meridiens), astrolabe pose dont l alidade tourne, chandelle ; table de droite : carte du ciel deroulee, compas a pointes, sablier dont le sable coule, livres empiles, chandelle.
- Retour de Thibs (14 h 02) : la cathedrale volait et cachait les maisons ; perspective des toits a rendre credible. La ville est maintenant faite de quatre rangs de maisons, du fond vers l avant, de plus en plus grandes et basses dans l image (`rang(n)`, `maison(...)`) : maisons a pignon face a nous avec leur versant qui fuit et le mur lateral, ou a faitage parallele dont on voit le versant avant d en haut (tuiles, faitage eclaire par la lune), cheminees, fenetres allumees ou eteintes, ruelles eclairees entre les rangs. La cathedrale est posee apres le rang du fond et avant les trois autres, qui cachent son pied ; nef, arcs-boutants, rose et ses deux fleches restent visibles au-dessus des toits.
- Verifie : captures a 393 px, aucune erreur, 0 tiret long ; maquette regeneree depuis une copie du depot et republiee.

### Revue un par un : decor de Bertrand refait (23 novembre 2026, 13 h 55)

Demande de Thibs : en pleine montagne, sur un chemin assez large qui monte vers le col et tourne bientot a droite ; sapins enneiges d un vert profond de chaque cote ; a gauche une cloture de bois le long du chemin ; a droite la grotte de Bertrand, une chandelle allumee a l entree ; au loin un loup hurle ; juste apres le coucher du soleil, pas encore la nuit ; il neige legerement. Animations : loup qui hurle, arbres qui bougent au vent, lune qui se degage des nuages, flamme qui vacille mais tient.
- **Scene** (`_MERCH_FX[5]`, reecrite) : ciel de crepuscule (bleu nuit en haut, rose et orange a l horizon), premieres etoiles. Lune derriere deux nuages qui s ecartent et la devoilent (cycle de 40 s : cachee, devoilee, puis les nuages reviennent lentement), leur bord eclaire quand elle sort. Deux chaines de sommets aux aretes roses ; rangees de petits sapins au loin. Le loup, sur un rocher au fond du chemin, leve la tete et hurle toutes les 9 s (ondes pales du hurlement). Chemin enneige large au premier plan, qui monte et tourne a droite, avec ses ornieres ; cloture de bois en perspective a gauche (poteaux, deux lisses, neige sur les poteaux) ; sapins vert profond enneiges des deux cotes, cisailles par le vent (deux ondulations superposees). A droite, la paroi rocheuse a l arete enneigee, la grotte sombre, son bord eclaire par la chandelle ; la chandelle a l entree, flamme qui se penche et palpite sans jamais s eteindre, halo qui respire. Neige qui tombe doucement (80 flocons, vitesses et derive variees).
- Fond sous la scene (`SOL[5]` dans `appliquer.py`) : `#2a2848`.
- Retour de Thibs (13 h 59) : perspective fausse, chemin qui levite, grotte mal encastree, loup trop sommaire, ondes du hurlement a retirer, figure a refaire. Corrige :
  - Terrain : un plateau enneige monte jusqu a la crete du col (`terre(x)`, ligne brisee lissee), dessine avant le chemin ; les petits sapins lointains sont poses sur cette crete. Le chemin n est plus un polygone a la main : une courbe mediane (Bezier cubique) dont la largeur decroit avec la profondeur (`demi(u)`), bords decales selon la normale, donc il retrecit regulierement et tourne a droite au col, ou des sapins cachent le virage. Cloture posee sur le bord gauche reel du chemin, poteaux mis a l echelle de la profondeur.
  - Paroi : contour irregulier (bruit), strates, corniches enneigees ; grotte a l arche irreguliere, fond en degrade, bord eclaire par la chandelle, stalactites de glace ; une congere monte sur le pied de la paroi et le seuil, la chandelle y est posee.
  - Loup : assis de profil sur un rocher enneige a gauche du col, queue touffue au sol, arriere-train, poitrail et collerette de fourrure, pattes, oreilles pointues ; la tete se leve et la gueule s ouvre pour hurler (cycle de 9 s), liseré de lune sur le dos. Plus aucune onde.
  - Figure (sixieme morceau de `src_svg.js`, posee par `appliquer.py` jusqu a `  ];\n  return svgs[idx]`) : vieil ermite au crane degarni, cheveux et longue barbe blancs, manteau de laine a col de fourrure, neige sur les epaules, bottes bandees, baton noueux ; dans l autre main, le bougeoir de laiton et sa chandelle dont la flamme vacille et le halo respire (SMIL).
- Retour de Thibs (14 h 08) : zone vide a droite du chemin, nuages trop rapides, montagnes lointaines a detailler.
  - La montagne de la grotte est agrandie : son flanc part de 66 % de la largeur et monte jusqu en haut a droite ; le chemin disparait derriere elle au col. Strates, lueur rose sur la crete, quatre corniches enneigees.
  - Massifs lointains (`massif(...)`, deux plans, sept sommets) : aretes dechiquetees, versant gauche eclaire par le couchant et versant a l ombre, neves sous les sommets au bord en dents de scie (plus clairs cote soleil), couloirs rocheux, liseré rose sur l arete, voiles de brume a leur pied. Remplacent les deux lignes de crete lisses.
  - Nuages : cycle de la lune porte de 40 a 80 s, petits nuages deux fois et demie plus lents. Le liseré de lune n est plus un arc trace a part (il se voyait comme un trait au-dessus du nuage) mais la meme forme decalee vers le haut, sous le nuage.
  - Note : le correctif du liseré fait plus tot (13 h 55) avait ete perdu lors de la reecriture de 13 h 59 ; il est refait.
- Retour de Thibs (14 h 12) : la montagne s arretait net, le chemin devait tourner derriere elle ; retirer l arbre de droite ; foret de gauche a mettre en perspective.
  - Le pied de la montagne suit desormais le bord droit du chemin (`BD`, decale de `DR`) depuis l avant jusqu au virage, puis rejoint la paroi : le chemin passe derriere elle. Face tournee vers le chemin assombrie en degrade, arete de l epaule eclairee, talus de neige au pied de la paroi le long du chemin.
  - Sapin a 68 % de la largeur (contre la paroi) retire.
  - Foret de gauche : seize sapins sur deux rangs, places le long d une ligne qui fuit vers le col ; tres grands au premier plan (jusqu a 60 % de la hauteur de scene), de plus en plus petits et hauts dans l image en s eloignant, dessines du plus lointain au plus proche.
- Retour de Thibs (14 h 15) : retirer les lignes (elles debordaient dans le ciel), detailler la roche, retirer les dents blanches, ajouter un portique de bois.
  - Retires : les huit strates tracees jusqu au bord de la scene, l arete eclairee de l epaule, le trait du talus, le trait de la congere, le polygone d ombre et la bande claire a bords droits, les stalactites.
  - `mont()` trace la silhouette de la montagne ; elle sert au remplissage ET de decoupe (`clip`) a tous les details, qui ne peuvent donc plus deborder : ombre en degrade cote chemin, lueur du couchant en haut, 22 facettes plus claires ou plus sombres, 14 fissures brisees, 9 plaques de neige sur les replats, eboulis enneiges au pied.
  - Portique de bois (`poutre(...)`) : deux montants, un linteau, deux jambes de force, veinures, neige sur le linteau et le haut des montants, montant gauche eclaire par la chandelle.
- Retour de Thibs (14 h 19) : revenir a l ancien modele de la montagne (celui de 14 h 12), sans le reconstruire ; seulement empecher les petits traits de sortir de la montagne ; garder l entree a poutres, larges, epaisses et bien emboitees.
  - Code de 14 h 12 remis tel quel (ombre de la face cote chemin, arete eclairee, talus et son trait, bande claire, neige de crete, corniches, trait de la congere), et les facettes, fissures et plaques de 14 h 15 sont retirees. Seule difference : les huit strates sont tracees dans `ctx.clip()` sur `mont()`, elles s arretent au bord de la montagne. Les stalactites restent retirees (demande de 14 h 15).
  - Portique refait (`bois(...)`) : montants de 2,8 % de la largeur, linteau de 5 % de la hauteur qui deborde de chaque cote, tenons des montants visibles a travers le linteau avec chevilles, deux jambes de force logees entre montant et linteau, bois de bout du linteau (cernes), veinures, neige sur le linteau, montant gauche eclaire par la chandelle.
- Verifie : rendu a 2 / 4 / 12 / 20 / 30 s et capture a 393 px, aucune erreur, 0 tiret long ; maquette regeneree depuis une copie du depot et republiee.

### Fiche marchand simplifiee (23 novembre 2026, 14 h 32)

Demande de Thibs, pour les six fiches (`appliquer.py`, etapes 4, 5 et 5 bis) :
- retires : la citation du bas (« Approche-toi, voyageur... » / « Patience... ») et son filet, et la phrase de specialite entre « Ses marchandises » et la liste (le champ `speciality` reste dans les donnees, il n est plus affiche ici) ;
- l histoire est posee sur un parchemin (degrade creme vers ocre, bord brun, ombre interne) ;
- les blocs de marchandises sont bruns (degrade #6e4a2c vers #553620, bord #8a6440, assise sombre), texte creme ;
- une seule couleur pour tous les titres de section, quel que soit le marchand : or (#d9a84e pour « Marchand itinerant » sur le fond sombre, #b8862f pour « Histoire » et « Ses marchandises » sur le fond clair). `m.accent` n est plus utilise dans la fiche.
Verifie : fiche de Melisende en bas de page, aucune erreur ; maquette regeneree et republiee.

### Corbeau de Gaucher : il sort du plan (23 novembre 2026, 14 h 33)

Retour de Thibs : en partant, le corbeau « s ecrasait contre un mur invisible » (il etait coupe au bord du SVG de la figure, 104 px de large). La figure 4 porte maintenant `overflow:visible` : le corbeau arrive de loin a droite de la scene (hors champ), se pose, s envole et file vers la gauche jusqu a sortir du cadre de la scene, dont le conteneur coupe tout ce qui depasse. Il reste visible pendant tout son vol (opacite a 1 de 6 % a 99,5 % du cycle de 16 s). Note : dans la petite vignette de la liste des marchands (44 x 53 px), le corbeau peut donc deborder de la vignette pendant ses vols.

## Marchands integres dans l app (23 novembre 2026, 14 h 35)

Thibs a valide la mise a jour des six marchands. `python3 design/marchands/appliquer.py` a ete lance sur le depot, puis `www/index.html` recopie dans `android/app/src/main/assets/public/` (identique, verifie par `cmp`).

Ce qui entre dans `www/index.html` : les donnees (`_MERCHANTS`, `_MERCHANT_ITEMS`, textes d Anselme revus), les six figures SVG refaites, les six scenes animees (`_MERCH_FX`, `_merchSceneStart`, animees meme en economie de batterie), l en-tete de page marchand (scene, figure, nom), la fiche simplifiee (histoire sur parchemin, marchandises sur fond brun, titres dores, plus de citation ni de phrase de specialite) et le demarrage de la scene a l ouverture.

Verifie dans l application reelle (serveur local, Chromium, mouvement reduit emule) : les six pages marchand s ouvrent, leur scene s anime (deux images differentes a 0,5 s d ecart), la citation du bas a disparu, la liste compte 4 ou 5 marchandises, aucune erreur JavaScript. Structure : 6 balises `<script`, 4 blocs inline, `node --check` sur les quatre, lxml valide, 0 tiret long.

Pour retoucher un marchand plus tard : `appliquer.py` ne peut PAS etre relance (ses ancres de depart, comme `// 1 - MARCHAND DE R`, n existent plus dans `index.html`). Modifier directement `www/index.html` (les sources `design/marchands/src_*.js` restent une copie de reference), puis regenerer la maquette par `python3 design/marchands/generer.py`.

