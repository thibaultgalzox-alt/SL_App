// 21 novembre : Metanoia Pro = 5 swipes par jour ; une quete ecartee ne revient pas le meme jour.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
(async()=>{const b=await chromium.launch();
for(const pro of [false,true]){
const p=await b.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true,deviceScaleFactor:2});
const err=[];p.on('pageerror',e=>err.push(e.message));
await p.goto('http://127.0.0.1:8777/index.html');await p.waitForTimeout(3000);
await p.evaluate(()=>{ST._ob={age:1,situation:1,sportLevel:1,physGoal:0,sportAccess:[0,2],collectifSport:'',collectifJours:[],mindLevel:0,screenHours:3,sleep:1,resistances:[1,2],prog:'Standard'};ST.myWhy='x';ST._tutoSeen=true;_obFinish();});
await p.waitForTimeout(2000);
await p.evaluate(pro=>{document.querySelectorAll('.tuto-ui,#tuto-card,#tuto-ov,.tuto-overlay').forEach(x=>x.remove());ST.day=24;ST.integrity=90;ST._unlocksSeen={};for(var k in (window._UNLOCKS||{}))ST._unlocksSeen[k]=1;
 ST._tutoScreens=new Proxy({},{get:function(){return true}});window.isOpen=function(){return true};ST.weekPlan=genWeek();
 if(pro)ST._pro={actif:true}; else delete ST._pro;
 var t=getToday(),d=(ST.day-1)%7;t.secs=[Object.assign(gSE(24),{id:'se'+d}),Object.assign(gSM(),{id:'sm'+d})];ST._boost={day:ST.day,id:null};save();nav('s-main');renderMain()},pro);
await p.waitForTimeout(1200);
const vus=[];let ok=0;
for(let i=0;i<7;i++){
  const r=await p.evaluate(()=>{var t=getToday(),avant=t.secs[0].name;var pile=document.querySelector('#ql-sec .sec-pile[data-sec="0"]');if(!pile)return {err:'pas de pile'};
    var carte=pile.querySelector(':scope>.qcard');var jeton=(document.querySelector('.sec-jeton')||{}).textContent;var rest=_secRestants();_secPartir(pile,carte,0);return {avant:avant,rest:rest,jeton:jeton};});
  await p.waitForTimeout(500);
  const apres=await p.evaluate(()=>getToday().secs[0].name);
  if(apres!==r.avant){ok++; vus.push(r.avant);}
  if(i===6)vus.push(apres);
  console.log((pro?'PRO ':'std ')+'essai '+(i+1)+' restants='+r.rest+' jeton="'+r.jeton+'" '+(apres!==r.avant?'swipe OK':'refuse'));
}
const dbl=vus.filter((v,i)=>vus.indexOf(v)!==i);
console.log((pro?'PRO':'std')+' : '+ok+' swipes reussis ; doublons dans la journee : '+(dbl.length?dbl.join(','):'aucun')+' ; erreurs '+JSON.stringify(err.slice(0,2)));
await p.close();}
await b.close()})();
