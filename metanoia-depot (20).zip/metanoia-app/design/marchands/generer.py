# Fabrique design/marchands/maquette/ a partir du VRAI code de www/index.html :
# fonctions et donnees des marchands extraites telles quelles, balisage de la
# fenetre marchand tel quel, polices de l app. Ne pas retoucher la maquette :
# modifier index.html (via appliquer.py) puis relancer ce script.
#   python3 design/marchands/generer.py   (depuis la racine du depot)
import os, re, shutil, html
R=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
W=os.path.join(R,'www'); OUT=os.path.join(R,'design','marchands','maquette')
s=open(os.path.join(W,'index.html'),encoding='utf-8').read()

def bloc(debut, ouvre='{'):
    """Texte depuis `debut` jusqu a l accolade (ou crochet) fermante equilibree."""
    i=s.index(debut); j=s.index(ouvre,i); ferme={'{':'}','[':']'}[ouvre]
    k=j; n=0; q=None; esc=False
    while k<len(s):
        c=s[k]
        if q:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c==q: q=None
        elif c in '\'"`': q=c
        elif s.startswith('//',k) and s[k-1] not in ':\\':
            k=s.index('\n',k); continue
        elif c==ouvre: n+=1
        elif c==ferme:
            n-=1
            if n==0:
                fin=k+1
                if s[fin:fin+1]==';': fin+=1
                return s[i:fin]
        k+=1
    raise Exception('non ferme : '+debut)

CODE=[bloc('var _MERCHANTS=[','['), bloc('var _MERCHANT_ITEMS={'), bloc('var _DAILY_POOL=[','['),
      bloc('function _merchantSvg(idx){')]
i=s.index('// ── Scenes animees des marchands'); j=s.index('function _openMerchantPage(idx){')
CODE.append(s[i:j]); CODE.append(bloc('function _openMerchantPage(idx){')); CODE.append(bloc('function _closeMerchantPage(){'))
KF=''.join(bloc('@keyframes '+k) for k in ['_shopSlideUp','_shopGlow1','_shopGlow2'])
i=s.index('<div id="shop-merchant-page-overlay"'); OV=None
# balisage : jusqu a la fermeture de l overlay (comptage des div)
k=i; n=0
for m in re.finditer(r'<(/?)div\b',s[i:]):
    n+= -1 if m.group(1) else 1
    if n==0: OV=s[i:s.index('>',i+m.end())+1]; break
assert OV and OV.endswith('</div>'), 'overlay introuvable'

page='''<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Metanoia : les marchands</title><link rel="stylesheet" href="fonts.css">
<style>'''+KF+'''
body{margin:0;font-family:'Sora',sans-serif;background:#1c1424;color:#f5f0e8}
.tete{max-width:760px;margin:0 auto;padding:18px 16px 6px}
.tete h1{font:italic 700 26px 'Cormorant Garamond',serif;margin:0 0 4px}
.tete p{font-size:12px;opacity:.75;margin:0 0 12px;line-height:1.5}
.onglets{display:flex;flex-wrap:wrap;gap:6px}
.onglets button{font:700 11px 'Sora',sans-serif;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:#f5f0e8;border-radius:20px;padding:7px 11px;cursor:pointer}
.onglets button.on{background:#f5f0e8;color:#1c1424}
#shop-merchant-page-overlay{position:relative!important;inset:auto!important;padding-top:10px!important;background:transparent!important;backdrop-filter:none!important;align-items:flex-start!important}
#shop-merchant-page-body{max-height:none!important}
</style></head><body>
<div class="tete"><h1>Les six marchands</h1>
<p>Maquette générée depuis le vrai code de l'app (www/index.html). Choisis un marchand : la scène s'anime en boucle lente.</p>
<div class="onglets" id="onglets"></div></div>
'''+OV+'''
<script>
var ST={}; function _attachSwipeDown(){} function _shopCycleInfo(){ return {active:true,idx:window._mqIdx||0,daysUntilNext:2,daysLeftActive:3}; }
'''+'\n'.join(CODE)+'''
var o=document.getElementById('onglets');
_MERCHANTS.forEach(function(m,i){ var b=document.createElement('button'); b.textContent=m.name; b.onclick=function(){ voir(i); }; o.appendChild(b); });
function voir(i){ window._mqIdx=i; [].forEach.call(o.children,function(b,k){ b.className=k===i?'on':''; }); _openMerchantPage(i); }
voir(0);
</script></body></html>'''
for c in ['\u2014','\u2013','&mdash;','&ndash;']: assert c not in page, c
if os.path.isdir(OUT): shutil.rmtree(OUT)
os.makedirs(os.path.join(OUT,'fonts'))
open(os.path.join(OUT,'index.html'),'w',encoding='utf-8').write(page)
shutil.copy(os.path.join(W,'fonts.css'),OUT)
for f in os.listdir(os.path.join(W,'fonts')): shutil.copy(os.path.join(W,'fonts',f),os.path.join(OUT,'fonts'))
print('maquette', len(page))
