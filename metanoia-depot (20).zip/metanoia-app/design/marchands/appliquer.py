# Applique la refonte des marchands a www/index.html (et a la copie Android).
# Part toujours de l etat courant ; chaque ancre doit exister une seule fois.
#   python3 design/marchands/appliquer.py   (depuis la racine du depot)
import os, re
R=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
D=os.path.join(R,'design','marchands'); P=os.path.join(R,'www','index.html')
s=open(P,encoding='utf-8').read()
lire=lambda n: open(os.path.join(D,n),encoding='utf-8').read()

def entre(debut,fin,nouveau,garder_fin=True):
    global s
    assert s.count(debut)==1, debut[:60]
    i=s.index(debut); j=s.index(fin,i); assert j>i
    s=s[:i]+nouveau+(s[j:] if garder_fin else s[j+len(fin):])

# 1. Donnees : _MERCHANTS + _MERCHANT_ITEMS (avec les commentaires entre les deux)
data=lire('src_data.js')
entre('var _MERCHANTS=[\n','\n};\n',data.rstrip('\n'),garder_fin=False)
s=s.replace(data.rstrip('\n'),data.rstrip('\n')+'\n',1)
# controle : chaque objet attribue existe dans le catalogue
pool=set(re.findall(r"effect:'(\w+)'",s[s.index('var _DAILY_POOL'):s.index('];',s.index('var _DAILY_POOL'))]))
for e in re.findall(r'"(\w+)"',data[data.index('var _MERCHANT_ITEMS'):]):
    assert e.isdigit() or e in pool, 'objet absent du catalogue : '+e

# 2. Les six figures SVG remplacees
svg=lire('src_svg.js').split('@@@\n')
entre('    // 0 - LE FORGERON','    // 1 - MARCHAND DE R',svg[2])  # figure 0 refaite le 23 novembre
entre('    // 1 - MARCHAND DE R',"    // 2 - L'ARCHIVISTE",svg[0])
entre("    // 2 - L'ARCHIVISTE",'    // 3 - LE VOYANT',svg[4])  # figure 2 refaite le 23 novembre
entre('    // 3 - LE VOYANT',"    // 4 - LE MERCENAIRE",svg[1])
entre('    // 4 - LE MERCENAIRE','    // 5 - LE SAGE',svg[3])  # figure 4 refaite le 23 novembre
entre('    // 5 - LE SAGE','  ];\n  return svgs[idx]',svg[5])  # figure 5 refaite le 23 novembre
s=s.replace("    // 2 - L'ARCHIVISTE :","    // 2 - L'ENLUMINEUR (ex-Archiviste) :",1)

# 3. Scenes animees, juste avant la page marchand
sc=lire('src_scenes.js')
assert s.count('function _openMerchantPage(idx){')==1
s=s.replace('function _openMerchantPage(idx){',sc+'\nfunction _openMerchantPage(idx){',1)

# 4. En-tete : scene animee plein cadre, figure posee devant, texte dessous
TETE=r"""var SOL=['#14301c','#050b1c','#3a1c22','#16112c','#1c0c12','#2a2848'][idx]||'#111';
  var fig=_merchantSvg(idx).replace(/<circle cx="100" cy="\d+" r="\d+" fill="url\(#[a-z-]+\)"\/>/,'');
  var html='<div style="background:'+SOL+';text-align:center;color:#fff;position:relative;overflow:hidden;border-radius:22px 22px 0 0">'
    +'<div style="position:relative;height:236px">'
    +'<canvas class="mx-scene" style="position:absolute;inset:0;width:100%;height:100%;display:block"></canvas>'
    +'<div style="position:absolute;left:0;right:0;bottom:0;height:56px;background:linear-gradient(rgba(0,0,0,0),'+SOL+')"></div>'
    +'<div style="position:absolute;left:50%;bottom:-4px;width:104px;height:125px;transform:translateX(-50%);filter:drop-shadow(0 6px 14px rgba(0,0,0,.65))">'+fig+'</div>'
    +'</div>'
    +'<div style="position:relative;padding:8px 18px 20px">'
    +'<div style="font-size:9px;font-weight:800;letter-spacing:.25em;text-transform:uppercase;color:#d9a84e;margin-bottom:6px">Marchand itinérant</div>'
    +'<h2 style="font-size:24px;font-weight:800;font-style:italic;margin:0 0 6px;font-family:\'Cormorant Garamond\',serif">'+m.name+'</h2>'
    +'<div style="font-size:12px;color:rgba(255,255,255,.72);font-style:italic;margin-bottom:8px">'+m.title+'</div>'
    +arrivalTxt
    +'</div>'
    +'</div>'
    """
entre("var html='<div style=\"background:'+m.bgGrad","+'<div style=\"padding:24px 20px 30px\">'",TETE)

# 5. Specialite -> liste des marchandises de ce marchand
LISTE=r"""+'<div style="font-size:9px;font-weight:800;letter-spacing:.2em;color:#b8862f;text-transform:uppercase;margin:22px 0 10px;border-bottom:1px solid rgba(0,0,0,.08);padding-bottom:6px">Ses marchandises</div>'
    +(_MERCHANT_ITEMS[idx]||[]).map(function(e){ var it=null; for(var k=0;k<_DAILY_POOL.length;k++){ if(_DAILY_POOL[k].effect===e){ it=_DAILY_POOL[k]; break; } } if(!it) return '';
      return '<div style="display:flex;align-items:center;gap:11px;padding:9px 11px;margin-bottom:7px;background:linear-gradient(135deg,#6e4a2c,#553620);border:1px solid #8a6440;border-radius:12px;box-shadow:0 2px 0 #3a2414">'
        +'<div style="flex:0 0 34px;height:34px;border-radius:10px;background:rgba(255,235,200,.14);display:flex;align-items:center;justify-content:center;font-size:18px">'+it.icon+'</div>'
        +'<div style="text-align:left;min-width:0"><div style="font-size:12.5px;font-weight:800;color:#fbf1dc">'+it.name+'</div><div style="font-size:11px;color:#e6d4b0;line-height:1.4">'+it.desc+'</div></div></div>'; }).join('')
    """
entre("+'<div style=\"background:linear-gradient(135deg,'+m.accent+'12","+'<div style=\"text-align:center;margin-top:24px",LISTE)

# 5 bis. Fiche simplifiee (23 novembre, 14 h 32) : plus de citation en bas, histoire sur parchemin,
# un seul or pour tous les titres de section, quel que soit le marchand
pied="""    +'<div style="text-align:center;margin-top:24px;padding:12px;border-top:1px dashed rgba(0,0,0,.08);font-size:10px;color:#8a7e6a;font-style:italic">'
    +(isCurrent?'« Approche-toi, voyageur. Le marché t\\'attend. »':'« Patience. Mon tour viendra. »')
    +'</div>'
"""
assert s.count(pied)==1, 'pied'; s=s.replace(pied,'',1)
h1="""+'<div style="font-size:9px;font-weight:800;letter-spacing:.2em;color:'+m.accent+';text-transform:uppercase;margin-bottom:10px;border-bottom:1px solid rgba(0,0,0,.08);padding-bottom:6px">Histoire</div>'
    +loreParas"""
assert s.count(h1)==1, 'histoire'
s=s.replace(h1,"""+'<div style="font-size:9px;font-weight:800;letter-spacing:.2em;color:#b8862f;text-transform:uppercase;margin-bottom:10px;border-bottom:1px solid rgba(0,0,0,.08);padding-bottom:6px">Histoire</div>'
    +'<div style="background:radial-gradient(ellipse at 30% 20%,#fbf2dc 0%,#f1e1bc 55%,#e4cc9c 100%);border:1px solid #d2b27c;border-radius:6px;padding:16px 16px 4px;box-shadow:inset 0 0 18px rgba(140,96,40,.28),0 2px 6px rgba(60,40,20,.18)">'+loreParas+'</div>'""",1)
s=s.replace("""padding:24px 20px 30px">'""","""padding:24px 20px 22px">'""",1)

# 6. Demarrage de la scene a l ouverture
a="if(ov){ov.style.display='flex';_attachSwipeDown(ov.firstElementChild,_closeMerchantPage);}\n}"
assert s.count(a)==1
s=s.replace(a,"if(ov){ov.style.display='flex';_attachSwipeDown(ov.firstElementChild,_closeMerchantPage);}\n  _merchSceneStart(content.querySelector('.mx-scene'),idx);\n}",1)

# 7. Badge « Present au marche » lisible sur le fond sombre de la scene
b="background:rgba(46,204,113,.15);color:#2e7d32"
assert s.count(b)==1; s=s.replace(b,"background:rgba(74,222,128,.16);color:#6ee7a0")

for c in ['\u2014','\u2013','\\u2014','\\u2013','&mdash;','&ndash;']: assert c not in s, c
open(P+'.tmp','w',encoding='utf-8').write(s); os.replace(P+'.tmp',P)
print('ok',len(s))
