// ── Scenes animees des marchands (page de chaque marchand) ────────────
// _MERCH_FX[i](ctx,w,h,t) : dessin sans etat, t en secondes. Lent, decor
// d abord ; le personnage (SVG) se pose devant, au centre bas.
function _mxR(seed){ return function(){ seed|=0; seed=seed+0x6D2B79F5|0; var t=Math.imul(seed^seed>>>15,1|seed); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
function _mxBruit(x,s){ return Math.sin(x*1.7+s)*.5+Math.sin(x*3.9+s*2.3)*.25+Math.sin(x*8.3+s*.7)*.12+Math.sin(x*17.1+s*1.9)*.05; }
var _mxPts={};
function _mxPoint(ctx,x,y,r,rgb,a){ var c=_mxPts[rgb]; if(!c){ c=document.createElement('canvas'); c.width=c.height=64; var g=c.getContext('2d'), d=g.createRadialGradient(32,32,0,32,32,32); d.addColorStop(0,'rgba('+rgb+',1)'); d.addColorStop(.45,'rgba('+rgb+',.55)'); d.addColorStop(1,'rgba('+rgb+',0)'); g.fillStyle=d; g.fillRect(0,0,64,64); _mxPts[rgb]=c; } if(a<=0||r<=0) return; ctx.globalAlpha=Math.min(1,a); ctx.drawImage(c,x-r,y-r,2*r,2*r); }
function _mxCiel(ctx,w,h,stops){ var g=ctx.createLinearGradient(0,0,0,h); stops.forEach(function(s){ g.addColorStop(s[0],s[1]); }); ctx.fillStyle=g; ctx.fillRect(0,0,w,h); }
function _mxHalo(ctx,x,y,r,col,a){ if(a<=0) return; var g=ctx.createRadialGradient(x,y,0,x,y,r); g.addColorStop(0,col); g.addColorStop(1,'rgba(0,0,0,0)'); ctx.globalAlpha=a; ctx.fillStyle=g; ctx.fillRect(x-r,y-r,2*r,2*r); ctx.globalAlpha=1; }
function _mxCrete(ctx,w,h,base,amp,s,col,fq){ ctx.fillStyle=col; ctx.beginPath(); ctx.moveTo(0,h); for(var x=0;x<=w;x+=4){ ctx.lineTo(x,h*base-h*amp*(_mxBruit(x/w*(fq||3),s)+.6)); } ctx.lineTo(w,h); ctx.closePath(); ctx.fill(); }
function _mxEtoiles(ctx,w,h,n,seed,t,a,ymax){ var r=_mxR(seed); for(var i=0;i<n;i++){ var x=r()*w, y=r()*h*(ymax||.6), z=r(), tw=.55+.45*Math.sin(t*(.6+z*1.6)+i); ctx.globalAlpha=a*tw*(.35+.65*z); ctx.fillStyle='#fff'; ctx.fillRect(x,y,z>.92?1.8:1.1,z>.92?1.8:1.1); } ctx.globalAlpha=1; }
function _mxBrume(ctx,w,h,y,ep,col,t,v,a){ for(var k=0;k<3;k++){ var x=((t*v*(1+k*.4)+k*w*.37)%(w*1.6))-w*.3; var g=ctx.createRadialGradient(x,y,0,x,y,w*.55); g.addColorStop(0,col); g.addColorStop(1,'rgba(0,0,0,0)'); ctx.save(); ctx.globalAlpha=a; ctx.translate(x,y); ctx.scale(1,ep/(w*.55)); ctx.translate(-x,-y); ctx.fillStyle=g; ctx.fillRect(x-w*.55,y-w*.55,w*1.1,w*1.1); ctx.restore(); } }

var _MERCH_FX=[
  // 0 - FORGERON : la forteresse de Montfaucon, pierre et bois, en ruine fumante
  // sur une butte, de jour ; montagnes vertes et fleuries, nuages, montgolfieres,
  // oiseaux, papillons. Element principal a GAUCHE.
  function(ctx,w,h,t){
    var PI=Math.PI, r, i;
    // butte de la forteresse (plateau a gauche) : cote du terrain en x
    function butte(x){ var u=(x-w*.23)/(w*.22); return h*.73-h*.21*Math.exp(-u*u*u*u); }
    // pre du premier plan
    function pre(x){ return h*.84+h*.035*Math.sin(x/w*5.2+1.3)+h*.015*Math.sin(x/w*13+.4); }
    // ciel de jour
    _mxCiel(ctx,w,h,[[0,'#5fb0ea'],[.45,'#a9d8f3'],[.72,'#e4f1ee'],[1,'#f3ecd2']]);
    // soleil a droite, halo qui respire
    var sx=w*.7, sy=h*.15;
    _mxHalo(ctx,sx,sy,w*.32,'rgba(255,246,205,.85)',.75+.1*Math.sin(t*.7));
    ctx.fillStyle='#fffbe8'; ctx.beginPath(); ctx.arc(sx,sy,h*.055,0,2*PI); ctx.fill();
    // nuages : grappes de disques, ventre bleute, derive lente vers la droite
    function nuage(x,y,s,a){
      var g=ctx.createLinearGradient(0,y-s,0,y+s*.6); g.addColorStop(0,'rgba(255,255,255,'+a+')'); g.addColorStop(1,'rgba(214,230,242,'+a+')');
      ctx.fillStyle=g; ctx.beginPath();
      [[-1.05,.18,.5],[-.55,-.12,.68],[0,-.32,.82],[.6,-.1,.64],[1.08,.2,.46],[0,.2,.6]].forEach(function(c){ ctx.moveTo(x+c[0]*s+c[2]*s,y+c[1]*s); ctx.arc(x+c[0]*s,y+c[1]*s,c[2]*s,0,2*PI); });
      ctx.fill();
    }
    [[.06,.12,h*.075,.9,.9],[.37,.07,h*.05,.75,1.25],[.58,.24,h*.06,.8,.7],[.92,.33,h*.045,.7,1.05],[.2,.29,h*.04,.6,.85]].forEach(function(c,k){
      var per=w*1.5, x=((c[0]*per+t*c[4]*4.2)%per)-w*.25; nuage(x,h*c[1],c[2],c[3]); });
    // montagnes lointaines, bleu-vert, cretes eclairees
    _mxCrete(ctx,w,h,.62,.2,2.6,'#9cc3b4',2.2);
    _mxCrete(ctx,w,h,.66,.13,5.1,'#86b896',2.8);
    // montgolfieres : enveloppe a fuseaux, nacelle, balancement
    function ballon(x,y,s,c1,c2){
      ctx.save(); ctx.translate(x,y); ctx.rotate(Math.sin(t*.9+x*.01)*.04);
      ctx.beginPath(); ctx.moveTo(0,s*1.45);
      ctx.bezierCurveTo(-s*.34,s*1.2,-s*1.05,s*.55,-s,-.05*s); ctx.bezierCurveTo(-s*.96,-s*.75,-s*.5,-s*1.08,0,-s*1.08);
      ctx.bezierCurveTo(s*.5,-s*1.08,s*.96,-s*.75,s,-.05*s); ctx.bezierCurveTo(s*1.05,s*.55,s*.34,s*1.2,0,s*1.45); ctx.closePath();
      ctx.fillStyle=c1; ctx.fill(); ctx.save(); ctx.clip();
      ctx.fillStyle=c2; for(var k=-2;k<=2;k+=2){ ctx.beginPath(); ctx.ellipse(k*s*.36,0,s*.15,s*1.6,0,0,2*PI); ctx.fill(); }
      var g=ctx.createRadialGradient(s*.35,-s*.45,s*.1,0,0,s*1.4); g.addColorStop(0,'rgba(255,255,255,.35)'); g.addColorStop(1,'rgba(0,0,0,.22)'); ctx.fillStyle=g; ctx.fillRect(-s*1.2,-s*1.2,s*2.4,s*2.8);
      ctx.restore();
      ctx.strokeStyle='rgba(70,45,30,.75)'; ctx.lineWidth=Math.max(.6,s*.06); ctx.beginPath();
      ctx.moveTo(-s*.2,s*1.38); ctx.lineTo(-s*.2,s*1.85); ctx.moveTo(s*.2,s*1.38); ctx.lineTo(s*.2,s*1.85); ctx.stroke();
      ctx.fillStyle='#7a4f2c'; ctx.fillRect(-s*.26,s*1.82,s*.52,s*.34); ctx.fillStyle='rgba(0,0,0,.18)'; ctx.fillRect(-s*.26,s*2.04,s*.52,s*.12);
      ctx.restore();
    }
    [[.0,.36,h*.042,'#d9493a','#f3e3c4',3.1,0],[.55,.17,h*.07,'#2f6fb8','#f2c14e',2.2,2],[.8,.47,h*.03,'#e2913b','#fff3dc',3.8,4]].forEach(function(b){
      var per=w*1.4, x=((b[0]*per+t*b[5])%per)-w*.2, y=h*b[1]+Math.sin(t*.45+b[6])*h*.03; ballon(x,y,b[2],b[3],b[4]); });
    // collines intermediaires, plus vertes
    _mxCrete(ctx,w,h,.74,.08,8.3,'#6fae5e',3.4);
    // arbres feuillus : tronc, couronne en trois masses, eclairee a droite, qui se balance au vent
    function arbre(x,y,ht,ph){ var sw=Math.sin(t*.8+ph)*ht*.025; ctx.fillStyle='#5a3a22'; ctx.beginPath(); ctx.moveTo(x-ht*.05,y); ctx.lineTo(x-ht*.03+sw*.3,y-ht*.5); ctx.lineTo(x+ht*.03+sw*.3,y-ht*.5); ctx.lineTo(x+ht*.05,y); ctx.fill();
      [[0,-.68,.3,'#3f7f3a'],[-.2,-.55,.22,'#356f33'],[.2,-.56,.22,'#4a8c42'],[.05,-.86,.2,'#5a9e4c']].forEach(function(c){ ctx.fillStyle=c[3]; ctx.beginPath(); ctx.arc(x+c[0]*ht+sw,y+c[1]*ht,c[2]*ht,0,2*PI); ctx.fill(); });
      ctx.fillStyle='rgba(255,255,210,.18)'; ctx.beginPath(); ctx.arc(x+ht*.12+sw,y-ht*.78,ht*.13,0,2*PI); ctx.fill();
      ctx.fillStyle='rgba(20,50,20,.25)'; ctx.beginPath(); ctx.ellipse(x+ht*.1,y,ht*.3,ht*.04,0,0,2*PI); ctx.fill(); }
    // le lac, entre les collines a droite : reflet du ciel, rides et scintillement
    var lx=w*.78, ly=h*.715, lrx=w*.19, lry=h*.04;
    ctx.fillStyle='#5f9a4c'; ctx.beginPath(); ctx.ellipse(lx,ly+1.5,lrx+3,lry+2.5,0,0,2*PI); ctx.fill();
    var gl=ctx.createLinearGradient(0,ly-lry,0,ly+lry); gl.addColorStop(0,'#bfe2f2'); gl.addColorStop(1,'#6fb2d6'); ctx.fillStyle=gl; ctx.beginPath(); ctx.ellipse(lx,ly,lrx,lry,0,0,2*PI); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.ellipse(lx,ly,lrx,lry,0,0,2*PI); ctx.clip();
    ctx.strokeStyle='rgba(255,255,255,.55)'; ctx.lineWidth=1; for(var lr=0;lr<9;lr++){ var rx=lx-lrx+((lr*lrx*.37+t*6)%(lrx*2)), ry=ly-lry*.6+(lr%4)*lry*.38; ctx.beginPath(); ctx.moveTo(rx,ry); ctx.lineTo(rx+w*.025,ry); ctx.stroke(); }
    for(var sc=0;sc<6;sc++){ var sa=.5+.5*Math.sin(t*2.3+sc*1.7); ctx.fillStyle='rgba(255,255,240,'+sa*.8+')'; ctx.fillRect(lx-lrx*.6+sc*lrx*.25,ly-lry*.2+(sc%2)*lry*.3,2,1); }
    ctx.restore();
    arbre(w*.6,h*.72,h*.13,1); arbre(w*.66,h*.705,h*.1,2.3); arbre(w*.97,h*.71,h*.14,3.1); arbre(w*.9,h*.69,h*.09,4.4);
    // oiseaux : vol en V qui traverse, ailes qui battent
    function oiseau(x,y,s,ph){ var a=Math.sin(t*7+ph)*s*.75; ctx.beginPath(); ctx.moveTo(x-s,y-a); ctx.quadraticCurveTo(x-s*.45,y-a*.2-s*.25,x,y); ctx.quadraticCurveTo(x+s*.45,y-a*.2-s*.25,x+s,y-a); ctx.stroke(); }
    ctx.strokeStyle='rgba(45,52,64,.85)'; ctx.lineCap='round';
    [[0,.2,1,5],[.5,.3,.8,4]].forEach(function(v,n){
      var per=w*1.6, bx=((v[0]*per+t*w*.035*v[2])%per)-w*.3, by=h*v[1]+Math.sin(t*.6+n)*h*.025;
      ctx.lineWidth=1.3*v[2];
      for(var k=0;k<v[3];k++){ var rg=Math.ceil(k/2)*(k%2?1:-1), ox=-Math.abs(rg)*h*.05*v[2], oy=rg*h*.035*v[2]+Math.sin(t*1.4+k)*1.2; oiseau(bx+ox,by+oy,h*.022*v[2],k*1.3+n); }
    });
    // ---- la forteresse ----
    var mortier='rgba(60,50,40,.18)';
    function pierre(x,y,lw,lh,dx){ // bloc de pierre texture, lumiere venant de droite
      var g=ctx.createLinearGradient(x,0,x+lw,0); g.addColorStop(0,'#8d8577'); g.addColorStop(.55,'#ada595'); g.addColorStop(1,'#c4bcab');
      ctx.fillStyle=g; ctx.fillRect(x,y,lw,lh);
      ctx.save(); ctx.beginPath(); ctx.rect(x,y,lw,lh); ctx.clip(); ctx.strokeStyle=mortier; ctx.lineWidth=.8; ctx.beginPath();
      var bh=Math.max(4,h*.024), rang=0; for(var yy=y+bh;yy<y+lh;yy+=bh,rang++){ ctx.moveTo(x,yy); ctx.lineTo(x+lw,yy); }
      rang=0; for(var y2=y;y2<y+lh;y2+=bh,rang++){ for(var xx=x+(rang%2?bh*.9:0)+(dx||0);xx<x+lw;xx+=bh*1.8){ ctx.moveTo(xx,y2); ctx.lineTo(xx,Math.min(y+lh,y2+bh)); } }
      ctx.stroke(); ctx.restore();
    }
    function creneaux(x,y,lw,n){ var c=lw/(n*2-1); ctx.fillStyle='#b1a999'; for(var k=0;k<n;k++){ ctx.fillRect(x+k*2*c,y-c*.9,c,c*.9); } }
    function fente(x,y,s){ ctx.fillStyle='#2b2620'; ctx.beginPath(); ctx.moveTo(x-s*.35,y+s*1.6); ctx.lineTo(x-s*.35,y); ctx.arc(x,y,s*.35,PI,0); ctx.lineTo(x+s*.35,y+s*1.6); ctx.fill(); }
    var bas=h*.9, U=h*.024;
    // courtine
    pierre(w*.065,h*.47,w*.335,bas-h*.47,0); creneaux(w*.065,h*.47,w*.335,9);
    // tour gauche, intacte : hourd de bois et toit conique en bardeaux, fanion
    var tx=w*.065, tw=w*.085, tt=h*.34;
    pierre(tx,tt,tw,bas-tt,U*.4); fente(tx+tw*.5,tt+h*.07,U);
    ctx.fillStyle='#6e4a2b'; ctx.fillRect(tx-tw*.12,tt-h*.065,tw*1.24,h*.065);
    ctx.strokeStyle='rgba(40,25,12,.45)'; ctx.lineWidth=.8; ctx.beginPath(); for(var p=tx-tw*.12+U*.6;p<tx+tw*1.12;p+=U*.6){ ctx.moveTo(p,tt-h*.065); ctx.lineTo(p,tt); } ctx.stroke();
    ctx.fillStyle='rgba(20,12,6,.35)'; ctx.fillRect(tx-tw*.12,tt-h*.012,tw*1.24,h*.012);
    var g=ctx.createLinearGradient(tx,0,tx+tw,0); g.addColorStop(0,'#6b3f22'); g.addColorStop(1,'#a0643a');
    ctx.fillStyle=g; ctx.beginPath(); ctx.moveTo(tx-tw*.22,tt-h*.06); ctx.lineTo(tx+tw*.5,tt-h*.17); ctx.lineTo(tx+tw*1.22,tt-h*.06); ctx.closePath(); ctx.fill();
    ctx.strokeStyle='rgba(50,28,14,.35)'; ctx.beginPath(); for(var k=1;k<5;k++){ var f=k/5; ctx.moveTo(tx+tw*.5-(tw*.72)*f,tt-h*.17+h*.16*f); ctx.lineTo(tx+tw*.5+(tw*.72)*f,tt-h*.17+h*.16*f); } ctx.stroke();
    var mx=tx+tw*.5, my=tt-h*.17; ctx.strokeStyle='#3a2a1a'; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(mx,my); ctx.lineTo(mx,my-h*.07); ctx.stroke();
    ctx.fillStyle='#b8323a'; ctx.beginPath(); ctx.moveTo(mx,my-h*.07);
    for(var q=0;q<=6;q++){ var fx=mx+q*h*.012, fy=my-h*.07+Math.sin(t*4-q*.9)*h*.008*q/6; ctx.lineTo(fx,fy); }
    for(q=6;q>=0;q--){ fx=mx+q*h*.012; fy=my-h*.045+Math.sin(t*4-q*.9)*h*.008*q/6-(q/6)*h*.012; ctx.lineTo(fx,fy); } ctx.fill();
    // donjon : pierre en bas, etage de bois a demi brule, sommet effondre
    var dx0=w*.17, dw=w*.12, dt=h*.31;
    pierre(dx0,dt,dw,bas-dt,U*.2); fente(dx0+dw*.3,dt+h*.08,U); fente(dx0+dw*.7,dt+h*.08,U); fente(dx0+dw*.5,dt+h*.2,U*.9);
    // etage de bois restant (colombage), bord droit dechire
    var et=dt-h*.075; ctx.fillStyle='#8a5c34'; ctx.beginPath(); ctx.moveTo(dx0-U*.3,dt); ctx.lineTo(dx0-U*.3,et); ctx.lineTo(dx0+dw*.45,et+h*.01); ctx.lineTo(dx0+dw*.55,et+h*.035); ctx.lineTo(dx0+dw*.62,et+h*.03); ctx.lineTo(dx0+dw*.72,dt-h*.012); ctx.lineTo(dx0+dw,dt); ctx.closePath(); ctx.fill();
    ctx.strokeStyle='#4a2f19'; ctx.lineWidth=1.4; ctx.beginPath(); ctx.moveTo(dx0-U*.3,et+h*.002); ctx.lineTo(dx0+dw*.45,et+h*.012);
    ctx.moveTo(dx0+dw*.05,dt); ctx.lineTo(dx0+dw*.05,et+h*.004); ctx.moveTo(dx0+dw*.25,dt); ctx.lineTo(dx0+dw*.25,et+h*.007); ctx.moveTo(dx0+dw*.05,dt); ctx.lineTo(dx0+dw*.25,et+h*.007); ctx.moveTo(dx0+dw*.42,dt); ctx.lineTo(dx0+dw*.42,et+h*.012); ctx.stroke();
    // poutres calcinees qui depassent
    ctx.strokeStyle='#2a1e16'; ctx.lineWidth=2.2; ctx.beginPath();
    ctx.moveTo(dx0+dw*.55,et+h*.03); ctx.lineTo(dx0+dw*.66,et-h*.05); ctx.moveTo(dx0+dw*.78,dt-h*.01); ctx.lineTo(dx0+dw*.95,et-h*.02); ctx.moveTo(dx0+dw*.4,et+h*.01); ctx.lineTo(dx0+dw*.36,et-h*.035); ctx.stroke();
    ctx.fillStyle='rgba(35,28,22,.55)'; ctx.fillRect(dx0+dw*.55,dt-h*.004,dw*.45,h*.03); // suie
    // breche dans la courtine et tour droite effondree
    var bx0=w*.33, bw=w*.075, bt=h*.41;
    ctx.save(); ctx.beginPath(); ctx.moveTo(bx0,bas); ctx.lineTo(bx0,bt+h*.01); ctx.lineTo(bx0+bw*.2,bt+h*.045); ctx.lineTo(bx0+bw*.4,bt+h*.015); ctx.lineTo(bx0+bw*.62,bt+h*.075); ctx.lineTo(bx0+bw*.8,bt+h*.035); ctx.lineTo(bx0+bw,bt+h*.065); ctx.lineTo(bx0+bw,bas); ctx.closePath(); ctx.clip();
    pierre(bx0,bt,bw,bas-bt,U*.6); ctx.restore();
    fente(bx0+bw*.5,bt+h*.12,U*.9);
    // lierre sur la pierre
    r=_mxR(21); for(i=0;i<26;i++){ var lx=w*.07+r()*w*.32, ly=h*.45+r()*h*.12; ctx.fillStyle=r()>.5?'rgba(70,128,58,.9)':'rgba(96,152,70,.9)'; ctx.beginPath(); ctx.arc(lx,ly+Math.sin(t*1.2+i)*.4,U*(.25+r()*.35),0,2*PI); ctx.fill(); }
    // palissade de bois sur le flanc droit, quelques pieux tombes
    for(i=0;i<9;i++){ var sxp=w*.405+i*w*.016, syp=butte(sxp)-h*.002, ht=h*(.055+(i%3)*.008), inc=(i==4||i==7)?.55:((i%2)?.06:-.04);
      ctx.save(); ctx.translate(sxp,syp+h*.02); ctx.rotate(inc); ctx.fillStyle=i%2?'#7b5130':'#8f6038'; ctx.beginPath(); ctx.moveTo(-U*.3,0); ctx.lineTo(-U*.3,-ht); ctx.lineTo(0,-ht-U*.45); ctx.lineTo(U*.3,-ht); ctx.lineTo(U*.3,0); ctx.fill(); ctx.restore(); }
    // la butte recouvre la base : la forteresse est assise DANS le terrain
    var gb=ctx.createLinearGradient(0,h*.5,0,h); gb.addColorStop(0,'#78b55e'); gb.addColorStop(1,'#4f8f3f');
    ctx.fillStyle=gb; ctx.beginPath(); ctx.moveTo(-2,h); for(var xb=-2;xb<=w+3;xb+=3){ ctx.lineTo(xb,butte(xb)); } ctx.lineTo(w+3,h); ctx.closePath(); ctx.fill();
    // levre d herbe et rochers au pied des murs
    ctx.fillStyle='#8cc56a'; ctx.beginPath(); for(xb=w*.04;xb<=w*.5;xb+=3){ ctx.lineTo(xb,butte(xb)-1.2-Math.abs(Math.sin(xb*.9))*1.6); } for(xb=w*.5;xb>=w*.04;xb-=3){ ctx.lineTo(xb,butte(xb)+2); } ctx.fill();
    r=_mxR(5); for(i=0;i<10;i++){ var rx=w*(.05+r()*.4), ry=butte(rx)+h*.012+r()*h*.02, rs=U*(.35+r()*.5); ctx.fillStyle='#968e80'; ctx.beginPath(); ctx.ellipse(rx,ry,rs*1.4,rs,0,0,2*PI); ctx.fill(); ctx.fillStyle='rgba(255,255,255,.25)'; ctx.beginPath(); ctx.ellipse(rx+rs*.3,ry-rs*.3,rs*.6,rs*.35,0,0,2*PI); ctx.fill(); }
    // eboulis au pied de la tour effondree
    r=_mxR(33); for(i=0;i<9;i++){ var ex=w*(.33+r()*.09), ey=butte(ex)+h*.004-r()*h*.012; ctx.fillStyle=i%2?'#a39b8b':'#8a8274'; ctx.fillRect(ex,ey,U*(.4+r()*.5),U*(.3+r()*.35)); }
    // fumee des ruines : deux panaches gris, poussees vers la droite
    [[dx0+dw*.7,et-h*.01,24,1],[bx0+bw*.5,bt+h*.03,14,.6]].forEach(function(src,j){
      for(var s=0;s<src[2];s++){ var pp=((t*.05+s/src[2]+j*.37)%1), px2=src[0]+pp*w*.32+Math.sin(t*.8+s*1.7)*w*.012*pp, py2=src[1]-pp*h*.42, pr=w*(.018+pp*.075)*src[3];
        _mxPoint(ctx,px2,py2,pr,pp<.25?'78,72,70':'132,128,128',Math.min(1,pp*6)*(1-pp)*.68*src[3]); } });
    ctx.globalAlpha=1;
    // pre du premier plan
    var gp=ctx.createLinearGradient(0,h*.78,0,h); gp.addColorStop(0,'#5f9f48'); gp.addColorStop(1,'#2f5f2c');
    ctx.fillStyle=gp; ctx.beginPath(); ctx.moveTo(0,h); for(var x3=0;x3<=w;x3+=4) ctx.lineTo(x3,pre(x3)); ctx.lineTo(w,h); ctx.closePath(); ctx.fill();
    // fleurs : sur la butte, les collines et le pre, qui ondulent au vent
    var COUL=['#ffffff','#ffd84a','#ff8fb3','#c58cff','#ff6b5a','#fff2a8'];
    r=_mxR(9); for(i=0;i<70;i++){ var fxp=r()*w, zone=r(), fyp, fs;
      if(fxp<w*.6&&zone<.45){ fyp=butte(fxp)+h*.02+r()*(h*.95-butte(fxp)); } else { fyp=pre(fxp)+h*.01+r()*h*.1; }
      if(fxp>w*.36&&fxp<w*.64&&fyp>h*.62) { r(); continue; } // pas devant le marchand
      fs=.8+r()*1.3+(fyp/h-.6)*2.2; var bal=Math.sin(t*1.6+fxp*.05)*fs*.6;
      ctx.strokeStyle='rgba(50,100,40,.8)'; ctx.lineWidth=.7; ctx.beginPath(); ctx.moveTo(fxp,fyp+fs*2.2); ctx.lineTo(fxp+bal,fyp); ctx.stroke();
      ctx.fillStyle=COUL[i%COUL.length]; ctx.beginPath(); ctx.arc(fxp+bal,fyp,fs,0,2*PI); ctx.fill();
      if(fs>1.6){ ctx.fillStyle='#e8a521'; ctx.beginPath(); ctx.arc(fxp+bal,fyp,fs*.38,0,2*PI); ctx.fill(); } }
    // herbes hautes qui se couchent au vent, sur les bords
    ctx.lineWidth=1.1; r=_mxR(17); for(i=0;i<46;i++){ var gx=r()<.5?r()*w*.34:w*.66+r()*w*.34, gy=h*(.95+r()*.06), gh=h*(.05+r()*.06), ve=Math.sin(t*1.3+gx*.03)*gh*.35+gh*.12;
      ctx.strokeStyle=i%3?'rgba(58,110,44,.9)':'rgba(96,150,62,.9)'; ctx.beginPath(); ctx.moveTo(gx,gy); ctx.quadraticCurveTo(gx+ve*.3,gy-gh*.6,gx+ve,gy-gh); ctx.stroke(); }
    // petit cimetiere au bord du pre : croix de pierre penchees, tertres, mousse
    function croix(x,y,ht,a){ ctx.save(); ctx.translate(x,y); ctx.rotate(a); ctx.fillStyle='rgba(40,70,30,.35)'; ctx.beginPath(); ctx.ellipse(ht*.05,0,ht*.45,ht*.08,0,0,2*PI); ctx.fill();
      ctx.fillStyle='#4e4a44'; ctx.fillRect(-ht*.09,-ht-1,ht*.18+1,ht+1); ctx.fillRect(-ht*.32,-ht*.8,ht*.64+1,ht*.17); ctx.fillStyle='#9a958a'; ctx.fillRect(-ht*.07,-ht,ht*.14,ht); ctx.fillRect(-ht*.3,-ht*.78,ht*.6,ht*.13);
      ctx.fillStyle='#c2bdb0'; ctx.fillRect(ht*.02,-ht,ht*.05,ht); ctx.fillRect(-ht*.3,-ht*.78,ht*.6,ht*.04);
      ctx.fillStyle='rgba(80,120,60,.8)'; ctx.beginPath(); ctx.arc(-ht*.05,-ht*.12,ht*.07,0,2*PI); ctx.arc(-ht*.25,-ht*.72,ht*.05,0,2*PI); ctx.fill();
      ctx.restore(); }
    [[.69,.86,.11,-.08],[.76,.845,.09,.06],[.84,.865,.12,-.03],[.9,.845,.08,.12],[.79,.9,.1,.04],[.95,.88,.1,-.1]].forEach(function(c){ croix(w*c[0],h*c[1],h*c[2],c[3]); });
    arbre(w*.03,h*.93,h*.3,5.2); arbre(w*1.0,h*.96,h*.26,6.1);
    // papillons
    [[.2,.78,'#ffb02e',0],[.78,.72,'#f4f0ff',2.1],[.6,.6,'#ff7aa8',4.2]].forEach(function(b){
      var bx2=w*b[0]+Math.sin(t*.37+b[3])*w*.09, by2=h*b[1]+Math.sin(t*.71+b[3]*1.3)*h*.06+Math.sin(t*3.1+b[3])*h*.01, ail=Math.abs(Math.sin(t*11+b[3]))*.85+.15, s2=h*.016;
      ctx.fillStyle=b[2]; ctx.save(); ctx.translate(bx2,by2);
      ctx.beginPath(); ctx.ellipse(-s2*.55*ail,-s2*.2,s2*.6*ail,s2*.5,-.4,0,2*PI); ctx.ellipse(s2*.55*ail,-s2*.2,s2*.6*ail,s2*.5,.4,0,2*PI); ctx.fill();
      ctx.beginPath(); ctx.ellipse(-s2*.4*ail,s2*.35,s2*.4*ail,s2*.32,.3,0,2*PI); ctx.ellipse(s2*.4*ail,s2*.35,s2*.4*ail,s2*.32,-.3,0,2*PI); ctx.fill();
      ctx.fillStyle='#3b2a1e'; ctx.fillRect(-.6,-s2*.5,1.2,s2*1.1); ctx.restore(); });
  },
  // 1 - ALCHIMISTE : Montpellier muree, la tour d Alienor et ses vapeurs ;
  // au loin a gauche, un bucher en feu ; devant, son etabli et deux alambics
  // en marche ; a droite, deux passants caches derriere une charrette
  function(ctx,w,h,t){
    _mxCiel(ctx,w,h,[[0,'#060d26'],[.55,'#132a5c'],[1,'#2b4a7c']]);
    _mxEtoiles(ctx,w,h,90,11,t,.9,.7);
    var lx=w*.5, ly=h*.15; _mxHalo(ctx,lx,ly,w*.3,'rgba(190,210,255,.45)',1); ctx.fillStyle='#eef2ff'; ctx.beginPath(); ctx.arc(lx,ly,h*.075,0,7); ctx.fill(); ctx.fillStyle='rgba(160,180,220,.35)'; ctx.beginPath(); ctx.arc(lx-4,ly-3,h*.02,0,7); ctx.arc(lx+5,ly+6,h*.014,0,7); ctx.fill();
    _mxCrete(ctx,w,h,.72,.07,2.4,'#1a2f5a',2.5);
    // le bucher, au loin sur une butte a gauche, au-dessus des toits
    var bxx=w*.25, byy=h*.53, fl=.75+.25*Math.sin(t*5.3)*Math.sin(t*3.1+1);
    // butte en silhouette, plus sombre que le ciel, et son bord eclaire par le feu
    ctx.fillStyle='#0b1630'; ctx.beginPath(); ctx.moveTo(-w*.02,h*.8); ctx.quadraticCurveTo(w*.1,byy-h*.005,bxx,byy); ctx.quadraticCurveTo(w*.4,byy-h*.005,w*.52,h*.8); ctx.closePath(); ctx.fill();
    var rim=ctx.createRadialGradient(bxx,byy,0,bxx,byy,w*.2); rim.addColorStop(0,'rgba(255,150,70,'+(.85*fl)+')'); rim.addColorStop(1,'rgba(255,150,70,0)');
    ctx.strokeStyle=rim; ctx.lineWidth=1.6; ctx.beginPath(); ctx.moveTo(-w*.02,h*.8); ctx.quadraticCurveTo(w*.1,byy-h*.005,bxx,byy); ctx.quadraticCurveTo(w*.4,byy-h*.005,w*.52,h*.8); ctx.stroke();
    _mxHalo(ctx,bxx,byy-h*.04,w*.22,'rgba(255,120,40,.5)',fl);
    var lb=ctx.createRadialGradient(bxx,byy,0,bxx,byy,w*.12); lb.addColorStop(0,'rgba(255,140,60,'+(.35*fl)+')'); lb.addColorStop(1,'rgba(255,140,60,0)'); ctx.fillStyle=lb; ctx.beginPath(); ctx.ellipse(bxx,byy+h*.03,w*.12,h*.05,0,0,7); ctx.fill();
    // fumee sombre qui monte et derive
    for(var sm=0;sm<16;sm++){ var ps=((t*.06+sm/16)%1); _mxPoint(ctx,bxx+ps*w*.12+Math.sin(t*.7+sm)*w*.01,byy-h*.1-ps*h*.42,w*(.012+ps*.06),'40,40,58',Math.min(1,ps*5)*(1-ps)*.55); }
    ctx.globalAlpha=1;
    // poteau et fagots
    ctx.fillStyle='#2a1a14'; ctx.fillRect(bxx-1,byy-h*.1,2,h*.1);
    ctx.fillStyle='#3b2418'; ctx.beginPath(); ctx.moveTo(bxx-w*.04,byy); ctx.lineTo(bxx-w*.025,byy-h*.035); ctx.lineTo(bxx+w*.025,byy-h*.035); ctx.lineTo(bxx+w*.04,byy); ctx.fill();
    // flammes : langues qui vacillent
    for(var lf=0;lf<7;lf++){ var lfx=bxx+(lf-3)*w*.008, ph=Math.sin(t*(6+lf*.7)+lf*2.1), lh=h*(.03+.025*(1-Math.abs(lf-3)/3))*(1+.25*ph);
      var gf=ctx.createLinearGradient(0,byy-h*.02-lh,0,byy-h*.01); gf.addColorStop(0,'rgba(255,240,150,0)'); gf.addColorStop(.35,'rgba(255,190,70,.9)'); gf.addColorStop(1,'rgba(240,80,30,.95)'); ctx.fillStyle=gf;
      ctx.beginPath(); ctx.moveTo(lfx-3.5,byy-h*.01); ctx.quadraticCurveTo(lfx-4,byy-h*.02-lh*.5,lfx+Math.sin(t*4+lf)*2.5,byy-h*.02-lh); ctx.quadraticCurveTo(lfx+4,byy-h*.02-lh*.5,lfx+3.5,byy-h*.01); ctx.fill(); }
    // cote exacte de la crete (les deux courbes de Bezier de la butte), pour poser la foule dessus
    function crete(x){ var P=x<bxx?[-w*.02,h*.8,w*.1,byy-h*.005,bxx,byy]:[bxx,byy,w*.4,byy-h*.005,w*.52,h*.8], lo=0, hi=1;
      for(var it=0;it<22;it++){ var m=(lo+hi)/2, xm=(1-m)*(1-m)*P[0]+2*(1-m)*m*P[2]+m*m*P[4]; if(xm<x) lo=m; else hi=m; }
      var u=(lo+hi)/2; return (1-u)*(1-u)*P[1]+2*(1-u)*u*P[3]+u*u*P[5]; }
    // la foule qui regarde, sur la crete de la butte
    var rf=_mxR(77); for(var pe=0;pe<9;pe++){ var u=(pe<4?-1:1)*(.035+rf()*.07), pxx=bxx+u*w, cr=(pxx-bxx)/(w*.25), pyy=crete(pxx)+1.5, ph2=h*(.028+rf()*.01), sw=Math.sin(t*1.1+pe*1.7)*.6;
      ctx.fillStyle='#070d20'; ctx.beginPath(); ctx.moveTo(pxx-ph2*.28,pyy); ctx.lineTo(pxx-ph2*.2+sw,pyy-ph2*.7); ctx.lineTo(pxx+ph2*.2+sw,pyy-ph2*.7); ctx.lineTo(pxx+ph2*.28,pyy); ctx.fill(); ctx.beginPath(); ctx.arc(pxx+sw,pyy-ph2*.82,ph2*.17,0,7); ctx.fill();
      ctx.fillStyle='rgba(255,150,70,'+(.5*fl)+')'; ctx.fillRect(pxx+(u<0?ph2*.16:-ph2*.22)+sw,pyy-ph2*.7,1,ph2*.6); }
    // etincelles qui montent
    var rb=_mxR(41); for(var sp=0;sp<14;sp++){ var p5=((t*(.12+rb()*.1)+rb())%1); ctx.globalAlpha=(1-p5)*(.6+.4*Math.sin(t*9+sp)); ctx.fillStyle=sp%2?'#ffd27a':'#ff8a3a'; ctx.fillRect(bxx+(rb()-.5)*w*.05+p5*w*.04+Math.sin(t*2+sp)*3,byy-h*.05-p5*h*.25,1.4,1.4); }
    ctx.globalAlpha=1;
    // la ville muree
    var r=_mxR(5), base=h*.8; ctx.fillStyle='#0f1d3d';
    for(var x=0;x<w;){ var bw=10+r()*16, bh=h*(.05+r()*.07); ctx.beginPath(); ctx.moveTo(x,base); ctx.lineTo(x,base-bh); ctx.lineTo(x+bw/2,base-bh-bw*.45); ctx.lineTo(x+bw,base-bh); ctx.lineTo(x+bw,base); ctx.fill(); x+=bw-1; }
    ctx.beginPath(); ctx.moveTo(w*.33,base-h*.1); ctx.lineTo(w*.345,base-h*.25); ctx.lineTo(w*.36,base-h*.1); ctx.fill(); ctx.fillRect(w*.325,base-h*.11,w*.045,h*.11);
    var r2=_mxR(9); for(var f=0;f<26;f++){ var fx=r2()*w, fy=base-h*(.02+r2()*.08), on=Math.sin(t*.4+f*2.3)>-.6; if(on){ ctx.fillStyle='rgba(255,200,110,'+(.5+.3*Math.sin(t*2+f))+')'; ctx.fillRect(fx,fy,2,2.5); } }
    ctx.fillStyle='#0a1530'; ctx.fillRect(0,base,w,h*.06); for(var c=0;c<w;c+=9) ctx.fillRect(c,base-4,5,4);
    _mxBrume(ctx,w,h,base+h*.03,h*.05,'rgba(140,170,230,.25)',t,6,1);
    // la tour sur la colline, a droite
    var tx=w*.83; ctx.fillStyle='#0a1430'; ctx.beginPath(); ctx.moveTo(w*.62,h); ctx.quadraticCurveTo(w*.75,h*.66,tx,h*.66); ctx.quadraticCurveTo(w*.95,h*.66,w*1.05,h*.8); ctx.lineTo(w,h); ctx.fill();
    ctx.fillRect(tx-w*.035,h*.44,w*.07,h*.23); ctx.beginPath(); ctx.moveTo(tx-w*.05,h*.45); ctx.lineTo(tx,h*.34); ctx.lineTo(tx+w*.05,h*.45); ctx.fill(); ctx.fillRect(tx+w*.014,h*.33,w*.012,h*.07);
    var fen=.75+.25*Math.sin(t*1.7)*Math.sin(t*2.9); _mxHalo(ctx,tx,h*.53,w*.12,'rgba(120,255,210,.5)',fen); ctx.fillStyle='rgba(170,255,220,'+fen+')'; ctx.fillRect(tx-3,h*.5,6,10);
    // vapeurs : trois rubans qui montent et se perdent dans les etoiles
    var cols=['120,240,210','255,210,120','190,160,255'];
    for(var v=0;v<3;v++){ for(var k=0;k<40;k++){ var p=((t*.03+k/40+v*.13)%1), vx=tx+w*.02-p*w*(.28+v*.14)+Math.sin(p*5+t*.45+v*2.1)*w*(.015+p*.07), vy=h*.33-p*h*(.27-v*.03)-Math.sin(p*3.1)*h*.03; _mxPoint(ctx,vx,vy,4+p*w*.06,cols[v],Math.min(1,p*6)*(1-p)*.42); } }
    ctx.globalAlpha=1;
    var r3=_mxR(21); for(var e=0;e<18;e++){ var p3=((t*.02+r3())%1), ex=tx-w*.15-p3*w*.5+Math.sin(t+e)*10, ey=h*.12-p3*h*.06; ctx.globalAlpha=Math.sin(p3*Math.PI)*(.5+.5*Math.sin(t*3+e)); ctx.fillStyle='#fff'; ctx.fillRect(ex,ey,1.5,1.5); }
    ctx.globalAlpha=1;
    _mxCrete(ctx,w,h,1.03,.1,6.2,'#050b1c',1.5);
    // ---- premier plan ----
    // etabli a gauche, eclaire par le brasero
    var tb=h*.8, flb=.8+.2*Math.sin(t*7)*Math.sin(t*4.3);
    _mxHalo(ctx,w*.13,tb-h*.05,w*.3,'rgba(255,150,70,.45)',flb);
    ctx.fillStyle='#3a2416'; ctx.fillRect(w*.02,tb,w*.31,h*.03); ctx.fillStyle='#2a190f'; ctx.fillRect(w*.04,tb+h*.03,w*.022,h*.2); ctx.fillRect(w*.29,tb+h*.03,w*.022,h*.2);
    ctx.fillStyle='rgba(255,170,90,.35)'; ctx.fillRect(w*.02,tb,w*.31,1.5);
    // alambic de cuivre sur son brasero : cucurbite, chapiteau, bec, recipient
    var ax=w*.1, ay=tb-h*.03;
    ctx.fillStyle='#2b2b30'; ctx.fillRect(ax-w*.04,ay,w*.08,h*.03); ctx.fillStyle='#1c1c20'; ctx.fillRect(ax-w*.042,ay-2,w*.084,3);
    for(var bf=0;bf<4;bf++){ var bfx=ax-w*.026+bf*w*.017, bfh=h*(.025+.012*Math.sin(t*9+bf*1.7)); ctx.fillStyle=bf%2?'rgba(255,200,90,.95)':'rgba(255,120,40,.95)'; ctx.beginPath(); ctx.moveTo(bfx-3,ay); ctx.quadraticCurveTo(bfx,ay-bfh*1.3,bfx+3,ay); ctx.fill(); }
    var cu=ctx.createRadialGradient(ax+w*.012,ay-h*.11,2,ax,ay-h*.085,w*.06); cu.addColorStop(0,'#f0b07a'); cu.addColorStop(.6,'#b5633b'); cu.addColorStop(1,'#6a3018');
    ctx.fillStyle=cu; ctx.beginPath(); ctx.ellipse(ax,ay-h*.075,w*.048,h*.07,0,0,7); ctx.fill();
    ctx.beginPath(); ctx.moveTo(ax-w*.016,ay-h*.14); ctx.lineTo(ax-w*.012,ay-h*.18); ctx.lineTo(ax+w*.012,ay-h*.18); ctx.lineTo(ax+w*.016,ay-h*.14); ctx.fill();
    ctx.beginPath(); ctx.ellipse(ax,ay-h*.2,w*.026,h*.03,0,0,7); ctx.fill();
    ctx.strokeStyle='#a8572f'; ctx.lineWidth=2.6; ctx.lineCap='round'; ctx.beginPath(); ctx.moveTo(ax+w*.02,ay-h*.2); ctx.quadraticCurveTo(ax+w*.1,ay-h*.21,ax+w*.14,ay-h*.1); ctx.stroke();
    // recipient de verre qui se remplit, goutte qui tombe du bec
    var rx=ax+w*.15, ry=tb-h*.045; ctx.fillStyle='rgba(180,230,255,.25)'; ctx.strokeStyle='rgba(220,240,255,.7)'; ctx.lineWidth=1;
    ctx.beginPath(); ctx.arc(rx,ry,h*.04,0,7); ctx.fill(); ctx.stroke(); ctx.fillRect(rx-2,ry-h*.07,4,h*.035);
    var niv=.45+.1*Math.sin(t*.2); ctx.save(); ctx.beginPath(); ctx.arc(rx,ry,h*.04-1,0,7); ctx.clip(); ctx.fillStyle='rgba(242,201,78,.85)'; ctx.fillRect(rx-h*.05,ry+h*.04-h*.08*niv,h*.1,h*.08); ctx.restore();
    var gt=(t*1.3)%1; ctx.fillStyle='rgba(255,220,120,'+(1-gt*.3)+')'; ctx.beginPath(); ctx.arc(ax+w*.14,ay-h*.1+gt*h*.06,1.5,0,7); ctx.fill();
    // vapeur du chapiteau
    for(var vp=0;vp<8;vp++){ var pv=((t*.25+vp/8)%1); _mxPoint(ctx,ax-w*.01+Math.sin(t+vp)*4,ay-h*.24-pv*h*.16,4+pv*10,'220,230,255',(1-pv)*Math.min(1,pv*5)*.35); } ctx.globalAlpha=1;
    // second alambic : cornue de verre sur une chandelle, bulles
    var cx2=w*.29, cy2=tb-h*.06;
    ctx.fillStyle='#e8e0c8'; ctx.fillRect(cx2-3,tb-h*.025,6,h*.025); ctx.fillStyle='rgba(255,210,110,'+(.8+.2*Math.sin(t*11))+')'; ctx.beginPath(); ctx.ellipse(cx2,tb-h*.032,2.2,4+Math.sin(t*13),0,0,7); ctx.fill();
    ctx.strokeStyle='#4a3a2a'; ctx.lineWidth=1.4; ctx.beginPath(); ctx.moveTo(cx2-8,tb); ctx.lineTo(cx2-6,cy2+h*.035); ctx.moveTo(cx2+8,tb); ctx.lineTo(cx2+6,cy2+h*.035); ctx.stroke();
    ctx.fillStyle='rgba(150,110,255,.55)'; ctx.strokeStyle='rgba(225,215,255,.8)'; ctx.lineWidth=1; ctx.beginPath(); ctx.arc(cx2,cy2,h*.032,0,7); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx2+h*.022,cy2-h*.022); ctx.quadraticCurveTo(cx2+w*.03,cy2-h*.1,cx2+w*.06,cy2-h*.06); ctx.lineWidth=3; ctx.strokeStyle='rgba(225,215,255,.6)'; ctx.stroke();
    for(var bl=0;bl<5;bl++){ var pb=((t*.9+bl/5)%1); ctx.fillStyle='rgba(240,235,255,'+(1-pb)+')'; ctx.beginPath(); ctx.arc(cx2+Math.sin(bl*2.3)*h*.015,cy2+h*.02-pb*h*.04,1.1,0,7); ctx.fill(); }
    // ---- la charrette, et deux curieux qui epient derriere ----
    var kx=w*.67, ky=h*.8, kw=w*.27;
    function guetteur(x,y,s,ph,cap){ // tete qui monte, epie, redescend ; yeux qui luisent
      var c=(t+ph)%7, u=c<1.5?0:c<2.3?(c-1.5)/.8:c<5?1:c<5.6?1-(c-5)/.6:0; u=u*u*(3-2*u);
      var yy=y+s*1.6*(1-u);
      ctx.fillStyle=cap; ctx.beginPath(); ctx.arc(x,yy,s,0,7); ctx.fill(); ctx.fillRect(x-s,yy,s*2,s*1.6);
      ctx.fillStyle='#b99882'; ctx.beginPath(); ctx.ellipse(x-s*.25,yy+s*.25,s*.62,s*.7,0,0,7); ctx.fill();
      var reg=Math.sin(t*.9+ph)*s*.08; ctx.fillStyle='#fff6e0'; ctx.fillRect(x-s*.62+reg,yy+s*.1,s*.22,s*.18); ctx.fillRect(x-s*.12+reg,yy+s*.1,s*.22,s*.18);
      ctx.fillStyle='#1a1a22'; ctx.fillRect(x-s*.6+reg,yy+s*.13,s*.12,s*.13); ctx.fillRect(x-s*.1+reg,yy+s*.13,s*.12,s*.13);
      ctx.fillStyle=cap; ctx.fillRect(x+s*.2,yy-s*.2,s*.7,s*1.4); }
    guetteur(kx+kw*.89,ky-h*.09,h*.034,0,'#3c2f4a');
    guetteur(kx+kw*.5,ky-h*.1,h*.03,3.2,'#2f3f36');
    // chargement : sacs et tonneau
    ctx.fillStyle='#8a7a5a'; ctx.beginPath(); ctx.ellipse(kx+kw*.2,ky-h*.02,kw*.13,h*.04,0,0,7); ctx.fill(); ctx.beginPath(); ctx.ellipse(kx+kw*.52,ky-h*.025,kw*.14,h*.045,0,0,7); ctx.fill();
    ctx.fillStyle='#6a4428'; ctx.fillRect(kx+kw*.82,ky-h*.06,kw*.14,h*.065); ctx.fillStyle='#3a2a1c'; ctx.fillRect(kx+kw*.82,ky-h*.045,kw*.14,2); ctx.fillRect(kx+kw*.82,ky-h*.015,kw*.14,2);
    // caisse de la charrette
    ctx.fillStyle='#5a3a22'; ctx.fillRect(kx,ky,kw,h*.075); ctx.strokeStyle='rgba(20,10,5,.5)'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(kx,ky+h*.025); ctx.lineTo(kx+kw,ky+h*.025); ctx.moveTo(kx,ky+h*.05); ctx.lineTo(kx+kw,ky+h*.05); ctx.stroke();
    ctx.fillStyle='rgba(170,190,240,.22)'; ctx.fillRect(kx,ky,kw,1.5);
    ctx.strokeStyle='#4a2f1b'; ctx.lineWidth=3; ctx.beginPath(); ctx.moveTo(kx,ky+h*.06); ctx.lineTo(kx-w*.09,ky+h*.12); ctx.stroke();
    // roue
    var wx=kx+kw*.55, wy=ky+h*.1, wr=h*.075; ctx.strokeStyle='#3a2414'; ctx.lineWidth=3.2; ctx.beginPath(); ctx.arc(wx,wy,wr,0,7); ctx.stroke(); ctx.lineWidth=1.8;
    ctx.beginPath(); for(var sk=0;sk<8;sk++){ var an=sk*Math.PI/4; ctx.moveTo(wx,wy); ctx.lineTo(wx+Math.cos(an)*wr,wy+Math.sin(an)*wr); } ctx.stroke(); ctx.fillStyle='#2a1a0e'; ctx.beginPath(); ctx.arc(wx,wy,3,0,7); ctx.fill();
    var r4=_mxR(33); for(var l=0;l<10;l++){ var lx2=r4()*w+Math.sin(t*.3+l)*20, ly2=h*(.86+r4()*.1)+Math.sin(t*.5+l*2)*6; ctx.globalAlpha=.4+.4*Math.sin(t*1.5+l*1.3); ctx.fillStyle='#d8ffb0'; ctx.fillRect(lx2,ly2,1.6,1.6); }
    ctx.globalAlpha=1;
  },
  // 2 - ENLUMINEUR : le Mont au couchant, monastere fortifie (remparts, tours,
  // abbaye, fleche), drapeaux au vent ; une flotte s eloigne vers l horizon ;
  // au premier plan un navire coule ; dauphins qui sautent ; mouettes.
  function(ctx,w,h,t){
    var PI=Math.PI, k, i;
    _mxCiel(ctx,w,h,[[0,'#2a1636'],[.33,'#7a3a4a'],[.55,'#e0864a'],[.62,'#f6c56a'],[1,'#f6c56a']]);
    var hz=h*.6, sx=w*.34, sy=hz-h*.07-h*.015*Math.sin(t*.06);
    ctx.save(); ctx.translate(sx,sy); ctx.rotate(t*.012); for(k=0;k<14;k++){ ctx.rotate(PI*2/14); ctx.globalAlpha=.05+.04*Math.sin(t*.5+k); ctx.fillStyle='#ffe2a0'; ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(w*1.2,-w*.05); ctx.lineTo(w*1.2,w*.05); ctx.fill(); } ctx.restore(); ctx.globalAlpha=1;
    _mxHalo(ctx,sx,sy,w*.4,'rgba(255,220,140,.8)',1); ctx.fillStyle='#fff3cf'; ctx.beginPath(); ctx.arc(sx,sy,h*.06,0,2*PI); ctx.fill();
    for(var n=0;n<5;n++){ var ny=h*(.14+n*.07), nx=((t*(2+n)+n*90)%(w+200))-100; ctx.globalAlpha=.32; ctx.fillStyle=n<2?'#c46a6a':'#f0a070'; ctx.beginPath(); ctx.ellipse(nx,ny,w*.22,h*.011,0,0,7); ctx.ellipse(nx+w*.5,ny+6,w*.16,h*.009,0,0,7); ctx.fill(); }
    ctx.globalAlpha=1;
    // la mer, scintillement du soleil
    var gm=ctx.createLinearGradient(0,hz,0,h); gm.addColorStop(0,'#f2b56a'); gm.addColorStop(.35,'#c0705a'); gm.addColorStop(1,'#3e2440'); ctx.fillStyle=gm; ctx.fillRect(0,hz,w,h-hz);
    for(var q=0;q<30;q++){ var qy=hz+2+q*q*.14, qw=(14-q*.25)*(1+Math.sin(t*1.2+q)*.3); ctx.globalAlpha=Math.max(0,.6-q*.018); ctx.fillStyle='#fff0c0'; ctx.fillRect(sx-qw+Math.sin(t*2+q)*4,qy,qw*2,1.2); }
    ctx.globalAlpha=1;
    // vaguelettes
    ctx.strokeStyle='rgba(255,225,180,.28)'; ctx.lineWidth=1; var rv=_mxR(12); for(k=0;k<26;k++){ var vx=rv()*w, vy=hz+h*.03+rv()*h*.35, vl=4+rv()*10*(vy/h); vx=(vx+t*(3+vy/h*6))%w; ctx.beginPath(); ctx.moveTo(vx,vy); ctx.quadraticCurveTo(vx+vl/2,vy-1.5,vx+vl,vy); ctx.stroke(); }
    // navire generique : coque, mat, voile carree a croix, fanion
    function navire(x,y,s,a,voile){
      ctx.save(); ctx.translate(x,y); ctx.rotate(a);
      ctx.fillStyle='#3a2018'; ctx.beginPath(); ctx.moveTo(-s*.62,-s*.12); ctx.lineTo(s*.66,-s*.16); ctx.quadraticCurveTo(s*.5,s*.1,s*.3,s*.12); ctx.lineTo(-s*.4,s*.12); ctx.quadraticCurveTo(-s*.58,s*.05,-s*.62,-s*.12); ctx.fill();
      ctx.fillStyle='#5a3424'; ctx.fillRect(-s*.6,-s*.16,s*1.24,s*.05);
      ctx.fillStyle='#2a1610'; ctx.fillRect(-s*.02,-s*.95,s*.04,s*.82);
      if(voile){ ctx.fillStyle='#efe2c4'; ctx.beginPath(); ctx.moveTo(-s*.32,-s*.82); ctx.quadraticCurveTo(0,-s*.76,s*.32,-s*.82); ctx.lineTo(s*.3,-s*.34); ctx.quadraticCurveTo(0,-s*.28,-s*.3,-s*.34); ctx.fill();
        ctx.fillStyle='#a8302a'; ctx.fillRect(-s*.035,-s*.78,s*.07,s*.42); ctx.fillRect(-s*.2,-s*.6,s*.4,s*.06); }
      ctx.fillStyle='#a8302a'; ctx.beginPath(); ctx.moveTo(s*.02,-s*.95); ctx.lineTo(s*.22,-s*.92+Math.sin(t*4+x)*s*.03); ctx.lineTo(s*.02,-s*.88); ctx.fill();
      ctx.restore();
    }
    // la flotte qui s eloigne vers l horizon, a gauche
    for(k=0;k<5;k++){ var per=46, pf=((t+k*per/5)/per)%1, e=pf*pf*(3-2*pf);
      var fx0=w*(.05+.085*k), fx=fx0+(w*.3-fx0)*e*.45, fy=hz+h*(.17-e*.165)+h*.01*(k%2), fs=h*.12*(1-e*.85);
      ctx.globalAlpha=Math.min(1,pf*8)*(1-Math.max(0,(pf-.88)/.12)); navire(fx,fy+Math.sin(t*1.2+k)*fs*.03,fs,Math.sin(t*1.1+k)*.04,true);
      ctx.fillStyle='rgba(255,235,200,.35)'; ctx.fillRect(fx-fs*.5,fy+fs*.1,fs,1); }
    ctx.globalAlpha=1;
    // ---- le Mont, a droite : monastere fortifie ----
    var mx=w*.77, mb=hz+h*.035, roc='#3a1c2a', mur='#4a2434', ombre='#2c1220', clair='rgba(255,200,140,.4)';
    ctx.fillStyle=roc; ctx.beginPath(); ctx.moveTo(mx-w*.2,mb); ctx.bezierCurveTo(mx-w*.14,mb-h*.04,mx-w*.09,mb-h*.13,mx-w*.05,mb-h*.21); ctx.lineTo(mx+w*.06,mb-h*.21); ctx.bezierCurveTo(mx+w*.1,mb-h*.13,mx+w*.15,mb-h*.04,mx+w*.21,mb); ctx.fill();
    // village en gradins
    var rr=_mxR(4); for(k=0;k<10;k++){ var vx2=mx+w*(-.13+rr()*.25), vy2=mb-h*(.05+rr()*.1), vw=w*(.018+rr()*.016); ctx.fillStyle=k%2?'#55293a':'#4e2434'; ctx.fillRect(vx2,vy2,vw,h*.03); ctx.fillStyle=ombre; ctx.beginPath(); ctx.moveTo(vx2-1,vy2); ctx.lineTo(vx2+vw/2,vy2-vw*.55); ctx.lineTo(vx2+vw+1,vy2); ctx.fill(); }
    // remparts au pied, avec tours rondes a machicoulis
    function tourR(x,y,lw,ht){ ctx.fillStyle=mur; ctx.fillRect(x-lw/2,y-ht,lw,ht); ctx.fillStyle=ombre; ctx.fillRect(x-lw/2,y-ht,lw*.3,ht);
      ctx.fillStyle=mur; ctx.fillRect(x-lw*.62,y-ht-lw*.25,lw*1.24,lw*.25); for(var c=0;c<4;c++) ctx.fillRect(x-lw*.62+c*lw*.36,y-ht-lw*.45,lw*.2,lw*.2);
      ctx.fillStyle='rgba(0,0,0,.25)'; for(c=0;c<5;c++) ctx.fillRect(x-lw*.58+c*lw*.27,y-ht,lw*.1,lw*.12); ctx.fillStyle=clair; ctx.fillRect(x+lw/2-1.2,y-ht,1.2,ht); }
    ctx.fillStyle=mur; ctx.fillRect(mx-w*.19,mb-h*.05,w*.39,h*.05); for(k=0;k<15;k++) ctx.fillRect(mx-w*.19+k*w*.026,mb-h*.062,w*.013,h*.012);
    ctx.fillStyle=clair; ctx.fillRect(mx-w*.19,mb-h*.05,w*.39,1);
    tourR(mx-w*.19,mb,w*.028,h*.085); tourR(mx-w*.09,mb,w*.03,h*.095); tourR(mx+w*.04,mb,w*.026,h*.08); tourR(mx+w*.18,mb,w*.03,h*.09);
    // porte fortifiee
    ctx.fillStyle=ombre; ctx.beginPath(); ctx.moveTo(mx-w*.03,mb); ctx.lineTo(mx-w*.03,mb-h*.03); ctx.arc(mx-w*.02,mb-h*.03,w*.01,PI,0); ctx.lineTo(mx-w*.01,mb); ctx.fill();
    // seconde enceinte a mi-hauteur
    ctx.fillStyle=mur; ctx.fillRect(mx-w*.09,mb-h*.145,w*.19,h*.022); for(k=0;k<8;k++) ctx.fillRect(mx-w*.09+k*w*.025,mb-h*.153,w*.012,h*.009);
    tourR(mx-w*.09,mb-h*.123,w*.022,h*.06); tourR(mx+w*.1,mb-h*.123,w*.022,h*.055);
    // l abbaye : soubassement massif a contreforts, nef, cloitre, clocher et fleche
    var ab='#3a1a2a'; ctx.fillStyle=ab; ctx.fillRect(mx-w*.07,mb-h*.27,w*.15,h*.08);
    ctx.fillStyle='#2e1422'; for(k=0;k<6;k++) ctx.fillRect(mx-w*.07+k*w*.028,mb-h*.27,w*.008,h*.08);
    ctx.fillStyle='rgba(255,215,140,.75)'; for(k=0;k<5;k++){ if(Math.sin(t*.6+k*1.7)>-.5){ ctx.beginPath(); ctx.moveTo(mx-w*.058+k*w*.028,mb-h*.2); ctx.lineTo(mx-w*.058+k*w*.028,mb-h*.225); ctx.arc(mx-w*.054+k*w*.028,mb-h*.225,w*.004,PI,0); ctx.lineTo(mx-w*.05+k*w*.028,mb-h*.2); ctx.fill(); } }
    ctx.fillStyle=ab; ctx.beginPath(); ctx.moveTo(mx-w*.075,mb-h*.27); ctx.lineTo(mx-w*.06,mb-h*.33); ctx.lineTo(mx+w*.065,mb-h*.33); ctx.lineTo(mx+w*.08,mb-h*.27); ctx.fill();
    ctx.beginPath(); ctx.moveTo(mx-w*.065,mb-h*.33); ctx.lineTo(mx,mb-h*.37); ctx.lineTo(mx+w*.07,mb-h*.33); ctx.fill();
    ctx.fillRect(mx-w*.016,mb-h*.42,w*.032,h*.06); ctx.fillStyle='rgba(255,215,140,.8)'; ctx.fillRect(mx-2,mb-h*.405,4,h*.02);
    ctx.fillStyle=ab; ctx.beginPath(); ctx.moveTo(mx-w*.016,mb-h*.42); ctx.lineTo(mx,mb-h*.56); ctx.lineTo(mx+w*.016,mb-h*.42); ctx.fill();
    var gl=.5+.5*Math.sin(t*.8); _mxHalo(ctx,mx,mb-h*.57,12,'rgba(255,230,140,.9)',gl); ctx.fillStyle='#ffd77a'; ctx.fillRect(mx-1,mb-h*.58,2,4);
    // drapeaux qui flottent sur le Mont
    function drapeau(x,y,lg,col,ph){ ctx.strokeStyle='#2a1018'; ctx.lineWidth=1.1; ctx.beginPath(); ctx.moveTo(x,y); ctx.lineTo(x,y-lg*1.3); ctx.stroke();
      ctx.fillStyle=col; ctx.beginPath(); ctx.moveTo(x,y-lg*1.3); for(var s=0;s<=8;s++){ var u=s/8; ctx.lineTo(x+u*lg,y-lg*1.3+Math.sin(t*3.2-u*4+ph)*lg*.12*u); }
      for(s=8;s>=0;s--){ var u2=s/8; ctx.lineTo(x+u2*lg,y-lg*.85+Math.sin(t*3.2-u2*4+ph)*lg*.12*u2-(s==8?lg*.14:0)); } ctx.fill(); }
    // chaque hampe part du parapet de sa tour (hauteur de la tour + son crenelage)
    // canon sur le rempart, qui tire sur la flotte : le boulet tombe en mer (cycle de 8 s)
    var kx=mx-w*.14, ky=mb-h*.05, PC2=8, ck=(t%PC2)/PC2, rec=ck<.03?ck/.03:ck<.15?1-(ck-.03)/.12:0, ang=-.14;
    ctx.save(); ctx.translate(kx+rec*2.2,ky-h*.008); ctx.fillStyle='#3a2216'; ctx.fillRect(-w*.006,-h*.012,w*.02,h*.012); ctx.fillStyle='#221418'; ctx.beginPath(); ctx.arc(-w*.002,-h*.001,h*.007,0,2*PI); ctx.arc(w*.01,-h*.001,h*.007,0,2*PI); ctx.fill();
    ctx.rotate(ang); ctx.fillStyle='#2a2a30'; ctx.beginPath(); ctx.moveTo(w*.008,-h*.022); ctx.lineTo(-w*.03,-h*.019); ctx.lineTo(-w*.03,-h*.009); ctx.lineTo(w*.008,-h*.006); ctx.closePath(); ctx.fill(); ctx.fillRect(-w*.032,-h*.021,w*.005,h*.014);
    ctx.fillStyle='rgba(255,200,140,.35)'; ctx.fillRect(-w*.028,-h*.021,w*.034,1); ctx.restore();
    // parapet devant l affut : les roues et l affut sont caches, le fut sort par une embrasure
    ctx.fillStyle=mur; ctx.fillRect(kx-w*.045,ky-h*.012,w*.075,h*.014);
    ctx.fillRect(kx-w*.045,ky-h*.026,w*.011,h*.016); ctx.fillRect(kx+w*.016,ky-h*.026,w*.014,h*.016);
    ctx.fillStyle=clair; ctx.fillRect(kx-w*.045,ky-h*.012,w*.075,1); ctx.fillRect(kx-w*.045,ky-h*.026,w*.011,1); ctx.fillRect(kx+w*.016,ky-h*.026,w*.014,1);
    ctx.fillStyle='rgba(0,0,0,.25)'; ctx.fillRect(kx-w*.034,ky-h*.012,w*.05,h*.003);
    // bouche du canon : le bout du fut, apres rotation (tir presque a l horizontale, un peu vers le bas)
    var lxm=-w*.03, lym=-h*.0145, mzx=kx+rec*2.2+lxm*Math.cos(ang)-lym*Math.sin(ang), mzy=ky-h*.008+lxm*Math.sin(ang)+lym*Math.cos(ang);
    if(ck<.05){ _mxPoint(ctx,mzx-3,mzy,h*.035*(1-ck/.05)+3,'255,210,120',1-ck/.05); }
    for(var fm=0;fm<6;fm++){ var pf=ck*3-fm*.04; if(pf<0||pf>1) continue; _mxPoint(ctx,mzx-pf*w*.035-fm*2,mzy-pf*h*.05,h*(.012+pf*.03),'215,205,200',(1-pf)*.6); }
    ctx.globalAlpha=1;
    // tir tendu : le boulet file droit dans l axe du fut (a peine infle par la pesanteur) et s ecrase dans l eau
    var dxk=-Math.cos(ang), dyk=-Math.sin(ang), chute=h*.012, by1=hz+h*.025, dist=(by1-chute-mzy)/dyk, bx1=mzx+dxk*dist, vol=.07;
    if(ck>.02&&ck<.02+vol){ var ub=(ck-.02)/vol, bbx=mzx+dxk*dist*ub, bby=mzy+dyk*dist*ub+chute*ub*ub;
      ctx.strokeStyle='rgba(230,220,210,.35)'; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(bbx,bby); ctx.lineTo(bbx-dxk*w*.04,bby-dyk*w*.04); ctx.stroke(); ctx.fillStyle='#14101a'; ctx.beginPath(); ctx.arc(bbx,bby,1.9,0,2*PI); ctx.fill(); _mxPoint(ctx,bbx+3,bby-1,4,'200,190,185',.35); ctx.globalAlpha=1; }
    var us=(ck-.02-vol)/.3; if(us>0&&us<1){ var sh=Math.sin(Math.min(1,us*1.6)*PI)*h*.05;
      var gs=ctx.createLinearGradient(0,by1-sh,0,by1); gs.addColorStop(0,'rgba(255,248,236,0)'); gs.addColorStop(.3,'rgba(255,248,236,.8)'); gs.addColorStop(1,'rgba(255,248,236,.9)'); ctx.fillStyle=gs;
      ctx.beginPath(); ctx.moveTo(bx1-w*.008,by1); ctx.quadraticCurveTo(bx1-w*.004,by1-sh*.7,bx1,by1-sh); ctx.quadraticCurveTo(bx1+w*.004,by1-sh*.7,bx1+w*.008,by1); ctx.fill();
      var rs=_mxR(9); ctx.strokeStyle='rgba(255,248,236,'+(1-us)*.85+')'; ctx.lineWidth=1.2; ctx.lineCap='round'; ctx.beginPath(); for(var gd2=0;gd2<8;gd2++){ var vx=(rs()-.5)*w*.06, vy=h*(.04+rs()*.05), dx=bx1+vx*us, dy=by1-vy*4*us*(1-us); ctx.moveTo(dx,dy); ctx.lineTo(dx-vx*.06,dy+h*.008); } ctx.stroke();
      ctx.strokeStyle='rgba(255,240,220,'+(1-us)*.5+')'; ctx.lineWidth=1; ctx.beginPath(); ctx.ellipse(bx1,by1+1,w*(.01+us*.05),h*(.003+us*.01),0,0,2*PI); ctx.stroke(); }
    drapeau(mx-w*.19,mb-h*.085-w*.007,h*.04,'#c8a040',0); drapeau(mx+w*.18,mb-h*.09-w*.0075,h*.04,'#2a4a8a',1.3);
    drapeau(mx-w*.09,mb-h*.183-w*.0055,h*.035,'#efe2c4',2.1); drapeau(mx+w*.1,mb-h*.178-w*.0055,h*.035,'#a8302a',2.9); drapeau(mx,mb-h*.42,h*.03,'#c8a040',3.6);
    // reflet du Mont
    for(var rq=0;rq<10;rq++){ var ry=mb+3+rq*4, rw=w*(.17-rq*.014)*(1+Math.sin(t*1.1+rq)*.08); ctx.globalAlpha=.3-rq*.028; ctx.fillStyle=roc; ctx.fillRect(mx-rw+Math.sin(t*1.5+rq*2)*2,ry,rw*2,2); }
    ctx.globalAlpha=1;
    // dauphins qui sautent, et petits poissons
    function dauphin(x0,y0,lg,ht,per,ph,s){ var c=((t+ph)%per)/per; if(c>.32) return; var u=c/.32, x=x0+u*lg, y=y0-ht*4*u*(1-u), an=Math.atan2(-ht*4*(1-2*u),lg);
      ctx.save(); ctx.translate(x,y); ctx.rotate(an); ctx.fillStyle='#4a5a78';
      ctx.beginPath(); ctx.moveTo(s*.6,0); ctx.quadraticCurveTo(s*.3,-s*.22,-s*.3,-s*.12); ctx.lineTo(-s*.55,-s*.2); ctx.lineTo(-s*.5,0); ctx.lineTo(-s*.58,s*.16); ctx.lineTo(-s*.3,s*.06); ctx.quadraticCurveTo(s*.2,s*.16,s*.6,0); ctx.fill();
      ctx.beginPath(); ctx.moveTo(0,-s*.16); ctx.lineTo(-s*.12,-s*.34); ctx.lineTo(-s*.16,-s*.14); ctx.fill(); ctx.fillStyle='rgba(255,235,210,.5)'; ctx.beginPath(); ctx.ellipse(s*.1,s*.05,s*.3,s*.05,0,0,7); ctx.fill(); ctx.restore();
      [[0,u<.15],[lg,u>.85]].forEach(function(sp){ if(!sp[1]) return; for(var g=0;g<6;g++){ ctx.fillStyle='rgba(255,245,225,.85)'; ctx.fillRect(x0+sp[0]+(g-2.5)*s*.12,y0-Math.abs(Math.sin(g*1.7+t*9))*s*.35,1.4,1.4); } }); }
    dauphin(w*.48,hz+h*.13,w*.11,h*.09,7,0,h*.06); dauphin(w*.54,hz+h*.15,w*.1,h*.08,7,2.3,h*.055); dauphin(w*.6,hz+h*.22,w*.09,h*.07,9,5.1,h*.05);
    for(k=0;k<4;k++){ var c3=((t*.9+k*1.3)%4)/4; if(c3<.2){ var u3=c3/.2, fx3=w*(.38+k*.08)+u3*w*.03, fy3=hz+h*(.24+k*.03)-h*.035*4*u3*(1-u3); ctx.fillStyle='#d8e0e6'; ctx.save(); ctx.translate(fx3,fy3); ctx.rotate((u3-.5)*1.6); ctx.beginPath(); ctx.ellipse(0,0,3,1.2,0,0,7); ctx.fill(); ctx.restore(); } }
    // ---- premier plan : le navire qui coule ----
    // cycle de 26 s : il gite, l eau embarque, la proue plonge, le mat se brise
    // et tombe, la poupe se dresse puis disparait ; anneaux de remous, ecume
    // le long de la ligne de flottaison, gerbes a la plongee, bouillons d air,
    // epaves qui derivent. Puis un autre navire reparait au loin (fondu).
    var nx=w*.17, ny=h*.81, ns=h*.2, P=26, cc=(t%P)/P;
    var fond=Math.max(0,Math.min(1,(cc-.12)/.72)), ff=fond*fond*(3-2*fond);
    var app=Math.min(1,cc/.06)*(cc>.94?1-(cc-.94)/.06:1);
    var gite=-.04+Math.sin(t*1.1)*.02+ff*1.05, desc=ff*ns*1.25, hx0=nx+ff*w*.025, hy0=ny+desc+Math.sin(t*1.3)*1.5;
    function coque(s){ // coque a bordages, chateau arriere, beaupre
      ctx.fillStyle='#3a2018'; ctx.beginPath(); ctx.moveTo(-s*.62,-s*.3); ctx.lineTo(-s*.42,-s*.3); ctx.lineTo(-s*.4,-s*.16); ctx.lineTo(s*.66,-s*.16); ctx.quadraticCurveTo(s*.56,s*.06,s*.34,s*.12); ctx.lineTo(-s*.42,s*.12); ctx.quadraticCurveTo(-s*.6,s*.04,-s*.62,-s*.3); ctx.fill();
      ctx.strokeStyle='rgba(15,6,4,.55)'; ctx.lineWidth=.8; ctx.beginPath(); for(var b=0;b<4;b++){ var yy=-s*.12+b*s*.06; ctx.moveTo(-s*.58,yy); ctx.quadraticCurveTo(0,yy+s*.015,s*.6-b*s*.05,yy); } ctx.stroke();
      ctx.fillStyle='#5a3424'; ctx.fillRect(-s*.62,-s*.33,s*.22,s*.04); ctx.fillRect(-s*.4,-s*.19,s*1.06,s*.035);
      ctx.fillStyle='rgba(255,210,150,.35)'; ctx.fillRect(-s*.62,-s*.33,s*1.28,1); ctx.fillStyle='#1e100a'; ctx.fillRect(-s*.56,-s*.26,s*.05,s*.05); ctx.fillRect(-s*.48,-s*.26,s*.05,s*.05);
      ctx.strokeStyle='#2a1610'; ctx.lineWidth=s*.025; ctx.beginPath(); ctx.moveTo(s*.6,-s*.17); ctx.lineTo(s*.9,-s*.3); ctx.stroke(); }
    ctx.save(); ctx.beginPath(); ctx.rect(0,0,w,ny+h*.006); ctx.clip(); ctx.globalAlpha=app;
    ctx.save(); ctx.translate(hx0,hy0); ctx.rotate(gite); coque(ns);
    // mat : entier, puis brise a mi-hauteur a partir de cc .42 ; voile dechiree
    var brk=Math.max(0,Math.min(1,(cc-.42)/.12)), chute=brk*brk*1.5;
    ctx.fillStyle='#2a1610'; ctx.fillRect(-ns*.02,-ns*.62,ns*.04,ns*.46);
    ctx.save(); ctx.translate(0,-ns*.6); ctx.rotate(chute);
    ctx.fillRect(-ns*.02,-ns*.38,ns*.04,ns*.4); ctx.fillRect(-ns*.3,-ns*.34,ns*.6,ns*.025);
    ctx.fillStyle='#e6d6b4'; ctx.beginPath(); ctx.moveTo(-ns*.28,-ns*.32); ctx.quadraticCurveTo(0,-ns*.26+brk*ns*.08,ns*.28,-ns*.32); ctx.lineTo(ns*.26,-ns*.02); ctx.lineTo(ns*.12,-ns*.06); ctx.lineTo(ns*.04,ns*.04); ctx.lineTo(-ns*.08,-ns*.04); ctx.lineTo(-ns*.26,0); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#a8302a'; ctx.fillRect(-ns*.03,-ns*.3,ns*.06,ns*.26); ctx.fillRect(-ns*.17,-ns*.2,ns*.34,ns*.05);
    ctx.fillStyle='rgba(60,30,20,.55)'; ctx.beginPath(); ctx.ellipse(ns*.14,-ns*.18,ns*.04,ns*.06,.4,0,7); ctx.ellipse(-ns*.15,-ns*.1,ns*.03,ns*.04,0,0,7); ctx.fill();
    ctx.restore();
    ctx.strokeStyle='rgba(30,16,10,.6)'; ctx.lineWidth=.7; ctx.beginPath(); ctx.moveTo(0,-ns*.62); ctx.lineTo(-ns*.6,-ns*.3); if(brk<.2){ ctx.moveTo(0,-ns*.9); ctx.lineTo(ns*.88,-ns*.3); } ctx.stroke();
    ctx.restore(); ctx.restore(); ctx.globalAlpha=1;
    if(app>0){
      var sw=ns*(.75+ff*.2); // largeur qui perce encore l eau
      // anneaux de remous qui s elargissent
      for(var ri=0;ri<3;ri++){ var pr=((t*.35+ri/3)%1); if(cc<.12) break; ctx.strokeStyle='rgba(255,232,205,'+((1-pr)*.38*app)+')'; ctx.lineWidth=1; ctx.beginPath(); ctx.ellipse(hx0,ny+h*.008,sw*(.55+pr*1.1),h*(.008+pr*.022),0,0,2*PI); ctx.stroke(); }
      // ecume irreguliere le long de la flottaison
      var ec=ctx.createLinearGradient(0,ny-h*.008,0,ny+h*.02); ec.addColorStop(0,'rgba(255,245,230,'+(.75*app)+')'); ec.addColorStop(1,'rgba(255,245,230,0)'); ctx.fillStyle=ec; ctx.beginPath();
      for(k=0;k<=18;k++){ var u=k/18, ex=hx0-sw*.6+u*sw*1.2, ey=ny+h*.004-Math.abs(Math.sin(u*PI))*h*(.006+.004*Math.sin(t*3+k*1.7)); if(k) ctx.lineTo(ex,ey); else ctx.moveTo(ex,ey); }
      for(k=18;k>=0;k--){ var u2=k/18; ctx.lineTo(hx0-sw*.7+u2*sw*1.4,ny+h*(.014+.004*Math.sin(t*2.3+k))); } ctx.closePath(); ctx.fill();
      // gerbes quand la proue plonge (deux moments)
      [[.3,.38],[.62,.7]].forEach(function(g){ if(cc<g[0]||cc>g[1]) return; var pg=(cc-g[0])/(g[1]-g[0]), rg=_mxR(Math.round(g[0]*100));
        for(var d=0;d<9;d++){ var vx=(rg()-.3)*ns*.9, vy=ns*(.35+rg()*.4), dx=hx0+ns*.35+vx*pg, dy=ny-vy*4*pg*(1-pg); ctx.strokeStyle='rgba(255,248,235,'+((1-pg)*.85)+')'; ctx.lineWidth=1.8; ctx.lineCap='round'; ctx.beginPath(); ctx.moveTo(dx,dy); ctx.lineTo(dx-vx*.12,dy+ns*.12*(1-2*pg)); ctx.stroke(); }
        _mxPoint(ctx,hx0+ns*.35,ny,ns*(.15+pg*.2),'255,246,232',(1-pg)*.6); ctx.globalAlpha=1; });
      // bouillons d air : nappes d ecume douces qui s etalent et se dissipent
      if(cc>.5&&cc<.94){ for(k=0;k<3;k++){ var pb=((t*.4+k*.37)%1), bx=hx0+(k-1)*ns*.28+Math.sin(k*3.1)*ns*.06; ctx.save(); ctx.translate(bx,ny+h*.008); ctx.scale(1,.22); _mxPoint(ctx,0,0,ns*(.08+pb*.2),'255,246,232',Math.sin(pb*PI)*.7); ctx.restore(); } ctx.globalAlpha=1; }
      // epaves qui derivent : planches, tonneau, cordage
      if(cc>.4){ var dr=(cc-.4)/.54, EP=[[-.5,0,'p',.08],[.4,1.4,'p',-.12],[.75,2.8,'t',0],[-.2,4.1,'p',.15],[.15,5.3,'c',0]];
        EP.forEach(function(e){ var px=hx0+e[0]*ns+(e[0]<0?-1:1)*dr*ns*.6, py=ny+h*.008+Math.sin(t*1.4+e[1])*1.2; ctx.save(); ctx.translate(px,py); ctx.rotate(e[3]+Math.sin(t*.8+e[1])*.08);
          if(e[2]=='p'){ ctx.fillStyle='#5a3a24'; ctx.fillRect(-ns*.12,-1.6,ns*.24,3.2); ctx.fillStyle='rgba(255,220,170,.3)'; ctx.fillRect(-ns*.12,-1.6,ns*.24,.8); }
          else if(e[2]=='t'){ ctx.fillStyle='#6a4428'; ctx.beginPath(); ctx.ellipse(0,-1,ns*.06,ns*.045,0,0,2*PI); ctx.fill(); ctx.strokeStyle='#2a1a10'; ctx.lineWidth=.8; ctx.beginPath(); ctx.moveTo(-ns*.03,-ns*.04); ctx.lineTo(-ns*.03,ns*.02); ctx.moveTo(ns*.03,-ns*.04); ctx.lineTo(ns*.03,ns*.02); ctx.stroke(); }
          else { ctx.strokeStyle='#c8a878'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(-ns*.1,0); ctx.quadraticCurveTo(-ns*.03,-2,0,0); ctx.quadraticCurveTo(ns*.04,2,ns*.1,0); ctx.stroke(); }
          ctx.restore(); }); }
    }
    // la mer devant le navire, et le rivage rocheux ou se tient le moine
    var gd=ctx.createLinearGradient(0,ny,0,h); gd.addColorStop(0,'rgba(90,48,68,.12)'); gd.addColorStop(1,'rgba(60,30,50,.5)'); ctx.fillStyle=gd; ctx.fillRect(0,ny+h*.01,w,h);
    ctx.strokeStyle='rgba(255,225,190,.35)'; ctx.lineWidth=1; for(k=0;k<6;k++){ var wx=((k*w*.19+t*8)%(w*1.1))-w*.05; ctx.beginPath(); ctx.moveTo(wx,ny+h*.02+k%3*3); ctx.quadraticCurveTo(wx+8,ny+h*.015+k%3*3,wx+16,ny+h*.02+k%3*3); ctx.stroke(); }
    for(var g2=0;g2<5;g2++){ var p=((t*.018+g2*.21)%1), gx=w*1.05-p*w*1.2, gy=h*(.2+g2*.05)+Math.sin(t*.6+g2)*8, a=Math.sin(t*3+g2)*3; ctx.strokeStyle='rgba(60,30,40,.7)'; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(gx-5,gy-a); ctx.quadraticCurveTo(gx-2,gy-2,gx,gy); ctx.quadraticCurveTo(gx+2,gy-2,gx+5,gy-a); ctx.stroke(); }
    // premier plan : le quai de pierre de la forteresse, sur lequel il se tient
    var qy=h*.88;
    ctx.fillStyle='rgba(30,14,24,.45)'; ctx.fillRect(0,qy-h*.006,w,h*.012);
    var gq=ctx.createLinearGradient(0,qy,0,h); gq.addColorStop(0,'#9a7262'); gq.addColorStop(.35,'#6e4a40'); gq.addColorStop(1,'#3a2228'); ctx.fillStyle=gq; ctx.fillRect(0,qy,w,h-qy);
    ctx.fillStyle='rgba(255,215,160,.55)'; ctx.fillRect(0,qy,w,1.6);
    ctx.strokeStyle='rgba(40,20,26,.45)'; ctx.lineWidth=1; ctx.beginPath();
    var rangs=[qy+h*.035,qy+h*.075]; rangs.forEach(function(yy){ ctx.moveTo(0,yy); ctx.lineTo(w,yy); });
    for(var bq=0;bq<14;bq++){ var bxq=bq*w/12+(bq%2)*w/24; ctx.moveTo(bxq,qy); ctx.lineTo(bxq-2,qy+h*.035); ctx.moveTo(bxq+w/24,qy+h*.035); ctx.lineTo(bxq+w/24-3,qy+h*.075); } ctx.stroke();
    ctx.fillStyle='rgba(255,220,170,.12)'; for(bq=0;bq<12;bq++) ctx.fillRect(bq*w/12+(bq%2)*w/24+2,qy+2,w/12-6,2);
    // bitte d amarrage, cordage enroule, caisse
    var bx3=w*.09; ctx.fillStyle='#3a2a2e'; ctx.fillRect(bx3-5,qy-h*.05,10,h*.06); ctx.beginPath(); ctx.ellipse(bx3,qy-h*.05,7,3,0,0,7); ctx.fill(); ctx.fillStyle='rgba(255,210,150,.35)'; ctx.fillRect(bx3+3,qy-h*.05,1.5,h*.06);
    ctx.strokeStyle='#c8a878'; ctx.lineWidth=1.8; ctx.beginPath(); ctx.moveTo(bx3,qy-h*.03); ctx.quadraticCurveTo(bx3-w*.06,qy+h*.02,bx3-w*.1,qy-h*.01); ctx.stroke();
    ctx.beginPath(); for(var cr=0;cr<3;cr++){ ctx.ellipse(w*.2,qy+h*.03,10-cr*3,3.6-cr*1.1,0,0,7); } ctx.stroke();
    // caisses basses sur le quai (pas plus hautes que le rebord, pour ne rien cacher)
    function caisse(x,cw,ch,c){ var y=qy+h*.012; ctx.fillStyle=c; ctx.fillRect(x,y-ch,cw,ch); ctx.strokeStyle='rgba(30,16,8,.55)'; ctx.lineWidth=1; ctx.strokeRect(x+.5,y-ch+.5,cw-1,ch-1); ctx.beginPath(); ctx.moveTo(x,y-ch); ctx.lineTo(x+cw,y); ctx.moveTo(x,y-ch*.5); ctx.lineTo(x+cw,y-ch*.5); ctx.stroke(); ctx.fillStyle='rgba(255,215,160,.35)'; ctx.fillRect(x,y-ch,cw,1.3); ctx.fillStyle='rgba(0,0,0,.2)'; ctx.fillRect(x+cw,y-ch*.9,2,ch*.9); }
    caisse(w*.28,w*.05,h*.045,'#6a4428'); caisse(w*.325,w*.035,h*.032,'#7a5030');
    ctx.fillStyle='#5a3a22'; ctx.beginPath(); ctx.ellipse(w*.38,qy+h*.004,w*.016,h*.03,0,0,2*PI); ctx.fill(); ctx.strokeStyle='#2a1a10'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(w*.366,qy-h*.012); ctx.lineTo(w*.394,qy-h*.012); ctx.moveTo(w*.366,qy+h*.016); ctx.lineTo(w*.394,qy+h*.016); ctx.stroke();
    caisse(w*.66,w*.045,h*.04,'#7a5030'); caisse(w*.705,w*.055,h*.05,'#6a4428'); caisse(w*.83,w*.06,h*.045,'#6a4428'); caisse(w*.885,w*.04,h*.03,'#7a5030');
  },
  // 3 - ASTROLOGUE : le grenier de Melisende au-dessus de Chartres. Une grande
  // ouverture en arche donne sur une nuit parfaite (voie lactee, etoiles,
  // cometes) et sur les toits de la ville et la cathedrale. Dans le grenier :
  // tables d astrologie (globe qui tourne, astrolabe, carte du ciel, compas,
  // sablier, chandelles), foin, toiles d araignee, araignee qui remonte son fil.
  // Animations : constellations qui se tracent, comete en feu, globe, araignee.
  function(ctx,w,h,t){
    var PI=Math.PI, k, i;
    // ---- l arche : geometrie ----
    var ax0=w*.12, ax1=w*.88, acx=(ax0+ax1)/2, arx=(ax1-ax0)/2, spr=h*.36, top=h*.05, sill=h*.7;
    function arche(suite){ if(!suite) ctx.beginPath(); ctx.moveTo(ax0,sill); ctx.lineTo(ax0,spr); ctx.ellipse(acx,spr,arx,spr-top,0,PI,2*PI); ctx.lineTo(ax1,sill); ctx.closePath(); }
    // ---- le ciel, vu par l arche ----
    ctx.save(); arche(); ctx.clip();
    _mxCiel(ctx,w,h,[[0,'#04061a'],[.45,'#0b1236'],[.7,'#1a1f4e'],[1,'#2a2552']]);
    // voie lactee : bande diagonale de nuees et d etoiles fines
    for(k=0;k<26;k++){ var u=k/25, bx=w*(.05+u*.95), by=h*(.62-u*.52)+Math.sin(u*9)*h*.03; _mxPoint(ctx,bx,by,h*(.09+.05*Math.sin(u*7+1)),k%3?'150,160,230':'215,190,235',.22); }
    ctx.globalAlpha=1;
    var rv=_mxR(88); for(k=0;k<260;k++){ var u2=rv(), vx=w*(.05+u2*.95)+(rv()-.5)*h*.2, vy=h*(.62-u2*.52)+(rv()-.5)*h*.16; ctx.globalAlpha=.25+rv()*.5; ctx.fillStyle='#e8ecff'; ctx.fillRect(vx,vy,.9,.9); }
    ctx.globalAlpha=1;
    _mxEtoiles(ctx,w,h,170,5,t,.95,.75);
    // etoiles brillantes a croix
    var re=_mxR(31); for(k=0;k<9;k++){ var ex=ax0+re()*(ax1-ax0), ey=top+h*.04+re()*h*.4, tw=.6+.4*Math.sin(t*(1.2+re())+k), es=1.8+re()*1.6; ctx.globalAlpha=tw; ctx.fillStyle='#fffbe8'; ctx.fillRect(ex-es*2,ey-.4,es*4,.8); ctx.fillRect(ex-.4,ey-es*2,.8,es*4); _mxPoint(ctx,ex,ey,es*2.2,'255,250,230',tw*.8); }
    ctx.globalAlpha=1;
    // deux cometes lointaines, figees, longue queue pale
    [[.26,.2,-.5,.16],[.74,.14,-2.5,.12]].forEach(function(c){ var cx=w*c[0], cy=h*c[1], L=w*c[3], g=ctx.createLinearGradient(cx,cy,cx+Math.cos(c[2])*L,cy-Math.sin(c[2])*L); g.addColorStop(0,'rgba(220,235,255,.8)'); g.addColorStop(1,'rgba(220,235,255,0)');
      ctx.strokeStyle=g; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(cx,cy); ctx.lineTo(cx+Math.cos(c[2])*L,cy-Math.sin(c[2])*L); ctx.stroke(); _mxPoint(ctx,cx,cy,4,'235,245,255',.9); });
    ctx.globalAlpha=1;
    // constellations qui se tracent, une a la fois : segments qui s alignent
    var CONST=[
      [[.2,.3],[.26,.26],[.32,.27],[.37,.31],[.36,.38],[.43,.39],[.44,.32],[.37,.31]],
      [[.56,.14],[.6,.2],[.66,.17],[.71,.23],[.76,.19]],
      [[.62,.3],[.66,.36],[.7,.3],[.67,.44],[.64,.5],[.7,.5],[.67,.44]],
      [[.24,.12],[.3,.1],[.35,.15],[.31,.2],[.24,.12]]];
    var PC=9, ci=Math.floor(t/PC)%CONST.length, ct=(t%PC)/PC, C=CONST[ci], ns=C.length-1;
    var fade=ct<.75?1:1-(ct-.75)/.25;
    ctx.strokeStyle='rgba(180,200,255,'+(.7*fade)+')'; ctx.lineWidth=1.1; ctx.lineCap='round';
    for(k=0;k<ns;k++){ var s0=k/ns*.55, pr=Math.max(0,Math.min(1,(ct-s0)/(.55/ns))); if(pr<=0) break;
      var x0=w*C[k][0], y0=h*C[k][1], x1=w*C[k+1][0], y1=h*C[k+1][1]; ctx.beginPath(); ctx.moveTo(x0,y0); ctx.lineTo(x0+(x1-x0)*pr,y0+(y1-y0)*pr); ctx.stroke(); }
    C.forEach(function(p,j){ var al=Math.min(1,ct*6)*fade; _mxPoint(ctx,w*p[0],h*p[1],4,'200,215,255',al); ctx.globalAlpha=al; ctx.fillStyle='#ffffff'; ctx.fillRect(w*p[0]-1,h*p[1]-1,2,2); });
    ctx.globalAlpha=1;
    // comete en feu qui traverse le ciel
    var PF=11, cf=(t%PF)/PF; if(cf<.45){ var u3=cf/.45, hx=ax1+w*.05-u3*(ax1-ax0+w*.2), hy=top+h*.06+u3*h*.22, dx=1, dy=-.27;
      for(k=0;k<26;k++){ var q=k/26; _mxPoint(ctx,hx+dx*q*w*.22,hy+dy*q*w*.22+Math.sin(t*12+k)*q*2,h*(.03-q*.022)+1,q<.3?'255,210,120':'255,120,50',(1-q)*.75); }
      ctx.globalAlpha=1; _mxPoint(ctx,hx,hy,h*.05,'255,240,200',.9); ctx.fillStyle='#fffdf0'; ctx.beginPath(); ctx.arc(hx,hy,2.4,0,2*PI); ctx.fill();
      var rs=_mxR(Math.floor(t*6)); for(k=0;k<6;k++){ ctx.fillStyle='rgba(255,190,90,.8)'; ctx.fillRect(hx+rs()*w*.08,hy-h*.02+rs()*h*.05,1.3,1.3); } }
    ctx.globalAlpha=1;
    // ---- Chartres, en contrebas, vue d en haut : rangs de maisons du fond
    // vers l avant (plus grandes, plus basses dans l image, toits plus visibles),
    // la cathedrale posee dans la ville, derriere les rangs du devant ----
    _mxCrete(ctx,w,h,.55,.02,3.3,'#161a3c',2);
    function maison(x,yb,lw,wh,rh,pignon,r){
      var mur=r()>.5?'#3a3a62':'#34345a', toit=r()>.5?'#262a4e':'#2c2a50', cote=lw*.35;
      if(pignon){ // pignon face a nous, versant du toit qui fuit vers la droite
        ctx.fillStyle=toit; ctx.beginPath(); ctx.moveTo(x+lw/2,yb-wh-rh); ctx.lineTo(x+lw/2+cote,yb-wh-rh-cote*.45); ctx.lineTo(x+lw+cote,yb-wh-cote*.45); ctx.lineTo(x+lw,yb-wh); ctx.fill();
        ctx.fillStyle='#24244a'; ctx.beginPath(); ctx.moveTo(x+lw,yb-wh); ctx.lineTo(x+lw+cote,yb-wh-cote*.45); ctx.lineTo(x+lw+cote,yb-cote*.45); ctx.lineTo(x+lw,yb); ctx.fill();
        ctx.fillStyle=mur; ctx.beginPath(); ctx.moveTo(x,yb); ctx.lineTo(x,yb-wh); ctx.lineTo(x+lw/2,yb-wh-rh); ctx.lineTo(x+lw,yb-wh); ctx.lineTo(x+lw,yb); ctx.fill();
        ctx.strokeStyle='rgba(20,18,40,.5)'; ctx.lineWidth=.8; ctx.beginPath(); ctx.moveTo(x,yb-wh); ctx.lineTo(x+lw/2,yb-wh-rh); ctx.lineTo(x+lw,yb-wh); ctx.stroke();
        ctx.strokeStyle='rgba(170,185,240,.35)'; ctx.beginPath(); ctx.moveTo(x+lw/2,yb-wh-rh); ctx.lineTo(x+lw/2+cote,yb-wh-rh-cote*.45); ctx.stroke();
      } else { // faitage parallele : on voit le versant avant du toit, vu d en haut
        ctx.fillStyle=mur; ctx.fillRect(x,yb-wh,lw,wh);
        var g=ctx.createLinearGradient(0,yb-wh-rh,0,yb-wh); g.addColorStop(0,'#3a3e6e'); g.addColorStop(1,toit); ctx.fillStyle=g;
        ctx.beginPath(); ctx.moveTo(x-lw*.04,yb-wh); ctx.lineTo(x+lw*.12,yb-wh-rh); ctx.lineTo(x+lw*.88,yb-wh-rh); ctx.lineTo(x+lw*1.04,yb-wh); ctx.fill();
        ctx.strokeStyle='rgba(170,185,240,.4)'; ctx.lineWidth=.8; ctx.beginPath(); ctx.moveTo(x+lw*.12,yb-wh-rh); ctx.lineTo(x+lw*.88,yb-wh-rh); ctx.stroke();
        ctx.strokeStyle='rgba(20,18,40,.35)'; ctx.beginPath(); for(var tl=1;tl<3;tl++){ var yy=yb-wh-rh*tl/3; ctx.moveTo(x+lw*(.04+.08*(1-tl/3)),yy); ctx.lineTo(x+lw*(.96-.08*(1-tl/3)),yy); } ctx.stroke();
      }
      if(r()>.55){ ctx.fillStyle='#22223e'; ctx.fillRect(x+lw*(.25+r()*.4),yb-wh-rh*.9,lw*.1,rh*.55); } else r();
      for(var f=0;f<2;f++){ if(r()>.5){ var fx=x+lw*(.2+f*.45), on=Math.sin(t*.5+x*.7+f*2)>-.7; ctx.fillStyle=on?'rgba(255,200,110,'+(.6+.25*Math.sin(t*1.3+x))+')':'#1a1a34'; ctx.fillRect(fx,yb-wh*.62,Math.max(1.2,lw*.12),Math.max(1.6,wh*.22)); } else r(); }
    }
    var RANGS=[[.545,.32],[.585,.5],[.63,.72],[.68,1]];
    // rang du fond
    function rang(n){ var rr=_mxR(19+n*7), sc=RANGS[n][1], yb=h*RANGS[n][0];
      for(var x=ax0-w*.02-rr()*w*.03;x<ax1+w*.02;){ var lw=w*(.04+rr()*.03)*sc*1.6, wh=h*(.04+rr()*.02)*sc*1.5, rh=h*(.03+rr()*.015)*sc*1.5, pg=rr()>.55;
        maison(x,yb+rr()*h*.008*sc,lw,wh,rh,pg,rr); x+=lw*(pg?1.3:1)+w*.004*sc+(rr()>.8?w*.02*sc:0); }
      // ruelle eclairee devant le rang
      ctx.fillStyle='rgba(255,180,90,'+(.08+.04*sc)+')'; ctx.fillRect(ax0,yb+h*.003,ax1-ax0,h*.006*sc); }
    rang(0);
    // la cathedrale, posee entre les rangs : son pied sera cache par les maisons du devant
    var kx=w*.64, kb=h*.575, nef='#1e2148', kc=.9;
    ctx.save(); ctx.translate(kx,kb); ctx.scale(kc,kc); ctx.translate(-kx,-kb);
    ctx.fillStyle=nef; ctx.fillRect(kx-w*.02,kb-h*.11,w*.2,h*.11); ctx.beginPath(); ctx.moveTo(kx-w*.02,kb-h*.11); ctx.lineTo(kx+w*.08,kb-h*.16); ctx.lineTo(kx+w*.18,kb-h*.11); ctx.fill();
    ctx.fillStyle='rgba(170,185,240,.3)'; ctx.beginPath(); ctx.moveTo(kx+w*.08,kb-h*.16); ctx.lineTo(kx+w*.18,kb-h*.11); ctx.lineTo(kx+w*.17,kb-h*.11); ctx.closePath(); ctx.fill();
    ctx.fillStyle=nef; for(var k2=0;k2<6;k2++){ ctx.beginPath(); ctx.moveTo(kx+k2*w*.033,kb-h*.11); ctx.lineTo(kx+k2*w*.033+w*.012,kb-h*.14); ctx.lineTo(kx+k2*w*.033+w*.014,kb-h*.11); ctx.fill(); }
    ctx.fillRect(kx-w*.075,kb-h*.17,w*.032,h*.17); ctx.beginPath(); ctx.moveTo(kx-w*.075,kb-h*.17); ctx.lineTo(kx-w*.059,kb-h*.3); ctx.lineTo(kx-w*.043,kb-h*.17); ctx.fill();
    ctx.fillRect(kx-w*.03,kb-h*.19,w*.034,h*.19); ctx.beginPath(); ctx.moveTo(kx-w*.03,kb-h*.19); ctx.lineTo(kx-w*.026,kb-h*.24); ctx.lineTo(kx-w*.018,kb-h*.26); ctx.lineTo(kx-w*.013,kb-h*.35); ctx.lineTo(kx-w*.008,kb-h*.26); ctx.lineTo(kx,kb-h*.24); ctx.lineTo(kx+w*.004,kb-h*.19); ctx.fill();
    ctx.fillStyle='rgba(150,170,230,.25)'; ctx.fillRect(kx-w*.045,kb-h*.17,1,h*.17); ctx.fillRect(kx+w*.004,kb-h*.19,1,h*.19);
    var ro=.6+.3*Math.sin(t*.9); _mxPoint(ctx,kx-w*.036,kb-h*.11,h*.03,'255,180,90',ro*.6); ctx.globalAlpha=1; ctx.fillStyle='rgba(255,200,120,'+ro+')'; ctx.beginPath(); ctx.arc(kx-w*.036,kb-h*.11,h*.011,0,2*PI); ctx.fill();
    for(k2=0;k2<5;k2++){ ctx.fillStyle='rgba(255,190,100,'+(.5+.3*Math.sin(t+k2))+')'; ctx.fillRect(kx+w*.01+k2*w*.033,kb-h*.085,2,h*.025); }
    ctx.restore();
    rang(1); rang(2); rang(3);
    _mxBrume(ctx,w,h,h*.66,h*.025,'rgba(120,130,200,.18)',t,4,1);
    ctx.restore(); ctx.globalAlpha=1;
    // ---- le grenier : murs de planches autour de l arche ----
    ctx.save(); ctx.beginPath(); ctx.rect(0,0,w,h); arche(true); ctx.clip('evenodd');
    var gw=ctx.createLinearGradient(0,0,0,h); gw.addColorStop(0,'#1e140f'); gw.addColorStop(.7,'#2e1f16'); gw.addColorStop(1,'#1a110c'); ctx.fillStyle=gw; ctx.fillRect(0,0,w,h);
    ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.lineWidth=1; for(x=w*.03;x<w;x+=w*.055){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke(); }
    ctx.strokeStyle='rgba(255,190,120,.06)'; for(x=w*.034;x<w;x+=w*.055){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke(); }
    // chevrons de la charpente
    ctx.fillStyle='#3a2618'; ctx.save(); ctx.translate(0,h*.02); ctx.rotate(.5); ctx.fillRect(-w*.1,-h*.02,w*.4,h*.035); ctx.restore();
    ctx.save(); ctx.translate(w,h*.02); ctx.rotate(-.5); ctx.fillRect(-w*.3,-h*.02,w*.4,h*.035); ctx.restore();
    ctx.restore();
    // encadrement de l arche (poutres) et lueur de la nuit sur ses bords
    ctx.strokeStyle='#4a3020'; ctx.lineWidth=h*.03; arche(); ctx.stroke();
    ctx.strokeStyle='rgba(140,160,230,.25)'; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(ax0+h*.015,sill); ctx.lineTo(ax0+h*.015,spr); ctx.ellipse(acx,spr,arx-h*.015,spr-top-h*.015,0,PI,2*PI); ctx.lineTo(ax1-h*.015,sill); ctx.stroke();
    ctx.fillStyle='#3a2618'; ctx.fillRect(ax0-h*.03,sill-h*.01,ax1-ax0+h*.06,h*.03);
    // toiles d araignee dans les coins hauts
    function toile(x,y,r,a0,a1){ ctx.strokeStyle='rgba(225,225,240,.35)'; ctx.lineWidth=.7; var n=6, k2, j;
      ctx.beginPath(); for(k2=0;k2<=n;k2++){ var a=a0+(a1-a0)*k2/n; ctx.moveTo(x,y); ctx.lineTo(x+Math.cos(a)*r,y+Math.sin(a)*r); } ctx.stroke();
      for(j=1;j<=5;j++){ var rj=r*j/5.4; ctx.beginPath(); for(k2=0;k2<=n;k2++){ var a2=a0+(a1-a0)*k2/n, sg=k2%2?.86:1; var px=x+Math.cos(a2)*rj*sg, py=y+Math.sin(a2)*rj*sg; if(k2) ctx.quadraticCurveTo(x+Math.cos(a2-(a1-a0)/n/2)*rj*.8,y+Math.sin(a2-(a1-a0)/n/2)*rj*.8,px,py); else ctx.moveTo(px,py); } ctx.stroke(); } }
    toile(0,0,h*.2,0,PI/2); toile(w,0,h*.17,PI/2,PI); toile(ax0+h*.02,spr+h*.02,h*.09,-PI*.95,-PI*.5);
    // l araignee descend lentement, s arrete, puis remonte son fil
    var PA=12, ca=(t%PA)/PA, ay0=h*.02, ay=ca<.4?ay0+(ca/.4)*h*.3:ca<.55?ay0+h*.3:ay0+h*.3*(1-(ca-.55)/.45), axx=w*.07;
    ctx.strokeStyle='rgba(235,235,245,.55)'; ctx.lineWidth=.6; ctx.beginPath(); ctx.moveTo(axx,0); ctx.lineTo(axx,ay); ctx.stroke();
    var pt=ca>=.55?Math.sin(t*14)*.6:0; ctx.fillStyle='#0c0808'; ctx.beginPath(); ctx.ellipse(axx,ay+3,2.6,3.4,0,0,2*PI); ctx.fill(); ctx.beginPath(); ctx.arc(axx,ay-.6,1.7,0,2*PI); ctx.fill();
    ctx.strokeStyle='#0c0808'; ctx.lineWidth=.8; ctx.beginPath(); for(k=0;k<4;k++){ var la=(k-1.5)*.45; [-1,1].forEach(function(sd){ ctx.moveTo(axx,ay+2); ctx.quadraticCurveTo(axx+sd*4,ay+2+la*4-2+pt*sd,axx+sd*5.5,ay+3+la*6+pt); }); } ctx.stroke();
    // plancher
    var gf=ctx.createLinearGradient(0,h*.74,0,h); gf.addColorStop(0,'#3a2618'); gf.addColorStop(1,'#1a1008'); ctx.fillStyle=gf; ctx.fillRect(0,h*.74,w,h*.26);
    ctx.strokeStyle='rgba(0,0,0,.35)'; ctx.lineWidth=1; for(k=0;k<5;k++){ ctx.beginPath(); ctx.moveTo(0,h*(.77+k*.05)); ctx.lineTo(w,h*(.77+k*.05)); ctx.stroke(); }
    // foin : meules dans les coins, brins epars
    function meule(x,y,r){ var g=ctx.createRadialGradient(x,y-r*.4,2,x,y,r*1.2); g.addColorStop(0,'#e8c060'); g.addColorStop(1,'#9a7428'); ctx.fillStyle=g; ctx.beginPath(); ctx.ellipse(x,y,r*1.3,r*.8,0,PI,2*PI); ctx.fill();
      ctx.strokeStyle='rgba(250,220,130,.8)'; ctx.lineWidth=.8; var rh=_mxR(Math.round(x)); ctx.beginPath(); for(var k3=0;k3<24;k3++){ var a=PI+rh()*PI, d=r*(.4+rh()*.9); var sx=x+Math.cos(a)*d*1.3, sy=y+Math.sin(a)*d*.8; ctx.moveTo(sx,sy); ctx.lineTo(sx+(rh()-.5)*8,sy+(rh()-.5)*6-2); } ctx.stroke(); }
    meule(w*.04,h*1.0,h*.2); meule(w*.97,h*1.0,h*.18);
    ctx.strokeStyle='rgba(230,190,90,.7)'; ctx.lineWidth=.8; var rb=_mxR(3); ctx.beginPath(); for(k=0;k<30;k++){ var sx2=rb()*w, sy2=h*(.8+rb()*.18); if(sx2>w*.38&&sx2<w*.62) continue; ctx.moveTo(sx2,sy2); ctx.lineTo(sx2+(rb()-.5)*9,sy2+(rb()-.5)*3); } ctx.stroke();
    // lueur des chandelles
    var fl=.85+.15*Math.sin(t*9)*Math.sin(t*5.3);
    _mxHalo(ctx,w*.2,h*.66,w*.22,'rgba(255,170,80,.4)',fl); _mxHalo(ctx,w*.8,h*.66,w*.22,'rgba(255,170,80,.4)',fl);
    // ---- table de gauche : globe qui tourne, astrolabe, chandelle ----
    function table(x0,x1,y){ ctx.fillStyle='#4a2e1a'; ctx.fillRect(x0,y,x1-x0,h*.03); ctx.fillStyle='rgba(255,190,120,.3)'; ctx.fillRect(x0,y,x1-x0,1.2); ctx.fillStyle='#2e1c10'; ctx.fillRect(x0+w*.015,y+h*.03,w*.018,h*.22); ctx.fillRect(x1-w*.033,y+h*.03,w*.018,h*.22); }
    var ty=h*.76; table(w*.02,w*.32,ty);
    var gx=w*.12, gy=ty-h*.11, gr=h*.075;
    ctx.fillStyle='#6a4a2a'; ctx.fillRect(gx-2,gy+gr,4,h*.03); ctx.fillRect(gx-w*.03,ty-h*.008,w*.06,h*.008);
    var go=ctx.createRadialGradient(gx-gr*.35,gy-gr*.35,1,gx,gy,gr); go.addColorStop(0,'#5a86c8'); go.addColorStop(1,'#1e3a6a'); ctx.fillStyle=go; ctx.beginPath(); ctx.arc(gx,gy,gr,0,2*PI); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.arc(gx,gy,gr,0,2*PI); ctx.clip();
    var rot=t*.5; [[0,-.3,.5,.35],[1.9,.25,.4,.3],[3.4,-.1,.35,.45],[4.8,.35,.3,.2]].forEach(function(c){ var lon=c[0]+rot, z=Math.cos(lon); if(z<-.15) return; var px=gx+Math.sin(lon)*gr*.85, py=gy+c[1]*gr; ctx.fillStyle='rgba(120,170,90,'+(.5+.45*z)+')'; ctx.beginPath(); ctx.ellipse(px,py,gr*c[2]*Math.max(.15,z),gr*c[3],0,0,2*PI); ctx.fill(); });
    ctx.strokeStyle='rgba(230,220,180,.45)'; ctx.lineWidth=.7; for(k=0;k<4;k++){ var lm=k*PI/4+rot, rx=Math.abs(Math.cos(lm))*gr; ctx.beginPath(); ctx.ellipse(gx,gy,rx,gr,0,0,2*PI); ctx.stroke(); }
    for(k=-1;k<=1;k++){ ctx.beginPath(); ctx.ellipse(gx,gy+k*gr*.45,gr*Math.sqrt(1-k*k*.2),gr*.08,0,0,2*PI); ctx.stroke(); }
    ctx.restore();
    ctx.strokeStyle='#c8a040'; ctx.lineWidth=1.6; ctx.beginPath(); ctx.arc(gx,gy,gr+2.5,-PI*.75,PI*.75); ctx.stroke();
    ctx.fillStyle='rgba(255,255,255,.18)'; ctx.beginPath(); ctx.ellipse(gx-gr*.4,gy-gr*.45,gr*.25,gr*.15,-.6,0,2*PI); ctx.fill();
    // astrolabe pose a plat
    var lx=w*.24, ly=ty-h*.035; ctx.fillStyle='#b8862f'; ctx.beginPath(); ctx.ellipse(lx,ly,w*.035,h*.03,0,0,2*PI); ctx.fill(); ctx.strokeStyle='#5a3a12'; ctx.lineWidth=.8; ctx.beginPath(); ctx.ellipse(lx,ly,w*.026,h*.022,0,0,2*PI); ctx.stroke();
    ctx.save(); ctx.translate(lx,ly); ctx.scale(1,.85); ctx.rotate(-t*.3); ctx.beginPath(); ctx.moveTo(-w*.025,0); ctx.lineTo(w*.025,0); ctx.moveTo(0,-h*.02); ctx.lineTo(0,h*.02); ctx.stroke(); ctx.restore();
    // chandelle
    var cx2=w*.3, cy2=ty; ctx.fillStyle='#efe6d0'; ctx.fillRect(cx2-2.5,cy2-h*.06,5,h*.06); ctx.fillStyle='rgba(255,210,110,'+fl+')'; ctx.beginPath(); ctx.ellipse(cx2+Math.sin(t*7)*.5,cy2-h*.07,2,4.5,0,0,2*PI); ctx.fill(); ctx.fillStyle='#fff8e0'; ctx.beginPath(); ctx.ellipse(cx2,cy2-h*.066,.9,2,0,0,2*PI); ctx.fill();
    // ---- table de droite : carte du ciel deroulee, compas, sablier, livres ----
    table(w*.68,w*.98,ty);
    ctx.fillStyle='#e8dcbc'; ctx.beginPath(); ctx.moveTo(w*.7,ty); ctx.lineTo(w*.73,ty-h*.05); ctx.lineTo(w*.9,ty-h*.05); ctx.lineTo(w*.93,ty); ctx.fill();
    ctx.fillStyle='#c8b890'; ctx.beginPath(); ctx.ellipse(w*.7,ty-h*.003,3,h*.008,0,0,2*PI); ctx.fill(); ctx.beginPath(); ctx.ellipse(w*.93,ty-h*.003,3,h*.008,0,0,2*PI); ctx.fill();
    ctx.strokeStyle='rgba(60,50,90,.7)'; ctx.lineWidth=.7; ctx.beginPath(); ctx.ellipse(w*.815,ty-h*.025,w*.06,h*.018,0,0,2*PI); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(w*.77,ty-h*.03); ctx.lineTo(w*.8,ty-h*.02); ctx.lineTo(w*.84,ty-h*.035); ctx.lineTo(w*.86,ty-h*.015); ctx.stroke();
    ctx.fillStyle='#2a2650'; [[.77,.03],[.8,.02],[.84,.035],[.86,.015],[.75,.015],[.88,.04]].forEach(function(p){ ctx.fillRect(w*p[0]-1,ty-h*p[1]-1,2,2); });
    // compas a pointes, pose sur la carte
    ctx.strokeStyle='#c9d2da'; ctx.lineWidth=1.1; ctx.beginPath(); ctx.moveTo(w*.86,ty-h*.075); ctx.lineTo(w*.835,ty-h*.012); ctx.moveTo(w*.86,ty-h*.075); ctx.lineTo(w*.885,ty-h*.012); ctx.stroke(); ctx.fillStyle='#c8a040'; ctx.beginPath(); ctx.arc(w*.86,ty-h*.075,1.6,0,2*PI); ctx.fill();
    // sablier, le sable coule
    var hx2=w*.95, hy2=ty, hh=h*.07, sab=(t%10)/10;
    ctx.fillStyle='#6a4a2a'; ctx.fillRect(hx2-6,hy2-hh,12,2); ctx.fillRect(hx2-6,hy2-2,12,2);
    ctx.fillStyle='rgba(210,230,255,.25)'; ctx.beginPath(); ctx.moveTo(hx2-5,hy2-hh+2); ctx.lineTo(hx2+5,hy2-hh+2); ctx.lineTo(hx2+.8,hy2-hh/2); ctx.lineTo(hx2+5,hy2-2); ctx.lineTo(hx2-5,hy2-2); ctx.lineTo(hx2-.8,hy2-hh/2); ctx.fill();
    ctx.fillStyle='#e8c070'; var hs=(1-sab)*(hh/2-4); ctx.beginPath(); ctx.moveTo(hx2-hs*.9,hy2-hh/2-hs); ctx.lineTo(hx2+hs*.9,hy2-hh/2-hs); ctx.lineTo(hx2,hy2-hh/2); ctx.fill();
    var bs=sab*(hh/2-4); ctx.beginPath(); ctx.moveTo(hx2-5,hy2-2); ctx.lineTo(hx2+5,hy2-2); ctx.lineTo(hx2,hy2-2-bs); ctx.fill(); ctx.fillRect(hx2-.4,hy2-hh/2,.8,hh/2-2);
    // livres empiles et chandelle
    [['#6a1e24',.71],['#1e3a6a',.705],['#2e5a3a',.715]].forEach(function(b,j){ ctx.fillStyle=b[0]; ctx.fillRect(w*b[1],ty-h*.018-j*h*.018,w*.07,h*.018); });
    ctx.fillStyle='#efe6d0'; ctx.fillRect(w*.74-2.5,ty-h*.094,5,h*.04); ctx.fillStyle='rgba(255,210,110,'+fl+')'; ctx.beginPath(); ctx.ellipse(w*.74+Math.sin(t*6)*.5,ty-h*.104,2,4.5,0,0,2*PI); ctx.fill();
  },
  // 4 - MERCENAIRE : Gaucher au premier plan d un champ de bataille. Au fond,
  // une charge de cavaliers s elance vers les archers de l envahisseur, alignes
  // devant la ville a droite ; leurs volees, rapides et tendues, s abattent sur
  // la charge et se plantent presque toutes dans le sol. Le premier plan est
  // jonche d armes et de ruines : lances brisees, epees plantees, boucliers,
  // heaumes, roue, pans de mur, banniere tombee, fumees.
  function(ctx,w,h,t){
    var PI=Math.PI, k, i;
    _mxCiel(ctx,w,h,[[0,'#2a1a3c'],[.35,'#6a2f48'],[.6,'#c4583c'],[.76,'#f09a50'],[1,'#f7c070']]);
    _mxEtoiles(ctx,w,h,16,23,t,.3,.18);
    var hz=h*.66, sx=w*.22, sy=hz-h*.07;
    _mxHalo(ctx,sx,sy,w*.55,'rgba(255,170,90,.55)',1);
    ctx.fillStyle='#ffe6b0'; ctx.beginPath(); ctx.arc(sx,sy,h*.065,0,2*PI); ctx.fill();
    _mxCrete(ctx,w,h,.68,.05,1.7,'#7a3a4a',2);
    // ---- la ville, au fond a droite ----
    var vb=h*.62, mur='#5a2a3c', clair='rgba(255,190,130,.55)';
    ctx.fillStyle='#8a4a52'; ctx.beginPath(); ctx.moveTo(w*.56,h*.74); ctx.quadraticCurveTo(w*.7,vb-h*.02,w*.84,vb-h*.03); ctx.quadraticCurveTo(w*.98,vb-h*.02,w*1.06,h*.72); ctx.lineTo(w*1.06,h*.74); ctx.closePath(); ctx.fill();
    function tour(x,lw,ht,toit){ ctx.fillStyle=mur; ctx.fillRect(x,vb-ht,lw,ht+h*.04); if(toit){ ctx.beginPath(); ctx.moveTo(x-lw*.15,vb-ht); ctx.lineTo(x+lw*.5,vb-ht-lw*1.3); ctx.lineTo(x+lw*1.15,vb-ht); ctx.fill(); } else for(var c=0;c<3;c++) ctx.fillRect(x+c*lw*.4,vb-ht-lw*.25,lw*.22,lw*.25); ctx.fillStyle=clair; ctx.fillRect(x,vb-ht,1.2,ht+h*.04); }
    ctx.fillStyle=mur; ctx.fillRect(w*.66,vb-h*.05,w*.36,h*.08); for(var c2=w*.66;c2<w;c2+=w*.014) ctx.fillRect(c2,vb-h*.062,w*.008,h*.012);
    var r=_mxR(61); for(var m=0;m<9;m++){ var mx=w*(.69+r()*.28), mh=h*(.05+r()*.06), mw=w*(.018+r()*.02); ctx.fillStyle='#4e2434'; ctx.beginPath(); ctx.moveTo(mx,vb-h*.05); ctx.lineTo(mx,vb-h*.05-mh*.5); ctx.lineTo(mx+mw/2,vb-h*.05-mh*.5-mw*.6); ctx.lineTo(mx+mw,vb-h*.05-mh*.5); ctx.lineTo(mx+mw,vb-h*.05); ctx.fill(); }
    tour(w*.655,w*.03,h*.1,false); tour(w*.745,w*.028,h*.12,true); tour(w*.86,w*.035,h*.14,false); tour(w*.95,w*.028,h*.1,true);
    ctx.fillStyle=mur; ctx.fillRect(w*.8,vb-h*.2,w*.016,h*.16); ctx.beginPath(); ctx.moveTo(w*.795,vb-h*.2); ctx.lineTo(w*.808,vb-h*.27); ctx.lineTo(w*.821,vb-h*.2); ctx.fill();
    var r2=_mxR(7); for(var f=0;f<12;f++){ var fx=w*(.67+r2()*.3), fy=vb-h*(.02+r2()*.08); ctx.fillStyle='rgba(255,200,120,'+(.45+.35*Math.sin(t*1.5+f*1.9))+')'; ctx.fillRect(fx,fy,1.6,2); }
    for(var s=0;s<10;s++){ var ps=((t*.03+s/10)%1); _mxPoint(ctx,w*.88+ps*w*.08,vb-h*.16-ps*h*.3,w*(.01+ps*.04),'120,80,90',Math.min(1,ps*5)*(1-ps)*.4); }
    ctx.globalAlpha=1;
    // plaine du fond
    var gpl=ctx.createLinearGradient(0,h*.64,0,h*.76); gpl.addColorStop(0,'#a8605e'); gpl.addColorStop(1,'#7e4450'); ctx.fillStyle=gpl; ctx.fillRect(0,h*.665,w,h*.12);
    _mxBrume(ctx,w,h,h*.68,h*.02,'rgba(255,200,170,.3)',t,5,1);
    // ---- l envahisseur : une ligne d archers devant la ville, qui bandent et tirent ----
    var PV=4.2, cv=(t%PV)/PV;
    for(k=0;k<8;k++){ var ax=w*(.67+k*.04), ay=h*.715, as=h*.042, tend=cv<.85?Math.min(1,cv/.85):0;
      ctx.fillStyle='#2a1420'; ctx.strokeStyle='#2a1420'; ctx.lineCap='round';
      ctx.lineWidth=as*.1; ctx.beginPath(); ctx.moveTo(ax-as*.08,ay); ctx.lineTo(ax,ay-as*.4); ctx.lineTo(ax+as*.12,ay); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(ax-as*.12,ay-as*.38); ctx.lineTo(ax-as*.08,ay-as*.82); ctx.lineTo(ax+as*.1,ay-as*.82); ctx.lineTo(ax+as*.12,ay-as*.38); ctx.fill();
      ctx.beginPath(); ctx.arc(ax,ay-as*.95,as*.13,0,2*PI); ctx.fill();
      ctx.lineWidth=as*.08; ctx.beginPath(); ctx.moveTo(ax-as*.05,ay-as*.75); ctx.lineTo(ax-as*.42,ay-as*.82); ctx.moveTo(ax+as*.05,ay-as*.75); ctx.lineTo(ax-as*.05+tend*as*.18,ay-as*.82); ctx.stroke();
      ctx.lineWidth=as*.07; ctx.beginPath(); ctx.arc(ax-as*.18,ay-as*.82,as*.38,PI*.72,PI*1.28,false); ctx.stroke();
      var bx0=ax-as*.18+Math.cos(PI*.72)*as*.38, by0=ay-as*.82+Math.sin(PI*.72)*as*.38, by1=ay-as*.82-Math.sin(PI*.72)*as*.38;
      ctx.lineWidth=.7; ctx.strokeStyle='rgba(220,200,180,.7)'; ctx.beginPath(); ctx.moveTo(bx0,by1); ctx.lineTo(ax-as*.05+tend*as*.18,ay-as*.82); ctx.lineTo(bx0,by0); ctx.stroke(); }
    // ---- la charge, au fond : cavaliers qui s elancent vers la droite ----
    function cavalier(x,y,s,ph,col,fan,al){
      var g=t*5.5+ph, bond=Math.abs(Math.sin(g))*s*.08;
      ctx.save(); ctx.globalAlpha=al; ctx.translate(x,y-bond); ctx.fillStyle=col; ctx.strokeStyle=col; ctx.lineCap='round'; ctx.lineWidth=s*.09;
      [[-.34,0],[-.22,1.3],[.26,2.4],[.38,3.6]].forEach(function(j){ var a=Math.sin(g+j[1])*.7, kx=s*j[0]+Math.sin(a)*s*.2, ky=s*.12+Math.cos(a)*s*.2; ctx.beginPath(); ctx.moveTo(s*j[0],s*.02); ctx.lineTo(kx,ky); ctx.lineTo(kx+Math.sin(a*1.4-.4)*s*.18,ky+s*.18); ctx.stroke(); });
      ctx.beginPath(); ctx.ellipse(0,-s*.06,s*.46,s*.17,0,0,2*PI); ctx.fill();
      ctx.beginPath(); ctx.moveTo(s*.3,-s*.14); ctx.lineTo(s*.5,-s*.42); ctx.lineTo(s*.64,-s*.38); ctx.lineTo(s*.48,-s*.04); ctx.fill();
      ctx.beginPath(); ctx.ellipse(s*.62,-s*.36,s*.13,s*.065,.5,0,2*PI); ctx.fill();
      ctx.lineWidth=s*.07; ctx.beginPath(); ctx.moveTo(-s*.44,-s*.1); ctx.quadraticCurveTo(-s*.62,-s*.1+Math.sin(g)*s*.06,-s*.7,s*.06); ctx.stroke();
      ctx.fillStyle=fan; ctx.globalAlpha=.85*al; ctx.beginPath(); ctx.moveTo(-s*.3,-s*.18); ctx.lineTo(s*.25,-s*.18); ctx.lineTo(s*.2,s*.06); ctx.lineTo(-s*.12,s*.08+Math.sin(g)*s*.03); ctx.lineTo(-s*.38,s*.02); ctx.fill(); ctx.globalAlpha=al; ctx.fillStyle=col;
      ctx.beginPath(); ctx.moveTo(-s*.08,-s*.2); ctx.lineTo(s*.02,-s*.56); ctx.lineTo(s*.16,-s*.54); ctx.lineTo(s*.12,-s*.2); ctx.fill();
      ctx.beginPath(); ctx.arc(s*.1,-s*.64,s*.1,0,2*PI); ctx.fill();
      ctx.lineWidth=s*.035; ctx.beginPath(); ctx.moveTo(-s*.2,-s*.5); ctx.lineTo(s*1.25,-s*.3); ctx.stroke();
      ctx.fillStyle=fan; ctx.beginPath(); ctx.moveTo(s*.95,-s*.34); ctx.lineTo(s*.72+Math.sin(g*.7)*s*.03,-s*.46); ctx.lineTo(s*.8,-s*.33); ctx.fill();
      ctx.restore(); }
    var FAN=['#2a4a8a','#9a2a2a','#c09a3a'];
    // la charge part de la gauche et s arrete avant les archers : chaque cavalier apparait puis s efface dans la poussiere
    for(k=0;k<7;k++){ var per=w*.72, x=((t*w*.03+k*w*.103)%per)-w*.12, y=h*.72+(k%2)*h*.012, al=Math.min(1,(x+w*.12)/(w*.08))*Math.min(1,(w*.6-x)/(w*.1));
      _mxPoint(ctx,x-h*.04,y,h*.035,'210,150,130',.4*al); cavalier(x,y,h*.06,k*1.7,'#3a1828',FAN[k%3],Math.max(0,al)); if(al<.6) _mxPoint(ctx,x,y-h*.02,h*.05,'210,150,130',(1-al)*.35); }
    ctx.globalAlpha=1;
    // ---- volees : fleches rapides et tendues, qui se plantent presque toutes dans le sol ----
    var vr=_mxR(300+Math.floor(t/PV)), tir=cv>=.85?(cv-.85)/.15:-1, fl2=[];
    for(k=0;k<8;k++){ fl2.push([w*(.67+k*.04)-h*.02,h*.68,w*(.08+vr()*.48),h*(.715+vr()*.03),vr()]); }
    // fleches de la volee precedente, plantees (s effacent lentement)
    var vr0=_mxR(300+Math.floor(t/PV)-1), age=(t%PV)/PV;
    for(k=0;k<8;k++){ var px=w*(.08+vr0()*.48), py=h*(.715+vr0()*.03); vr0(); ctx.globalAlpha=1-age*.7; ctx.strokeStyle='#8a6440'; ctx.lineWidth=1.1; ctx.beginPath(); ctx.moveTo(px,py); ctx.lineTo(px+h*.022,py-h*.022); ctx.stroke(); ctx.strokeStyle='#f2ead6'; ctx.lineWidth=1.8; ctx.beginPath(); ctx.moveTo(px+h*.017,py-h*.017); ctx.lineTo(px+h*.022,py-h*.022); ctx.stroke(); }
    ctx.globalAlpha=1;
    if(tir>=0){ fl2.forEach(function(a){ var u=Math.min(1,tir*1.15), ax=a[0]+(a[2]-a[0])*u, ay=a[1]+(a[3]-a[1])*u-h*.06*4*u*(1-u)*.5, vx=a[2]-a[0], vy=a[3]-a[1]-h*.06*.5*4*(1-2*u), n=Math.sqrt(vx*vx+vy*vy), L=h*.03;
      ctx.strokeStyle='#8a6440'; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(ax,ay); ctx.lineTo(ax-vx/n*L,ay-vy/n*L); ctx.stroke();
      ctx.strokeStyle='#f2ead6'; ctx.lineWidth=2; ctx.beginPath(); ctx.moveTo(ax-vx/n*L*.8,ay-vy/n*L*.8); ctx.lineTo(ax-vx/n*L,ay-vy/n*L); ctx.stroke();
      if(u>=1) _mxPoint(ctx,a[2],a[3],h*.012,'200,150,130',.5); }); ctx.globalAlpha=1; }
    // corbeaux lointains
    for(var cb=0;cb<3;cb++){ var pc=t*.2+cb*2.1, cx=w*(.45+.12*Math.cos(pc))+cb*8, cy=h*(.22+.05*Math.sin(pc)), wg=Math.sin(t*6+cb*2)*3; ctx.strokeStyle='#1a0c14'; ctx.lineWidth=1.4; ctx.beginPath(); ctx.moveTo(cx-6,cy-wg); ctx.quadraticCurveTo(cx-3,cy-1,cx,cy); ctx.quadraticCurveTo(cx+3,cy-1,cx+6,cy-wg); ctx.stroke(); }
    // ---- premier plan : le champ de bataille jonche d armes et de ruines ----
    var sol=h*.76;
    var gs=ctx.createLinearGradient(0,sol,0,h); gs.addColorStop(0,'#6a3a40'); gs.addColorStop(.4,'#4a2830'); gs.addColorStop(1,'#2a1418'); ctx.fillStyle=gs;
    ctx.beginPath(); ctx.moveTo(0,h); for(var xs=0;xs<=w;xs+=4) ctx.lineTo(xs,sol+h*.012*Math.sin(xs/w*7+1)+h*.006*Math.sin(xs/w*19)); ctx.lineTo(w,h); ctx.fill();
    // flaques de boue qui refletent le ciel, ornieres
    [[.2,.88,.07],[.74,.9,.06],[.5,.97,.05]].forEach(function(p){ ctx.fillStyle='rgba(240,160,110,.25)'; ctx.beginPath(); ctx.ellipse(w*p[0],h*p[1],w*p[2],h*.012,0,0,2*PI); ctx.fill(); });
    ctx.strokeStyle='rgba(20,8,12,.35)'; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(0,h*.84); ctx.quadraticCurveTo(w*.3,h*.8,w*.45,h*.82); ctx.moveTo(w*.6,h*.83); ctx.quadraticCurveTo(w*.8,h*.8,w,h*.82); ctx.stroke();
    // ruines : deux pans de mur effondres, a gauche et a droite
    function pan(x,y,lw,ht,seed){ var rp=_mxR(seed); ctx.fillStyle='#6a4a4e'; ctx.beginPath(); ctx.moveTo(x,y); ctx.lineTo(x,y-ht*.7); for(var k4=0;k4<=6;k4++) ctx.lineTo(x+lw*k4/6,y-ht*(.55+rp()*.45)); ctx.lineTo(x+lw,y); ctx.fill();
      ctx.save(); ctx.clip(); ctx.strokeStyle='rgba(30,14,18,.45)'; ctx.lineWidth=.8; ctx.beginPath(); for(var yy=y-h*.012;yy>y-ht;yy-=h*.016){ ctx.moveTo(x,yy); ctx.lineTo(x+lw,yy); } for(var row=0,y2=y;y2>y-ht;y2-=h*.016,row++){ for(var x2=x+(row%2)*lw*.08;x2<x+lw;x2+=lw*.16){ ctx.moveTo(x2,y2); ctx.lineTo(x2,y2-h*.016); } } ctx.stroke(); ctx.restore();
      ctx.fillStyle='rgba(255,190,140,.25)'; ctx.fillRect(x+lw-1.5,y-ht*.8,1.5,ht*.8);
      for(var k5=0;k5<5;k5++){ ctx.fillStyle=k5%2?'#5a3c40':'#7a5a5e'; ctx.fillRect(x+lw+rp()*lw*.5,y-rp()*h*.012-3,w*(.01+rp()*.012),h*(.01+rp()*.01)); } }
    pan(w*.0,h*.86,w*.13,h*.14,5); pan(w*.82,h*.84,w*.11,h*.1,9);
    // roue de chariot brisee, a moitie enfoncee
    ctx.save(); ctx.translate(w*.25,h*.83); ctx.rotate(.2); ctx.strokeStyle='#3a2414'; ctx.lineWidth=2.6; ctx.beginPath(); ctx.arc(0,0,h*.05,PI*.95,PI*2.3); ctx.stroke(); ctx.lineWidth=1.5; ctx.beginPath(); for(k=0;k<6;k++){ if(k==2) continue; var an=k*PI/3; ctx.moveTo(0,0); ctx.lineTo(Math.cos(an)*h*.05,Math.sin(an)*h*.05); } ctx.stroke(); ctx.restore();
    // lances brisees couchees, epees plantees, boucliers, heaumes
    ctx.lineCap='round';
    [[.06,.95,.2,-.12],[.62,.93,.16,.08],[.86,.97,.18,-.05],[.3,.98,.12,.15]].forEach(function(l){ ctx.strokeStyle='#5a3a22'; ctx.lineWidth=2.2; ctx.beginPath(); ctx.moveTo(w*l[0],h*l[1]); ctx.lineTo(w*(l[0]+l[2]),h*l[1]+w*l[2]*l[3]); ctx.stroke(); ctx.strokeStyle='#c9d2da'; ctx.lineWidth=2.6; ctx.beginPath(); ctx.moveTo(w*(l[0]+l[2]),h*l[1]+w*l[2]*l[3]); ctx.lineTo(w*(l[0]+l[2]+.02),h*l[1]+w*(l[2]+.02)*l[3]); ctx.stroke(); });
    function epee(x,y,ht,a){ ctx.save(); ctx.translate(x,y); ctx.rotate(a); ctx.fillStyle='#b8c2cc'; ctx.fillRect(-1.2,-ht,2.4,ht); ctx.fillStyle='#6a5030'; ctx.fillRect(-ht*.18,-ht,ht*.36,2.2); ctx.fillRect(-1.3,-ht*1.2,2.6,ht*.2); ctx.fillStyle='#b5a070'; ctx.beginPath(); ctx.arc(0,-ht*1.22,2,0,2*PI); ctx.fill(); ctx.fillStyle='rgba(255,220,180,.5)'; ctx.fillRect(.2,-ht,.8,ht); ctx.restore(); }
    epee(w*.17,h*.9,h*.08,-.15); epee(w*.7,h*.88,h*.07,.12); epee(w*.93,h*.92,h*.09,-.08); epee(w*.35,h*.86,h*.05,.2);
    function bouclier(x,y,s,c,a){ ctx.save(); ctx.translate(x,y); ctx.rotate(a); ctx.scale(1,.55); ctx.fillStyle=c; ctx.beginPath(); ctx.moveTo(-s,-s); ctx.lineTo(s,-s); ctx.lineTo(s,0); ctx.quadraticCurveTo(s,s*.9,0,s*1.2); ctx.quadraticCurveTo(-s,s*.9,-s,0); ctx.closePath(); ctx.fill(); ctx.strokeStyle='rgba(20,10,10,.5)'; ctx.lineWidth=1.5; ctx.stroke(); ctx.fillStyle='#c09a3a'; ctx.fillRect(-s*.12,-s*.9,s*.24,s*1.8); ctx.restore(); }
    bouclier(w*.12,h*.92,h*.035,'#2a4a8a',.3); bouclier(w*.78,h*.95,h*.04,'#9a2a2a',-.2); bouclier(w*.66,h*.84,h*.025,'#2a4a8a',.1);
    function heaume(x,y,s){ ctx.fillStyle='#8d969e'; ctx.beginPath(); ctx.ellipse(x,y,s,s*.75,0,PI,2*PI); ctx.fill(); ctx.fillRect(x-s,y,s*2,s*.35); ctx.fillStyle='#2a1a1e'; ctx.fillRect(x-s*.7,y-s*.15,s*1.4,s*.14); ctx.fillStyle='rgba(255,220,180,.5)'; ctx.beginPath(); ctx.ellipse(x-s*.35,y-s*.45,s*.25,s*.12,-.4,0,2*PI); ctx.fill(); }
    heaume(w*.42,h*.95,h*.022); heaume(w*.88,h*.87,h*.018);
    // banniere tombee, en travers
    ctx.strokeStyle='#3a2418'; ctx.lineWidth=1.6; ctx.beginPath(); ctx.moveTo(w*.58,h*.99); ctx.lineTo(w*.68,h*.96); ctx.stroke();
    ctx.fillStyle='#c09a3a'; ctx.beginPath(); ctx.moveTo(w*.66,h*.965); ctx.quadraticCurveTo(w*.7,h*.975+Math.sin(t*1.2)*1.5,w*.74,h*.985); ctx.lineTo(w*.73,h*1.01); ctx.lineTo(w*.66,h*.995); ctx.fill();
    // fleches plantees au premier plan (pas devant Gaucher)
    var rq=_mxR(51); for(var q=0;q<10;q++){ var qx=rq()*w, qy=h*(.8+rq()*.18), qa=-1.1-rq()*.4; if(qx>w*.4&&qx<w*.6){ rq(); continue; } ctx.strokeStyle='#6a4a2e'; ctx.lineWidth=1.1; ctx.beginPath(); ctx.moveTo(qx,qy); ctx.lineTo(qx+Math.cos(qa)*h*.05,qy+Math.sin(qa)*h*.05); ctx.stroke(); ctx.strokeStyle='#e2d8c0'; ctx.lineWidth=2.4; ctx.beginPath(); ctx.moveTo(qx+Math.cos(qa)*h*.044,qy+Math.sin(qa)*h*.044); ctx.lineTo(qx+Math.cos(qa)*h*.05,qy+Math.sin(qa)*h*.05); ctx.stroke(); }
    // fumees qui montent du champ, braises
    [[.08,.8],[.9,.78],[.3,.79]].forEach(function(f2,j){ for(var sm=0;sm<8;sm++){ var pp=((t*.05+sm/8+j*.3)%1); _mxPoint(ctx,w*f2[0]+pp*w*.06,h*f2[1]-pp*h*.35,w*(.012+pp*.05),'90,70,80',Math.min(1,pp*6)*(1-pp)*.45); } });
    ctx.globalAlpha=1; var rb=_mxR(17); for(var br=0;br<12;br++){ var p3=((t*(.08+rb()*.05)+rb())%1); ctx.globalAlpha=(1-p3)*(.5+.5*Math.sin(t*7+br)); ctx.fillStyle=br%2?'#ffb35a':'#ff7a3a'; ctx.fillRect(w*(.05+rb()*.9)+Math.sin(t+br)*4,h*.82-p3*h*.2,1.4,1.4); }
    ctx.globalAlpha=1;
  },
  // 5 - SAGE : en montagne, juste apres le coucher du soleil. Un large chemin
  // enneige monte vers le col et tourne a droite ; cloture de bois a gauche ;
  // sapins enneiges qui ondulent au vent ; a droite, la grotte de Bertrand et
  // sa chandelle a l entree. Au loin un loup hurle. La lune se degage des
  // nuages. Il neige doucement.
  function(ctx,w,h,t){
    var PI=Math.PI, k, i;
    _mxCiel(ctx,w,h,[[0,'#151a44'],[.35,'#3a2f66'],[.58,'#a0577a'],[.72,'#e98a6a'],[.82,'#f2b27a'],[1,'#f2b27a']]);
    _mxEtoiles(ctx,w,h,40,51,t,.55,.32);
    // la lune, que les nuages devoilent puis recouvrent (cycle de 40 s)
    var mx=w*.34, my=h*.17, mr=h*.05, cy=(t%80)/80, dv=cy<.12?0:cy<.5?(cy-.12)/.38:cy<.86?1:1-(cy-.86)/.14; dv=dv*dv*(3-2*dv);
    _mxHalo(ctx,mx,my,w*.2,'rgba(220,225,255,.55)',.25+.75*dv);
    ctx.fillStyle='#f2f0e4'; ctx.beginPath(); ctx.arc(mx,my,mr,0,2*PI); ctx.fill();
    ctx.fillStyle='rgba(180,180,200,.35)'; ctx.beginPath(); ctx.arc(mx-mr*.3,my-mr*.2,mr*.22,0,2*PI); ctx.arc(mx+mr*.3,my+mr*.25,mr*.15,0,2*PI); ctx.fill();
    // nuage : si bord est donne, un liseré clair epouse tout le haut du nuage (meme forme, decalee vers le haut)
    function nuage(x,y,s,col,bord){ function forme(dy){ ctx.beginPath(); [[-1,.15,.55],[-.45,-.15,.7],[.15,-.3,.75],[.7,-.05,.6],[1.15,.2,.45],[.1,.2,.7]].forEach(function(c){ ctx.moveTo(x+c[0]*s+c[2]*s,y+dy+c[1]*s); ctx.arc(x+c[0]*s,y+dy+c[1]*s,c[2]*s,0,2*PI); }); }
      if(bord){ ctx.fillStyle=bord; forme(-1.6); ctx.fill(); } ctx.fillStyle=col; forme(0); ctx.fill(); }
    var lune=Math.max(0,1-dv);
    nuage(mx-w*.03-dv*w*.3,my+h*.01,h*.06,'rgba(52,44,92,.96)','rgba(230,230,255,'+(.35+.4*dv)+')');
    nuage(mx+w*.06+dv*w*.34,my-h*.015,h*.05,'rgba(60,50,100,.95)','rgba(230,230,255,'+(.3+.4*dv)+')');
    nuage(w*.8+Math.sin(t*.02)*w*.03,h*.1,h*.04,'rgba(70,58,110,.7)',null); nuage(w*.08+Math.sin(t*.016)*w*.03,h*.3,h*.035,'rgba(150,90,120,.55)',null);
    // sommets lointains, rose du soir sur les aretes enneigees
    function chaine(base,amp,seed,fq,col,neige){ ctx.fillStyle=col; ctx.beginPath(); ctx.moveTo(0,h); var pts=[]; for(var x=0;x<=w;x+=3){ var y=h*base-h*amp*(Math.abs(_mxBruit(x/w*fq,seed))*1.6+.2); pts.push([x,y]); ctx.lineTo(x,y); } ctx.lineTo(w,h); ctx.fill();
      if(neige){ ctx.strokeStyle=neige; ctx.lineWidth=1.4; ctx.beginPath(); pts.forEach(function(p,j){ if(j) ctx.lineTo(p[0],p[1]); else ctx.moveTo(p[0],p[1]); }); ctx.stroke(); } }
    // massifs lointains : aretes dechiquetees, versant eclaire par le couchant (a gauche) et versant a l ombre,
    // neves au sommet, couloirs, voile de brume a leur pied ; deux plans, le plus lointain plus pale
    function massif(cx,base,ht,lg,seed,C){
      var r=_mxR(seed), sx=cx+(r()-.5)*lg*.2, sy=base-ht, G=[], D=[], n=9, k3;
      for(k3=0;k3<=n;k3++){ var u=k3/n; G.push([cx-lg+(sx-cx+lg)*u+(k3&&k3<n?(r()-.5)*lg*.08:0), base+(sy-base)*u+(k3&&k3<n?(r()-.5)*ht*.08:0)]); }
      for(k3=0;k3<=n;k3++){ var u2=k3/n; D.push([sx+(cx+lg-sx)*u2+(k3&&k3<n?(r()-.5)*lg*.08:0), sy+(base-sy)*u2+(k3&&k3<n?(r()-.5)*ht*.08:0)]); }
      function trace(){ ctx.beginPath(); G.forEach(function(p,j){ if(j) ctx.lineTo(p[0],p[1]); else ctx.moveTo(p[0],p[1]); }); D.forEach(function(p){ ctx.lineTo(p[0],p[1]); }); ctx.closePath(); }
      trace(); ctx.fillStyle=C[0]; ctx.fill();
      ctx.save(); trace(); ctx.clip();
      // versant eclaire : de l arete gauche jusqu a une epine qui descend du sommet
      var E=[]; for(k3=0;k3<=6;k3++){ var u3=k3/6; E.push([sx+lg*.18*u3+(k3?(r()-.5)*lg*.06:0), sy+(base-sy)*u3]); }
      ctx.fillStyle=C[1]; ctx.beginPath(); G.forEach(function(p,j){ if(j) ctx.lineTo(p[0],p[1]); else ctx.moveTo(p[0],p[1]); }); for(k3=0;k3<E.length;k3++) ctx.lineTo(E[k3][0],E[k3][1]); ctx.closePath(); ctx.fill();
      // neves : sous le sommet, bord inferieur en dents de scie, plus clair cote soleil
      var sl=sy+ht*(.32+r()*.12); ctx.beginPath(); ctx.moveTo(cx-lg,sy-2); ctx.lineTo(cx+lg,sy-2); ctx.lineTo(cx+lg,sl);
      for(k3=12;k3>=0;k3--){ var xx=cx-lg+lg*2*k3/12; ctx.lineTo(xx,sl+(k3%2?ht*.09:-ht*.02)+(r()-.5)*ht*.05); } ctx.closePath();
      ctx.save(); ctx.clip(); ctx.fillStyle=C[3]; ctx.fillRect(cx-lg,sy-2,lg*2,ht); ctx.fillStyle=C[2]; ctx.beginPath(); G.forEach(function(p,j){ if(j) ctx.lineTo(p[0],p[1]); else ctx.moveTo(p[0],p[1]); }); for(k3=0;k3<E.length;k3++) ctx.lineTo(E[k3][0],E[k3][1]); ctx.closePath(); ctx.fill(); ctx.restore();
      // couloirs et barres rocheuses
      ctx.strokeStyle=C[4]; ctx.lineWidth=.8; for(k3=0;k3<5;k3++){ var gx0=sx+(r()-.5)*lg*.9, gy0=sy+ht*(.15+r()*.3); ctx.beginPath(); ctx.moveTo(gx0,gy0); ctx.lineTo(gx0+(r()-.5)*lg*.15,gy0+ht*(.2+r()*.3)); ctx.stroke(); }
      ctx.restore();
      ctx.strokeStyle=C[5]; ctx.lineWidth=1; ctx.beginPath(); G.forEach(function(p,j){ if(j) ctx.lineTo(p[0],p[1]); else ctx.moveTo(p[0],p[1]); }); ctx.stroke();
    }
    var LOIN=['#7a74a6','#b294b0','#fbe3e4','#d2d4ec','rgba(90,84,130,.45)','rgba(255,210,200,.8)'], MI=['#4c4a7c','#7e6a96','#f2d6dc','#b4b8dc','rgba(40,36,70,.5)','rgba(255,200,195,.6)'];
    massif(w*.08,h*.6,h*.3,w*.2,3,LOIN); massif(w*.32,h*.6,h*.4,w*.22,7,LOIN); massif(w*.58,h*.6,h*.32,w*.2,11,LOIN); massif(w*.86,h*.6,h*.36,w*.2,13,LOIN);
    var bru=ctx.createLinearGradient(0,h*.42,0,h*.6); bru.addColorStop(0,'rgba(150,120,170,0)'); bru.addColorStop(1,'rgba(150,120,170,.55)'); ctx.fillStyle=bru; ctx.fillRect(0,h*.42,w,h*.18);
    massif(w*.2,h*.6,h*.2,w*.17,21,MI); massif(w*.45,h*.6,h*.16,w*.15,25,MI); massif(w*.66,h*.6,h*.22,w*.16,29,MI);
    var bru2=ctx.createLinearGradient(0,h*.5,0,h*.6); bru2.addColorStop(0,'rgba(140,120,170,0)'); bru2.addColorStop(1,'rgba(140,120,170,.5)'); ctx.fillStyle=bru2; ctx.fillRect(0,h*.5,w,h*.1);
    // ---- le terrain : un plateau enneige qui monte jusqu au col ----
    var TT=[[0,.6],[.25,.585],[.45,.56],[.6,.535],[.78,.52],[1,.5]];
    function terre(x){ var f=x/w; for(var j=1;j<TT.length;j++){ if(f<=TT[j][0]){ var u=(f-TT[j-1][0])/(TT[j][0]-TT[j-1][0]); return h*(TT[j-1][1]+(TT[j][1]-TT[j-1][1])*u); } } return h*TT[TT.length-1][1]; }
    var gn=ctx.createLinearGradient(0,h*.5,0,h); gn.addColorStop(0,'#aeaad0'); gn.addColorStop(1,'#77739f'); ctx.fillStyle=gn;
    ctx.beginPath(); ctx.moveTo(0,h); for(var xt=0;xt<=w;xt+=4) ctx.lineTo(xt,terre(xt)); ctx.lineTo(w,h); ctx.fill();
    ctx.strokeStyle='rgba(255,225,230,.55)'; ctx.lineWidth=1.2; ctx.beginPath(); for(xt=0;xt<=w;xt+=4){ if(xt) ctx.lineTo(xt,terre(xt)); else ctx.moveTo(xt,terre(xt)); } ctx.stroke();
    // petits sapins lointains poses sur la crete du plateau
    var rf=_mxR(14); for(k=0;k<40;k++){ var fx=rf()*w, fh=h*(.025+rf()*.025), fy=terre(fx)+h*(.004+rf()*.02); if(fx>w*.47&&fx<w*.66){ continue; } ctx.fillStyle='#1c3a3e'; ctx.beginPath(); ctx.moveTo(fx-fh*.32,fy); ctx.lineTo(fx,fy-fh); ctx.lineTo(fx+fh*.32,fy); ctx.fill(); ctx.fillStyle='rgba(235,238,250,.5)'; ctx.beginPath(); ctx.moveTo(fx-fh*.13,fy-fh*.6); ctx.lineTo(fx,fy-fh); ctx.lineTo(fx+fh*.13,fy-fh*.6); ctx.fill(); }
    // ---- le loup, au loin, assis sur un rocher a gauche du col : il hurle ----
    var lx=w*.43, lb=terre(w*.43)+h*.01;
    ctx.fillStyle='#3a3658'; ctx.beginPath(); ctx.moveTo(lx-w*.07,lb); ctx.quadraticCurveTo(lx-w*.06,lb-h*.05,lx-w*.02,lb-h*.065); ctx.lineTo(lx+w*.035,lb-h*.068); ctx.quadraticCurveTo(lx+w*.06,lb-h*.04,lx+w*.07,lb); ctx.fill();
    ctx.fillStyle='rgba(240,240,252,.85)'; ctx.beginPath(); ctx.moveTo(lx-w*.045,lb-h*.058); ctx.quadraticCurveTo(lx-w*.02,lb-h*.072,lx+w*.035,lb-h*.068); ctx.quadraticCurveTo(lx+w*.045,lb-h*.06,lx+w*.05,lb-h*.05); ctx.quadraticCurveTo(lx,lb-h*.058,lx-w*.045,lb-h*.058); ctx.fill();
    var cl=(t%9)/9, hu=cl<.15?cl/.15:cl<.6?1:cl<.72?1-(cl-.6)/.12:0; hu=hu*hu*(3-2*hu);
    var s=h*.075, wx=lx+w*.005, wy=lb-h*.066;
    ctx.save(); ctx.translate(wx,wy); ctx.fillStyle='#16142c';
    // queue touffue posee au sol
    ctx.beginPath(); ctx.moveTo(-s*.3,-s*.05); ctx.quadraticCurveTo(-s*.75,-s*.02,-s*.85,s*.02); ctx.quadraticCurveTo(-s*.6,s*.06,-s*.25,s*.02); ctx.fill();
    // corps assis : arriere-train, dos qui se redresse, poitrail
    ctx.beginPath(); ctx.moveTo(-s*.42,0); ctx.quadraticCurveTo(-s*.5,-s*.34,-s*.22,-s*.5); ctx.quadraticCurveTo(-s*.05,-s*.62,s*.08,-s*.82); ctx.lineTo(s*.26,-s*.78); ctx.quadraticCurveTo(s*.3,-s*.5,s*.2,-s*.28); ctx.lineTo(s*.18,0); ctx.closePath(); ctx.fill();
    // pattes avant droites, cuisse
    ctx.fillRect(s*.06,-s*.3,s*.07,s*.3); ctx.fillRect(s*.16,-s*.3,s*.06,s*.3); ctx.beginPath(); ctx.ellipse(-s*.24,-s*.12,s*.2,s*.13,-.2,0,2*PI); ctx.fill();
    ctx.beginPath(); ctx.ellipse(s*.12,0,s*.09,s*.03,0,0,2*PI); ctx.ellipse(-s*.08,0,s*.1,s*.03,0,0,2*PI); ctx.fill();
    // collerette de fourrure sur le poitrail
    ctx.beginPath(); ctx.moveTo(s*.1,-s*.78); ctx.lineTo(s*.3,-s*.62); ctx.lineTo(s*.22,-s*.58); ctx.lineTo(s*.3,-s*.5); ctx.lineTo(s*.2,-s*.46); ctx.lineTo(s*.24,-s*.38); ctx.lineTo(s*.12,-s*.4); ctx.fill();
    // tete : se leve vers la lune et hurle
    ctx.save(); ctx.translate(s*.17,-s*.8); ctx.rotate(-.25-hu*.95);
    ctx.beginPath(); ctx.moveTo(-s*.1,s*.06); ctx.quadraticCurveTo(-s*.06,-s*.12,s*.08,-s*.12); ctx.lineTo(s*.34,-s*.06); ctx.lineTo(s*.36,-s*.02-hu*s*.02); ctx.lineTo(s*.14,0); ctx.lineTo(s*.32,s*.02+hu*s*.06); ctx.lineTo(s*.3,s*.05+hu*s*.07); ctx.lineTo(s*.1,s*.08); ctx.quadraticCurveTo(-s*.02,s*.14,-s*.1,s*.06); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-s*.04,-s*.1); ctx.lineTo(-s*.02,-s*.3); ctx.lineTo(s*.06,-s*.11); ctx.fill(); ctx.beginPath(); ctx.moveTo(s*.03,-s*.11); ctx.lineTo(s*.06,-s*.27); ctx.lineTo(s*.12,-s*.1); ctx.fill();
    ctx.fillStyle='rgba(200,205,240,.55)'; ctx.fillRect(s*.12,-s*.07,s*.025,s*.02);
    ctx.restore();
    // liseré de lune sur le dos et la tete
    ctx.strokeStyle='rgba(215,215,250,.45)'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(-s*.45,-s*.12); ctx.quadraticCurveTo(-s*.46,-s*.36,-s*.22,-s*.5); ctx.quadraticCurveTo(-s*.05,-s*.62,s*.08,-s*.82); ctx.stroke();
    ctx.restore();
    // ---- le chemin : ligne mediane courbe, largeur selon la profondeur ----
    function centre(u){ var P=[[.5,1.04],[.44,.74],[.5,.6],[.76,.53]], a1=1-u; var x=a1*a1*a1*P[0][0]+3*a1*a1*u*P[1][0]+3*a1*u*u*P[2][0]+u*u*u*P[3][0], y=a1*a1*a1*P[0][1]+3*a1*a1*u*P[1][1]+3*a1*u*u*P[2][1]+u*u*u*P[3][1]; return [x*w,y*h]; }
    function demi(u){ return w*(.3*Math.pow(1-u,1.7)+.016); }
    var GA=[], DR=[]; for(k=0;k<=40;k++){ var u=k/40, c=centre(u), c2=centre(Math.min(1,u+.01)), c1=centre(Math.max(0,u-.01)), dx=c2[0]-c1[0], dy=c2[1]-c1[1], n=Math.sqrt(dx*dx+dy*dy)||1, nx=-dy/n, ny=dx/n, hw=demi(u); GA.push([c[0]-nx*hw,c[1]-ny*hw]); DR.push([c[0]+nx*hw,c[1]+ny*hw]); }
    var gc=ctx.createLinearGradient(0,h*.53,0,h); gc.addColorStop(0,'#d2cce6'); gc.addColorStop(1,'#aaa4cc'); ctx.fillStyle=gc; ctx.beginPath(); GA.forEach(function(p,j){ if(j) ctx.lineTo(p[0],p[1]); else ctx.moveTo(p[0],p[1]); }); for(k=DR.length-1;k>=0;k--) ctx.lineTo(DR[k][0],DR[k][1]); ctx.fill();
    ctx.strokeStyle='rgba(100,92,140,.35)'; ctx.lineWidth=1; ctx.beginPath(); GA.forEach(function(p,j){ if(j) ctx.lineTo(p[0],p[1]); else ctx.moveTo(p[0],p[1]); }); ctx.stroke(); ctx.beginPath(); DR.forEach(function(p,j){ if(j) ctx.lineTo(p[0],p[1]); else ctx.moveTo(p[0],p[1]); }); ctx.stroke();
    [.33,.67].forEach(function(f){ ctx.strokeStyle='rgba(110,100,150,.3)'; ctx.lineWidth=1.3; ctx.beginPath(); for(var j=0;j<=40;j++){ var x=GA[j][0]+(DR[j][0]-GA[j][0])*f, y=GA[j][1]+(DR[j][1]-GA[j][1])*f; if(j) ctx.lineTo(x,y); else ctx.moveTo(x,y); } ctx.stroke(); });
    // ---- la paroi et la grotte, a droite, prises dans la montagne ----
    var fl=.78+.12*Math.sin(t*7.3)+.1*Math.sin(t*11.7+1);
    var PR=[]; for(k=0;k<=30;k++){ var u2=k/30, px=w*(.67+.36*u2)+_mxBruit(u2*7,3)*w*.012, py=h*(.62-.6*Math.pow(u2,.6))+(u2>.75?h*.5*Math.pow((u2-.75)/.25,2)*.2:0)+_mxBruit(u2*11,5)*h*.025; PR.push([px,py]); }
    var gr=ctx.createLinearGradient(w*.66,0,w,0); gr.addColorStop(0,'#2e2846'); gr.addColorStop(.5,'#4a4268'); gr.addColorStop(1,'#3a3456'); ctx.fillStyle=gr;
    // le pied de la montagne longe le bord droit du chemin, de l avant jusqu au virage : le chemin tourne derriere elle
    var J=26, BD=[]; for(k=0;k<=J;k++) BD.push([DR[k][0]+w*(.02-.0005*k),DR[k][1]+h*.004]);
    // le pied de la montagne longe le bord droit du chemin, de l avant jusqu au virage : le chemin tourne derriere elle
    function mont(){ ctx.beginPath(); ctx.moveTo(BD[0][0],h); BD.forEach(function(p){ ctx.lineTo(p[0],p[1]); }); ctx.quadraticCurveTo(PR[0][0]-w*.01,BD[J][1]-h*.01,PR[0][0],PR[0][1]); PR.forEach(function(p){ ctx.lineTo(p[0],p[1]); }); ctx.lineTo(w*1.03,h); ctx.closePath(); }
    mont(); ctx.fill();
    // face qui regarde le chemin, dans l ombre, plus sombre pres du virage : donne la profondeur
    var gp=ctx.createLinearGradient(BD[0][0],0,BD[0][0]+w*.12,0); gp.addColorStop(0,'rgba(20,14,34,.55)'); gp.addColorStop(1,'rgba(20,14,34,0)'); ctx.fillStyle=gp;
    ctx.beginPath(); ctx.moveTo(BD[0][0],h); BD.forEach(function(p){ ctx.lineTo(p[0],p[1]); }); ctx.lineTo(PR[0][0],PR[0][1]); for(k=J;k>=0;k--) ctx.lineTo(BD[k][0]+w*(.1-.0028*k),BD[k][1]-h*(.12-.004*k)); ctx.closePath(); ctx.fill();
    // arete de l epaule, eclairee par le reste du jour
    ctx.strokeStyle='rgba(255,200,190,.35)'; ctx.lineWidth=1.2; ctx.beginPath(); for(k=0;k<=J;k++){ var ex=BD[k][0]+w*(.1-.0028*k), ey=BD[k][1]-h*(.12-.004*k); if(k) ctx.lineTo(ex,ey); else ctx.moveTo(ex,ey); } ctx.lineTo(PR[0][0],PR[0][1]); ctx.stroke();
    // talus de neige au pied de la paroi, le long du chemin
    ctx.fillStyle='#c4bedc'; ctx.beginPath(); ctx.moveTo(BD[0][0]-w*.01,h); BD.forEach(function(p,j){ ctx.lineTo(p[0]-w*.008*(1-j/J),p[1]); }); for(k=J;k>=0;k--) ctx.lineTo(BD[k][0]+w*.03*(1-k/J)+w*.004,BD[k][1]-h*(.03*(1-k/J)+.004)); ctx.closePath(); ctx.fill();
    ctx.strokeStyle='rgba(255,245,245,.6)'; ctx.lineWidth=1; ctx.beginPath(); for(k=0;k<=J;k++){ var tx2=BD[k][0]+w*.03*(1-k/J)+w*.004, ty2=BD[k][1]-h*(.03*(1-k/J)+.004); if(k) ctx.lineTo(tx2,ty2); else ctx.moveTo(tx2,ty2); } ctx.stroke();
    // strates : decoupees dans la silhouette de la montagne, elles ne sortent plus dans le ciel
    ctx.save(); mont(); ctx.clip();
    ctx.strokeStyle='rgba(20,16,36,.35)'; ctx.lineWidth=1; for(k=0;k<8;k++){ var sy=h*(.2+k*.08); ctx.beginPath(); ctx.moveTo(w*(.72+.12*Math.max(0,.6-k*.1)+k*.005),sy); ctx.quadraticCurveTo(w*.86,sy+h*.025,w*1.02,sy-h*.01); ctx.stroke(); }
    ctx.restore();
    ctx.fillStyle='rgba(255,190,170,.12)'; ctx.beginPath(); ctx.moveTo(PR[0][0],PR[0][1]); PR.forEach(function(p){ ctx.lineTo(p[0],p[1]); }); ctx.lineTo(PR[PR.length-1][0],PR[PR.length-1][1]+h*.06); ctx.lineTo(PR[0][0]+w*.05,PR[0][1]+h*.04); ctx.fill();
    ctx.fillStyle='rgba(240,242,252,.92)'; ctx.beginPath(); PR.forEach(function(p,j){ if(j) ctx.lineTo(p[0],p[1]); else ctx.moveTo(p[0],p[1]); }); for(k=PR.length-1;k>=0;k--) ctx.lineTo(PR[k][0]+1,PR[k][1]+h*(.018+.012*Math.sin(k*1.7))); ctx.fill();
    [[.76,.5],[.86,.36],[.95,.47],[.9,.22]].forEach(function(r){ ctx.beginPath(); ctx.ellipse(w*r[0],h*r[1],w*.03,h*.01,-.1,PI,2*PI); ctx.fill(); });
    var gx=w*.895, gy=h*.86; _mxHalo(ctx,w*.83,h*.78,w*.22,'rgba(255,180,90,.5)',fl);
    var gi=ctx.createRadialGradient(gx,gy-h*.08,2,gx,gy-h*.06,w*.08); gi.addColorStop(0,'#05030a'); gi.addColorStop(1,'#1e1630'); ctx.fillStyle=gi;
    ctx.beginPath(); ctx.moveTo(gx-w*.07,gy); ctx.quadraticCurveTo(gx-w*.075,gy-h*.12,gx-w*.04,gy-h*.19); ctx.quadraticCurveTo(gx,gy-h*.24,gx+w*.045,gy-h*.18); ctx.quadraticCurveTo(gx+w*.075,gy-h*.1,gx+w*.07,gy); ctx.fill();
    ctx.strokeStyle='rgba(255,190,120,'+(.5*fl)+')'; ctx.lineWidth=1.6; ctx.beginPath(); ctx.moveTo(gx-w*.07,gy); ctx.quadraticCurveTo(gx-w*.075,gy-h*.12,gx-w*.04,gy-h*.19); ctx.quadraticCurveTo(gx,gy-h*.24,gx+w*.045,gy-h*.18); ctx.stroke();
    // portique de grosses poutres emboitees : deux montants epais, un linteau qui deborde et repose
    // dans leurs entailles (tenons visibles a travers le linteau, chevilles), deux jambes de force
    // logees entre montant et linteau, neige sur le dessus, montant gauche eclaire par la chandelle
    function bois(x,y,lw,lh,c,fil){ ctx.fillStyle=c; ctx.fillRect(x,y,lw,lh); ctx.strokeStyle='rgba(30,16,8,.4)'; ctx.lineWidth=.8; ctx.beginPath();
      for(var gq=1;gq<4;gq++){ if(fil){ ctx.moveTo(x+lw*gq/4,y+3); ctx.lineTo(x+lw*gq/4+(gq%2?1:-1),y+lh-3); } else { ctx.moveTo(x+3,y+lh*gq/4); ctx.lineTo(x+lw-3,y+lh*gq/4+(gq%2?.6:-.6)); } } ctx.stroke();
      ctx.strokeStyle='rgba(20,10,4,.6)'; ctx.lineWidth=1; ctx.strokeRect(x+.5,y+.5,lw-1,lh-1); }
    var pw2=w*.028, pl=gx-w*.095, prr=gx+w*.058, lh2=h*.05, pt=gy-h*.235, lx0=pl-w*.025, lx1=prr+pw2+w*.025;
    // jambes de force (derriere les montants et le linteau)
    ctx.strokeStyle='#4a2e18'; ctx.lineWidth=w*.018; ctx.lineCap='butt'; ctx.beginPath(); ctx.moveTo(pl+pw2*.5,pt+lh2+h*.075); ctx.lineTo(pl+pw2+w*.045,pt+lh2*.5); ctx.moveTo(prr+pw2*.5,pt+lh2+h*.075); ctx.lineTo(prr-w*.045,pt+lh2*.5); ctx.stroke();
    ctx.strokeStyle='rgba(255,200,140,.18)'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(pl+pw2*.5,pt+lh2+h*.075-w*.009); ctx.lineTo(pl+pw2+w*.045,pt+lh2*.5-w*.009); ctx.stroke();
    // montants
    bois(pl,pt+lh2*.4,pw2,gy-pt-lh2*.4+h*.012,'#6a4628',true); bois(prr,pt+lh2*.4,pw2,gy-pt-lh2*.4+h*.012,'#5a3a20',true);
    ctx.fillStyle='rgba(255,180,100,'+(.4*fl)+')'; ctx.fillRect(pl+pw2-2.5,pt+lh2,2.5,gy-pt-lh2);
    // linteau
    bois(lx0,pt,lx1-lx0,lh2,'#7a5232',false);
    ctx.fillStyle='rgba(255,215,160,.3)'; ctx.fillRect(lx0,pt,lx1-lx0,1.4);
    // tenons des montants qui traversent le linteau, chevilles
    [pl,prr].forEach(function(x){ ctx.fillStyle='#5e3c20'; ctx.fillRect(x+pw2*.22,pt+lh2*.15,pw2*.56,lh2*.7); ctx.strokeStyle='rgba(20,10,4,.6)'; ctx.lineWidth=.8; ctx.strokeRect(x+pw2*.22+.4,pt+lh2*.15+.4,pw2*.56-.8,lh2*.7-.8);
      ctx.fillStyle='#2e1a0c'; ctx.beginPath(); ctx.arc(x+pw2*.5,pt+lh2*.5,1.4,0,2*PI); ctx.fill(); ctx.beginPath(); ctx.arc(x+pw2*.5,pt+lh2+h*.02,1.3,0,2*PI); ctx.fill(); });
    // bouts du linteau en bois de bout (cernes)
    [lx0,lx1].forEach(function(x,j3){ ctx.strokeStyle='rgba(40,22,10,.5)'; ctx.lineWidth=.7; ctx.beginPath(); ctx.ellipse(x+(j3?-2:2),pt+lh2/2,1.6,lh2*.32,0,0,2*PI); ctx.stroke(); });
    // neige sur le linteau
    ctx.fillStyle='rgba(242,244,255,.96)'; ctx.beginPath(); ctx.moveTo(lx0-w*.004,pt+1); ctx.quadraticCurveTo(gx-w*.04,pt-h*.03,gx,pt-h*.022); ctx.quadraticCurveTo(gx+w*.05,pt-h*.032,lx1+w*.004,pt+1); ctx.lineTo(lx1,pt+h*.008); ctx.quadraticCurveTo(gx,pt-h*.004,lx0,pt+h*.008); ctx.fill();
    // congere : la neige monte sur le pied de la paroi et sur le seuil de la grotte
    ctx.fillStyle='#b4b0d4'; ctx.beginPath(); ctx.moveTo(w*.7,h); ctx.quadraticCurveTo(w*.76,h*.82,w*.84,h*.855); ctx.quadraticCurveTo(w*.9,h*.875,w*.97,h*.85); ctx.quadraticCurveTo(w*1.01,h*.84,w*1.03,h*.86); ctx.lineTo(w*1.03,h); ctx.fill();
    ctx.strokeStyle='rgba(255,240,230,.5)'; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(w*.72,h*.93); ctx.quadraticCurveTo(w*.76,h*.82,w*.84,h*.855); ctx.quadraticCurveTo(w*.9,h*.875,w*.97,h*.85); ctx.stroke();
    // la chandelle a l entree : la flamme vacille mais tient
    var cx=w*.82, cy2=h*.85; ctx.fillStyle='#e8dfc8'; ctx.fillRect(cx-3,cy2-h*.05,6,h*.05); ctx.fillStyle='#c8b898'; ctx.fillRect(cx-5,cy2-2,10,3);
    var pen=Math.sin(t*2.1)*.15+Math.sin(t*5.3)*.08, fh2=h*(.035+.006*Math.sin(t*9)+.004*Math.sin(t*13.1));
    _mxHalo(ctx,cx,cy2-h*.07,h*.08,'rgba(255,200,110,.9)',fl);
    ctx.save(); ctx.translate(cx,cy2-h*.05); ctx.rotate(pen);
    var gf=ctx.createLinearGradient(0,-fh2,0,0); gf.addColorStop(0,'rgba(255,240,180,.2)'); gf.addColorStop(.4,'rgba(255,200,90,.95)'); gf.addColorStop(1,'rgba(255,120,40,.95)'); ctx.fillStyle=gf;
    ctx.beginPath(); ctx.moveTo(-3,-1); ctx.quadraticCurveTo(-3.6,-fh2*.5,Math.sin(t*6)*1.2,-fh2); ctx.quadraticCurveTo(3.6,-fh2*.5,3,-1); ctx.fill();
    ctx.fillStyle='#fffbe8'; ctx.beginPath(); ctx.ellipse(0,-fh2*.32,1.2,fh2*.2,0,0,2*PI); ctx.fill(); ctx.restore();
    // sapins enneiges, vert profond, qui ondulent au vent
    function sapin(x,y,ht,ph){ var sk=Math.sin(t*.9+ph)*.035+Math.sin(t*2.3+ph*1.7)*.01; ctx.save(); ctx.translate(x,y); ctx.transform(1,0,sk,1,0,0);
      ctx.fillStyle='#3a2618'; ctx.fillRect(-ht*.03,-ht*.12,ht*.06,ht*.12);
      for(var e=0;e<5;e++){ var yb=-ht*(.1+e*.17), lg=ht*(.36-e*.06), hh=ht*.3;
        var g=ctx.createLinearGradient(-lg,0,lg,0); g.addColorStop(0,'#0b2e22'); g.addColorStop(.6,'#124734'); g.addColorStop(1,'#1a5a40'); ctx.fillStyle=g;
        ctx.beginPath(); ctx.moveTo(-lg,yb); ctx.quadraticCurveTo(-lg*.4,yb-hh*.35,0,yb-hh); ctx.quadraticCurveTo(lg*.4,yb-hh*.35,lg,yb); ctx.quadraticCurveTo(0,yb+ht*.03,-lg,yb); ctx.fill();
        ctx.fillStyle='rgba(245,246,255,.92)'; ctx.beginPath(); ctx.moveTo(-lg*.9,yb-ht*.01); ctx.quadraticCurveTo(-lg*.4,yb-hh*.42,0,yb-hh*.98); ctx.quadraticCurveTo(lg*.2,yb-hh*.6,lg*.55,yb-hh*.22); ctx.quadraticCurveTo(lg*.1,yb-hh*.3,-lg*.2,yb-hh*.15); ctx.quadraticCurveTo(-lg*.55,yb-hh*.08,-lg*.9,yb-ht*.01); ctx.fill(); }
      ctx.restore(); }
    // au fond, les sapins qui cachent le virage ; puis les grands sapins de gauche
    sapin(w*.62,terre(w*.62)+h*.03,h*.12,3.1); sapin(w*.57,terre(w*.57)+h*.02,h*.08,1);
    // foret de gauche en perspective : grands sapins au premier plan, de plus en plus petits vers le col
    var FO=[], rfo=_mxR(73); for(k=0;k<16;k++){ var d=k/15, d2=Math.pow(d,.85), x=w*(-.04+d2*.44)+(rfo()-.5)*w*.05*(1-d*.6), rang2=k%2;
      x-=rang2*w*.06*(1-d); var yb=h*1.02+(terre(x)+h*.015-h*1.02)*Math.pow(d,.7)-rang2*h*.03*(1-d), ht=h*(.6*Math.pow(1-d,1.4)+.055)*(1-rang2*.12)*(.9+rfo()*.2); FO.push([x,yb,ht,k*1.3]); }
    FO.sort(function(a,b){ return a[1]-b[1]; }).forEach(function(f){ sapin(f[0],f[1],f[2],f[3]); });
    // la cloture de bois, le long du bord gauche du chemin
    var poteaux=[]; for(k=0;k<=10;k++){ var j=Math.round(k*2.9), p=GA[j], sc=Math.max(.12,1-j/40*1.05); poteaux.push([p[0]-w*.018*sc,p[1],sc]); }
    ctx.strokeStyle='#5a3a22'; for(var rl=0;rl<2;rl++){ ctx.lineWidth=Math.max(1,2.4); ctx.beginPath(); poteaux.forEach(function(p,j2){ var y=p[1]-h*(.045+rl*.045)*p[2]; if(j2) ctx.lineTo(p[0],y); else ctx.moveTo(p[0],y); }); ctx.stroke(); }
    poteaux.forEach(function(p){ var ph=h*.11*p[2], pw=Math.max(1.2,4.5*p[2]); ctx.fillStyle='#4a2e1a'; ctx.fillRect(p[0]-pw/2,p[1]-ph,pw,ph); ctx.fillStyle='rgba(245,246,255,.9)'; ctx.fillRect(p[0]-pw/2-.4,p[1]-ph-1.2,pw+.8,2); });
    ctx.strokeStyle='rgba(245,246,255,.7)'; ctx.lineWidth=1; ctx.beginPath(); poteaux.forEach(function(p,j2){ var y=p[1]-h*.091*p[2]; if(j2) ctx.lineTo(p[0],y); else ctx.moveTo(p[0],y); }); ctx.stroke();
    // sapins du premier plan, a droite, devant la paroi
    sapin(w*1.02,h*1.06,h*.5,10.4);
    // neige qui tombe doucement
    var rn=_mxR(61); ctx.fillStyle='#ffffff'; for(k=0;k<80;k++){ var vz=.4+rn()*.6, x0=rn()*w, y0=rn()*h, yy=(y0+t*h*.05*vz)%h, xx=(x0+Math.sin(t*.7+k)*8*vz+t*4*vz)%w; ctx.globalAlpha=.45+.45*vz; ctx.beginPath(); ctx.arc(xx,yy,.6+vz*1.1,0,2*PI); ctx.fill(); }
    ctx.globalAlpha=1;
  }
];
// Lance l animation d une scene dans un canvas ; s arrete seule quand le
// canvas quitte la page ou n est plus affiche. ~30 images/s.
function _merchSceneStart(cv,idx){
  if(!cv||!_MERCH_FX[idx]) return;
  var fx=_MERCH_FX[idx], ctx=cv.getContext('2d'), dpr=Math.min(2,window.devicePixelRatio||1), w0=0, h0=0, der=0, t0=performance.now()-((idx*7919)%20000);
  // Toujours anime, meme si le telephone demande moins d animations (decision
  // de Thibs, 23 novembre 2026), comme les emblemes et les decors des titres.
  var calme=false;
  function img(now){
    if(!cv.isConnected||!cv.offsetParent) return;
    if(now-der<32&&!calme){ requestAnimationFrame(img); return; } der=now;
    var w=cv.clientWidth, h=cv.clientHeight; if(!w||!h){ requestAnimationFrame(img); return; }
    if(w!==w0||h!==h0){ cv.width=Math.round(w*dpr); cv.height=Math.round(h*dpr); w0=w; h0=h; }
    ctx.setTransform(dpr,0,0,dpr,0,0); ctx.globalAlpha=1;
    try{ fx(ctx,w,h,(now-t0)/1000); }catch(e){ return; }
    if(!calme) requestAnimationFrame(img);
  }
  requestAnimationFrame(img);
}
