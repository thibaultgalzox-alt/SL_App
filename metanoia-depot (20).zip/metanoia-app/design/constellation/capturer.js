// Rend les maquettes de constellation dans l app reelle (serveur sur 8777).
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path=require('path');
const cas=[['nuit',6],['carte',6],['chasseur',6],['chasseur',10]];
(async()=>{const b=await chromium.launch();
for(const [m,nb] of cas){
const p=await b.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true,deviceScaleFactor:2});const err=[];p.on('pageerror',e=>err.push(e.message));
await p.goto('http://127.0.0.1:8777/index.html');await p.waitForTimeout(2500);
await p.evaluate(()=>{ST._ob={age:1,situation:1,sportLevel:1,physGoal:0,sportAccess:[0,2],collectifSport:'',collectifJours:[],mindLevel:0,screenHours:3,sleep:1,resistances:[1,2],prog:'Standard'};ST.myWhy='x';ST._tutoSeen=true;_obFinish();});
await p.waitForTimeout(1500);
await p.addStyleTag({content:'.flash,.toast,#toast{display:none!important}'});
await p.addScriptTag({path:path.join(__dirname,'modeles.js')});
await p.evaluate(a=>{var [m,nb]=a;document.querySelectorAll('.tuto-ui,#tuto-card,#tuto-ov,.tuto-overlay').forEach(x=>x.remove());ST.day=60;
 var e=[];TRAITS.forEach(function(t,i){t.frags.forEach(function(f,j){if(i<nb||(nb<10&&((i===nb&&j<2)||(i===nb+1&&j<1)||(i===nb+3&&j<2))))e.push(f);});});ST.earnedFragments=e;save();
 ST._tutoScreens=new Proxy({},{get:function(){return true}});window._isUnlocked=function(){return true};nav('s-identity');renderIdentity();
 document.querySelectorAll('[id$="-ov"],.tuto-ui').forEach(x=>{if(getComputedStyle(x).position==='fixed')x.remove()});
 CM.appliquer(m);document.getElementById('id-traits').scrollIntoView({block:'start'});},[m,nb]);
await p.waitForTimeout(700);
// clic sur un trait : le vrai panneau des fragments doit s ouvrir
const panneau=await p.evaluate(()=>{var g=document.querySelector('.cm-trait[data-trait="resilience"]');g.dispatchEvent(new MouseEvent('click',{bubbles:true}));return (document.getElementById('id-frag-panel').innerText||'').replace(/\s+/g,' ').slice(0,50)});
const r=await p.evaluate(()=>{var t=document.getElementById('id-traits').getBoundingClientRect();return {y:t.top,h:t.height}});
await p.screenshot({path:'/tmp/sa/cm_'+m+nb+'.png',clip:{x:0,y:Math.max(0,r.y-30),width:393,height:Math.min(r.h+40,820)}});
console.log(m,nb,'panneau="'+panneau+'"',err.slice(0,2));await p.close();}
await b.close()})();
