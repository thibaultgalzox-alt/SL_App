// Maquettes de la refonte de la Constellation des traits (21 novembre 2026).
// Injectees dans l app reelle par design/constellation/capturer.js : elles
// lisent les vrais TRAITS et ST.earnedFragments, et chaque trait reste
// cliquable (_idSelectTrait ouvre le vrai panneau des fragments).
(function(){
  var C=170;
  function R(s){ var x=Math.sin(s*127.1)*43758.5453; return x-Math.floor(x); }
  function etat(){
    var e=ST.earnedFragments||[];
    return TRAITS.map(function(t){ var on=t.frags.map(function(f){ return e.indexOf(f)>=0; });
      return {t:t,on:on,n:on.filter(Boolean).length,complet:on.every(Boolean)}; });
  }
  // Poussiere d etoiles de fond, deterministe
  function poussiere(n,col,amax){ var s=''; for(var i=0;i<n;i++){ var x=R(i+1)*340,y=R(i+50)*340,r=.25+R(i+99)*.7;
    s+='<circle cx="'+x.toFixed(1)+'" cy="'+y.toFixed(1)+'" r="'+r.toFixed(2)+'" fill="'+col+'" opacity="'+(.15+R(i+7)*amax).toFixed(2)+'"'+(i%7===0?' class="cm-scint" style="animation-delay:-'+(R(i+3)*4).toFixed(1)+'s"':'')+'/>'; } return s; }
  // Une etoile : allumee (halo + coeur + eclat) ou eteinte
  function etoile(x,y,on,th,gros){
    if(!on) return '<circle cx="'+x+'" cy="'+y+'" r="1.5" fill="'+th.off+'"/><circle cx="'+x+'" cy="'+y+'" r="3.4" fill="none" stroke="'+th.off+'" stroke-width=".5" opacity=".6"/>';
    var r=gros?3.4:2.6;
    return '<circle cx="'+x+'" cy="'+y+'" r="'+(r*4)+'" fill="url(#cmHalo)" class="cm-scint" style="animation-delay:-'+(R(x+y)*4).toFixed(1)+'s"/>'
      +(gros?'<path d="M'+x+' '+(y-r*3.2)+'Q'+x+' '+y+' '+(x+r*3.2)+' '+y+'Q'+x+' '+y+' '+x+' '+(y+r*3.2)+'Q'+x+' '+y+' '+(x-r*3.2)+' '+y+'Q'+x+' '+y+' '+x+' '+(y-r*3.2)+'Z" fill="'+th.eclat+'" opacity=".9"/>':'')
      +'<circle cx="'+x+'" cy="'+y+'" r="'+r+'" fill="'+th.on+'"/><circle cx="'+(x-.6)+'" cy="'+(y-.6)+'" r="'+(r*.45)+'" fill="#fff" opacity=".9"/>';
  }
  function lien(a,b,on,th){ return '<line x1="'+a[0]+'" y1="'+a[1]+'" x2="'+b[0]+'" y2="'+b[1]+'" stroke="'+(on?th.lien:th.lienOff)+'" stroke-width="'+(on?1.3:.7)+'"'+(on?'':' stroke-dasharray="2 3"')+' stroke-linecap="round"/>'; }
  function defs(th){ return '<defs><radialGradient id="cmHalo"><stop offset="0" stop-color="'+th.halo+'" stop-opacity=".9"/><stop offset=".35" stop-color="'+th.halo+'" stop-opacity=".35"/><stop offset="1" stop-color="'+th.halo+'" stop-opacity="0"/></radialGradient>'
    +'<radialGradient id="cmVoie" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="'+th.voie+'" stop-opacity=".55"/><stop offset="1" stop-color="'+th.voie+'" stop-opacity="0"/></radialGradient></defs>'; }
  var STYLE='<style>.cm-scint{animation:cmScint 4s ease-in-out infinite}@keyframes cmScint{0%,100%{opacity:1}50%{opacity:.45}}.cm-trait{cursor:pointer}</style>';

  // Formes des 10 asterismes (3 etoiles chacun), autour d un centre
  var FORMES=[[[-15,9],[0,-13],[15,8]],[[-16,-6],[2,10],[16,-10]],[[-12,-12],[14,-4],[-4,13]],[[-16,4],[-2,-12],[15,10]],[[-14,-10],[0,6],[14,-8]],
              [[-10,12],[4,-14],[16,6]],[[-16,-2],[0,-14],[12,12]],[[-14,10],[6,-12],[16,4]],[[-16,8],[0,-10],[16,8]],[[-14,12],[0,0],[14,-14]]];
  function ronde(th,clair){
    var E=etat(), s=defs(th)+STYLE;
    s+='<ellipse cx="'+C+'" cy="'+C+'" rx="150" ry="60" transform="rotate(-28 170 170)" fill="url(#cmVoie)"/>';   // voie lactee
    if(clair){ // carte celeste : cercles gradues
      [150,118,82].forEach(function(r){ s+='<circle cx="'+C+'" cy="'+C+'" r="'+r+'" fill="none" stroke="'+th.grille+'" stroke-width=".6"/>'; });
      for(var k=0;k<72;k++){ var a=k*5*Math.PI/180, r1=150, r2=k%6===0?143:147; s+='<line x1="'+(C+Math.cos(a)*r1).toFixed(1)+'" y1="'+(C+Math.sin(a)*r1).toFixed(1)+'" x2="'+(C+Math.cos(a)*r2).toFixed(1)+'" y2="'+(C+Math.sin(a)*r2).toFixed(1)+'" stroke="'+th.grille+'" stroke-width=".6"/>'; }
      for(k=0;k<12;k++){ var b=k*30*Math.PI/180; s+='<line x1="'+(C+Math.cos(b)*82).toFixed(1)+'" y1="'+(C+Math.sin(b)*82).toFixed(1)+'" x2="'+(C+Math.cos(b)*150).toFixed(1)+'" y2="'+(C+Math.sin(b)*150).toFixed(1)+'" stroke="'+th.grille+'" stroke-width=".4" stroke-dasharray="1 3"/>'; }
    } else {
      s+='<circle cx="'+C+'" cy="'+C+'" r="118" fill="none" stroke="'+th.grille+'" stroke-width=".5" stroke-dasharray="1 4"/>';
    }
    s+=poussiere(clair?60:110,th.poussiere,clair?.35:.6);
    E.forEach(function(e,i){
      var an=(-90+i*36)*Math.PI/180, cx=C+Math.cos(an)*116, cy=C+Math.sin(an)*116;
      var P=FORMES[i].map(function(p){ return [+(cx+p[0]).toFixed(1),+(cy+p[1]).toFixed(1)]; });
      var g='<g class="cm-trait" data-trait="'+e.t.id+'" onclick="_idSelectTrait(\''+e.t.id+'\')">';
      if(e.complet) g+='<circle cx="'+cx+'" cy="'+cy+'" r="26" fill="url(#cmHalo)" opacity=".35"/>';
      g+=lien(P[0],P[1],e.on[0]&&e.on[1],th)+lien(P[1],P[2],e.on[1]&&e.on[2],th);
      P.forEach(function(p,k){ g+=etoile(p[0],p[1],e.on[k],th,k===1&&e.complet); });
      var ly=cy+(cy>C?27:-22);
      g+='<text x="'+cx+'" y="'+ly+'" text-anchor="middle" font-family="Sora,sans-serif" font-size="7.2" font-weight="800" letter-spacing=".9" fill="'+(e.complet?th.nom:th.nomOff)+'">'+e.t.name.toUpperCase()+'</text>';
      g+='<circle cx="'+cx+'" cy="'+cy+'" r="28" fill="transparent"/></g>';
      s+=g;
    });
    // centre : l etoile du joueur et le compte
    var nb=E.filter(function(e){return e.complet;}).length, fr=(ST.earnedFragments||[]).length;
    s+='<circle cx="'+C+'" cy="'+C+'" r="46" fill="url(#cmHalo)" opacity="'+(.25+.5*nb/10)+'"/>';
    s+=etoile(C,C-12,true,th,true);
    s+='<text x="'+C+'" y="'+(C+16)+'" text-anchor="middle" font-family="Sora,sans-serif" font-size="17" font-weight="800" fill="'+th.nom+'">'+nb+'<tspan font-size="10" fill="'+th.nomOff+'">/10</tspan></text>';
    s+='<text x="'+C+'" y="'+(C+28)+'" text-anchor="middle" font-family="Sora,sans-serif" font-size="6.5" font-weight="700" letter-spacing="1.2" fill="'+th.nomOff+'">CONSTELLATIONS</text>';
    return s;
  }

  // Le Chasseur : une seule grande constellation, la silhouette du joueur
  var CORPS={
    esprit_eveille:[[170,34],[146,70],[194,70]],         // capuche
    focus_profond:[[158,84],[170,70],[182,84]],          // regard
    corps_dominant:[[116,112],[170,104],[224,112]],      // epaules
    resilience:[[158,138],[170,156],[182,138]],          // coeur
    corps_engage:[[104,152],[92,196],[106,232]],         // bras gauche
    disc_brute:[[236,152],[248,196],[236,232]],          // bras droit
    rigueur:[[140,190],[170,195],[200,190]],             // ceinture
    equilibre:[[128,252],[170,240],[212,252]],           // robe
    fondation:[[118,302],[170,310],[222,302]],           // socle
    momentum:[[266,300],[266,184],[266,58]]              // baton qui monte
  };
  var SQUELETTE=[[[146,70],[116,112]],[[194,70],[224,112]],[[170,104],[158,138]],[[170,104],[182,138]],[[116,112],[104,152]],[[224,112],[236,152]],
    [[116,112],[140,190]],[[224,112],[200,190]],[[140,190],[128,252]],[[200,190],[212,252]],[[128,252],[118,302]],[[212,252],[222,302]],[[236,232],[266,184]]];
  function chasseur(th){
    var E=etat(), s=defs(th)+STYLE, idx={};
    E.forEach(function(e){ idx[e.t.id]=e; });
    s+='<ellipse cx="'+C+'" cy="'+C+'" rx="160" ry="70" transform="rotate(-62 170 170)" fill="url(#cmVoie)"/>';
    s+=poussiere(120,th.poussiere,.6);
    SQUELETTE.forEach(function(l){ s+=lien(l[0],l[1],false,th); });
    var nb=0;
    Object.keys(CORPS).forEach(function(id){ var e=idx[id]; if(!e) return; var P=CORPS[id]; if(e.complet) nb++;
      var g='<g class="cm-trait" data-trait="'+id+'" onclick="_idSelectTrait(\''+id+'\')">';
      g+=lien(P[0],P[1],e.on[0]&&e.on[1],th)+lien(P[1],P[2],e.on[1]&&e.on[2],th)+(id==='esprit_eveille'||id==='resilience'||id==='focus_profond'?lien(P[0],P[2],e.on[0]&&e.on[2],th):'');
      P.forEach(function(p,k){ g+=etoile(p[0],p[1],e.on[k],th,e.complet&&k===1); });
      var mx=(P[0][0]+P[1][0]+P[2][0])/3, my=(P[0][1]+P[1][1]+P[2][1])/3;
      g+='<circle cx="'+mx+'" cy="'+my+'" r="22" fill="transparent"/></g>';
      s+=g; });
    // nom de la constellation
    s+='<text x="'+C+'" y="334" text-anchor="middle" font-family="Cinzel,Georgia,serif" font-size="11" font-weight="700" letter-spacing="3" fill="'+th.nom+'">LE CHASSEUR</text>';
    s+='<text x="20" y="24" font-family="Sora,sans-serif" font-size="15" font-weight="800" fill="'+th.nom+'">'+nb+'<tspan font-size="9" fill="'+th.nomOff+'">/10</tspan></text>';
    s+='<text x="20" y="34" font-family="Sora,sans-serif" font-size="6" font-weight="700" letter-spacing="1" fill="'+th.nomOff+'">TRAITS ALLUMÉS</text>';
    return s;
  }

  var NUIT={on:'#FFE6A6',eclat:'#FFF3CF',halo:'#F5C565',off:'rgba(255,240,220,.42)',lien:'rgba(245,197,101,.85)',lienOff:'rgba(255,235,210,.22)',voie:'#7A2D52',grille:'rgba(255,230,200,.16)',poussiere:'#FFF1DC',nom:'#F7D58C',nomOff:'rgba(247,226,200,.55)'};
  var CARTE={on:'#E2A23A',eclat:'#F6C760',halo:'#E8A23C',off:'rgba(77,16,47,.38)',lien:'#B4471E',lienOff:'rgba(77,16,47,.25)',voie:'#F2C9A4',grille:'rgba(120,70,40,.22)',poussiere:'#8A5A3A',nom:'#4D102F',nomOff:'rgba(77,16,47,.5)'};

  window.CM={
    nuit:{fond:'radial-gradient(120% 90% at 50% 35%,#4A1430 0%,#2C0A1D 50%,#180610 100%)',bord:'rgba(245,197,101,.35)',svg:function(){ return ronde(NUIT,false); }},
    carte:{fond:'linear-gradient(160deg,#FBF4E8,#F3E3CC)',bord:'rgba(180,71,30,.28)',svg:function(){ return ronde(CARTE,true); }},
    chasseur:{fond:'radial-gradient(120% 90% at 50% 30%,#3E1330 0%,#22091A 55%,#12040C 100%)',bord:'rgba(245,197,101,.35)',svg:function(){ return chasseur(NUIT); }},
    appliquer:function(nom){ var m=CM[nom], t=document.getElementById('id-traits'), c=t&&t.querySelector('.id-const'); if(!c) return;
      t.style.background=m.fond; t.style.borderColor=m.bord; t.style.boxShadow='0 8px 24px rgba(40,8,24,.28)';
      c.outerHTML='<div class="id-const cm" style="aspect-ratio:1/1;position:relative"><svg viewBox="0 0 340 340" width="100%" height="100%" style="display:block">'+m.svg()+'</svg></div>'; }
  };
})();
