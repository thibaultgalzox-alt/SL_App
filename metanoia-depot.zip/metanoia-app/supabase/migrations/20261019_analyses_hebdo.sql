-- Metanoia : analyses de la semaine redigees par IA (19 octobre 2026)
-- Une ligne par joueur et par semaine. Ecrite uniquement par la fonction
-- « analyse-hebdo » (cle service) ; le joueur ne peut que lire les siennes.
-- Supprimee avec le compte (on delete cascade).

create table if not exists public.analyses_hebdo (
  user_id    uuid        not null references auth.users(id) on delete cascade,
  semaine    integer     not null check (semaine between 1 and 5000),
  contenu    jsonb       not null,
  modele     text,
  created_at timestamptz not null default now(),
  primary key (user_id, semaine)
);

create index if not exists analyses_hebdo_recentes on public.analyses_hebdo (user_id, created_at);

alter table public.analyses_hebdo enable row level security;

drop policy if exists "analyses_hebdo lecture des siennes" on public.analyses_hebdo;
create policy "analyses_hebdo lecture des siennes"
  on public.analyses_hebdo for select
  using (auth.uid() = user_id);
-- Aucune politique d ecriture : seule la cle service (la fonction) ecrit.
