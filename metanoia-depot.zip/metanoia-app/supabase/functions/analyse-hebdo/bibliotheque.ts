// Metanoia : bibliotheque de faits verifies (20 octobre 2026)
// Chaque fait a ete verifie sur sa source (article, resume ou communique
// officiel). L IA n a le droit de citer QUE ces faits : aucun autre chiffre
// exterieur. Le serveur choisit les 6 plus utiles selon le joueur (etiquettes).
// Ajouter un fait : texte court, source « Auteur, annee », etiquettes.

export type Fait = { id: string; texte: string; source: string; tags: string[] };

export const BIBLIOTHEQUE: Fait[] = [
  // Formation des habitudes
  { id: "lally_66", source: "Lally et al., 2010, European Journal of Social Psychology",
    texte: "Dans l'étude de référence sur la formation des habitudes, une nouvelle habitude devenait automatique en 66 jours en médiane, de 18 à 254 jours selon les personnes.",
    tags: ["general"] },
  { id: "lally_oubli", source: "Lally et al., 2010, European Journal of Social Psychology",
    texte: "Rater une seule fois n'a pas freiné de façon notable la formation de l'habitude : l'automatisme revenait vite.",
    tags: ["general", "echec", "rebond", "serie"] },
  { id: "singh_revue", source: "Singh et al., 2024, Healthcare",
    texte: "Une revue de 20 études (2601 participants) situe la formation d'une habitude entre 59 et 66 jours en médiane, de 4 à 335 jours selon les personnes. Les habitudes du matin et celles qu'on a choisies soi-même sont plus solides.",
    tags: ["general", "heure", "lever"] },
  { id: "wood_43", source: "Wood, Quinn et Kashy, 2002, Journal of Personality and Social Psychology",
    texte: "Dans une étude par carnet de bord, 43 % des actions quotidiennes étaient des habitudes, faites presque chaque jour au même endroit, l'esprit souvent ailleurs.",
    tags: ["ancrage"] },
  { id: "judah_ancrage", source: "Judah, Gardner et Aunger, 2013, British Journal of Health Psychology",
    texte: "Des personnes qui accrochaient le fil dentaire juste après le brossage formaient une habitude plus forte que celles qui le faisaient avant : accrocher une nouvelle habitude à une ancienne aide.",
    tags: ["ancrage", "quete_fragile"] },
  // Plans, suivi, motivation
  { id: "gollwitzer_si_alors", source: "Gollwitzer et Sheeran, 2006, Advances in Experimental Social Psychology",
    texte: "Sur 94 tests, les plans « si..., alors je... » amélioraient nettement l'atteinte des objectifs (effet moyen à fort).",
    tags: ["general", "plan"] },
  { id: "harkin_suivi", source: "Harkin et al., 2016, Psychological Bulletin",
    texte: "Une synthèse de 138 études (19951 participants) montre que suivre ses progrès aide à atteindre ses objectifs, encore plus quand on les écrit ou qu'on les partage.",
    tags: ["bilan"] },
  { id: "dai_nouveau_depart", source: "Dai, Milkman et Riis, 2014, Management Science",
    texte: "Chez des étudiants, la probabilité d'aller à la salle de sport augmentait de 33,4 % en début de semaine et de 47,1 % en début de semestre : les nouveaux départs relancent la motivation.",
    tags: ["rebond", "jour", "general"] },
  { id: "milkman_tentation", source: "Milkman, Minson et Volpp, 2014, Management Science",
    texte: "Des personnes qui ne pouvaient écouter leurs livres audio préférés qu'à la salle de sport y allaient 51 % plus souvent au début de l'étude ; l'effet s'est atténué après les vacances.",
    tags: ["sport", "motivation", "quete_fragile"] },
  { id: "bond_heure", source: "Bond et al., 2019, Obesity",
    texte: "Parmi 375 personnes ayant maintenu une perte de poids, 68 % faisaient leur sport à heure fixe, et elles en faisaient plus (350 minutes par semaine en médiane, contre 285).",
    tags: ["heure", "sport"] },
  // Échec, série, rechute
  { id: "breines_compassion", source: "Breines et Chen, 2012, Personality and Social Psychology Bulletin",
    texte: "Après un échec, les participants invités à se traiter avec bienveillance ont travaillé plus longtemps pour réussir le test suivant que ceux qui se jugeaient durement.",
    tags: ["echec", "resistance"] },
  { id: "adams_ecart", source: "Adams et Leary, 2007, Journal of Social and Clinical Psychology",
    texte: "Chez des personnes au régime strict, se traiter avec bienveillance après un écart réduisait la détresse et l'envie de tout lâcher ensuite.",
    tags: ["echec", "nourriture", "resistance"] },
  { id: "marlatt_violation", source: "Marlatt et Gordon, 1985, Relapse Prevention",
    texte: "Vivre un écart comme une faute personnelle, durable et totale (« je suis nul, c'est fichu ») est ce qui transforme un écart en vraie rechute.",
    tags: ["rebond", "resistance", "echec"] },
  { id: "silverman_serie", source: "Silverman et Barasch, 2023, Journal of Consumer Research",
    texte: "Après une série cassée, les gens reprennent moins volontiers l'activité (58 % contre 66 % quand la série tient), et ils sont prêts à faire un effort pour la réparer.",
    tags: ["serie", "rebond"] },
  { id: "hofmann_tentations", source: "Hofmann et al., 2012, Journal of Personality and Social Psychology",
    texte: "Chez 205 personnes suivies une semaine, les plus disciplinées n'avaient pas moins d'envies : elles vivaient moins de conflits, surtout parce qu'elles évitaient les situations de tentation.",
    tags: ["resistance", "tentation", "porno", "reseaux", "nourriture", "alcool"] },
  { id: "wing_amis", source: "Wing et Jeffery, 1999, Journal of Consulting and Clinical Psychology",
    texte: "Des personnes engagées avec des amis et un soutien social étaient 66 % à maintenir leur perte de poids, contre 24 % de celles venues seules.",
    tags: ["social", "engagement"] },
  { id: "gine_engagement", source: "Giné, Karlan et Zinman, 2010, American Economic Journal: Applied Economics",
    texte: "Des fumeurs qui avaient mis leur propre argent en jeu sur un contrat d'arrêt réussissaient plus souvent le test de contrôle à 6 mois et à 12 mois.",
    tags: ["engagement", "alcool"] },
  // Sommeil, énergie, alcool
  { id: "vandongen_sommeil", source: "Van Dongen et al., 2003, Sleep",
    texte: "Dormir 6 h ou moins pendant 14 nuits dégradait autant les capacités que jusqu'à 2 nuits blanches, et les participants ne s'en rendaient presque pas compte.",
    tags: ["sommeil", "energie_basse", "lever"] },
  { id: "greer_malbouffe", source: "Greer, Goldstein et Walker, 2013, Nature Communications",
    texte: "Après une nuit blanche, les aliments les plus caloriques devenaient nettement plus désirables, et la zone du cerveau qui pèse les décisions tournait au ralenti.",
    tags: ["sommeil", "nourriture"] },
  { id: "nsf_sommeil", source: "Hirshkowitz et al., 2015, Sleep Health",
    texte: "La recommandation pour les adultes de 18 à 64 ans est de 7 à 9 h de sommeil par nuit.",
    tags: ["sommeil", "lever"] },
  { id: "pietila_alcool", source: "Pietilä et al., 2018, JMIR Mental Health",
    texte: "Chez 4098 personnes, la récupération du corps pendant les 3 premières heures de sommeil baissait de 9,3 % après peu d'alcool, de 24 % après une consommation modérée et de 39,2 % après une forte.",
    tags: ["alcool", "sommeil", "energie_basse"] },
  // Écrans
  { id: "hunt_reseaux", source: "Hunt et al., 2018, Journal of Social and Clinical Psychology",
    texte: "143 étudiants limités à 10 minutes par jour sur chaque réseau social (30 minutes en tout) pendant 3 semaines se sentaient nettement moins seuls et moins déprimés.",
    tags: ["reseaux", "humeur"] },
  { id: "allcott_facebook", source: "Allcott et al., 2020, American Economic Review",
    texte: "Désactiver Facebook pendant 4 semaines libérait en moyenne 60 minutes par jour et augmentait le bien-être ; l'usage restait plus bas ensuite.",
    tags: ["reseaux"] },
  { id: "kushlev_notifs", source: "Kushlev, Proulx et Dunn, 2016, CHI",
    texte: "Chez 221 étudiants, une semaine avec les notifications activées donnait plus d'inattention et d'agitation qu'une semaine en mode Ne pas déranger, téléphone hors de vue.",
    tags: ["reseaux", "concentration"] },
  // Sport, froid
  { id: "oms_activite", source: "Organisation mondiale de la santé, 2020",
    texte: "L'OMS recommande aux adultes 150 à 300 minutes d'activité modérée par semaine, plus du renforcement musculaire au moins 2 jours par semaine.",
    tags: ["sport"] },
  { id: "pearce_humeur", source: "Pearce et al., 2022, JAMA Psychiatry",
    texte: "L'équivalent de 2,5 h de marche rapide par semaine était associé à un risque de dépression 25 % plus faible ; la moitié de cette dose, à un risque 18 % plus faible.",
    tags: ["sport", "humeur"] },
  { id: "buijze_froid", source: "Buijze et al., 2016, PLOS ONE",
    texte: "Chez 3018 personnes, finir sa douche par 30 à 90 secondes d'eau froide réduisait de 29 % les absences pour maladie, sans réduire le nombre de jours malade.",
    tags: ["froid"] },
  // Pornographie
  { id: "fernandez_reboot", source: "Fernandez, Kuss et Griffiths, 2021, Archives of Sexual Behavior",
    texte: "Dans 104 journaux d'abstinence, l'arrêt de la pornographie paraissait parfois impossible à cause des habitudes et des nombreux déclencheurs, mais devenait atteignable avec des stratégies concrètes et du soutien.",
    tags: ["porno", "resistance"] },
  { id: "fernandez_7jours", source: "Fernandez et al., 2023, Archives of Sexual Behavior",
    texte: "Chez 176 utilisateurs réguliers, 7 jours sans pornographie n'ont pas provoqué de symptômes de manque mesurables par rapport à un groupe témoin.",
    tags: ["porno"] },
];

// Etiquettes du joueur, tirees des faits de la semaine
const RESIST: [RegExp, string][] = [
  [/pornographie/i, "porno"], [/réseaux/i, "reseaux"], [/concentré/i, "concentration"],
  [/nourriture/i, "nourriture"], [/alcool/i, "alcool"], [/lever/i, "lever"],
  [/sortir/i, "social"], [/engagements/i, "engagement"],
];

// deno-lint-ignore no-explicit-any
export function choisirFaits(f: any, max = 6): Fait[] {
  const t = new Set<string>(["general"]);
  const j = f?.joueur || {};
  for (const r of (j.resistances_declarees || []) as string[]) for (const [re, tag] of RESIST) if (re.test(r)) { t.add(tag); t.add("resistance"); }
  if (j.sommeil === "Moins de 6 h") t.add("sommeil");
  const T = f?.trois_mois || {};
  const anat = (T.anatomie_des_echecs_de_la_semaine || []) as Record<string, unknown>[];
  if (anat.length) t.add("echec");
  if (anat.some((a) => a.serie_avant_est_un_record)) t.add("serie");
  if (anat.some((a) => a.resistance_concernee)) t.add("resistance");
  if ((T.rebond?.suivis_d_un_autre_echec_pct ?? 0) > 25) t.add("rebond");
  if ((T.heures || []).some((h: Record<string, unknown>) => h.glisse_plus_tard)) t.add("heure");
  for (const p of (T.patterns_d_echec || []) as { k: string }[]) {
    if (p.k === "tard") t.add("heure");
    else if (p.k === "energie_basse") t.add("energie_basse");
    else if (p.k === "humeur") t.add("humeur");
    else if (p.k === "sans_bilan") t.add("bilan");
    else if (p.k.startsWith("jour_")) t.add("jour");
  }
  if (f?.quete_la_plus_fragile) t.add("quete_fragile");
  const noms = JSON.stringify([f?.jours || [], f?.trois_mois?.quetes || [], f?.quete_la_plus_solide || null]).toLowerCase();
  if (/froid/.test(noms)) t.add("froid");
  if (/squat|pompe|course|courir|salle|muscu|sport|marche|vélo|velo/.test(noms)) t.add("sport");
  if (f?.bilan && f.bilan.jours_reussis === f.bilan.jours_comptes) t.add("ancrage");
  // Score : etiquettes en commun, les faits « general » seulement en appoint
  const score = (x: Fait) => x.tags.filter((g) => t.has(g) && g !== "general").length * 2 + (x.tags.includes("general") ? 1 : 0);
  return BIBLIOTHEQUE.map((x) => ({ x, s: score(x) })).filter((o) => o.s > 0)
    .sort((a, b) => b.s - a.s).slice(0, max).map((o) => o.x);
}
