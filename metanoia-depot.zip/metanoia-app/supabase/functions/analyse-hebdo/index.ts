// Metanoia : fonction Supabase « analyse-hebdo » (19 octobre 2026)
//
// Recoit les faits de la semaine, calcules et verifies par le telephone, et
// demande a une IA de les mettre en mots. Une analyse par joueur et par
// semaine : la reponse est gardee en base et renvoyee telle quelle ensuite.
//
// Chaine de secours (20 octobre) : plusieurs API gratuites se relaient. Si
// l une est a court de quota, en panne, trop lente, ou rend une reponse
// invalide, la suivante prend le relais. Un maillon dont la cle manque est
// simplement saute. Ordre par defaut (gratuits, sans entrainement sur les
// donnees d apres leurs conditions en octobre 2026) :
//   (20 octobre : Groq a retire llama-3.3-70b-versatile et llama-3.1-8b-instant
//    le 16 aout 2026, ils repondent 404 ; remplaces par ses successeurs officiels)
//   1. Groq        openai/gpt-oss-120b       cle GROQ_CLE (ou IA_CLE)
//   2. Groq        qwen/qwen3.8-27b          meme cle, quota separe par modele (preview)
//   3. Cerebras    gpt-oss-120b              cle CEREBRAS_CLE
//   4. OpenRouter  meta-llama/llama-3.3-70b-instruct:free   cle OPENROUTER_CLE
//   5. Groq        openai/gpt-oss-20b        dernier recours gratuit, plus faible
//   6. Anthropic   claude-haiku-5-5          cle ANTHROPIC_CLE, payant, facultatif
// IA_CHAINE (facultatif) remplace cet ordre : tableau JSON de
//   {"nom":"...","url":"https://.../v1","cle":"NOM_DU_SECRET","modele":"...","format":"openai"|"anthropic"}
//   REVENUECAT_SECRET  facultatif mais conseille : cle secrete RevenueCat (sk_...),
//                      pour verifier que le joueur est bien abonne
//   REVENUECAT_DROIT   defaut "pro"
// SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY sont fournis
// automatiquement par Supabase.

import { createClient } from "npm:@supabase/supabase-js@2.45.4";
import { CONSIGNES } from "./consignes.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const CLES = ["verdict", "marche", "coince", "change", "fond", "action", "si_alors"];
const FACULTATIVES = ["si_alors", "fond"];   // fond : vide quand moins de 3 semaines d historique


function json(corps: unknown, statut = 200) {
  return new Response(JSON.stringify(corps), { status: statut, headers: { ...CORS, "Content-Type": "application/json" } });
}

// Plus de tirets longs, plus de balises : le texte sera affiche tel quel
function nettoyer(t: unknown): string {
  return String(t ?? "")
    .replace(/[\u2014\u2013]/g, ",")
    .replace(/<[^>]*>/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 600);
}

function extraireJSON(texte: string): Record<string, string> | null {
  const a = texte.indexOf("{"), b = texte.lastIndexOf("}");
  if (a < 0 || b <= a) return null;
  try {
    const o = JSON.parse(texte.slice(a, b + 1));
    const r: Record<string, string> = {};
    for (const k of CLES) {
      r[k] = nettoyer(o[k]);
      if (!r[k] && !FACULTATIVES.includes(k)) return null;
    }
    return r;
  } catch {
    return null;
  }
}

async function estAbonne(userId: string): Promise<boolean> {
  const secret = Deno.env.get("REVENUECAT_SECRET");
  if (!secret) return true; // verification desactivee (a eviter en production)
  const droit = Deno.env.get("REVENUECAT_DROIT") || "pro";
  const r = await fetch(`https://api.revenuecat.com/v1/subscribers/${encodeURIComponent(userId)}`, {
    headers: { Authorization: `Bearer ${secret}` },
  });
  if (!r.ok) return false;
  const d = await r.json();
  const e = d?.subscriber?.entitlements?.[droit];
  if (!e) return false;
  return !e.expires_date || new Date(e.expires_date).getTime() > Date.now();
}

// extra : parametres propres au modele (raisonnement court pour gpt-oss,
// raisonnement masque pour qwen), retires si le fournisseur repond 400
type Maillon = { nom: string; url: string; cle: string; modele: string; format: "openai" | "anthropic"; extra?: Record<string, unknown> };

const CHAINE_DEFAUT: Maillon[] = [
  { nom: "groq", url: "https://api.groq.com/openai/v1", cle: "GROQ_CLE", modele: "openai/gpt-oss-120b", format: "openai", extra: { reasoning_effort: "low" } },
  { nom: "groq", url: "https://api.groq.com/openai/v1", cle: "GROQ_CLE", modele: "qwen/qwen3.8-27b", format: "openai", extra: { reasoning_format: "hidden" } },
  { nom: "cerebras", url: "https://api.cerebras.ai/v1", cle: "CEREBRAS_CLE", modele: "gpt-oss-120b", format: "openai", extra: { reasoning_effort: "low" } },
  { nom: "openrouter", url: "https://openrouter.ai/api/v1", cle: "OPENROUTER_CLE", modele: "meta-llama/llama-3.3-70b-instruct:free", format: "openai" },
  { nom: "groq", url: "https://api.groq.com/openai/v1", cle: "GROQ_CLE", modele: "openai/gpt-oss-20b", format: "openai", extra: { reasoning_effort: "low" } },
  { nom: "anthropic", url: "https://api.anthropic.com/v1", cle: "ANTHROPIC_CLE", modele: "claude-haiku-5-5", format: "anthropic" },
];

function chaine(): Maillon[] {
  const perso = Deno.env.get("IA_CHAINE");
  if (perso) { try { const c = JSON.parse(perso); if (Array.isArray(c) && c.length) return c; } catch { /* ignore */ } }
  return CHAINE_DEFAUT;
}
function cleDe(m: Maillon): string | undefined {
  return Deno.env.get(m.cle) || (m.cle === "GROQ_CLE" ? Deno.env.get("IA_CLE") : undefined);
}

// Garde-fou contre les chiffres inventes : tout pourcentage, decimal ou
// nombre superieur a 31 ecrit par l IA doit exister dans les faits.
function chiffreInvente(analyse: Record<string, string>, faits: unknown): string | null {
  const connus = new Set((JSON.stringify(faits).match(/\d+(?:\.\d+)?/g) || []).map((x) => String(Number(x))));
  const texte = Object.values(analyse).join(" ");
  const re = /(\d+(?:[.,]\d+)?)\s*(%?)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(texte))) {
    const brut = m[1].replace(",", ".");
    const n = Number(brut);
    const aVerifier = m[2] === "%" || brut.includes(".") || n > 31;
    if (aVerifier && !connus.has(String(n))) return m[0].trim();
  }
  return null;
}

async function appeler(m: Maillon, cle: string, contenu: string, jsonForce: boolean): Promise<Response> {
  const ctrl = new AbortController();
  const minuterie = setTimeout(() => ctrl.abort(), 25000);
  try {
    if (m.format === "anthropic") {
      return await fetch(m.url.replace(/\/$/, "") + "/messages", {
        method: "POST", signal: ctrl.signal,
        headers: { "x-api-key": cle, "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify({ model: m.modele, max_tokens: 1200, system: CONSIGNES, messages: [{ role: "user", content: contenu }] }),
      });
    }
    return await fetch(m.url.replace(/\/$/, "") + "/chat/completions", {
      method: "POST", signal: ctrl.signal,
      headers: { Authorization: `Bearer ${cle}`, "content-type": "application/json" },
      body: JSON.stringify({ model: m.modele, temperature: 0.6, max_tokens: 2000,   // marge pour le raisonnement court des gpt-oss, sans depasser la limite par minute du gratuit
        ...(jsonForce ? { response_format: { type: "json_object" }, ...(m.extra || {}) } : {}),
        messages: [{ role: "system", content: CONSIGNES }, { role: "user", content: contenu }] }),
    });
  } finally { clearTimeout(minuterie); }
}

async function rediger(faits: unknown): Promise<{ analyse: Record<string, string> | null; modele: string; essais: string[] }> {
  const contenu = "Faits de la semaine et des 3 derniers mois (JSON) :\n" + JSON.stringify(faits);
  const essais: string[] = [];
  for (const m of chaine()) {
    const cle = cleDe(m);
    if (!cle) continue;
    const id = m.nom + "/" + m.modele;
    try {
      let r = await appeler(m, cle, contenu, true);
      if (r.status === 400 && m.format === "openai") r = await appeler(m, cle, contenu, false);
      // 429 bref (limite par minute) : une seconde chance si l attente annoncee est courte
      if (r.status === 429) {
        const att = Number(r.headers.get("retry-after"));
        if (att > 0 && att <= 8) { await new Promise((ok) => setTimeout(ok, att * 1000)); r = await appeler(m, cle, contenu, true); }
      }
      if (!r.ok) { essais.push(id + " : " + r.status); continue; }   // 429 quota, 5xx panne...
      const d = await r.json();
      const texte = m.format === "anthropic"
        ? (d.content || []).map((c: { text?: string }) => c.text || "").join("")
        : (d?.choices?.[0]?.message?.content || "");
      const analyse = extraireJSON(texte);
      if (!analyse) { essais.push(id + " : JSON invalide"); continue; }
      if (!(faits as { trois_mois?: unknown })?.trois_mois) analyse.fond = "";   // pas de recul : pas de pattern de fond
      if (!/^si\b/i.test(analyse.si_alors) || !/alors je/i.test(analyse.si_alors)) analyse.si_alors = "";
      const inv = chiffreInvente(analyse, faits);
      if (inv) { essais.push(id + " : chiffre absent des faits (" + inv + ")"); continue; }
      return { analyse, modele: id, essais };
    } catch (e) {
      essais.push(id + " : " + String((e as Error)?.name === "AbortError" ? "delai depasse" : (e as Error)?.message || e).slice(0, 80));
    }
  }
  if (!essais.length) essais.push("aucune cle IA trouvee dans les secrets (GROQ_CLE...)");
  console.warn("[analyse-hebdo] aucun maillon n a abouti", essais);
  return { analyse: null, modele: "", essais };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ erreur: "methode" }, 405);
  try {
    // 1. Qui demande ? (jeton de session du joueur)
    const auth = req.headers.get("Authorization") || "";
    const url = Deno.env.get("SUPABASE_URL")!;
    const asUser = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const { data: u } = await asUser.auth.getUser();
    const user = u?.user;
    if (!user) return json({ erreur: "non connecte" }, 401);

    // 2. Demande valide et raisonnable
    const corps = await req.json().catch(() => null);
    const semaine = Number(corps?.semaine);
    const faits = corps?.faits;
    if (!Number.isInteger(semaine) || semaine < 1 || semaine > 5000 || !faits || typeof faits !== "object") return json({ erreur: "demande" }, 400);
    if (JSON.stringify(faits).length > 24000) return json({ erreur: "trop long" }, 413);

    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // 3. Deja redigee ? On la renvoie, sans rappeler l IA
    const { data: deja } = await admin.from("analyses_hebdo").select("contenu").eq("user_id", user.id).eq("semaine", semaine).maybeSingle();
    if (deja?.contenu) return json({ analyse: deja.contenu, cache: true });

    // 4. Abonne ?
    if (!(await estAbonne(user.id))) return json({ erreur: "abonnement" }, 402);

    // 5. Garde-fou de facture : 3 analyses au plus par 7 jours et par joueur
    const depuis = new Date(Date.now() - 7 * 864e5).toISOString();
    const { count } = await admin.from("analyses_hebdo").select("semaine", { count: "exact", head: true }).eq("user_id", user.id).gte("created_at", depuis);
    if ((count ?? 0) >= 3) return json({ erreur: "limite" }, 429);

    // 6. Redaction, puis memorisation
    const r = await rediger(faits);
    if (!r.analyse) return json({ erreur: "redaction", essais: r.essais }, 502);   // l app garde sa redaction locale ; essais : diagnostic admin
    await admin.from("analyses_hebdo").insert({ user_id: user.id, semaine, contenu: r.analyse, modele: r.modele });
    return json({ analyse: r.analyse });
  } catch (e) {
    return json({ erreur: String((e as Error)?.message || e).slice(0, 200) }, 500);
  }
});
