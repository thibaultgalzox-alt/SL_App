// Metanoia : fonction Supabase « analyse-hebdo » (19 octobre 2026)
//
// Recoit les faits de la semaine, calcules et verifies par le telephone, et
// demande a une IA de les mettre en mots. Une analyse par joueur et par
// semaine : la reponse est gardee en base et renvoyee telle quelle ensuite.
//
// Chaine de secours (20 octobre) : plusieurs API gratuites se relaient. Si
// l une est a court de quota, en panne, trop lente, ou rend une reponse
// invalide, la suivante prend le relais. Un maillon dont la cle manque est
// simplement saute. Ordre par defaut (gratuits, sans entrainement sur les
// donnees d apres leurs conditions en octobre 2026) :
//   (20 octobre : Groq a retire llama-3.3-70b-versatile et llama-3.1-8b-instant
//    le 16 aout 2026, ils repondent 404 ; remplaces par ses successeurs officiels)
//   1. Groq        openai/gpt-oss-120b       cle GROQ_CLE (ou IA_CLE)
//   2. Cloudflare  @cf/openai/gpt-oss-120b   cles CLOUDFLARE_CLE (jeton API) et CLOUDFLARE_COMPTE (identifiant de compte)
//   3. OpenRouter  openai/gpt-oss-120b:free  cle OPENROUTER_CLE
//   4. Groq        qwen/qwen3.8-27b          meme cle Groq, quota separe (preview)
//   5. Cerebras    gpt-oss-120b              cle CEREBRAS_CLE (plus d offre gratuite durable)
//   6. OpenRouter  meta-llama/llama-3.3-70b-instruct:free
//   7. Groq        openai/gpt-oss-20b        dernier recours gratuit, plus faible
//   8. Anthropic   claude-haiku-5-5          cle ANTHROPIC_CLE, payant, facultatif
// IA_CHAINE (facultatif) remplace cet ordre : tableau JSON de
//   {"nom":"...","url":"https://.../v1","cle":"NOM_DU_SECRET","modele":"...","format":"openai"|"anthropic"}
//   REVENUECAT_SECRET  facultatif mais conseille : cle secrete RevenueCat (sk_...),
//                      pour verifier que le joueur est bien abonne
//   REVENUECAT_DROIT   defaut "pro"
// SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY sont fournis
// automatiquement par Supabase.

import { createClient } from "npm:@supabase/supabase-js@2.45.4";
import { CONSIGNES } from "./consignes.ts";
import { choisirFaits } from "./bibliotheque.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
// Version 2 (20 octobre) : des moments plutot que marche / coince / change
const CLES = ["verdict", "fond", "action", "si_alors"];
const FACULTATIVES = ["si_alors", "fond"];   // fond : vide quand moins de 3 semaines d historique
const TYPES_MOMENT = ["exploit", "echec", "declic"];
type Moment = { jour: string; type: string; texte: string };
type Analyse = { verdict: string; fond: string; action: string; si_alors: string; moments: Moment[]; v: number };


function json(corps: unknown, statut = 200) {
  return new Response(JSON.stringify(corps), { status: statut, headers: { ...CORS, "Content-Type": "application/json" } });
}

// Plus de tirets longs, plus de balises : le texte sera affiche tel quel
function nettoyer(t: unknown): string {
  return String(t ?? "")
    .replace(/[\u2014\u2013]/g, ",")
    .replace(/([a-zà-ÿ])_([a-zà-ÿ])/gi, "$1 $2")   // pas de cle de code (« energie_basse ») dans le texte
    .replace(/<[^>]*>/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 1200);   // 22 octobre : textes plus developpes
}

function extraireJSON(texte: string): Analyse | null {
  const a = texte.indexOf("{"), b = texte.lastIndexOf("}");
  if (a < 0 || b <= a) return null;
  try {
    const o = JSON.parse(texte.slice(a, b + 1));
    const r: Record<string, unknown> = {};
    for (const k of CLES) {
      r[k] = nettoyer(o[k]);
      if (!r[k] && !FACULTATIVES.includes(k)) return null;
    }
    const m = Array.isArray(o.moments) ? o.moments : [];
    r.moments = m.slice(0, 4).map((x: Record<string, unknown>) => ({
      jour: nettoyer(x?.jour).slice(0, 20).toLowerCase(),
      type: TYPES_MOMENT.includes(String(x?.type)) ? String(x?.type) : "declic",
      texte: nettoyer(x?.texte),
    })).filter((x: Moment) => x.texte);
    if (!(r.moments as Moment[]).length) return null;
    r.v = 2;
    return r as Analyse;
  } catch {
    return null;
  }
}

async function estAbonne(userId: string): Promise<boolean> {
  const secret = Deno.env.get("REVENUECAT_SECRET");
  if (!secret) return true; // verification desactivee (a eviter en production)
  const droit = Deno.env.get("REVENUECAT_DROIT") || "pro";
  const r = await fetch(`https://api.revenuecat.com/v1/subscribers/${encodeURIComponent(userId)}`, {
    headers: { Authorization: `Bearer ${secret}` },
  });
  if (!r.ok) return false;
  const d = await r.json();
  const e = d?.subscriber?.entitlements?.[droit];
  if (!e) return false;
  return !e.expires_date || new Date(e.expires_date).getTime() > Date.now();
}

// extra : parametres propres au modele (raisonnement court pour gpt-oss,
// raisonnement masque pour qwen), retires si le fournisseur repond 400
type Maillon = { nom: string; url: string; cle: string; modele: string; format: "openai" | "anthropic"; extra?: Record<string, unknown> };

const CHAINE_DEFAUT: Maillon[] = [
  { nom: "groq", url: "https://api.groq.com/openai/v1", cle: "GROQ_CLE", modele: "openai/gpt-oss-120b", format: "openai", extra: { reasoning_effort: "low" } },
  // 21 octobre : Cloudflare Workers AI (10 000 « neurones » gratuits par jour, environ 34 analyses)
  { nom: "cloudflare", url: "https://api.cloudflare.com/client/v4/accounts/{CLOUDFLARE_COMPTE}/ai/v1", cle: "CLOUDFLARE_CLE", modele: "@cf/openai/gpt-oss-120b", format: "openai", extra: { reasoning_effort: "low" } },
  // 21 octobre : OpenRouter gratuit, gpt-oss-120b d abord (quota partage entre modeles gratuits : 50 par jour)
  { nom: "openrouter", url: "https://openrouter.ai/api/v1", cle: "OPENROUTER_CLE", modele: "openai/gpt-oss-120b:free", format: "openai", extra: { reasoning: { effort: "low" } } },
  { nom: "groq", url: "https://api.groq.com/openai/v1", cle: "GROQ_CLE", modele: "qwen/qwen3.8-27b", format: "openai", extra: { reasoning_format: "hidden" } },
  { nom: "cerebras", url: "https://api.cerebras.ai/v1", cle: "CEREBRAS_CLE", modele: "gpt-oss-120b", format: "openai", extra: { reasoning_effort: "low" } },
  { nom: "openrouter", url: "https://openrouter.ai/api/v1", cle: "OPENROUTER_CLE", modele: "meta-llama/llama-3.3-70b-instruct:free", format: "openai" },
  { nom: "groq", url: "https://api.groq.com/openai/v1", cle: "GROQ_CLE", modele: "openai/gpt-oss-20b", format: "openai", extra: { reasoning_effort: "low" } },
  { nom: "anthropic", url: "https://api.anthropic.com/v1", cle: "ANTHROPIC_CLE", modele: "claude-haiku-5-5", format: "anthropic" },
];

function chaine(): Maillon[] {
  const perso = Deno.env.get("IA_CHAINE");
  if (perso) { try { const c = JSON.parse(perso); if (Array.isArray(c) && c.length) return c; } catch { /* ignore */ } }
  return CHAINE_DEFAUT;
}
// Adresse avec une variable (ex. {CLOUDFLARE_COMPTE}) : remplie depuis les secrets, sinon maillon saute
function urlDe(m: Maillon): string | null {
  let manque = false;
  const u = m.url.replace(/\{([A-Z_]+)\}/g, (_x, v) => { const e = Deno.env.get(v); if (!e) manque = true; return e || ""; });
  return manque ? null : u;
}
function cleDe(m: Maillon): string | undefined {
  return Deno.env.get(m.cle) || (m.cle === "GROQ_CLE" ? Deno.env.get("IA_CLE") : undefined);
}

// Garde-fou contre les chiffres inventes : tout pourcentage, decimal ou
// nombre superieur a 31 ecrit par l IA doit exister dans les faits.
function chiffreInvente(analyse: Analyse, faits: unknown): string | null {
  // virgule decimale francaise (« 33,4 ») ramenee au point avant lecture
  const connus = new Set((JSON.stringify(faits).replace(/(\d),(\d)/g, "$1.$2").match(/\d+(?:\.\d+)?/g) || []).map((x) => String(Number(x))));
  const texte = [analyse.verdict, analyse.fond, analyse.action, analyse.si_alors, ...analyse.moments.map((x) => x.texte)].join(" ");
  const re = /(\d+(?:[.,]\d+)?)\s*(%?)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(texte))) {
    const brut = m[1].replace(",", ".");
    const n = Number(brut);
    const aVerifier = m[2] === "%" || brut.includes(".") || n > 31;
    if (aVerifier && !connus.has(String(n))) return m[0].trim();
  }
  return null;
}

// 22 octobre : reponses plus developpees (consignes de Thibs : « explique, developpe »)
const SORTIE = 2500;        // jetons de reponse, raisonnement compris
const SORTIE_COURTE = 1400; // en repli apres un 413 (limite de 8 000 jetons par minute de Groq gratuit)
async function appeler(m: Maillon, cle: string, contenu: string, jsonForce: boolean, sortie = SORTIE): Promise<Response> {
  const ctrl = new AbortController();
  const minuterie = setTimeout(() => ctrl.abort(), 25000);
  try {
    if (m.format === "anthropic") {
      return await fetch(m.url.replace(/\/$/, "") + "/messages", {
        method: "POST", signal: ctrl.signal,
        headers: { "x-api-key": cle, "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify({ model: m.modele, max_tokens: sortie, system: CONSIGNES, messages: [{ role: "user", content: contenu }] }),
      });
    }
    return await fetch(m.url.replace(/\/$/, "") + "/chat/completions", {
      method: "POST", signal: ctrl.signal,
      headers: { Authorization: `Bearer ${cle}`, "content-type": "application/json" },
      body: JSON.stringify({ model: m.modele, temperature: 0.6, max_tokens: sortie,
        ...(jsonForce ? { response_format: { type: "json_object" }, ...(m.extra || {}) } : {}),
        messages: [{ role: "system", content: CONSIGNES }, { role: "user", content: contenu }] }),
    });
  } finally { clearTimeout(minuterie); }
}

async function rediger(faits: unknown): Promise<{ analyse: Analyse | null; modele: string; essais: string[] }> {
  // 20 octobre : bibliotheque de faits verifies, les seuls chiffres exterieurs autorises
  const biblio = choisirFaits(faits).map((x) => ({ fait: x.texte, source: x.source }));
  // Les cles internes des schemas (« energie_basse ») ne partent pas : l IA les recopiait
  faits = JSON.parse(JSON.stringify(faits || {}));
  // deno-lint-ignore no-explicit-any
  for (const p of (((faits as any)?.trois_mois?.patterns_d_echec) || []) as any[]) delete p.k;
  const contenu = "Faits de la semaine et des 3 derniers mois (JSON) :\n" + JSON.stringify(faits)
    + "\n\nBibliotheque de faits verifies (les SEULS faits exterieurs que tu peux citer, un seul au plus) :\n" + JSON.stringify(biblio);
  // Version courte : sans les champs les moins utiles, et 3 faits de bibliotheque
  // deno-lint-ignore no-explicit-any
  const fc: any = JSON.parse(JSON.stringify(faits || {}));
  if (fc.trois_mois) for (const k of ["ses_mots_les_jours_rates_avant_cette_semaine", "semaines", "par_jour_de_semaine", "humeur_du_matin", "energie_du_soir", "mots_des_jours_rates", "heures"]) delete fc.trois_mois[k];
  const contenuCourt = "Faits de la semaine et des 3 derniers mois (JSON) :\n" + JSON.stringify(fc)
    + "\n\nBibliotheque de faits verifies (les SEULS faits exterieurs que tu peux citer, un seul au plus) :\n" + JSON.stringify(biblio.slice(0, 3));
  const essais: string[] = [];
  for (let m of chaine()) {
    const cle = cleDe(m);
    const url = urlDe(m);
    if (!cle || !url) continue;
    m = { ...m, url };
    const id = m.nom + "/" + m.modele;
    try {
      let r = await appeler(m, cle, contenu, true);
      // 413 (demande trop grosse pour la limite par minute du gratuit) : on rejoue une version courte
      if (r.status === 413) r = await appeler(m, cle, contenuCourt, true, SORTIE_COURTE);
      if (r.status === 400 && m.format === "openai") r = await appeler(m, cle, contenu, false);
      // 429 bref (limite par minute) : une seconde chance si l attente annoncee est courte
      if (r.status === 429) {
        const att = Number(r.headers.get("retry-after"));
        if (att > 0 && att <= 8) { await new Promise((ok) => setTimeout(ok, att * 1000)); r = await appeler(m, cle, contenu, true); }
      }
      if (!r.ok) { essais.push(id + " : " + r.status); continue; }   // 429 quota, 5xx panne...
      const d = await r.json();
      const texte = m.format === "anthropic"
        ? (d.content || []).map((c: { text?: string }) => c.text || "").join("")
        : (d?.choices?.[0]?.message?.content || "");
      const analyse = extraireJSON(texte);
      if (!analyse) { essais.push(id + " : JSON invalide"); continue; }
      if (!(faits as { trois_mois?: unknown })?.trois_mois) analyse.fond = "";
      // Exploit seulement s il est dans la liste calculee par le telephone
      // deno-lint-ignore no-explicit-any
      const expl = new Set((((faits as any)?.trois_mois?.exploits_de_la_semaine) || []).map((e: any) => String(e.jour || "").toLowerCase()));
      for (const mo of analyse.moments) if (mo.type === "exploit" && !expl.has(mo.jour)) mo.type = "declic";   // pas de recul : pas de pattern de fond
      if (!/^si\b/i.test(analyse.si_alors) || !/alors je/i.test(analyse.si_alors)) analyse.si_alors = "";
      const inv = chiffreInvente(analyse, { faits, biblio });
      if (inv) { essais.push(id + " : chiffre absent des faits (" + inv + ")"); continue; }
      return { analyse, modele: id, essais };
    } catch (e) {
      essais.push(id + " : " + String((e as Error)?.name === "AbortError" ? "delai depasse" : (e as Error)?.message || e).slice(0, 80));
    }
  }
  if (!essais.length) essais.push("aucune cle IA trouvee dans les secrets (GROQ_CLE...)");
  console.warn("[analyse-hebdo] aucun maillon n a abouti", essais);
  return { analyse: null, modele: "", essais };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ erreur: "methode" }, 405);
  try {
    // 1. Qui demande ? (jeton de session du joueur)
    const auth = req.headers.get("Authorization") || "";
    const url = Deno.env.get("SUPABASE_URL")!;
    const asUser = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const { data: u } = await asUser.auth.getUser();
    const user = u?.user;
    if (!user) return json({ erreur: "non connecte" }, 401);

    // 2. Demande valide et raisonnable
    const corps = await req.json().catch(() => null);
    const semaine = Number(corps?.semaine);
    const faits = corps?.faits;
    if (!Number.isInteger(semaine) || semaine < 1 || semaine > 5000 || !faits || typeof faits !== "object") return json({ erreur: "demande" }, 400);
    if (JSON.stringify(faits).length > 24000) return json({ erreur: "trop long" }, 413);

    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    // Admin (reglage des consignes) : « forcer » ignore le cache et la limite
    const forcer = corps?.forcer === true && user.id === (Deno.env.get("ADMIN_UID") || "d4f11013-e36b-4cc5-bc12-bc83ce29a9e6");

    // 3. Deja redigee ? On la renvoie, sans rappeler l IA
    const { data: deja } = forcer ? { data: null } : await admin.from("analyses_hebdo").select("contenu").eq("user_id", user.id).eq("semaine", semaine).maybeSingle();
    if (deja?.contenu) return json({ analyse: deja.contenu, cache: true });

    // 4. Abonne ?
    if (!(await estAbonne(user.id))) return json({ erreur: "abonnement" }, 402);

    // 5. Garde-fou de facture : 3 analyses au plus par 7 jours et par joueur
    const depuis = new Date(Date.now() - 7 * 864e5).toISOString();
    const { count } = await admin.from("analyses_hebdo").select("semaine", { count: "exact", head: true }).eq("user_id", user.id).gte("created_at", depuis);
    if (!forcer && (count ?? 0) >= 3) return json({ erreur: "limite" }, 429);

    // 6. Redaction, puis memorisation
    const r = await rediger(faits);
    if (!r.analyse) return json({ erreur: "redaction", essais: r.essais }, 502);   // l app garde sa redaction locale ; essais : diagnostic admin
    await admin.from("analyses_hebdo").upsert({ user_id: user.id, semaine, contenu: r.analyse, modele: r.modele });
    return json({ analyse: r.analyse, modele: r.modele });
  } catch (e) {
    return json({ erreur: String((e as Error)?.message || e).slice(0, 200) }, 500);
  }
});
