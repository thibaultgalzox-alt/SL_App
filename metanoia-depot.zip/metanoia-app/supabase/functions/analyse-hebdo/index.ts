// Metanoia : fonction Supabase « analyse-hebdo » (19 octobre 2026)
//
// Recoit les faits de la semaine, calcules et verifies par le telephone, et
// demande a une IA de les mettre en mots. Une analyse par joueur et par
// semaine : la reponse est gardee en base et renvoyee telle quelle ensuite.
//
// Secrets (Supabase > Edge Functions > Secrets) :
//   IA_FOURNISSEUR     "anthropic" (defaut) ou "openai" (toute API compatible
//                      OpenAI : Mistral, Groq, OpenRouter, Ollama...)
//   IA_CLE             cle API du fournisseur
//   IA_MODELE          defaut "claude-haiku-5-5" (anthropic)
//   IA_URL             pour "openai" : adresse de base, ex.
//                      https://api.mistral.ai/v1
//   REVENUECAT_SECRET  facultatif mais conseille : cle secrete RevenueCat (sk_...),
//                      pour verifier que le joueur est bien abonne
//   REVENUECAT_DROIT   defaut "pro"
// SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY sont fournis
// automatiquement par Supabase.

import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const CLES = ["verdict", "marche", "coince", "change", "action", "si_alors"];

const CONSIGNES = `Tu es le coach de Metanoia, une application d'habitudes en forme de jeu de role (quetes, series, donjons, rangs).
Tu ecris l'analyse de la semaine d'un joueur, en francais, en le tutoyant.

Regles absolues :
- Tu n'utilises QUE les faits fournis. Aucun chiffre, aucun jour, aucune quete qui n'y figure pas. Si une information manque, tu n'en parles pas.
- Tu cites ses propres mots (champs "obstacle" et "rechute") entre guillemets francais quand ils eclairent un echec.
- Ton : un coach exigeant et bienveillant. Direct, concret, jamais culpabilisant, jamais mielleux. Pas de jugement sur la personne : tu parles de ses actions et de ses journees.
- Pas de conseil medical, pas de diagnostic, pas de morale.
- Jamais de tiret cadratin ni demi-cadratin. Pas d'emoji. Pas de markdown.
- Phrases courtes. Chaque partie fait 1 a 3 phrases, 60 mots au plus.

Tu reponds UNIQUEMENT par un objet JSON, sans texte autour, avec ces cles :
"verdict" : la semaine en une phrase, avec le nombre de jours reussis, comparee a sa moyenne si elle est fournie.
"marche" : ce qui a marche, et pourquoi d'apres les faits.
"coince" : ce qui a coince, relie a ses mots ou a ses quetes fragiles. Si rien n'a coince, dis-le simplement.
"change" : ce qui change par rapport aux semaines d'avant (moyennes fournies) ; s'il n'y a pas de point de comparaison, dis que cette semaine sert de point de depart.
"action" : UNE seule action concrete pour la semaine qui vient, tiree des faits (zone de rupture a venir, quete fragile, jour faible habituel).
"si_alors" : un plan sous la forme exacte "Si ..., alors je ...", adapte a son obstacle principal.`;

function json(corps: unknown, statut = 200) {
  return new Response(JSON.stringify(corps), { status: statut, headers: { ...CORS, "Content-Type": "application/json" } });
}

// Plus de tirets longs, plus de balises : le texte sera affiche tel quel
function nettoyer(t: unknown): string {
  return String(t ?? "")
    .replace(/[\u2014\u2013]/g, ",")
    .replace(/<[^>]*>/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 600);
}

function extraireJSON(texte: string): Record<string, string> | null {
  const a = texte.indexOf("{"), b = texte.lastIndexOf("}");
  if (a < 0 || b <= a) return null;
  try {
    const o = JSON.parse(texte.slice(a, b + 1));
    const r: Record<string, string> = {};
    for (const k of CLES) {
      r[k] = nettoyer(o[k]);
      if (!r[k] && k !== "si_alors") return null;
    }
    return r;
  } catch {
    return null;
  }
}

async function estAbonne(userId: string): Promise<boolean> {
  const secret = Deno.env.get("REVENUECAT_SECRET");
  if (!secret) return true; // verification desactivee (a eviter en production)
  const droit = Deno.env.get("REVENUECAT_DROIT") || "pro";
  const r = await fetch(`https://api.revenuecat.com/v1/subscribers/${encodeURIComponent(userId)}`, {
    headers: { Authorization: `Bearer ${secret}` },
  });
  if (!r.ok) return false;
  const d = await r.json();
  const e = d?.subscriber?.entitlements?.[droit];
  if (!e) return false;
  return !e.expires_date || new Date(e.expires_date).getTime() > Date.now();
}

async function rediger(faits: unknown): Promise<{ analyse: Record<string, string>; modele: string } | null> {
  const fournisseur = (Deno.env.get("IA_FOURNISSEUR") || "anthropic").toLowerCase();
  const cle = Deno.env.get("IA_CLE");
  if (!cle) throw new Error("IA_CLE manquante");
  const contenu = "Faits de la semaine (JSON) :\n" + JSON.stringify(faits);
  let texte = "";
  let modele = "";
  if (fournisseur === "anthropic") {
    modele = Deno.env.get("IA_MODELE") || "claude-haiku-5-5";
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": cle, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: modele, max_tokens: 1200, system: CONSIGNES, messages: [{ role: "user", content: contenu }] }),
    });
    if (!r.ok) throw new Error("IA " + r.status + " " + (await r.text()).slice(0, 200));
    const d = await r.json();
    texte = (d.content || []).map((c: { text?: string }) => c.text || "").join("");
  } else {
    modele = Deno.env.get("IA_MODELE") || "mistral-small-latest";
    const base = (Deno.env.get("IA_URL") || "https://api.mistral.ai/v1").replace(/\/$/, "");
    const r = await fetch(base + "/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${cle}`, "content-type": "application/json" },
      body: JSON.stringify({ model: modele, temperature: 0.7, max_tokens: 1200,
        messages: [{ role: "system", content: CONSIGNES }, { role: "user", content: contenu }] }),
    });
    if (!r.ok) throw new Error("IA " + r.status + " " + (await r.text()).slice(0, 200));
    const d = await r.json();
    texte = d?.choices?.[0]?.message?.content || "";
  }
  const analyse = extraireJSON(texte);
  return analyse ? { analyse, modele } : null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ erreur: "methode" }, 405);
  try {
    // 1. Qui demande ? (jeton de session du joueur)
    const auth = req.headers.get("Authorization") || "";
    const url = Deno.env.get("SUPABASE_URL")!;
    const asUser = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const { data: u } = await asUser.auth.getUser();
    const user = u?.user;
    if (!user) return json({ erreur: "non connecte" }, 401);

    // 2. Demande valide et raisonnable
    const corps = await req.json().catch(() => null);
    const semaine = Number(corps?.semaine);
    const faits = corps?.faits;
    if (!Number.isInteger(semaine) || semaine < 1 || semaine > 5000 || !faits || typeof faits !== "object") return json({ erreur: "demande" }, 400);
    if (JSON.stringify(faits).length > 24000) return json({ erreur: "trop long" }, 413);

    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // 3. Deja redigee ? On la renvoie, sans rappeler l IA
    const { data: deja } = await admin.from("analyses_hebdo").select("contenu").eq("user_id", user.id).eq("semaine", semaine).maybeSingle();
    if (deja?.contenu) return json({ analyse: deja.contenu, cache: true });

    // 4. Abonne ?
    if (!(await estAbonne(user.id))) return json({ erreur: "abonnement" }, 402);

    // 5. Garde-fou de facture : 3 analyses au plus par 7 jours et par joueur
    const depuis = new Date(Date.now() - 7 * 864e5).toISOString();
    const { count } = await admin.from("analyses_hebdo").select("semaine", { count: "exact", head: true }).eq("user_id", user.id).gte("created_at", depuis);
    if ((count ?? 0) >= 3) return json({ erreur: "limite" }, 429);

    // 6. Redaction, puis memorisation
    const r = await rediger(faits);
    if (!r) return json({ erreur: "redaction" }, 502);
    await admin.from("analyses_hebdo").insert({ user_id: user.id, semaine, contenu: r.analyse, modele: r.modele });
    return json({ analyse: r.analyse });
  } catch (e) {
    return json({ erreur: String((e as Error)?.message || e).slice(0, 200) }, 500);
  }
});
