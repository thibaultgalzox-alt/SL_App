# Metanoia - projet Android (Capacitor)

Phases 1 a 4 du plan de migration. Le projet se compile dans Android Studio ;
il n'a pas pu etre compile ici, faute d'Android SDK (`dl.google.com` inaccessible).

## Pour le lancer

```bash
npm install
npx cap sync android
npx cap open android      # ouvre Android Studio
```

Puis dans Android Studio : Run, ou Build > Build APK(s).

## Ce qui est fait

- **Phase 1** - socle Capacitor, `appId` `com.metanoia_app`, `appName` Metanoia.
- **Phase 2** - polices et Supabase en local. Plus aucune dependance distante
  sauf Google Sign-In (phase 5).
- **Phase 3** - service worker retire, ligne « Version de l'application »
  retiree des parametres.
- **Phase 4** - stockage natif a deux copies, avec migration automatique.
- **Phase 5** - connexion Google native via @capgo/capacitor-social-login.
  Le script GSI distant n'est plus charge qu'en web. En natif, le selecteur
  de comptes Android renvoie un idToken, passe au meme signInWithIdToken de
  Supabase qu'auparavant. REQUIERT un client OAuth Android dans la console
  Google Cloud (voir ci-dessous).
- **Icones** - phenix seul sur fond bordeaux #4D102F, 5 densites, icone
  adaptative + heritee. Le mot METANOIA est retire de l'icone du lanceur
  (il serait rogne par le masque rond) mais reste sur l'icone du store
  et sur l'ecran de lancement.

## Ou se trouve quoi

| Fichier | Role |
|---|---|
| `www/index.html` | l'application, seul fichier modifie par rapport a ta version |
| `www/fonts.css` + `www/fonts/` | les 13 fichiers de police, 239 Ko |
| `www/supabase.js` | la bibliotheque Supabase, version locale |
| `capacitor.config.json` | identifiant, nom, dossier web |
| `android/` | le projet Android genere |
| `store/icone-play-512.png` | l'icone 512x512 pour la fiche Play Store |

## Compiler sans ordinateur

Le dossier `.github/workflows/android.yml` compile l'APK sur les serveurs de
GitHub. Depose le projet sur un depot GitHub, puis onglet Actions, « APK
Android », bouton « Run workflow ». L'APK se telecharge en bas de la page du
run, et l'empreinte SHA-1 s'affiche dans le journal de l'etape du meme nom.
Tout se fait depuis un navigateur, telephone compris.

## Changer l'identifiant de l'application

`com.metanoia_app` vient du domaine metanoia-app.com : Android refuse les
tirets, la regle Java les remplace par un underscore. Il est **definitif une
fois publie** sur le Play Store, modifiable librement avant. Les cinq endroits :
`capacitor.config.json`, `android/app/build.gradle` (`namespace` et
`applicationId`), `android/app/src/main/res/values/strings.xml`, le chemin
`android/app/src/main/java/com/metanoia_app/` et la ligne `package` de
`MainActivity.java`.

## A faire dans la console Google Cloud

Sans ces deux reglages, la connexion Google echoue en natif :

1. APIs & Services > Credentials > Create credentials > OAuth client ID,
   type **Android**, nom au choix.
   - Package name : `com.metanoia_app`
   - SHA-1 : `4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97`
2. Verifier dans Supabase (Authentication > Providers > Google) que le
   provider est actif et que le Client ID **Web** y figure.

- **Phase 6** - notifications locales natives (@capacitor/local-notifications).
  Les rappels sont desormais programmes par Android et partent application
  fermee, ce que l'ancien setInterval ne faisait pas. Le Web Push, impossible
  sans service worker, est court-circuite en natif.
- **Phase 7** - greffon d'horloge monotone, ecrit sur mesure
  (`android/.../HorlogePlugin.java`, enregistre dans MainActivity).
  Il expose SystemClock.elapsedRealtime(), que l'utilisateur ne peut pas
  regler, et l'instant de demarrage du telephone. Le rattrapage des jours
  borne desormais ce qu'il rejoue par ce temps reellement ecoule.

- **Evenements** - le canal force par Prediction est devenu un vrai second
  canal, strictement equivalent au naturel : volume, points, quete bonus
  Hard Mode et clear de Frenesie, pas seulement l'XP. Avant, deux tirages sur
  six (`double_pts`, `frenzy`) n'avaient aucun effet, et un shadow force ne
  donnait pas son x2 points. Regle ajoutee : Prediction s'adapte a l'evenement
  du jour et ne peut jamais etre le meme que lui. Reelection a trois endroits,
  au tirage (on retire l'evenement calendaire de demain), au passage de jour
  dans advDay(), et en garde-fou a chaque lecture dans _evForce(), parce que
  l'etat du jour bouge encore apres advDay. Plafond d'XP d'une journee ramene
  de 4990 a 3314 pour les quetes seules.
  Donjon : la condition « 1 quete en evenement » (10 donjons sur 108, Rang C+)
  fabriquait un doubleXP d'office les jours sans evenement calendaire, meme
  quand une Prediction etait deja active : les deux se multipliaient et le jour
  passait a x6. Une Prediction active compte desormais comme un evenement, donc
  plus de fabrication, et elle valide la condition par elle-meme.

- **Audit de securite** - quatre correctifs appliques a index.html.
  1. Le panneau de developpement est reserve au compte administrateur.
     Avant : cinq tapes dans le coin haut droit l ouvraient pour n importe quel
     joueur, sur telephone, sans outil (mesure : 25 050 points en cinq clics).
     RENSEIGNE ADMIN_UID OU ADMIN_EMAIL, declares juste avant toggleTestMode() :
     laisses vides, le panneau est desactive pour tout le monde, toi compris.
     Le mode test ne se rallume plus seul au demarrage, la session n etant pas
     encore resolue a cet instant : cinq tapes une fois connecte le rouvrent.
  2. submitReview() a une garde d idempotence. Avant : un double-clic creditait
     deux fois l XP, les points, UN JOUR DE SERIE et ecrivait deux bilans.
  3. _shopAddToInventory conserve price et orig. Avant : la revente retombait
     toujours sur son repli a 100 et rendait 50 pts, donc acheter a 41 puis
     revendre creait 9 pts par cycle.
  4. _sellInvItem ne decale plus l index une seconde fois, et ne vend qu un
     exemplaire d une pile. Avant, sous bouclier : cliquer la 3e case vendait
     le 1er objet, et toute la pile partait pour le prix d un seul.

  Reste a corriger, par ordre de gravite : l import de sauvegarde n a aucune
  borne (ligne 4972), et la policy de lecture de profiles expose le state_blob
  de tous les joueurs a tous les joueurs.

- **Deconnexion** - l interface repond au doigt leve : la ligne « Se
  deconnecter » disparait avant la synchronisation cloud, qui peut prendre six
  secondes, et le message suit. Puis la progression repart a J1 en conservant
  le questionnaire, le pourquoi et la date de mise a jour du formulaire, pour
  qu un changement de compte ne force personne a tout refaire.
  Filet hors ligne : _socLogout prend un instantane « avant-deconnexion » TANT
  QUE le compte est encore connu, donc range dans l anneau de ce compte. Il
  reapparait seul dans Reglages > Sauvegardes locales a la prochaine connexion
  de CE compte, et nulle part ailleurs. La reinitialisation ne purge donc NI
  IndexedDB NI localStorage, contrairement a testReset : ce serait effacer
  l instantane qu on vient de prendre.

- **Import de sauvegarde retire.** Un fichier importe remplacait l etat entier
  du jeu, et sa validation tenait en une ligne : « day est un nombre OU
  onboarded vaut true ». Le borner ne reglait rien, parce que TOUTES les
  valeurs de reference viennent du fichier : plafonner l XP a 5000 par jour n a
  aucun sens quand le nombre de jours est ecrit par celui qui triche. L export
  reste : le RGPD, article 20, ne porte que sur la SORTIE des donnees et
  n oblige a accepter aucun import. Les fonctions rgpdImport,
  _rgpdExtraitEtat et _rgpdImportFichier sont conservees intactes : pour
  reactiver, il suffit de remettre le bloc HTML d origine.
- **Diagnostic Google B5 reserve a l administrateur.** Il n apparait que sur un
  echec de connexion, jamais sur un succes. Son contenu est ecrit pour le
  developpeur : les joueurs recoivent desormais une phrase comprehensible,
  l outil reste entier pour le compte admin.

- **Rappel de sauvegarde dans Activite.** L import retire, un joueur sans
  compte n a plus aucun moyen de transferer sa progression : on le lui dit.
  Deux mecanismes complementaires. Une entree de journal (_actCheckCompte),
  posee a partir de J3 et au plus UNE par semaine de jeu grace a la cle
  « compte-rappel-<semaine> » : c est elle qui allume la pastille et fait
  ouvrir le panneau. Et une banniere CALCULEE a l ouverture, jamais stockee,
  qui porte le bouton « Creer un compte » et disparait a la seconde ou le
  joueur se connecte. Le bouton reutilise ST._socPulse, le clignotement du
  tutoriel, applique par nav() sur l ecran Social.

- **Fuite du state_blob fermee.** profiles porte a la fois les colonnes
  publiques du classement ET state_blob, la sauvegarde personnelle complete.
  L ancienne policy ne filtrait que les LIGNES, donc un GET
  /rest/v1/profiles?select=* rendait l etat de jeu entier de tous les joueurs.
  Correctif en trois temps, fichier metanoia-fuite-state-blob.sql :
  une vue « classement » qui n expose que les colonnes publiques et ecarte les
  suspects ; une fonction metanoia_pseudo_pris qui verifie l unicite sans lire
  la table ; et profiles restreinte a sa propre ligne en lecture.
  Cote client, quatre points : le classement interroge la vue, et les trois
  controles d unicite du pseudo passent par la fonction. Les dix autres acces a
  profiles sont des ecritures, la suppression RGPD, ou la lecture de sa propre
  ligne : tous inchanges.
  LE SQL ET L APPLICATION SE DEPLOIENT ENSEMBLE : une ancienne version du
  client lirait le classement dans profiles et afficherait une liste vide.

- **Greffon d horloge : la detection etait fausse.** HORLOGE_NATIVE ne testait
  que Capacitor.Plugins.Horloge. Or Capacitor.Plugins ne porte pas forcement un
  greffon natif sans pendant JavaScript : la voie documentee est
  registerPlugin(). Resultat, HORLOGE_NATIVE valait faux sur l appareil,
  _ratMonotone renvoyait null, _ratPlafondMonotone aussi, et TOUT le garde-fou
  etait saute EN SILENCE. L heure du telephone redevenait seule maitresse du
  calendrier. Constate en vrai : heure avancee, l application a suivi jusqu au
  jour 975, et le cliquet a ensuite refuse de revenir.
  Correctif : on essaie Capacitor.Plugins.Horloge PUIS registerPlugin.
  Ajout d un ecran de diagnostic reserve a l administrateur, bouton « Horloge »
  du panneau de test : il dit si le greffon repond, ce qu il renvoie, le
  plafond calcule et l etat du cliquet. Il porte aussi « Reparer », qui relache
  le cliquet et retablit un numero de jour saisi a la main, parce que le
  cliquet interdit de reculer par construction.

- Panneau de test ouvert apres la perte de la session. L identite admin n etait
  verifiee qu a l ouverture : au clic, dans toggleTestMode et au demarrage.
  Rien ne la revalidait ensuite, donc quand le jeton Supabase expirait, panneau
  affiche, il restait visible et pleinement utilisable.
  Correctif : `_verrouPanneauTest()`, appele dans le cycle de rendu et dans
  onAuthStateChange juste apres la reaffectation de _socUser. Il ferme le
  panneau, remet _TEST_MODE a faux et persiste. Teste : admin ouvre, session
  perdue, panneau ferme, reouverture refusee, admin revient, panneau rouvert,
  et le verrou ne gene jamais l admin connecte.

- Rappel de compte affiche aux utilisateurs connectes. Supabase restaure la
  session en asynchrone : au demarrage, `_socUser` vaut null pendant une
  seconde alors que le compte existe, et le cycle de rendu tranchait pendant
  ce laps. Deux bannieres posees « a l instant » sur un compte actif.
  Correctif : drapeau `_socAuthPret`, pose par `onAuthStateChange`, par la
  resolution de `getSession` y compris en echec, et tout de suite quand il n y
  a ni SDK ni configuration. Marqueur durable `ST._socDejaConnecte` pour ne
  pas reclamer un compte a un appareil qui en a deja porte un, cas du
  demarrage hors ligne. `_actPurgeCompte()` retire les bannieres deja posees
  des que la session arrive, par la cle `k` desormais retenue sur chaque
  entree, et par le titre pour celles creees avant. Cadence inchangee : un
  rappel par semaine tant qu il n y a pas de compte.

- Confirmation de deconnexion. Le geste partait d un seul appui et remet
  l appareil au jour 1. Une demande de confirmation precede desormais tout,
  et une fois les animations finies l application quitte les reglages pour
  l ecran des Quetes, onglet actif compris.

- Emblemes de guilde. Composition en cinq couches, entierement vectorielle et
  generee a l execution : 32 symboles, 14 cadres, 18 fonds, 10 effets et
  12 palettes, soit 967 680 combinaisons. Rien n est stocke en image, une
  guilde ne retient qu un code de moins de trente caracteres de la forme
  `v1|s<symbole>|f<cadre>|b<fond>|e<effet>|c<palette>`, ecrit dans la colonne
  `emblem` deja existante. Aucune migration SQL : la policy
  `guilds_update_owner` reserve deja l ecriture au proprietaire.
  Les emblemes d avant, qui etaient des emojis, restent affiches tels quels :
  `embSVG` les reconnait et les rend sans conversion.
  A la creation d une guilde, les cinq couches sont tirees au sort. Le Maitre
  les change ensuite dans les reglages de guilde, couche par couche, chaque
  vignette montrant SON embleme avec cette seule couche modifiee. Les autres
  membres y voient l embleme en grand, sans pouvoir le toucher.
  Les effets sont de petites particules posees en couronne, jamais au centre,
  jouees seulement a partir de 40 px et coupees par
  `prefers-reduced-motion`.

- Reglages de guilde : le bouton Enregistrer passait sous le bord de l ecran,
  donc le premier reflexe devenait la croix, qui jetait tout. La boite est
  desormais une colonne, en-tete fixe, corps qui defile, pied colle avec le
  bouton toujours visible. Hauteur bornee a min(80vh, 640px) et marge basse
  calee sur env(safe-area-inset-bottom) : elle ne depasse plus de l ecran.
  La croix previent quand un embleme, une devise ou un mode de recrutement
  n est pas enregistre.

- Effets d embleme refaits : ils se ressemblaient tous, c etaient onze fois
  les memes points. Onze effets distincts par la forme, le sens et le tempo.
  En continu : Comete (une comete et sa queue font le tour), Braises (elles
  montent du bas en vacillant), Neige (des flocons tombent a des vitesses
  differentes), Runes (deux anneaux tournent en sens contraires), Bulles
  (elles montent en ondulant), Poussiere (des motes respirent sur place).
  En salve, deux secondes d activite puis cinq de silence sur un cycle de
  sept : Etincelles (des eclats a quatre branches claquent), Foudre (un
  eclair traverse avec un flash), Onde (deux ondes de choc partent du
  centre), Balayage (une lame de lumiere passe en diagonale).
  Foudre et Balayage passent PAR DESSUS le symbole, les autres dessous.
  Au repos, sans animation, l eclair et le flash sont a opacite nulle : ni
  mouvement reduit ni vieux moteur ne laissent un aplat blanc sur le blason.
  Dans le selecteur seulement, les effets en salve rejouent toutes les
  2,6 s, sinon on choisirait la Foudre sans l avoir jamais vue frapper.
  Le catalogue passe a 32 x 14 x 18 x 11 x 12 = 1 064 448 combinaisons.

- Foudre refaite. Elle TOMBE desormais du haut : le trait grandit vers le bas
  depuis le bord superieur, par une echelle verticale animee depuis son point
  d attache. Trois couches pour la matiere, un halo large, le corps dans la
  palette et un coeur blanc plus etroit, plus deux fourches. Un pre-eclat tres
  bref precede la frappe, le flash est hache et jamais regulier, et l impact
  laisse une onde rasante au sol avec quatre eclats qui giclent. Cycle de 5 s,
  deux frappes par cycle. Verifie image par image : rien, pre-lueur, descente,
  flash, onde qui s elargit, puis silence.

- Cadrage du symbole par cadre. Une banniere n a pas sa masse au centre du
  carre de 64 : le symbole tombait sur les encoches du bas. Chaque cadre peut
  desormais porter un decalage vertical `dy`, applique au symbole. Pose sur
  Banniere -6, Pointe -5, Blason -2,5, Ecu -2, Gothique -1,5, Creneaux +1.

- Cinq cadres de plus : Rouage, Epines, Soleil, Banniere, Pointe. Le
  catalogue passe a 32 x 19 x 18 x 11 x 12 = 1 444 608 combinaisons.

- Foudre invisible : bug a moi. La base du groupe valait
  `translate(32 32) scale(0)` et `additive="sum"` MULTIPLIE les transformations,
  donc l echelle animee etait annulee par le zero de depart et l eclair ne
  s affichait jamais. Base ramenee a `translate(32 32)` seul, eclair agrandi,
  et deux frappes par cycle au lieu d une.

- Braises redessinees : un point tres clair dans un halo chaud a deux
  couches, une montee en zigzag sur cinq points, et un vacillement sur sept
  pas d echelle au lieu d une simple apparition. Elles ne se confondent plus
  avec les Bulles.

- Changer une valeur dans l editeur relancait toutes les animations : la
  grille entiere etait reconstruite a chaque choix. Or le contenu des
  vignettes voisines ne change pas, seules la selection et l apercu bougent.
  `_embChoisir` ne touche donc plus qu a ces deux la, via `_embMajApercu` et
  `_embMajSelection`. Verifie : apres un choix, les noeuds SVG de la grille
  sont les MEMES objets qu avant, donc SMIL continue sans redemarrer.

- Emblemes animes dans le classement Guilde : ils y etaient rendus en 15 px
  avec l animation coupee. Passes a 22 px et animes, et le seuil d animation
  descend de 36 a 20 px.

- Chat de guilde. Treize fois « Thibs a accompli une quete » noyaient les
  vrais messages : les evenements identiques qui se suivent sont desormais
  replies en une seule ligne portant un compteur. Mesure sur un jeu de
  19 messages : 6 lignes affichees, compteurs x13 et x2.
  Matiere et contraste : grain de papier sur la feuille, en-tete sur un
  bandeau soutenu avec l embleme en 34 px anime, evenements reduits a des
  pastilles discretes, bulles detachees par une ombre portee et un filet, la
  sienne en degrade avec reflet et assise, barre de saisie avec champ creuse
  et bouton d envoi en relief. Les messages reposent sur la barre de saisie
  grace a un `margin-top:auto` sur le premier, et non a
  `justify-content:flex-end` qui casse le defilement vers le haut.

- Effets passes en SMIL, et correction de ma lecture precedente du
  diagnostic. J avais conclu que ma regle de mouvement reduit coupait tout :
  c etait faux. Les elements testes par le diagnostic ne portent AUCUNE de
  mes classes, donc cette regle ne les touchait pas, et les trois techniques
  CSS repondaient NON quand meme. La vraie cause : Android met l echelle de
  duree des animations a zero en economie de batterie, et Chromium annule
  alors toutes les animations CSS du document. SMIL est un moteur separe, il
  continue de tourner, ce que le diagnostic montrait deja.
  Les onze effets sont donc reecrits en SMIL, sans une seule keyframe, et
  `embStyles()` n injecte plus rien. Contrainte posee : chaque effet doit
  rester visible par `animateTransform` seul, la seule technique prouvee sur
  l appareil ; les animations d opacite ne sont plus qu un bonus. Les salves
  passent a 6 s, dont environ 1,5 s d activite, et 2,4 s dans le selecteur.
  Le choix Automatique / Toujours / Jamais est desormais tranche en JS avant
  le rendu : en Jamais ou en mouvement reduit, aucune balise d animation n est
  meme emise.
  Verifie par comparaison de pixels sous mouvement reduit emule, 26 captures
  par effet sur 7,3 s, soit un cycle entier : les dix effets produisent
  26 images differentes. Mes deux sondes logicielles precedentes,
  `getComputedStyle` et `transform.animVal`, ne refletent pas SMIL et
  donnaient toutes deux de faux FIGE.

- Verdict du diagnostic d animation, et vrai coupable. Sur l appareil :
  61 images par seconde, donc la WebView peint parfaitement, et
  `prefers-reduced-motion` ACTIF. Les trois techniques CSS repondaient NON et
  SMIL oui, pour une seule raison : ma propre feuille coupait toutes les
  animations CSS sous mouvement reduit, et ne couvrait pas SMIL. Les effets n
  ont jamais ete casses, ils etaient desactives expres sur un telephone en
  economie de batterie. L hypothese d une WebView qui ne repeint pas etait
  fausse, le diagnostic l a tuee.
  Correctif : reglage « Animations des emblemes » dans les Reglages, trois
  etats qui tournent a chaque tape. Automatique suit le telephone, Toujours
  anime meme en economie de batterie, Jamais coupe partout. Le choix pose une
  classe sur la racine du document, et la regle de mouvement reduit ne s
  applique plus que si le joueur n a pas force. Teste sous mouvement reduit
  emule : en Automatique `animationName` vaut `none`, en Toujours `embBrz`,
  en Jamais `none`, et l eclair garde une opacite nulle quand il est coupe.

- Ecran de demarrage. Quand Android recycle la WebView, l application se
  recharge entierement, et comme le document fait 1,5 Mo dont 1,27 Mo de
  script, l utilisateur voyait du blanc plusieurs secondes. Un ecran peint
  AVANT le gros script affiche desormais le nom et une barre de progression
  pilotee a la main, retiree a la fin du boot, avec un filet de securite a
  12 s. Cela ne rend pas le chargement plus rapide, cela supprime le blanc.
  ATTENTION, la reference structurelle change : le document compte desormais
  4 balises `<script` et 3 blocs inline, contre 3 et 2 auparavant.

- Diagnostic d animation, bouton « Animations » du panneau de test, reserve a
  l administrateur. Il mesure, sans rien croire sur parole : les images par
  seconde reellement servies par la WebView, l etat de `prefers-reduced-motion`,
  et quatre techniques testees une par une en comparant une position ou une
  opacite a deux instants, animation CSS d opacite, transform CSS sur un `<g>`
  SVG, transform CSS avec `transform-box`, et SMIL `animateTransform`. Il
  donne aussi la version du moteur et dit si on tourne dans une WebView.
  Raison d etre : « une frame par clic » signale une WebView qui ne repeint
  que sur interaction, et aucune animation ne vaut d etre dessinee avant de
  savoir laquelle de ces quatre techniques fonctionne sur l appareil.

- Effets d embleme invisibles sur telephone. Deux causes mesurees.
  Primo, la taille : une particule de rayon 1 dans le carre de 64 mesure
  0,8 px quand le blason est rendu en 52 px, et un flocon faisait 1,46 px de
  diametre a l ecran. Les effets tournaient, ils etaient simplement trop
  petits pour se voir. Correctif : un facteur d echelle `_ech` passe a chaque
  effet, 2,1 et davantage encore quand le blason est petit, plus le blason du
  bandeau qui passe de 52 a 58 px. Mesure : le flocon passe de 1,46 a
  3,43 px, l apercu de l editeur de 1,46 a 4,25 px.
  Secundo, `prefers-reduced-motion`. Le mode economie de batterie d Android
  et le reglage d accessibilite « Supprimer les animations » le declenchent
  tous les deux, et la feuille coupe alors toutes les animations, ce qui est
  voulu. Verifie par emulation : en `reduce`, `animationName` vaut `none` sur
  tous les elements d effet. Ce n est pas un defaut, mais c est la premiere
  chose a verifier quand un effet ne bouge pas.

- Regression introduite par la passe de matiere, puis corrigee. Pour que le
  grain de papier reste sous le contenu, la feuille posait
  `#s-social > * { position:relative }`. Or chaque ecran porte sa propre
  barre de navigation `.bnav`, qui est un ENFANT DIRECT de l ecran et qui est
  en `position:fixed` : la regle la repassait dans le flux, et elle se
  retrouvait au milieu de l ecran, avec du vide en dessous, uniquement dans
  l onglet Social. Correctif : le grain passe en `z-index:-1`, ce qui le
  peint sous le contenu en flux sans toucher aux enfants, et la regle sur les
  enfants est supprimee. Mesure apres correctif, sur les cinq ecrans :
  `position:fixed`, bord bas a 915 pour une fenetre de 915.

- Matiere et profondeur, onglet Social. Meme palette, mais le grain du papier
  revient en fond, les cartes se detachent par une ombre portee et un filet,
  le bandeau de guilde devient un en-tete sur un ton plus soutenu, la ligne du
  joueur est creusee au lieu d etre simplement teintee, et le bouton de chat
  prend un reflet en haut et une assise en bas.

- Panneau de test deplacable et repliable. Il s etait rempli au point de
  masquer la zone observee. Poignee en haut a gauche, glissement au doigt
  comme a la souris (pointer events avec setPointerCapture), position bornee
  au viewport et retenue dans localStorage (`metanoia_pos_test`), bouton de
  repli qui ne laisse que la barre de titre (`metanoia_repli_test`).
  Boutons reorganises en grille de 3 colonnes, largeur fixee a 338 px.
  Mesure a 430 px de large : ancien 215 x 288, nouveau 338 x 170, soit 41 %
  de hauteur en moins, et 35 px une fois replie. Libelles inchanges.

- Fuseaux horaires. Pas de reglage ajoute, par choix : le greffon monotone
  borne deja tout bond de calendrier au temps reellement ecoule. Mesure : un
  saut de fuseau de +12 h sans vol donne 0 jour rejoue, le meme saut apres
  24 h de vol en donne 1, une horloge avancee de 880 jours en donne 0. Un
  voyage vers l ouest borne l ecart a 0, le jour ne recule jamais.

## Ce qui reste

- Phase 8 - depot sur le Play Store

## Cle de signature

`android/keystore/debug.keystore` est une cle de DEBOGAGE fixe, versionnee
expres : sans elle, chaque machine et chaque run GitHub en genere une au
hasard, donc une empreinte SHA-1 differente a chaque fois, et Google Sign-In
refuse la connexion. Elle ne protege rien (mot de passe « android », comme la
cle de debogage par defaut d'Android, identique chez tout le monde).

    SHA-1 : 4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97

La cle de PUBLICATION, elle, ne doit JAMAIS etre versionnee : elle ira dans
les secrets GitHub a la phase 8.
