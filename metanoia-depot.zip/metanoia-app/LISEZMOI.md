# Metanoia - projet Android (Capacitor)

## Si tu reprends ce projet, lis d abord ceci

Ce document est la memoire du projet. Il est tenu a jour apres chaque
chantier et il fait foi : ce qui n y est pas ecrit n a pas ete verifie.

### Les huit regles de Thibs, elles priment sur tout le reste

1. **L economie de jetons est centrale.** Jamais de `grep` non borne, jamais
   de vidage du fichier. Toute lecture passe par `cut -c1-N`, `head`, ou une
   plage etroite de `sed -n` / `awk`. Le fichier principal fait plus d un
   million et demi de caracteres : une lecture complete brule une session.
2. **Toujours renvoyer les fichiers modifies**, en disant lesquels ont bouge
   et lesquels n ont pas bouge. Apres CHAQUE patch, l archive
   `metanoia-depot.zip` est reconstruite et renvoyee, et ce LISEZMOI est mis
   a jour dans le meme envoi : c est lui que Thibs joint a chaque nouvelle
   discussion.
3. **Ne pas creer d autres bugs.** Verifier AVANT de livrer, jamais apres.
4. **Demander** quand c est reellement ambigu, pas pour se defausser.
5. **Francais**, ton direct et concis, commentaires de code compris.
6. **Thibs conteste les conclusions fausses, et il a raison.** Une hypothese
   se verifie avant d etre enoncee comme un fait. Se retracter explicitement
   quand on s est trompe, dans la reponse ET dans ce document.
7. **Aucun cadratin ni demi-cadratin.** Ni le caractere lui-meme, ni son
   echappement `\u2014` ou `\u2013`, ni l entite `&mdash;` ou `&ndash;`. Le
   compteur est a zero, il y reste. Y compris dans ce document, qui ne peut
   donc pas citer les caracteres interdits.
8. **Ne jamais reformuler un texte fourni par Thibs.** Corriger une faute,
   oui. Changer un mot parce qu on le prefere, non.

### La methode : verifier par execution, jamais par lecture

Obligatoire apres chaque modification de `www/index.html` :

```python
import re, os
s = open('index.html', encoding='utf-8').read()
print(len(s), len(re.findall(r'<script', s)))          # doit afficher 4
print(s.count('\u2014') + s.count('\u2013'))           # doit afficher 0
blocs = re.findall(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>', s, re.S)
print(len(blocs))                                      # doit afficher 3
from lxml import html as LH; LH.fromstring(s)          # analyse HTML
```

puis `node --check` sur chacun des trois blocs extraits.

Un `grep -c` sur une classe de caracteres contenant les deux tirets longs
donne, en locale C, des faux positifs sur les octets UTF-8 : ne pas s en
servir pour compter. Seul le comptage Python ci-dessus fait foi.

Pour verifier un COMPORTEMENT, et non la syntaxe, charger l application
reelle dans un navigateur plutot que raisonner sur le code :

```bash
cd www && python3 -m http.server 8777 &
```

puis Playwright (`/opt/npm-tools/node_modules/playwright`, Chromium en
`/opt/pw-browsers/chromium`) sur `http://127.0.0.1:8777/index.html`. On peut
poser un etat complet depuis la page : `ST.onboarded=true`, `ST.day=20`,
`ST.weekPlan=genWeek()`, puis appeler les vraies fonctions. C est ainsi qu
ont ete trouves les defauts du systeme de sanction. Quand charger toute
l application est inutile, extraire la VRAIE fonction du fichier par
equilibrage d accolades et l executer avec des doublures, jamais la
retaper.

### Les pieges deja payes

- Ecrire `</script>` a l interieur d un bloc inline genere depuis Python
  termine le bloc par surprise. Passer par un `<script src="...">` separe.
- Un ternaire multi-lignes dont les lignes `?` et `:` portent le `+` de
  concatenation est une erreur de syntaxe. Les lignes de continuation ne
  portent pas le `+`. Pris trois fois.
- `Array.indexOf(clone)` renvoie -1 : il compare des references.
- `todayStr()` produit `annee-mois-jour` avec un mois indexe a ZERO et sans
  zero de tete : `2026-9-16` pour le 16 octobre 2026. Ce n est pas de l ISO.
- Le creneau de jeu va de 8 h a minuit par defaut. Ce qui se declenche
  « a 22 h » dans de vieux commentaires se declenche en realite a la FIN du
  creneau.
- pg_cron rapporte `succeeded` pour un `select net.http_post(...)` parce que
  l appel ne fait que mettre en file. Le vrai resultat est dans
  `net._http_response`.
- Les fonctions Edge de Supabase refusent un appel sans jeton
  d autorisation AVANT d executer le corps : un en-tete maison n est jamais
  atteint.
- Un declencheur BEFORE qui `return null` annule l UPDATE en silence, et ils
  se declenchent dans l ordre alphabetique de leur nom.
- `navigator.onLine` signifie « une interface reseau est active », pas
  « internet marche ». Sous Android il ment en mode avion.
- Le bac a sable de developpement n a pas de DNS : impossible d y verifier
  un domaine ou une zone.

### Documents de reference hors depot

Thibs joint ces documents en debut de discussion. Ils sont DATES : ce qui
suit dans ce LISEZMOI les corrige quand ils divergent.

| Document | Date | Etat |
|---|---|---|
| Migration vers Capacitor | 7 octobre | phases 1 a 7 faites, phase 8 a faire |
| Compiler et configurer | 7 octobre | reference pour la compilation et la phase 5 |
| Audit de securite | 9 octobre | onze points, etat a jour dans la section du meme nom plus bas |
| Plan d acquisition 90 jours | 15 octobre | vit dans la conversation marketing ; seules ses taches app sont reprises ici |

Les chiffres de ces documents sont perimes : ils citent un `index.html` de
1,58 million de caracteres et 1 444 608 emblemes, le second est juste, le
premier ne l est plus (voir ci-dessous).

### Reperes chiffres au 18 octobre 2026

| Mesure | Valeur |
|---|---|
| `www/index.html` | 1 851 915 caracteres |
| `LISEZMOI.md` | ce fichier |
| Balises `<script>` | 4, dont 3 blocs inline |
| Cadratins | 0 |
| Archive livree | `metanoia-depot.zip`, 163 fichiers |

L archive se reconstruit toujours ainsi, et sa premiere entree DOIT etre
`metanoia-app/` :

```bash
cd /home/claude && rm -f /mnt/user-data/outputs/metanoia-depot.zip \
  && zip -rq /mnt/user-data/outputs/metanoia-depot.zip metanoia-app \
  -x 'metanoia-app/.git/*' -x 'metanoia-app/node_modules/*' \
  -x 'metanoia-app/*/node_modules/*' -x 'metanoia-app/android/.gradle/*' \
  -x 'metanoia-app/android/build/*' -x 'metanoia-app/android/app/build/*' \
  -x '*.zip'
```

Apres toute modification de `www/`, passer `npx cap copy android` avant de
zipper, sinon l archive emporte un `android/app/src/main/assets/public`
perime.

---

Phases 1 a 4 du plan de migration. Le projet se compile dans Android Studio ;
il n'a pas pu etre compile ici, faute d'Android SDK (`dl.google.com` inaccessible).

## Pour le lancer

```bash
npm install
npx cap sync android
npx cap open android      # ouvre Android Studio
```

Puis dans Android Studio : Run, ou Build > Build APK(s).

## Ce qui est fait

- **Phase 1** - socle Capacitor, `appId` `com.metanoia_app`, `appName` Metanoia.
- **Phase 2** - polices et Supabase en local. Plus aucune dependance distante
  sauf Google Sign-In (phase 5).
- **Phase 3** - service worker retire, ligne « Version de l'application »
  retiree des parametres.
- **Phase 4** - stockage natif a deux copies, avec migration automatique.
- **Phase 5** - connexion Google native via @capgo/capacitor-social-login.
  Le script GSI distant n'est plus charge qu'en web. En natif, le selecteur
  de comptes Android renvoie un idToken, passe au meme signInWithIdToken de
  Supabase qu'auparavant. REQUIERT un client OAuth Android dans la console
  Google Cloud (voir ci-dessous).
- **Icones** - phenix seul sur fond bordeaux #4D102F, 5 densites, icone
  adaptative + heritee. Le mot METANOIA est retire de l'icone du lanceur
  (il serait rogne par le masque rond) mais reste sur l'icone du store
  et sur l'ecran de lancement.

## Ou se trouve quoi

| Fichier | Role |
|---|---|
| `www/index.html` | l'application, seul fichier modifie par rapport a ta version |
| `www/fonts.css` + `www/fonts/` | les 13 fichiers de police, 239 Ko |
| `www/supabase.js` | la bibliotheque Supabase, version locale |
| `capacitor.config.json` | identifiant, nom, dossier web |
| `android/` | le projet Android genere |
| `store/icone-play-512.png` | l'icone 512x512 pour la fiche Play Store |

## Compiler sans ordinateur

Le dossier `.github/workflows/android.yml` compile l'APK sur les serveurs de
GitHub. Depose le projet sur un depot GitHub, puis onglet Actions, « APK
Android », bouton « Run workflow ». L'APK se telecharge en bas de la page du
run, et l'empreinte SHA-1 s'affiche dans le journal de l'etape du meme nom.
Tout se fait depuis un navigateur, telephone compris.

## Changer l'identifiant de l'application

`com.metanoia_app` vient du domaine metanoia-app.com : Android refuse les
tirets, la regle Java les remplace par un underscore. Il est **definitif une
fois publie** sur le Play Store, modifiable librement avant. Les cinq endroits :
`capacitor.config.json`, `android/app/build.gradle` (`namespace` et
`applicationId`), `android/app/src/main/res/values/strings.xml`, le chemin
`android/app/src/main/java/com/metanoia_app/` et la ligne `package` de
`MainActivity.java`.

## A faire dans la console Google Cloud

Sans ces deux reglages, la connexion Google echoue en natif :

1. APIs & Services > Credentials > Create credentials > OAuth client ID,
   type **Android**, nom au choix.
   - Package name : `com.metanoia_app`
   - SHA-1 : `4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97`
2. Verifier dans Supabase (Authentication > Providers > Google) que le
   provider est actif et que le Client ID **Web** y figure.

- **Phase 6** - notifications locales natives (@capacitor/local-notifications).
  Les rappels sont desormais programmes par Android et partent application
  fermee, ce que l'ancien setInterval ne faisait pas. Le Web Push, impossible
  sans service worker, est court-circuite en natif.
- **Phase 7** - greffon d'horloge monotone, ecrit sur mesure
  (`android/.../HorlogePlugin.java`, enregistre dans MainActivity).
  Il expose SystemClock.elapsedRealtime(), que l'utilisateur ne peut pas
  regler, et l'instant de demarrage du telephone. Le rattrapage des jours
  borne desormais ce qu'il rejoue par ce temps reellement ecoule.

- **Evenements** - le canal force par Prediction est devenu un vrai second
  canal, strictement equivalent au naturel : volume, points, quete bonus
  Hard Mode et clear de Frenesie, pas seulement l'XP. Avant, deux tirages sur
  six (`double_pts`, `frenzy`) n'avaient aucun effet, et un shadow force ne
  donnait pas son x2 points. Regle ajoutee : Prediction s'adapte a l'evenement
  du jour et ne peut jamais etre le meme que lui. Reelection a trois endroits,
  au tirage (on retire l'evenement calendaire de demain), au passage de jour
  dans advDay(), et en garde-fou a chaque lecture dans _evForce(), parce que
  l'etat du jour bouge encore apres advDay. Plafond d'XP d'une journee ramene
  de 4990 a 3314 pour les quetes seules.
  Donjon : la condition « 1 quete en evenement » (10 donjons sur 108, Rang C+)
  fabriquait un doubleXP d'office les jours sans evenement calendaire, meme
  quand une Prediction etait deja active : les deux se multipliaient et le jour
  passait a x6. Une Prediction active compte desormais comme un evenement, donc
  plus de fabrication, et elle valide la condition par elle-meme.

- **Audit de securite** - quatre correctifs appliques a index.html.
  1. Le panneau de developpement est reserve au compte administrateur.
     Avant : cinq tapes dans le coin haut droit l ouvraient pour n importe quel
     joueur, sur telephone, sans outil (mesure : 25 050 points en cinq clics).
     RENSEIGNE ADMIN_UID OU ADMIN_EMAIL, declares juste avant toggleTestMode() :
     laisses vides, le panneau est desactive pour tout le monde, toi compris.
     Le mode test ne se rallume plus seul au demarrage, la session n etant pas
     encore resolue a cet instant : cinq tapes une fois connecte le rouvrent.
  2. submitReview() a une garde d idempotence. Avant : un double-clic creditait
     deux fois l XP, les points, UN JOUR DE SERIE et ecrivait deux bilans.
  3. _shopAddToInventory conserve price et orig. Avant : la revente retombait
     toujours sur son repli a 100 et rendait 50 pts, donc acheter a 41 puis
     revendre creait 9 pts par cycle.
  4. _sellInvItem ne decale plus l index une seconde fois, et ne vend qu un
     exemplaire d une pile. Avant, sous bouclier : cliquer la 3e case vendait
     le 1er objet, et toute la pile partait pour le prix d un seul.

  Reste a corriger, par ordre de gravite : l import de sauvegarde n a aucune
  borne (ligne 4972), et la policy de lecture de profiles expose le state_blob
  de tous les joueurs a tous les joueurs.

- **Deconnexion** - l interface repond au doigt leve : la ligne « Se
  deconnecter » disparait avant la synchronisation cloud, qui peut prendre six
  secondes, et le message suit. Puis la progression repart a J1 en conservant
  le questionnaire, le pourquoi et la date de mise a jour du formulaire, pour
  qu un changement de compte ne force personne a tout refaire.
  Filet hors ligne : _socLogout prend un instantane « avant-deconnexion » TANT
  QUE le compte est encore connu, donc range dans l anneau de ce compte. Il
  reapparait seul dans Reglages > Sauvegardes locales a la prochaine connexion
  de CE compte, et nulle part ailleurs. La reinitialisation ne purge donc NI
  IndexedDB NI localStorage, contrairement a testReset : ce serait effacer
  l instantane qu on vient de prendre.

- **Import de sauvegarde retire.** Un fichier importe remplacait l etat entier
  du jeu, et sa validation tenait en une ligne : « day est un nombre OU
  onboarded vaut true ». Le borner ne reglait rien, parce que TOUTES les
  valeurs de reference viennent du fichier : plafonner l XP a 5000 par jour n a
  aucun sens quand le nombre de jours est ecrit par celui qui triche. L export
  reste : le RGPD, article 20, ne porte que sur la SORTIE des donnees et
  n oblige a accepter aucun import. Les fonctions rgpdImport,
  _rgpdExtraitEtat et _rgpdImportFichier sont conservees intactes : pour
  reactiver, il suffit de remettre le bloc HTML d origine.
- **Diagnostic Google B5 reserve a l administrateur.** Il n apparait que sur un
  echec de connexion, jamais sur un succes. Son contenu est ecrit pour le
  developpeur : les joueurs recoivent desormais une phrase comprehensible,
  l outil reste entier pour le compte admin.

- **Rappel de sauvegarde dans Activite.** L import retire, un joueur sans
  compte n a plus aucun moyen de transferer sa progression : on le lui dit.
  Deux mecanismes complementaires. Une entree de journal (_actCheckCompte),
  posee a partir de J3 et au plus UNE par semaine de jeu grace a la cle
  « compte-rappel-<semaine> » : c est elle qui allume la pastille et fait
  ouvrir le panneau. Et une banniere CALCULEE a l ouverture, jamais stockee,
  qui porte le bouton « Creer un compte » et disparait a la seconde ou le
  joueur se connecte. Le bouton reutilise ST._socPulse, le clignotement du
  tutoriel, applique par nav() sur l ecran Social.

- **Fuite du state_blob fermee.** profiles porte a la fois les colonnes
  publiques du classement ET state_blob, la sauvegarde personnelle complete.
  L ancienne policy ne filtrait que les LIGNES, donc un GET
  /rest/v1/profiles?select=* rendait l etat de jeu entier de tous les joueurs.
  Correctif en trois temps, fichier metanoia-fuite-state-blob.sql :
  une vue « classement » qui n expose que les colonnes publiques et ecarte les
  suspects ; une fonction metanoia_pseudo_pris qui verifie l unicite sans lire
  la table ; et profiles restreinte a sa propre ligne en lecture.
  Cote client, quatre points : le classement interroge la vue, et les trois
  controles d unicite du pseudo passent par la fonction. Les dix autres acces a
  profiles sont des ecritures, la suppression RGPD, ou la lecture de sa propre
  ligne : tous inchanges.
  LE SQL ET L APPLICATION SE DEPLOIENT ENSEMBLE : une ancienne version du
  client lirait le classement dans profiles et afficherait une liste vide.

- **Greffon d horloge : la detection etait fausse.** HORLOGE_NATIVE ne testait
  que Capacitor.Plugins.Horloge. Or Capacitor.Plugins ne porte pas forcement un
  greffon natif sans pendant JavaScript : la voie documentee est
  registerPlugin(). Resultat, HORLOGE_NATIVE valait faux sur l appareil,
  _ratMonotone renvoyait null, _ratPlafondMonotone aussi, et TOUT le garde-fou
  etait saute EN SILENCE. L heure du telephone redevenait seule maitresse du
  calendrier. Constate en vrai : heure avancee, l application a suivi jusqu au
  jour 975, et le cliquet a ensuite refuse de revenir.
  Correctif : on essaie Capacitor.Plugins.Horloge PUIS registerPlugin.
  Ajout d un ecran de diagnostic reserve a l administrateur, bouton « Horloge »
  du panneau de test : il dit si le greffon repond, ce qu il renvoie, le
  plafond calcule et l etat du cliquet. Il porte aussi « Reparer », qui relache
  le cliquet et retablit un numero de jour saisi a la main, parce que le
  cliquet interdit de reculer par construction.

- Panneau de test ouvert apres la perte de la session. L identite admin n etait
  verifiee qu a l ouverture : au clic, dans toggleTestMode et au demarrage.
  Rien ne la revalidait ensuite, donc quand le jeton Supabase expirait, panneau
  affiche, il restait visible et pleinement utilisable.
  Correctif : `_verrouPanneauTest()`, appele dans le cycle de rendu et dans
  onAuthStateChange juste apres la reaffectation de _socUser. Il ferme le
  panneau, remet _TEST_MODE a faux et persiste. Teste : admin ouvre, session
  perdue, panneau ferme, reouverture refusee, admin revient, panneau rouvert,
  et le verrou ne gene jamais l admin connecte.

- Rappel de compte affiche aux utilisateurs connectes. Supabase restaure la
  session en asynchrone : au demarrage, `_socUser` vaut null pendant une
  seconde alors que le compte existe, et le cycle de rendu tranchait pendant
  ce laps. Deux bannieres posees « a l instant » sur un compte actif.
  Correctif : drapeau `_socAuthPret`, pose par `onAuthStateChange`, par la
  resolution de `getSession` y compris en echec, et tout de suite quand il n y
  a ni SDK ni configuration. Marqueur durable `ST._socDejaConnecte` pour ne
  pas reclamer un compte a un appareil qui en a deja porte un, cas du
  demarrage hors ligne. `_actPurgeCompte()` retire les bannieres deja posees
  des que la session arrive, par la cle `k` desormais retenue sur chaque
  entree, et par le titre pour celles creees avant. Cadence inchangee : un
  rappel par semaine tant qu il n y a pas de compte.

- Confirmation de deconnexion. Le geste partait d un seul appui et remet
  l appareil au jour 1. Une demande de confirmation precede desormais tout,
  et une fois les animations finies l application quitte les reglages pour
  l ecran des Quetes, onglet actif compris.

- Emblemes de guilde. Composition en cinq couches, entierement vectorielle et
  generee a l execution : 32 symboles, 14 cadres, 18 fonds, 10 effets et
  12 palettes, soit 967 680 combinaisons. Rien n est stocke en image, une
  guilde ne retient qu un code de moins de trente caracteres de la forme
  `v1|s<symbole>|f<cadre>|b<fond>|e<effet>|c<palette>`, ecrit dans la colonne
  `emblem` deja existante. Aucune migration SQL : la policy
  `guilds_update_owner` reserve deja l ecriture au proprietaire.
  Les emblemes d avant, qui etaient des emojis, restent affiches tels quels :
  `embSVG` les reconnait et les rend sans conversion.
  A la creation d une guilde, les cinq couches sont tirees au sort. Le Maitre
  les change ensuite dans les reglages de guilde, couche par couche, chaque
  vignette montrant SON embleme avec cette seule couche modifiee. Les autres
  membres y voient l embleme en grand, sans pouvoir le toucher.
  Les effets sont de petites particules posees en couronne, jamais au centre,
  jouees seulement a partir de 40 px et coupees par
  `prefers-reduced-motion`.

- Reglages de guilde : le bouton Enregistrer passait sous le bord de l ecran,
  donc le premier reflexe devenait la croix, qui jetait tout. La boite est
  desormais une colonne, en-tete fixe, corps qui defile, pied colle avec le
  bouton toujours visible. Hauteur bornee a min(80vh, 640px) et marge basse
  calee sur env(safe-area-inset-bottom) : elle ne depasse plus de l ecran.
  La croix previent quand un embleme, une devise ou un mode de recrutement
  n est pas enregistre.

- Effets d embleme refaits : ils se ressemblaient tous, c etaient onze fois
  les memes points. Onze effets distincts par la forme, le sens et le tempo.
  En continu : Comete (une comete et sa queue font le tour), Braises (elles
  montent du bas en vacillant), Neige (des flocons tombent a des vitesses
  differentes), Runes (deux anneaux tournent en sens contraires), Bulles
  (elles montent en ondulant), Poussiere (des motes respirent sur place).
  En salve, deux secondes d activite puis cinq de silence sur un cycle de
  sept : Etincelles (des eclats a quatre branches claquent), Foudre (un
  eclair traverse avec un flash), Onde (deux ondes de choc partent du
  centre), Balayage (une lame de lumiere passe en diagonale).
  Foudre et Balayage passent PAR DESSUS le symbole, les autres dessous.
  Au repos, sans animation, l eclair et le flash sont a opacite nulle : ni
  mouvement reduit ni vieux moteur ne laissent un aplat blanc sur le blason.
  Dans le selecteur seulement, les effets en salve rejouent toutes les
  2,6 s, sinon on choisirait la Foudre sans l avoir jamais vue frapper.
  Le catalogue passe a 32 x 14 x 18 x 11 x 12 = 1 064 448 combinaisons.

- Foudre : la tension vient du clignotement, plus d un deplacement. La chute
  verticale est abandonnee. Pendant le premier quart du cycle, neuf eclats
  nerveux clignotent a des positions et des instants irreguliers, trois fois
  chacun, avec une amplitude qui monte a l approche de la frappe, pendant que
  le voile du blason respire sourdement. Puis l eclair apparait ENTIER et bat
  trois fois en moins de 0,3 s. L impact laisse une onde rasante et quatre
  eclats qui giclent. Trois couches pour la matiere, un halo large, le corps
  dans la palette et un coeur blanc plus etroit, plus deux fourches.
  Cycle de 5 s, deux frappes par cycle.
  Verifie : les 42 balises d animation ont des keyTimes valides, de meme
  longueur que leurs valeurs, partant de 0, finissant a 1 et jamais
  decroissants, un controle qui compte puisqu un keyTimes malforme est
  ignore en silence par le moteur. Puis 24 captures a 75 ms : 24 images
  differentes, precurseurs, frappe, onde, silence.

- Cadrage du symbole par cadre. Une banniere n a pas sa masse au centre du
  carre de 64 : le symbole tombait sur les encoches du bas. Chaque cadre peut
  desormais porter un decalage vertical `dy`, applique au symbole. Pose sur
  Banniere -6, Pointe -5, Blason -2,5, Ecu -2, Gothique -1,5, Creneaux +1.

- Cinq cadres de plus : Rouage, Epines, Soleil, Banniere, Pointe. Le
  catalogue passe a 32 x 19 x 18 x 11 x 12 = 1 444 608 combinaisons.

- Foudre invisible : bug a moi. La base du groupe valait
  `translate(32 32) scale(0)` et `additive="sum"` MULTIPLIE les transformations,
  donc l echelle animee etait annulee par le zero de depart et l eclair ne
  s affichait jamais. Base ramenee a `translate(32 32)` seul, eclair agrandi,
  et deux frappes par cycle au lieu d une.

- Braises redessinees : un point tres clair dans un halo chaud a deux
  couches, une montee en zigzag sur cinq points, et un vacillement sur sept
  pas d echelle au lieu d une simple apparition. Elles ne se confondent plus
  avec les Bulles.

- Changer une valeur dans l editeur relancait toutes les animations : la
  grille entiere etait reconstruite a chaque choix. Or le contenu des
  vignettes voisines ne change pas, seules la selection et l apercu bougent.
  `_embChoisir` ne touche donc plus qu a ces deux la, via `_embMajApercu` et
  `_embMajSelection`. Verifie : apres un choix, les noeuds SVG de la grille
  sont les MEMES objets qu avant, donc SMIL continue sans redemarrer.

## Audit du 10 octobre, huit defauts corriges

Audit mene par un second regard sur le code recent, chaque defaut reproduit
avant correction et reverifie apres.

1. XSS stockee par le nom de guilde. `g.name` etait concatene dans
   `innerHTML` sans `_esc` a quatre endroits : classement, recherche de
   guildes, bandeau de guilde, onglet Guilde. Une guilde nommee
   `<img src=x onerror=...>` executait du code chez tous ceux qui ouvraient
   ces vues. Un cinquieme site, le profil public, echappait correctement :
   c est l oubli qui saute aux yeux. Corrige partout, devise comprise, et
   `_esc` echappe desormais aussi les guillemets puisqu il alimente des
   attributs HTML. Verifie : 0 image injectee, le texte s affiche tel quel.

2. Un mode de recrutement abandonne finissait par partir au serveur.
   `_guildSetMode` ecrivait `_GUILD.info.recruitment` immediatement, donc la
   croix ne detectait aucune modification et un choix abandonne repartait au
   prochain enregistrement de la devise. Le choix ne vit plus que dans
   `_GUILD_MODE_DRAFT`, l affichage et l enregistrement le lisent, et il est
   consomme a l enregistrement. Verifie : etat reel intact a `ask` apres un
   choix `closed`, la croix previent, Revenir conserve, Quitter jette.

3. Le chat se figeait pour de bon si la session tombait pendant qu il etait
   ouvert. `_guildRenderMsgs` lisait `_socUser.id` sans garde, l exception
   partait dans le callback Realtime et le fil ne se redessinait plus jamais.
   Garde ajoutee, et une session perdue referme desormais le chat et coupe
   l abonnement.

4. Un seul code d embleme corrompu vidait tout le classement. Le modulo de JS
   conserve le signe, un index negatif restait negatif, et `embSVG` levait
   dans un `.map()`. Bornage par `((v%n)+n)%n`, plus un repli sur le premier
   element si le catalogue change. Verifie : `v1|s-1|f-9|...` rend sans lever.

5. Deux tapes rapides sur Reglages empilaient deux overlays aux identifiants
   dupliques : l editeur ne remplissait que le premier, la croix n en fermait
   qu un. L ancien overlay est retire avant d en creer un nouveau.

6. Choisir un mode de recrutement renvoyait le panneau tout en haut. La
   position de defilement est desormais relevee puis restauree.

7. Le curseur sautait en fin de champ a chaque frappe dans la recherche de
   guildes, ce qui rendait impossible la correction d un mot au milieu. La
   position est retenue a la frappe et restauree apres le re-rendu. Les DEUX
   branches sont couvertes, celle avec resultats et celle sans, cette
   derniere etant un doublon que le premier correctif avait manque.

8. `_embAppliquerMode` etait du code mort depuis le passage en SMIL : il
   posait des classes qu aucune regle CSS ne ciblait. Le reglage « Jamais »
   n eteignait donc que ce qui etait redessine ensuite. Chaque svg porte
   maintenant son code dans `data-emb`, et le changement de mode les
   redessine tous sur place. Verifie : 20 balises d animation, 0 apres
   Jamais, 20 au retour.

## Passe du 11 octobre

- Fond du bloc Correlation aligne sur celui de la Time Capsule,
  `linear-gradient(135deg,var(--gold-bg),#F8F0E2)`, et bordure adoucie. Le
  vert des jauges et les flammes ressortent nettement mieux dessus.

- Ecran blanc a la reprise de l application, cause trouvee cote ANDROID et
  non cote web. Le theme `AppTheme.NoActionBar` portait
  `android:background = @null` et aucun `windowBackground` : entre la reprise
  de l activite et le premier rendu de la WebView, Android peignait donc du
  blanc. Trois reglages : `android:windowBackground` et
  `android:colorBackground` sur le theme, pointant une couleur
  `metanoiaFond` = #F8F4EE ajoutee dans `colors.xml`, et `backgroundColor`
  dans `capacitor.config.json` pour que la WebView elle-meme parte en beige.
  Le rechargement reste aussi long, mais il ne se voit plus.

- Quatre cosmetiques redessines dans la facture des autres items de la
  boutique, apres les avoir tous rendus cote a cote pour comparer :
  Aura de l Ombre, Bordure Doree, Aura de Feu, Sceau du Monarque. Boite de
  100, fond arrondi, ombre portee au sol, facettes en aplats franches, un
  eclat clair pour le volume, des particules pour la vie. Les quatorze
  autres ne sont pas touches, ils tenaient deja.
  Le croissant de l Aura de l Ombre est obtenu par soustraction de deux
  disques : les arcs de la premiere version debordaient de la sphere et se
  lisaient comme un anneau exterieur.

- Emojis des onglets du classement remplaces par quatre illustrations
  maison, en COULEUR : globe bleu et vert, lames acier a poignees dorees,
  coupe en or a trois tons, flamme a quatre tons. Aplats francs, deux a
  quatre tons par icone, aucun degrade, 15 px.
  Les couleurs sont fixes et ne suivent pas l etat de l onglet : chaque
  icone porte au moins un ton clair, donc le contraste tient aussi bien sur
  la pastille sombre que sur le fond clair.
  Trois partis pris avaient ete rendus cote a cote avant de trancher :
  monochrome en `currentColor`, couleur pleine, et pastille coloree. La
  version monochrome passait par des DECOUPES en masque plutot que des
  accents peints en blanc, parce qu un accent blanc disparait des que le
  fond est clair. Elle n est pas retenue, mais la lecon vaut pour toute
  icone bicolore posee sur deux fonds.

### Incident de fabrication, et ce que j en retiens

En posant ces icones j ai utilise une expression reguliere globale de la
forme `<svg ...>.*?</svg> Libelle</button>`. Appliquee en chaine, chaque
icone fraichement inseree devenait le point de depart du match suivant, qui
avalait alors la fin du bouton precedent : les quatre boutons ont fusionne en
un seul et 2 000 caracteres ont disparu. Restaure depuis la derniere archive
livree, puis rejoue par un remplacement LIGNE PAR LIGNE, borne a la ligne du
bouton vise. A retenir : sur ce fichier, ne jamais faire porter un `.*?` sur
plusieurs lignes quand on remplace en boucle.

## Correlation Energie x Reussite, deuxieme passe

- Bloc reduit d un tiers : 195 px de haut avant, 129 apres, soit 34 % de
  moins. Piste de 78 a 37 px, icone de 32 a 27, valeur de 17 a 15, marges et
  rembourrages resserres partout. La graduation tous les 25 % est conservee,
  c est elle qui permet de distinguer 93 de 98.

- Illustrations redessinees. Les precedentes etaient des traits de 2 px a 20
  ou 32 % d opacite : fines et pales, c est exactement le reproche. Les trois
  nouvelles sont des masses pleines, et forment une progression lisible d un
  seul regard. La braise : une masse basse et trapue qui ne monte plus, une
  seule volute de fumee large, un coeur a peine tiede. La flamme : droite et
  franche, avec un coeur clair et un point blanc au centre. Le brasier : deux
  langues laterales pour la masse, un coeur tres clair, et six eclats qui
  giclent autour. Une seule volute sur la braise et non deux, car a 27 px
  deux traits proches se confondaient en un crochet illisible.

- L etoile des libelles passe a l or de l application, `var(--gold)`, en
  enveloppant le caractere dans un `span` au rendu. Le libelle lui-meme n est
  pas touche.

## La croix des reglages de guilde ne faisait rien

Symptome : on modifie quelque chose, on tape la croix, rien ne se passe ; on
tape ensuite Enregistrer et c est la demande « Quitter sans enregistrer ? »
qui surgit, au mauvais moment.

Cause : `#sl-confirm-overlay` etait a `z-index:9999`, exactement comme
`guild-set-overlay`. A z-index egal, c est l ordre du DOM qui tranche, et le
panneau de reglages est ajoute a la fin du body : il passait donc DEVANT la
confirmation. La croix ouvrait bien le dialogue, mais derriere le panneau,
invisible et injoignable. Il ne reapparaissait qu une fois le panneau retire
par l enregistrement. La confirmation passe a `z-index:99990`, au-dessus de
tous les panneaux de l application.

Au passage, `slConfirm` n avait qu un seul resolveur : ouvrir un dialogue par
dessus un autre laissait le premier en suspens pour toujours, et son
appelant restait bloque. Le precedent recoit desormais `false` avant d etre
remplace.

Verifie : `elementFromPoint` au centre de l ecran renvoie `sl-confirm-box`,
z 99990 contre 9999, le titre est le bon, Quitter referme les deux, et deux
dialogues coup sur coup se resolvent tous les deux au lieu d en bloquer un.
Parcours complet verifie aussi : embleme, mode et devise modifies puis
enregistres partent bien en un `guild_settings` et un `update guilds`, les
brouillons sont consommes, et la reouverture ne declenche plus aucun
avertissement residuel.

## Retouches visuelles du 10 octobre

- Bulle du chat, la sienne : eclaircie de `#d07e45 / #ad5a28` vers
  `#e2995f / #c2743c`, avec une ombre portee sur le texte pour garder la
  lisibilite du blanc sur ce ton plus clair.

- Correlation Energie x Reussite. La piste faisait 54 px de haut sur toute la
  largeur de la colonne : trois dalles, dont une vide qui se lisait comme une
  barre. Elle est desormais etroite, 46 px au plus, haute de 78 px, creusee
  plus franchement et graduee tous les 25 %, si bien qu une piste vide se lit
  comme vide et qu on distingue 93 de 98. La jauge a du volume par un
  degrade de lumiere, la carte prend le grain de papier et l ombre portee du
  reste de l application. Aucune modification du JS, les fonctionnalites et
  le barème de couleur sont intacts.

- Trois listes gardaient encore l animation coupee : l onglet Guilde du
  classement (`_socLoadGuildRanking`), les cartes de la recherche de guildes
  (`_guildBrowseCard`) et l overlay Classement des guildes
  (`_guildShowRanking`). Elles passaient `false` en troisieme argument, un
  reste de l epoque ou les animations coutaient une keyframe CSS par
  particule. Plus aucun appel ne coupe l animation. Verifie : a 22, 26, 28,
  30, 34, 38, 54 et 58 px, 42 balises d animation emises, et 0 en dessous du
  seuil de 20 px.

- Emblemes animes dans le classement Guilde : ils y etaient rendus en 15 px
  avec l animation coupee. Passes a 22 px et animes, et le seuil d animation
  descend de 36 a 20 px.

- Chat de guilde. Treize fois « Thibs a accompli une quete » noyaient les
  vrais messages : les evenements identiques qui se suivent sont desormais
  replies en une seule ligne portant un compteur. Mesure sur un jeu de
  19 messages : 6 lignes affichees, compteurs x13 et x2.
  Matiere et contraste : grain de papier sur la feuille, en-tete sur un
  bandeau soutenu avec l embleme en 34 px anime, evenements reduits a des
  pastilles discretes, bulles detachees par une ombre portee et un filet, la
  sienne en degrade avec reflet et assise, barre de saisie avec champ creuse
  et bouton d envoi en relief. Les messages reposent sur la barre de saisie
  grace a un `margin-top:auto` sur le premier, et non a
  `justify-content:flex-end` qui casse le defilement vers le haut.

- Effets passes en SMIL, et correction de ma lecture precedente du
  diagnostic. J avais conclu que ma regle de mouvement reduit coupait tout :
  c etait faux. Les elements testes par le diagnostic ne portent AUCUNE de
  mes classes, donc cette regle ne les touchait pas, et les trois techniques
  CSS repondaient NON quand meme. La vraie cause : Android met l echelle de
  duree des animations a zero en economie de batterie, et Chromium annule
  alors toutes les animations CSS du document. SMIL est un moteur separe, il
  continue de tourner, ce que le diagnostic montrait deja.
  Les onze effets sont donc reecrits en SMIL, sans une seule keyframe, et
  `embStyles()` n injecte plus rien. Contrainte posee : chaque effet doit
  rester visible par `animateTransform` seul, la seule technique prouvee sur
  l appareil ; les animations d opacite ne sont plus qu un bonus. Les salves
  passent a 6 s, dont environ 1,5 s d activite, et 2,4 s dans le selecteur.
  Le choix Automatique / Toujours / Jamais est desormais tranche en JS avant
  le rendu : en Jamais ou en mouvement reduit, aucune balise d animation n est
  meme emise.
  Verifie par comparaison de pixels sous mouvement reduit emule, 26 captures
  par effet sur 7,3 s, soit un cycle entier : les dix effets produisent
  26 images differentes. Mes deux sondes logicielles precedentes,
  `getComputedStyle` et `transform.animVal`, ne refletent pas SMIL et
  donnaient toutes deux de faux FIGE.

- Verdict du diagnostic d animation, et vrai coupable. Sur l appareil :
  61 images par seconde, donc la WebView peint parfaitement, et
  `prefers-reduced-motion` ACTIF. Les trois techniques CSS repondaient NON et
  SMIL oui, pour une seule raison : ma propre feuille coupait toutes les
  animations CSS sous mouvement reduit, et ne couvrait pas SMIL. Les effets n
  ont jamais ete casses, ils etaient desactives expres sur un telephone en
  economie de batterie. L hypothese d une WebView qui ne repeint pas etait
  fausse, le diagnostic l a tuee.
  Correctif : reglage « Animations des emblemes » dans les Reglages, trois
  etats qui tournent a chaque tape. Automatique suit le telephone, Toujours
  anime meme en economie de batterie, Jamais coupe partout. Le choix pose une
  classe sur la racine du document, et la regle de mouvement reduit ne s
  applique plus que si le joueur n a pas force. Teste sous mouvement reduit
  emule : en Automatique `animationName` vaut `none`, en Toujours `embBrz`,
  en Jamais `none`, et l eclair garde une opacite nulle quand il est coupe.

- Ecran de demarrage. Quand Android recycle la WebView, l application se
  recharge entierement, et comme le document fait 1,5 Mo dont 1,27 Mo de
  script, l utilisateur voyait du blanc plusieurs secondes. Un ecran peint
  AVANT le gros script affiche desormais le nom et une barre de progression
  pilotee a la main, retiree a la fin du boot, avec un filet de securite a
  12 s. Cela ne rend pas le chargement plus rapide, cela supprime le blanc.
  ATTENTION, la reference structurelle change : le document compte desormais
  4 balises `<script` et 3 blocs inline, contre 3 et 2 auparavant.

- Diagnostic d animation, bouton « Animations » du panneau de test, reserve a
  l administrateur. Il mesure, sans rien croire sur parole : les images par
  seconde reellement servies par la WebView, l etat de `prefers-reduced-motion`,
  et quatre techniques testees une par une en comparant une position ou une
  opacite a deux instants, animation CSS d opacite, transform CSS sur un `<g>`
  SVG, transform CSS avec `transform-box`, et SMIL `animateTransform`. Il
  donne aussi la version du moteur et dit si on tourne dans une WebView.
  Raison d etre : « une frame par clic » signale une WebView qui ne repeint
  que sur interaction, et aucune animation ne vaut d etre dessinee avant de
  savoir laquelle de ces quatre techniques fonctionne sur l appareil.

- Effets d embleme invisibles sur telephone. Deux causes mesurees.
  Primo, la taille : une particule de rayon 1 dans le carre de 64 mesure
  0,8 px quand le blason est rendu en 52 px, et un flocon faisait 1,46 px de
  diametre a l ecran. Les effets tournaient, ils etaient simplement trop
  petits pour se voir. Correctif : un facteur d echelle `_ech` passe a chaque
  effet, 2,1 et davantage encore quand le blason est petit, plus le blason du
  bandeau qui passe de 52 a 58 px. Mesure : le flocon passe de 1,46 a
  3,43 px, l apercu de l editeur de 1,46 a 4,25 px.
  Secundo, `prefers-reduced-motion`. Le mode economie de batterie d Android
  et le reglage d accessibilite « Supprimer les animations » le declenchent
  tous les deux, et la feuille coupe alors toutes les animations, ce qui est
  voulu. Verifie par emulation : en `reduce`, `animationName` vaut `none` sur
  tous les elements d effet. Ce n est pas un defaut, mais c est la premiere
  chose a verifier quand un effet ne bouge pas.

- Regression introduite par la passe de matiere, puis corrigee. Pour que le
  grain de papier reste sous le contenu, la feuille posait
  `#s-social > * { position:relative }`. Or chaque ecran porte sa propre
  barre de navigation `.bnav`, qui est un ENFANT DIRECT de l ecran et qui est
  en `position:fixed` : la regle la repassait dans le flux, et elle se
  retrouvait au milieu de l ecran, avec du vide en dessous, uniquement dans
  l onglet Social. Correctif : le grain passe en `z-index:-1`, ce qui le
  peint sous le contenu en flux sans toucher aux enfants, et la regle sur les
  enfants est supprimee. Mesure apres correctif, sur les cinq ecrans :
  `position:fixed`, bord bas a 915 pour une fenetre de 915.

- Matiere et profondeur, onglet Social. Meme palette, mais le grain du papier
  revient en fond, les cartes se detachent par une ombre portee et un filet,
  le bandeau de guilde devient un en-tete sur un ton plus soutenu, la ligne du
  joueur est creusee au lieu d etre simplement teintee, et le bouton de chat
  prend un reflet en haut et une assise en bas.

- Panneau de test deplacable et repliable. Il s etait rempli au point de
  masquer la zone observee. Poignee en haut a gauche, glissement au doigt
  comme a la souris (pointer events avec setPointerCapture), position bornee
  au viewport et retenue dans localStorage (`metanoia_pos_test`), bouton de
  repli qui ne laisse que la barre de titre (`metanoia_repli_test`).
  Boutons reorganises en grille de 3 colonnes, largeur fixee a 338 px.
  Mesure a 430 px de large : ancien 215 x 288, nouveau 338 x 170, soit 41 %
  de hauteur en moins, et 35 px une fois replie. Libelles inchanges.

- Fuseaux horaires. Pas de reglage ajoute, par choix : le greffon monotone
  borne deja tout bond de calendrier au temps reellement ecoule. Mesure : un
  saut de fuseau de +12 h sans vol donne 0 jour rejoue, le meme saut apres
  24 h de vol en donne 1, une horloge avancee de 880 jours en donne 0. Un
  voyage vers l ouest borne l ecart a 0, le jour ne recule jamais.

- Historique des bilans. L affichage demarre a 12 entrees, un bouton « Voir
  plus » en ajoute 30 a chaque appui et disparait quand tout est affiche.
  Compteur `_BILAN_VUS`, pose du bouton par `_stBilanPlus(total)` juste apres
  le rendu. Verifie dans Chromium sur la fonction extraite du fichier, avec
  57 entrees : 12, puis 42, puis 57, bouton retire, jamais duplique. Cas
  limites passes : liste vide (message « Aucun bilan encore. » intact, pas de
  bouton), pile 12 (pas de bouton), 13 (« 1 restant », singulier).

- Cartes Cosmetique. Le violet nuit est remplace par l ambre profond,
  bordure doree double : filet exterieur `2px solid #F6D98A` et lisere
  interieur `inset 0 0 0 1px rgba(255,241,201,.5)`. Fond
  `linear-gradient(155deg,#A8560F,#D9931F)`. Touche les cartes quotidiennes
  (`.dfront.dcosmetic`, `.ddesc.dcosmetic`, `.dback-cosmetic`, coins dores)
  et, pour rester accordee, la grille `.rc.cosmetic` avec son badge et son
  bouton. Encres passees en creme : nom #FFFDF6, libelles #FFE7B0, prix
  #FFF1C9, halo d icone en rgba(255,214,130,.65). Rendu verifie dans Chromium
  sur les regles extraites du fichier, pour les trois faces et pour la grille.
  Piege rencontre : `.ddesc-icon` n heritait d aucune couleur et restait
  sombre sur l ambre, une regle dediee a ete ajoutee.

- Cartes du jour desynchronisees. Symptome : on retourne une carte, elle
  montre un objet, on la retourne encore et c est un autre objet. Cause
  mesuree : le DOM de la grille datait d un jour boutique anterieur. Le flip
  dos vers face avant ne lit rien, il se contente de tourner la carte deja
  presente, mais le flip suivant rappelle `_getDailyPicked()`, qui renvoie le
  tirage du jour courant. Le jour peut avancer sans passer par
  `renderRewards()` : `_testSetJour` (ligne 9012) ne rappelle que
  `renderMain()`, et en mode reel la bascule de 14h change `_shopDayNum()`
  alors que l ecran est deja ouvert. Correctif : la grille porte
  `data-jour`, et `_dailyGrillePerimee()` la reconstruit avant tout
  retournement et avant tout achat. Verifie dans Chromium sur la fonction
  extraite du fichier : meme jour elle laisse passer sans rien faire, jour
  avance elle reconstruit, remarque la grille, previent par un toast et
  annule le retournement, l appel suivant laisse passer, une grille non
  marquee est reconstruite sans toast, une grille absente ne leve rien.

- Reste ouvert, non corrige : `_getDailyPickedRaw` clone l item
  `mystery_fragment` pour y inscrire le nom du fragment, donc
  `_DAILY_POOL.indexOf(clone)` vaut -1 et `ST._shopDailyPickIdx` devient
  irrecuperable. Au redemarrage, le tirage du jour est donc recalcule au lieu
  d etre restaure. Le seed est deterministe, mais `filteredPool` depend de
  `_itemPurchasable`, qui depend des fragments et des titres restants : si
  l un d eux est acquis dans la journee, le pool retrecit et les quatre
  offres changent. Correctif propose : memoriser l index de l item source et
  l id du fragment, puis rederiver le clone a la restauration.

## Audit de l ecran Stats

Cinq defauts corrige, tous verifies par execution.

- `sr7` efface a chaque jour d absence. Ligne 8771, le rattrapage des jours
  manques faisait `if(ST.sr7.length>7) ST.sr7=ST.sr7.slice(-7)`, reste d une
  epoque ou sr7 ne gardait qu une semaine. Les autres points d ecriture (8395,
  8666, 14060) ne tronquent pas. Mesure : 45 jours de suivi, une seule journee
  manquee, sr7 tombe de 45 a 7 valeurs, et le « Taux 30j » de l ecran Stats
  devient un taux sur 7 jours. Borne portee a 400, comme dayLog.

- Gain XP hebdomadaire sous-estime. `_gainXp` prenait `w2[0].xp` comme
  origine, donc le gain du premier jour de la fenetre disparaissait. Mesure :
  sept jours a +30 XP affichaient 180 au lieu de 210, soit un septieme en
  moins. L origine est desormais le dernier releve anterieur a la fenetre, et
  les bornes sont reperees par numero de jour et non par position, le reste du
  bloc supposant dayLog trie. Sept cas verifies, dont un dayLog desordonne,
  un debut d historique, une semaine a trous et un releve sans champ xp.

- Heatmap desalignee des jours de semaine. Les cellules etaient empilees par
  paquets de sept depuis le premier jour affiche (`dow=i%7`), donc les
  libelles L M M J V S D a gauche ne disaient vrai que si J1 tombait un lundi,
  soit un utilisateur sur sept. Mesure : un J1 un jeudi se retrouvait sur la
  ligne « L ». La grille s ancre maintenant sur le premier releve portant un
  `dow`, et les vieilles sauvegardes sans ce champ gardent l ancien calage.
  Verifie sur 365 jours : zero cellule mal placee.

- Etiquette de la sparkline 30j. Elle annoncait toujours J(jour-29) alors que
  la courbe porte `last30.length` points. Elle suit maintenant le nombre reel
  de points, six cas verifies.

- Etiquette de la sparkline XP. « Jour 1 » etait ecrit en dur dans le HTML
  alors que dayLog est borne a 400 entrees. Elle affiche desormais le premier
  jour reellement trace.

Signale, non corrige :

- `d.absent` est lu a six endroits (9500, 9505, 9541, 14844, 14845, 15009)
  mais n est jamais ecrit dans dayLog : la notion de journee d absence n est
  branchee nulle part, tous ces filtres sont donc sans effet.
- Zones de flow : le commentaire annonce « au moins 5 jours de donnees », le
  code teste `>=3`. Le code est le bon, le commentaire trompe le lecteur.
- Fluidite : `renderStats()` reinjecte 48 Ko de SVG pour la heatmap, mesure a
  5,5 ms sur Chromium de bureau, donc de l ordre de 25 ms en WebView. C est
  differe par `requestIdleCallback`, donc invisible a l ouverture, mais
  recalcule a chaque appui sur « Voir plus ». Non corrige : le gain ne
  justifiait pas le risque d un cache.

Hypotheses verifiees puis ecartees, pour ne pas les reprendre :

- Changement d onglet et position de defilement : teste dans Chromium avec
  des panes de hauteurs tres differentes, le defilement retombe a 0 de
  lui-meme. Pas de defaut.
- Double attribut `style` sur une cellule de heatmap : les deux conditions
  (`isToday` et cellule cliquable) sont mutuellement exclusives.
- Correlation energie et bilans de sanction : la condition d entree ne filtre
  pas `isSanction`, mais les bilans de sanction ne portent aucun champ
  `energy`, donc ils sont deja exclus.

## Audit de l ecran Social

Trois defauts corriges, tous verifies par execution.

- XSS stockee par le pseudo, chez le Maitre de guilde. La liste des membres
  transportait le pseudo dans l attribut `onclick` des boutons Promouvoir et
  Exclure, echappe pour la seule apostrophe : un pseudo contenant un guillemet
  double refermait l attribut. `_guildPromote` et `_guildKick` le passaient
  ensuite a `slConfirm`, qui l insere en HTML brut. La validation du pseudo
  est purement cliente (meme regle a l inscription et au changement), et la
  table `profiles` s ecrit en upsert direct : rien n empeche un membre de
  poser un pseudo piege. Mesure avant correction : deux attributs parasites
  injectes et du code execute au simple survol du bouton. Le pseudo est
  desormais relu dans le roster par `_guildPseudoDe(uid)` et echappe par
  `_esc` au seul endroit qui part en HTML. Apres correction : zero attribut
  parasite, zero balise creee, rien d execute.

- XP de saison mesuree sur la mauvaise periode. `_socCalcSeasonXp` renvoyait
  `_socXpGainedLastDays(14)`, une fenetre glissante de quatorze jours DE JEU,
  alors que la saison est une periode calendaire de quatorze jours. Le premier
  jour d une saison, cette fenetre portait encore treize jours de la
  precedente. Mesure : un joueur a +100 XP par jour declarait 1400 XP de
  saison le jour ou il n en avait gagne que 100, et un joueur de trois jours
  declarait tout son cumul. Le classement de saison etait donc decide par l
  activite d avant la saison. On ancre maintenant le total d XP au premier
  contact avec une nouvelle saison (`ST._socSeasonAncre`) et on compte l
  ecart. Neuf cas verifies, dont le changement de saison, la restauration d
  une sauvegarde plus ancienne (pas de gain negatif) et l idempotence (trois
  appels de suite, aucune sauvegarde superflue).

- Icone d evenement de guilde injectee en HTML brut. Dans `_guildRenderMsgs`,
  `m.body` etait echappe mais `m.icon`, pose par un client via le RPC
  `guild_event` et stocke dans le meme enregistrement, ne l etait pas.

Signale, non corrige :

- Les recompenses hebdomadaires ne sont jamais distribuees. `_SOC_TABS` vaut
  `['global','guild','season','streak']` : il n y a pas d onglet `weekly`,
  donc `_socRecordBestRank('weekly', ...)` n est jamais appele, aucune cle
  `w:` ne peut exister, et le bareme `_SOC_WEEKLY_PRIZES` (500 pts et une Cle
  du Neant pour le premier) est du code mort. A trancher : supprimer le
  bareme, ou reintroduire l onglet.
- La recompense de saison depend de la consultation. `ST._socRanks` n est
  alimente que par `_socLoadLeaderboard`, lui-meme appele seulement quand on
  clique sur un onglet, et l onglet par defaut est `global` a chaque
  ouverture. Un joueur premier de sa saison qui n ouvre jamais l onglet
  Saison ne touche rien. De plus c est le MEILLEUR rang vu lors d une
  consultation qui est retenu, pas le rang final. Correctif propose : charger
  le classement saison en arriere-plan a l ouverture de l ecran Social, et
  retenir le dernier rang plutot que le meilleur.
- Au-dela de la cinquantieme place, `myRank` reste a 0 : le joueur ne voit
  pas du tout sa position, la requete etant limitee a 50 lignes.
- Les guildes de demonstration sont concatenees au vrai classement et
  faussent les rangs. Deja marque `[DEMO]` dans le code, a retirer avant le
  Play Store.

## Audit de l ecran Identite

Trois defauts corriges, tous verifies par execution.

- Barre du prochain trait, fausse de bout en bout. Elle comparait le nombre
  TOTAL de fragments possedes a un denominateur `_nextTrait.fragNeeded||5`,
  or `fragNeeded` n existe sur aucun des dix traits et chacun demande trois
  fragments precis. Mesure : un joueur a vingt fragments dont aucun du trait
  vise lisait 5/5, barre pleine, pour une progression reelle de 0/3. On
  compte desormais les fragments DE CE TRAIT sur le nombre qu il demande.
  Sept cas verifies, dont le cas « plus aucun trait » (pas de division par
  zero).

- Total des fragments fige a 40 dans le calcul comme dans l affichage, alors
  qu un commentaire du code prevoit explicitement l ajout de fragments par
  mise a jour. Remplace par `FRAGMENTS.length`.

- Titre temporaire expire : le joueur etait desequipe meme s il avait gagne
  ce titre pour de bon entre-temps. Acheter un titre epique temporaire puis
  le debloquer legitimement le faisait disparaitre de la tete du joueur au
  bout de sept jours. La recherche ignorait aussi `NEW_TITLES_COMMON`, que le
  mode test peut accorder en temporaire. Six cas verifies.

- Titre « Aspirant » accorde trop tot. Il porte `traits:[]`, et
  `[].every()` vaut true : il tombait donc des le premier `checkFragments()`,
  soit des J1, alors qu il doit arriver a J2 avec le deblocage de l ecran
  Identite. Le marqueur `_starterTitle` etait declare mais lu nulle part. La
  boucle des titres communs teste maintenant `_isUnlocked('tab_identity')`,
  la meme condition que l onglet, pour que les deux ne divergent jamais.
  Verifie : rien a J1, accorde et annonce a J2, et un joueur qui le possede
  deja n est pas renotifie.

Signale, non corrige :

- `_buildTraitCard` divise par `tr.frags.length` sans garde. Aucun trait n a
  de liste vide aujourd hui, mais rien ne l empeche.

Verifie puis ecarte :

- Integrite des donnees : aucun id en double parmi les 40 fragments, 10
  traits et 36 titres, aucun nom de titre en double, aucune reference croisee
  cassee, tous les fragments ont une fonction `check`, et aucun id n est
  partage entre l espace des traits et celui des titres (les titres
  legendaires acceptant les deux).
- `RANKS` est strictement croissant, et la couleur du « Rang Planetaire I »,
  absente de la table, est bien rattrapee par le repli sur expression
  reguliere.
- Le rang A : j avais signale a tort qu il n existait pas. L echelle d XP du
  joueur va bien de B a S, mais le rang A est un TIER DE DONJON
  (`_DUNGEON_ORDER`, index 4), obtenable depuis #Quetes par l offset de
  `_rollDungeonChoices` (12 % au rang n+1, 3 % au n+2). Rien a corriger.
- Les dix fragments que ne reference aucun trait sont voulus.
- `_checkedTitles` est amorce au demarrage, aucun titre deja obtenu n est
  reannonce apres un rechargement.

## Audit de la Boutique

Quatre defauts corriges, tous verifies par execution.

- Duplication de boucliers. Deux lignes d une autre branche s etaient glissees
  dans `shield_1/3/5` : un dialogue « Tu t autorises... Reclamer cette
  recompense », pose APRES l activation. L annuler sortait par `return` avant
  le bloc de consommation. Mesure : bouclier 3j actif, quantite toujours a 1.
  Repetable a chaque expiration, donc bouclier gratuit a vie. Lignes retirees.

- Tout se revendait 50 pts. `_shopAddToInventory` stocke `price` et `orig`
  depuis un correctif precedent, mais AUCUN des quatorze appelants ne les
  transmet : ils valaient donc toujours 0 et `_sellInvItem` retombait sur son
  repli a 100. Le commentaire du code annoncait ce bug comme corrige, il ne l
  etait pas. On retrouve desormais les prix dans `_DAILY_POOL` par `effect`,
  ce qui couvre aussi les objets gagnes en donjon, en boite ou en recompense.
  Mesure apres correction : Elixir 30 pts au lieu de 50 (fin de l exploit),
  Reset Integrite 348 au lieu de 50 (fin de la spoliation). Balayage des 14
  objets au prix d achat le plus bas possible : zero revente rentable.

- `_shopUseItem` et `_sellInvItem` supprimaient par l index capture AVANT le
  `await` de confirmation. Si l inventaire avait bouge pendant la modale, c
  est un autre objet qui partait. On retire par la reference, avec garde sur
  -1, `splice(-1,1)` retirant sinon le dernier element.

Signale, non corrige :

- Les remises du marchand sont CONSTANTES. `_shopItemPrice` calcule
  `seed=(ST.day*137+i*31+idx*17)&0x7fffffff` puis `seed/0x7fffffff`, sans
  jamais melanger : pour des jours realistes le quotient vaut ~0,00001, donc
  `Math.round(rng*20)` vaut toujours 0. Mesure sur 2000 jours, 6 positions et
  4 marchands : la remise marchand vaut toujours exactement 10 % et la faveur
  toujours exactement 20 %, contre les 10 a 30 % et 20 a 35 % annonces par le
  code. Il faudrait atteindre le jour 391 877 pour voir le premier cran. Le
  reste du fichier utilise pourtant un vrai generateur
  (`seed*1103515245+12345`) dans `_getDailyPickedRaw`.
  ATTENTION : corriger ce melange seul ROUVRE l achat-revente rentable.
  Mesure avec le generateur corrige : 6,8 % des combinaisons deviennent
  profitables, jusqu a +32 pts par cycle sur le Reset Integrite, parce que le
  prix plancher tombe a 45,5 % du prix d origine alors que la revente est a
  50 %. Les deux corrections vont donc ensemble : melanger le seed ET
  plafonner la revente au prix reellement paye (ou la ramener a 40 %).

- `price` et `discount` des 30 objets du catalogue ne sont lus nulle part :
  tout le code passe par `item.orig||item.price`, donc `orig` gagne toujours.
  Les `-25%` inscrits dans les donnees sont decoratifs.

- `activate_shield` est le seul effet absent de `_DAILY_POOL` : les boucliers
  gardent donc le repli de revente a 50 pts.

## Remises du marchand, nouvelles bornes

Remise marchand ramenee a 5-10 %, faveur a 10-20 %, et le seed est desormais
melange par le generateur deja utilise dans `_getDailyPickedRaw`. Verifie sur
400 jours, 6 positions, 4 marchands et 10 prix : les six valeurs de remise
marchand et les onze de faveur sont toutes parcourues. Le prix plancher vaut
0,90 x 0,80 = 72 % du prix d origine, contre une revente a 50 %, donc zero
combinaison rentable a l achat-revente sur 96 000 testees.

## Audit de l ecran Quetes

Trois defauts corriges, tous verifies par execution.

- Un echec de quete principale comptait DOUBLE pour les donjons. Dans `trig`,
  `if(q2.type==='disc')ST.weeklyBoss.discFail=...;_dngFail();` : le `if` sans
  accolades ne couvrait que l incrementation de `discFail`, donc `_dngFail()`
  tombait pour toute quete principale echouee, en plus de l appel place en
  tete de la branche. Mesure : trois echecs reels donnaient un compteur a 6,
  et un donjon « max 3 fail » etait perdu alors que le plafond etait respecte.
  Les echecs de quetes secondaires, eux, comptaient juste.

- XP et points farmables a l infini. La garde de `trig` bloquait perfect vers
  clear, mais laissait passer perfect vers fail, puis fail vers perfect : le
  cycle creditait a chaque tour sans jamais reprendre. Mesure : dix cycles sur
  une seule quete donnaient 180 XP, et avant le jour 15, ou l echec ne coute
  ni points ni integrite, les points montaient aussi, 220 contre 100 au
  depart. Apres le jour 14 l XP restait farmable, seuls les points devenaient
  perdants. Une quete validee ne peut plus etre repassee en echec ; corriger
  un clic malheureux reste possible dans l autre sens. Matrice des six etats
  verifiee.

- Taux du Top/Flop au-dessus de 100 %. `questLog[].gen` est incremente par
  `advDay` en FIN de journee, `ok` par `trig` PENDANT la journee : un joueur
  parfait avait donc toujours ok = gen+1. Mesure : 200 %, 150 %, 133 %,
  125 %... le premier taux reellement affiche etant 150 % au jour 3. Le
  denominateur est borne par `Math.max(gen, ok)`.

Signale, non corrige :

- Asymetrie de la penalite d echec. Dans `trig`, echouer une quete principale
  apres le jour 14 coute 5 points d integrite ET 15 points. Dans `advDay`, l
  auto-echec d une quete laissee sans reponse ne coute que l integrite. Ne
  rien faire est donc moins punitif que de marquer honnetement son echec. A
  trancher : aligner `advDay` sur `trig`, ou retirer les 15 points de `trig`.

## Arbitrages tranches et bugs du 11 octobre

- Penalite d echec unifiee. Rater une quete obligatoire coute 5 points d
  integrite, et plus aucun point, quel que soit le chemin. Il y en avait
  TROIS, pas deux : `trig` (declare), `advDay` (bascule du jour) et
  `submitReview` (quetes non traitees au bilan). Les deux premiers retiraient
  15 points, le troisieme aussi et sans la franchise des quatorze premiers
  jours. Les trois appliquent maintenant la meme regle.

- Datation et evenements du mode test, meme cause. `_logDate` figeait une
  epoque au premier appel, puis chaque +1j ajoutait un jour a `ST.day` sans
  avancer le calendrier : la date projetee derivait, et le jour courant
  finissait dans le futur (mesure : jour 1033 date au 21/11/2026 alors qu on
  etait le 11/10). Deux consequences : la heatmap affichait des dates fausses,
  et `_evDateDecalee(0)` lit cette date pour choisir l evenement du jour alors
  que hors mode test il lit `new Date()`. Couper le mode test changeait donc
  la source, l evenement disparaissait de l ecran mais ses effets restaient
  acquis. Le jour courant est desormais ancre sur aujourd hui, le jour N-1 sur
  hier, et basculer le mode test ne change plus l evenement. `ST._dayEpoch`
  disparait.

- Notifications. L ecran Parametres ne lisait que l API web `Notification`,
  que la WebView Android n expose pas toujours : la pastille restait eteinte
  et l activer repondait « Notifications non supportees sur cet appareil »
  alors que le greffon `@capacitor/local-notifications` etait present et
  fonctionnel. `toggleNotif` passe maintenant par le greffon quand il existe,
  et une sonde silencieuse au demarrage (`checkPermissions`, qui ne declenche
  aucune demande) renseigne la pastille des le lancement.

- Animations des emblemes : toujours actives, pour tout le monde. La ligne de
  reglage a trois etats est retiree des Parametres, ainsi que son rendu.

- `slConfirm` : un `cancelLabel` vide masque desormais le bouton. La chaine
  vide etant falsy, le `||` remettait « Annuler » : la fiche Confidentialite
  et donnees, qui demandait deja un seul bouton, en affichait deux.

- Plafond monotone. Le `floor` strict comptait des tranches de 24 h et non des
  minuits franchis : fermer a 23h et rouvrir a 13h le lendemain donnait 14 h,
  donc plafond 0, donc passage de jour bloque ET utilisateur marque suspect
  pour un usage normal. On ajoute ce que le jour avait deja consomme a la
  derniere note (`horloge.msJour`), credit borne a moins de 24 h, qui ne peut
  donc jamais offrir plus d un jour. Huit cas verifies, dont la fraude
  classique (montre avancee de 24 h, app fermee a 23h, reouverture une minute
  apres) qui reste bloquee.

- Journal des incidents d horloge. Les cinq points de mise en doute
  consignent desormais un incident date dans `ST._horlogeIncidents` (borne a
  40). L ecran de diagnostic affiche le compte et propose « Signaler a
  l assistance », qui ouvre le client mail prerempli vers
  metanoia.assistance@gmail.com. Aucun envoi automatique n est possible :
  l application n a pas de service d envoi, seul le client mail du telephone
  peut expedier. Le journal part aussi vers Supabase avec le state_blob.

- Recompenses de classement : uniquement en fin de saison. Le bareme
  `_SOC_WEEKLY_PRIZES` est supprime, les vieilles cles « w: » sont
  neutralisees sans rien verser, et `_socRecordBestRank` retient le DERNIER
  rang connu au lieu du meilleur jamais apercu.

- Rang de saison note en arriere-plan. `_socNoterRangSaison()` est appele a
  l ouverture du Social, quel que soit l onglet affiche : un joueur premier
  qui n ouvrait jamais l onglet Saison ne touchait plus rien.

- Rang visible au-dela de la cinquantieme place. `_socRangExact(tab)`
  interroge le serveur en comptage pur (`head:true`, aucune ligne rapatriee,
  donc aucun risque pour le quota) et une ligne « toi » est ajoutee avec le
  numero exact.

- Conseil du Sage. Une secondaire ACCOMPLIE ne peut plus etre remplacee : le
  statut etait efface sans controle, donc on encaissait XP et points, on
  remplacait la quete, et on encaissait de nouveau. En echec ou en partie, le
  remplacement reste permis.

- Instantane « avant-deconnexion ». `_socLogout` le prenait mais rien ne le
  rejouait. `_snapVeillerDeconnexion()` compare au retour et propose la
  restauration quand l instantane est plus avance que la progression en
  place, une seule fois par instantane.

- `_buildTraitCard` : `0/0` donnait `NaN`, donc `width:NaN%`, que le
  navigateur ignore, soit une barre vide sans explication. Garde posee.

## Evenements : regression de mon correctif, puis correction reelle

Ancrer `_logDate` sur aujourd hui reglait la heatmap mais CASSAIT les
evenements en mode test : la date de tirage ne bougeait plus d un jour simule
a l autre, donc meme jour de semaine, meme cle de semaine, donc le meme
evenement en boucle, et aucun si la journee reelle n en portait pas. C est la
regression signalee immediatement apres livraison.

Deux pieces, parce que le probleme etait double.

- La date d AFFICHAGE et la date de TIRAGE sont separees. `_logDate` reste
  ancre sur aujourd hui et sert a l historique et a la heatmap, qui doivent
  montrer des dates passees plausibles. `_evDateDecalee` derive desormais, en
  mode test, une date du NUMERO de jour (`_EV_EPOQUE_TEST`, calee a midi pour
  qu aucun fuseau ne fasse basculer le jour), pour que chaque jour simule tire
  son propre evenement. Cette date n est jamais affichee.

- L evenement du jour est FIGE dans l etat (`ST._evFige = {j, id}`), au
  premier calcul de la journee. Il etait recalcule a chaque affichage, et la
  source de date differait selon que le mode test etait actif : le couper
  faisait disparaitre l evenement de l ecran alors que ses effets etaient deja
  encaisses. Fige, il ne peut plus changer en cours de journee, ni en
  basculant le mode test, ni en changeant de fuseau. Les previsions du
  lendemain (offset non nul) ne sont pas concernees.

Mesures apres correction :

- Mode test, 14 jours simules : huit types d evenements distincts, les jours
  defilent bien avec leurs evenements.
- Un jour simule portant `easyDay` le GARDE apres coupure du mode test, et
  sur trois lectures consecutives.
- Le figeage ne rejoue pas le tirage : trois appels le meme jour, une seule
  sauvegarde.
- Taux de drop sur 730 jours : 62,5 % de jours avec evenement hors mode test,
  58,5 % en mode test, l ecart tenant a l echantillonnage. Repartition
  conforme aux seuils annonces (doubleXP 13 %, easyDay 12 %, hardMode 11 %,
  double_pts 10 %, frenzy 8 %, shadow 5 %, lucky 3 %).
- Garantie de deux evenements par semaine calendaire : minimum observe 2 sur
  52 semaines completes, moyenne 4,16, aucune semaine en dessous.
- Plus longue serie sans evenement : 6 jours, identique dans les deux modes.

## Lot du 14 octobre

- Dates en double dans la heatmap. La date etait HORODATEE au moment de l
  ecriture de l entree : plusieurs jours de jeu enregistres le meme jour reel
  portaient donc la meme date. Cela arrive avec le mode test, mais aussi hors
  mode test, le rattrapage d absence poussant N entrees d un coup avec
  `_logDate`, qui ignore son argument. D ou deux entrees au 12/10 et un jour
  courant date de la veille. `_dateDeJour(n)` compte desormais a rebours
  depuis aujourd hui, a l AFFICHAGE : chaque jour a sa date, le jour courant
  est aujourd hui. La date stockee reste en repli.

- Sanction muette. Deux causes, mesurees sur les trois chemins.
  `window._TEST_MODE` exemptait TOUTE la session : en mode test, aucune
  sanction ne pouvait tomber, meme sur un jour reellement vecu. Seuls les
  jours FABRIQUES par le panneau doivent l etre, et c est ce que porte
  `_testExemptDay` ; les lots +7j et +30j restent proteges autrement, car
  `_testAutoOneDay` pose `reviewDone=true` avant d appeler advDay.
  Seconde cause, plus sournoise : une sanction restee en attente rend muets
  les TROIS chemins a la fois, tous testant `!ST.sanctionPending`. Un etat
  incoherent (texte vide) ou perime bloquait donc le mecanisme entier en
  silence. `ST.sanctionJour` est memorise et une purge au demarrage nettoie,
  verifiee sur six cas (la sanction d hier est conservee, celle de trois jours
  purgee).

- L ecran de sanction nomme les quetes manquees. Il annoncait un nombre sans
  jamais dire lesquelles.

- Plume de Sagesse : nouvel effet, « ton prochain jour rate ne casse pas ta
  serie ». L ancien +10 % XP sur 3 jours doublonnait avec l Elixir
  d experience. La serie est entamee a CINQ endroits (bilan du soir,
  rattrapage, ouverture tardive, deux chemins de cloture) : tous passent
  desormais par `_plumeProtege()`, qui consomme la protection une seule fois.
  Verifie : avec la plume, un jour rate laisse la serie a 12 au lieu de 11 ;
  quatre jours rates la ramenent quand meme a zero.

- Ecran blanc au retour au premier plan. Meme cause que les animations CSS :
  la WebView Android ne repeint que sur interaction. Un voile dedie
  (`#repaint-kick`, z-index -1, sans pointer-events) voit son opacite varier
  de maniere imperceptible pendant quatorze images au retour, ce qui invalide
  la surface. On ne touche NI a `body` NI a `documentElement` : une opacite ou
  une transformation sur l un d eux creerait un contexte d empilement et
  deplacerait tous les `position:fixed`, dont la barre de navigation, qui est
  un enfant direct de chaque ecran - c est la panne deja vue en septembre.
  Branche sur `appStateChange` de Capacitor, `pageshow`, `focus` et
  `visibilitychange`. Verifie dans Chromium : la barre du bas reste collee au
  bas pendant et apres le reveil, le defilement est conserve, les clics
  traversent le voile.

## Audit de l ecran Quetes, second passage

Trois defauts corriges, tous verifies par execution.

- Le melange des jours n en etait pas un. `genWeek` placait les grosses
  seances avec `sort(() => Math.random()-0.5)`, un comparateur incoherent qui
  ne produit PAS une permutation uniforme. Mesure sur 60 000 tirages de six
  jours : le lundi arrivait en premiere position 28,9 % du temps contre 16,7 %
  attendus, et le samedi en seconde position 5,2 %. Les grosses seances
  tombaient donc nettement plus souvent en debut de semaine. Un melange de
  Fisher-Yates (`_melanger`) remplace les QUATRE occurrences du motif : deux
  dans `genWeek`, deux dans l injection des quetes d arc. Apres correction,
  l ecart est de 16,4 a 16,9 % partout.

- Le doublement des points dependait du canal. `ptsV` passait la Potion de
  double points et l evenement NATUREL par un meme OU, mais ajoutait un second
  x2 pour l evenement FORCE par Prediction. Mesure sur une quete body a 2
  points : potion seule 4, potion + evenement naturel 4, potion + evenement
  force 8. Le doublement s applique desormais au plus une fois, quelle que
  soit sa source ; shadow reste cumulable, c est un effet distinct. Huit cas
  verifies, dont la combinaison naturel double_pts + force shadow, inchangee
  a 6.

- Quota « En partie » incoherent entre les quetes. `_enGalere` etait declare
  DANS la branche des quetes non-negociables, mais relu plus bas par le De du
  Destin, qui rend obligatoires AUSSI l eau et les secondaires. Pour ces
  quetes-la, la variable valait `undefined` et le quota retombait a 2 : le
  meme jour, un joueur en difficulte lisait « En partie(3) » sur sa quete body
  et « En partie(2) » sur sa quete eau. Le calcul passe par `_quotaPartiel()`,
  appele aux deux endroits.

Verifie et sain :

- Le creneau horaire, sur les 24 heures de debut possibles : toujours 16
  heures couvertes, y compris quand la fenetre enjambe minuit (20h donne bien
  20h-11h).
- `getToday()` et l indexation du plan hebdomadaire, avec son garde-fou.
- `_claimDungeon` : le drapeau `claimed` est pose apres la distribution, mais
  toute la fonction est synchrone, donc aucune double reclamation possible.
- `_ensureHardModeQuest` : garde contre le doublon effective.
- Les 318 identifiants lus par `getElementById` : 48 ne sont pas declares
  dans le HTML statique, mais ce sont des couches creees dynamiquement ou du
  code mort assume, et AUCUN n est lu sans garde. Aucune exception silencieuse.
- Les compteurs de serie de donjon : un seul chemin actif, protege par
  `_lastCountedDay` ; le bloc du bilan est neutralise par un `if(false &&`
  volontaire.

Signale, non corrige :

- Indicateur de synchronisation du Social : REBRANCHE. `_socUpdateSyncBar`
  existait et etait appelee a dix endroits, mais ses deux elements
  (`soc-sync-dot`, `soc-sync-label`) n avaient jamais ete declares : la
  fonction sortait sur son garde et n affichait rien. La barre est posee sous
  la carte profil. Verifie dans Chromium sur la fonction extraite du fichier :
  les quatre etats donnent la bonne couleur et le bon libelle, gris au repos,
  or pendant la synchronisation, vert au succes, rouge a l erreur, et un etat
  inconnu retombe sur le repos. Un point a noter : les libelles de la fonction
  sont ecrits sans accents (« Sync auto activee », « Synchronise »), sans
  doute parce qu ils n avaient jamais ete relus a l ecran. Je n y touche pas,
  c est du texte.
- Code mort assume, documente dans le fichier : `xp-nxt`, `s-streak`, `slbl`
  et `s-shop` (l ecran boutique s appelle `s-rewards`).

## Classement de Saison casse, 15 octobre

Thibs signale trois symptomes sur l onglet Saison du Social : les comptes de
demonstration affichent tous 0 XP, lui-meme avec plus de cent points de
saison n apparait pas en tete, et il n a jamais vu l ecran de resultat de fin
de saison.

La cause des deux premiers est une faute de frappe a deux endroits.
`_demoMergeRanking` triait sur `xp_season` et `_demoHunters` fabriquait un
champ `xp_season`, alors que la colonne s appelle `season_xp` partout
ailleurs (neuf occurrences). Consequences : `_socRowValue` lit `season_xp`,
donc chaque chasseur de demonstration valait 0 ; et le tri de saison comparait
une cle que personne ne porte, donc il ne triait rien.

Troisieme point, independant : Thibs etait absent des lignes renvoyees par le
serveur (son `season_id` etait perime), et le repli `_socRangExact` que j
avais ajoute affichait alors « #1 » sous la vingt-cinquieme place, ce qui est
incoherent.

Trois corrections, verifiees par execution :

- `xp_season` renomme en `season_xp` aux deux endroits. Apres coup, les
  demonstrations affichent de vraies valeurs (1431, 1404, 1377...) et plus
  aucune ligne a 0.
- Nouvelle fonction `_socAssurerMaLigne(rows, tab)`, appelee juste apres
  `_demoMergeRanking`, qui insere le joueur courant a partir de ses valeurs
  locales quand le serveur ne l a pas renvoye, puis retrie. Thibs apparait
  desormais a la douzieme place dans la liste elle-meme.
- La ligne « hors classement » du bas n est plus affichee que si le rang
  depasse 25.

Structure revue apres coup : 4 balises `<script`, 3 blocs en ligne, `node
--check` passe sur les trois, analyse lxml valide, cadratins a zero.

## Grade de Second, rond de profil dans la guilde, 16 octobre

Trois ajouts demandes par Thibs sur le Social.

**Le grade de Second.** Hierarchie a trois etages : Maitre > Second > Membre,
sans plafond sur le nombre de Seconds. Une seule fonction decide du rang,
`_gldRang`, et tout le reste en decoule : `_gldPeutAgir(role)` exige un rang
strictement superieur, donc un Second ne peut pas exclure un autre Second ni
toucher au Maitre ; `_gldPeutRecruter()` ouvre l etat de recrutement et les
demandes d adhesion au Maitre et au Second. L emblem et la devise restent au
Maitre seul. Matrice verifiee par execution, les neuf combinaisons :

    moi      cible    agir    recruter
    owner    owner    false   true
    owner    second   true    true
    owner    member   true    true
    second   owner    false   true
    second   second   false   true
    second   member   true    true
    member   *        false   false

Changement de comportement a signaler : avant, **n importe quel membre**
pouvait accepter ou refuser une candidature. C est desormais reserve au
Maitre et au Second, sans quoi donner ce pouvoir au Second ne voudrait rien
dire. Le texte du mode « sur demande » a ete corrige en consequence.

**Le rond dans la liste de guilde.** Le meme `.soc-lb-avatar` que les
classements Serie et Global, en 30 px, pose entre le numero et le pseudo. Un
clic dessus ouvre le profil du joueur, avec `event.stopPropagation()` pour ne
pas declencher le menu de la ligne. Le reste de la ligne garde le systeme
actuel : clic sur le pseudo pour promouvoir ou exclure.

**Le profil joueur.** `_openUserProfile` existait deja, ouvert depuis les
classements. Ajoute : la serie, la devise de la guilde sous son nom, et un
blason gris par defaut pour les chasseurs sans guilde (`_blasonGris`, qui
reprend l ecu `EMB.CAD[1]` en pierre grise, sans symbole ni animation).
« Record » devient « Top global », qui est bien ce que mesure `best_rank`.
Tant que `user_public_profile` ne renvoie pas `streak`, la case affiche un
tiret et non un zero : un zero affirmerait une serie cassee.

**Ce qui manque cote serveur.** Les roles vivent dans Supabase et le depot ne
contient aucun SQL. Il faut : autoriser `second` dans la contrainte de
`guild_members.role`, creer `guild_set_role(p_user, p_role)`, et modifier
`guild_kick`, `guild_settings`, `guild_request_decide` et
`user_public_profile`. Je n ai jamais vu le corps de ces quatre fonctions,
donc je ne les ai pas reecrites a l aveugle : Thibs doit d abord executer un
bloc d inspection. Tant que le SQL n est pas pose, le client degrade
proprement (le bouton « Nommer Second » renvoie une erreur, rien d autre ne
casse).

## Retouches du Second, 16 octobre

Retours de Thibs apres installation.

- « Retirer le grade » devient « Retrograder Membre », et la confirmation
  suit : titre « Retrograder en Membre ? », bouton « Retrograder ».
- Le texte vu par un membre simple dans les reglages parle maintenant du
  Maitre « et son ou ses Seconds », puisque leur nombre n est pas plafonne.
- `.gact-pop` debordait. Avec trois boutons, la bulle d actions depassait a
  droite et il fallait faire defiler la liste pour atteindre « Exclure ». Elle
  passe en `flex-wrap:wrap` avec `max-width:calc(100% - 56px)` et
  `white-space:normal`. Mesure apres coup a 430 px : bulle de 334 px de large,
  86 px de haut, deux lignes, `scrollWidth` du document inchange a 430.

Confirme par Thibs sur l appareil : la nomination d un Second fonctionne, et
un Second peut bien changer l etat de recrutement.

## La garde anti-triche, telle qu elle est reellement

Etabli le 16 octobre en lisant le serveur, parce que rien de tout cela n est
dans le depot. A connaitre avant de toucher au Social.

Le classement ne lit pas `profiles` mais une vue `classement`, definie
`select ... from profiles where suspect = false`. Un profil marque disparait
donc de TOUS les classements, pas seulement de celui de saison.

Trois declencheurs `BEFORE` sur `profiles`, executes dans l ordre
alphabetique de leur nom : `a_reject_stale_client_rev`, `b_garde_partage`,
`trg_guard_progress`, puis `zz_exempt_dev_suspect` que j ai ajoute.

`garde_partage` est la vraie garde. Seaux de jetons separes sur l XP, la
serie, les points et les objets ; elle ECRETE au lieu de refuser, pour que la
sauvegarde personnelle passe quand meme, et journalise tout dans
`fraude_journal` avec l IP et l agent. Le piege est a la ligne
`if v_gel and coalesce(old.suspect,false) then v_budget := 0` : une fois
marque, le budget d XP tombe a zero DEFINITIVEMENT, donc chaque
synchronisation redeborde et remarque. Un compte ne sort jamais de cet etat
tout seul, et `v_accepte` restant a 0, ni `xp_weekly` ni `season_xp` ne
peuvent plus croitre. C est la raison du `season_xp = 0` observe.

`guard_profile_progress` n ecrit pas `suspect`. Il annule silencieusement
toute mise a jour qui divise la progression par plus de cinq, par un
`return null`. Piege latent : le client croit avoir sauvegarde, le serveur n
a rien ecrit, personne n est averti.

Le compte Thibs avait ete marque, puis gelé depuis le 11 octobre : motif
`xp_gel`, 30976 XP envoyes, 17751 acceptes, 13225 d ecart a chaque envoi. Une
derogation a ete posee dans `garde_partage` pour les comptes de
developpement, qui sortent avant toute garde. A retirer avant une ouverture
publique.

## Un repere « C est toi » dans le profil

Ouvrir son propre profil depuis un classement ou depuis la liste de guilde ne
donnait aucun indice qu il s agissait de soi. Une pastille vermeil est posee
a cote du pseudo quand `userId` vaut celui du compte connecte. Le pseudo
passe en `text-overflow:ellipsis` pour que la pastille ne soit jamais
poussee hors de l ecran. Mesure a 430 px avec le pseudo le plus long
observe : aucun debordement horizontal.

## Navigation entre profils, 16 octobre

- L onglet de classement « Guilde » devient « Guildes ». Il classe des
  guildes, pas une guilde.
- Le bloc guilde du profil joueur passe d une ligne de tableau a une carte :
  blason en 54 px au lieu de 26, nom en Cinzel 17 px, devise entre
  guillemets. Sans guilde, l ecu gris et « Ce chasseur avance seul ».
- Cette carte est cliquable et ouvre `_guildOpenPublicProfile`, qui existait
  deja et dont les cartes de membres appellent `_openUserProfile`. La boucle
  joueur vers guilde vers joueur est donc fermee. `_profileShell` appelle
  `_profileCloseAll` en entree, et `_scrollLockOn` est compte, donc enchainer
  les feuilles ne derègle pas la position de defilement du fond.
- Les cartes de membres du profil de guilde affichent SECOND, en plus de
  MAITRE.

Limite assumee : il n y a pas de retour. Chaque feuille remplace la
precedente, donc fermer ramene a l ecran, pas au profil d ou l on venait.

## Guilde peuplee a l essai, sous-onglets inverses, 16 octobre

`_demoMembresGuilde()` reprend les quinze premiers chasseurs de
`_demoHunters()` et les met a la forme du roster : `user_id`, `pseudo`, `xp`,
`role`. Le troisieme recoit le grade de Second, sans quoi le grade ne se
verrait jamais a l essai. Le rendu les concatene au roster reel puis retrie
par XP decroissante, et le compteur de membres compte la liste affichee.

J avais d abord reserve l injection au mode test. C etait trop prudent et
incoherent avec le reste : les chasseurs de demonstration des classements
sont permanents, pilotes par le seul `_DEMO_ON`. Les membres factices suivent
donc le meme interrupteur, et `_DEMO_ON = false` fait tout disparaitre d un
coup.

La garde qui reste, elle, est necessaire : un faux membre n est jamais
actionnable (`!m._demo`), donc aucun appel a `guild_kick` ou
`guild_set_role` ne peut partir sur un identifiant qui n existe pas en base.

Mesure a 430 px avec deux membres reels : 17 sur 30, sept lignes visibles, le
reste au defilement dans la zone de 340 px, aucun debordement horizontal.

Le sous-titre du chat continue de compter les membres REELS, ce qui est
correct : on ne discute pas avec des chasseurs factices.

Les sous-onglets du Social sont inverses : Guilde d abord, Classements
ensuite. L onglet ouvert par defaut reste Classements.

## Un compte marque le sait enfin, 16 octobre

Jusqu ici, un joueur marque `suspect` disparaissait de tous les classements,
voyait son XP publique gelee a vie, et n en etait jamais informe. Il en
concluait que l application etait cassee. Trois pieces corrigent ca.

`_fraudeVerifier()` est appelee a la fin de `_socLoadProfile`, qui lit deja
la ligne complete du joueur. Elle compare `_socProfile.suspect` a
`ST._compteEnRevue` et n agit QUE sur un changement d etat : une
synchronisation qui ne change rien n ecrit rien. Les cles d Activite
`revue:on:<id>` et `revue:off:<id>` sont liberees l une par l autre, donc un
compte peut etre marque, reabilite, puis remarque, et chaque bascule produit
une entree.

Transitions verifiees par execution, sur la vraie fonction extraite du
fichier :

    jamais marque        pas de banniere, aucune entree
    marque               banniere + 1 entree
    deux syncs de plus   toujours 1 entree (pas de doublon)
    reabilite            banniere retiree + entree de resolution
    remarque plus tard   nouvelle entree

Le bandeau `#soc-revue-banner` est pose au-dessus des onglets de classement,
affiche par `_socRenderConnected` selon `ST._compteEnRevue`. Il porte un
bouton vers `_fraudeContacter()`, qui ouvre un courriel prerempli vers
l assistance avec l identifiant du compte, le pseudo, le jour de jeu et la
version. L identifiant est ce qui permet de retrouver la ligne dans
`fraude_journal` cote serveur. Mesure a 430 px : aucun debordement.

Au passage, le veilleur de guilde ne signalait que le titre de Maitre. Il
annonce maintenant aussi la nomination et le retrait du grade de Second.

Ce qui n est PAS fait : l envoi d un courriel AU joueur au moment du
marquage. Postgres ne sait pas envoyer de courrier ; il faut un service
externe. Decision en attente.

## Le cron fantome des notifications, 16 octobre

Trouve en remontant des 401 dans `net._http_response`. Un job pg_cron,
`metanoia-reminders`, appelait l Edge Function `send-reminders` toutes les
quinze minutes. Il n envoyait que `Content-Type` et `x-cron-secret`, pas
`Authorization` : la passerelle des Edge Functions de Supabase exige un JWT
AVANT d executer la fonction, donc la fonction n etait jamais atteinte.
Quatre-vingt-seize echecs par jour.

Le piege qui l avait cache : `cron.job_run_details` affichait `succeeded` a
chaque fois. pg_cron rapporte le succes du SQL, et le SQL etait un
`select net.http_post(...)`, qui reussit toujours puisqu il ne fait que
mettre la requete en file. Le resultat HTTP arrive ailleurs, dans
`net._http_response`. Un cron vert pour un echec total.

Sans importance au fond, parce que `send-reminders` est le chemin Web Push de
l epoque PWA : `_pushSaveViaRPC` envoie `endpoint`, `p256dh` et `auth`, les
trois elements d un abonnement de service worker. Dans la WebView Capacitor,
`pushManager.getSubscription()` ne renvoie rien, donc aucun abonnement n a
jamais ete enregistre et la fonction travaillait sur une table vide. Les
notifications actuelles passent par `LocalNotifications`, planifiees sur
l appareil, sans serveur.

Job supprime par `select cron.unschedule('metanoia-reminders')`. L Edge
Function est conservee : elle ne coute plus rien et servira si des
notifications poussees depuis le serveur reviennent un jour.

Code mort cote app, consequence de la meme bascule : tout le sous-systeme
Web Push. Retire le 16 octobre, 5001 caracteres.

Je n avais d abord nomme que trois fonctions a Thibs. En verifiant avant de
supprimer, `_pushSaveViaRPC` avait encore un appelant vivant, `_pushSubscribe`,
lui-meme appele depuis six endroits dont les reglages. Retirer trois fonctions
isolees aurait laisse un appelant sans appele. Le bloc entier est donc parti :
`PUSH_VAPID_PUBLIC`, `_pushB64ToU8`, `_pushLocalDate`, `_pushTz`,
`_pushNNRemaining`, `_pushSubscribe`, `_pushDungeonStart`, `_testNotif`,
`_pushSaveViaRPC`, `_pushSyncState`, `_pushSyncStateThrottled`, les six
appels gardes, le desabonnement dans `toggleNotif` et le bouton « Test notif »
du panneau de test.

Verifications apres coup : zero reference restante a `_push*`, `_testNotif` ou
`pushManager` dans tout le fichier ; `_testGrantTitles`, `_notifPrompt`,
`toggleNotif`, `_saveFlush` et `scheduleNotif` ont survecu ; `node --check`
passe sur les trois blocs. `toggleNotif` reste coherent : chemin natif par
`_notifNatifPlanifier`, chemin web par `scheduleNotif`.

## La chaine de courriel, 16 octobre

Un compte marque recoit desormais un courriel, en plus de l entree d Activite
et du bandeau poses le matin meme. Etat final de la chaine, cote serveur :

Le domaine **metanoia-app.com** a ete achete chez IONOS, qui heberge aussi
la zone DNS. Trois enregistrements y ont ete poses pour Resend, tous relatifs
a l envoi : `TXT resend._domainkey` pour la signature DKIM, `MX send` vers
`feedback-smtp.eu-west-1.amazonses.com` priorite 10, et `TXT send` portant
`v=spf1 include:amazonses.com ~all`. La region Resend est eu-west-1, ce qui
correspond au MX.

Point a retenir pour plus tard : le courrier d IONOS vit sur la RACINE (MX
`mx00`/`mx01.ionos.fr`, SPF sur `@`, DKIM sur `s1-ionos`/`s2-ionos`) tandis
que Resend vit sur le sous-domaine `send` et sur `resend._domainkey`. Aucune
collision, les deux cohabitent. Rien ne doit etre supprime dans la zone.

Aucune boite aux lettres n a ete creee. Les messages partent de
`assistance@metanoia-app.com` pour la delivrabilite, avec un champ `reply_to`
vers `metanoia.assistance@gmail.com` : la reponse d un joueur arrive donc
dans la boite deja consultee, sans redirection ni abonnement.

Il n y a plus aucune cle a saisir nulle part. La cle Resend vit dans le
coffre Supabase sous le nom `resend_api_key`, et les deux fonctions la lisent
par `vault.decrypted_secrets`. La table `mail_config` que j avais proposee
faisait doublon avec cet existant : elle a ete supprimee, ainsi que la
fonction `envoyer_mail`.

Verifie par execution : deux reponses 200 dans `net._http_response`, l envoi
de test a 08:04:59 UTC et le cron quotidien `metanoia-alerte-fraude` a
08:00:00.

Correction d une affirmation fausse de ma part le matin meme : j avais ecrit
qu aucun chemin ne ramenait un compte marque a la normale. C est faux,
`metanoia_annuler_triche` et `metanoia_blanchir` existent, et l alerte
quotidienne donne meme la commande prete pour chaque profil. Ce qui manquait
etait la moitie joueur, pas la moitie serveur.

## Un compte en revue ne se reinsere plus dans les classements

Defaut introduit par ma propre correction de la veille, vu sur l appareil
pendant le test de bout en bout : le compte marque etait bien exclu de la vue
`classement` cote serveur, mais `_socAssurerMaLigne` l y remettait depuis les
valeurs locales. Il s affichait donc PREMIER du classement Global, juste sous
le bandeau lui annoncant que ses classements etaient suspendus.

`_socAssurerMaLigne` sort maintenant immediatement si `ST._compteEnRevue`.
Trois cas verifies par execution sur la vraie fonction :

    compte normal                     insere, rang 1
    compte en revue                   non insere, liste inchangee
    en revue mais renvoye par serveur affiche quand meme

Le troisieme cas est voulu : si le serveur renvoie la ligne, c est que le
compte n est plus exclu, et c est lui qui a raison contre un drapeau local
qui n aurait pas encore ete rafraichi.

## Le bandeau de revue passe au vert, 16 octobre

Demande de Thibs : apres un clic sur « Contacter l assistance », le bandeau
doit afficher « Assistance contactee » en vert.

Le bandeau n est plus du HTML fige dans la page mais un conteneur vide rempli
par `_fraudeRendreBanniere()`, appelee par `_socRenderConnected` et par
`_fraudeContacter`. Deux etats : alerte ambre avec le bouton d action, ou
accuse de reception vert avec la date d ouverture du message.

Nuance assumee : ouvrir le client mail ne prouve pas que le message a ete
envoye, le joueur peut abandonner. Plutot que de changer le libelle demande,
l etat vert porte un lien « Envoyer un autre message », pour qu un joueur qui
a renonce ne reste pas devant un bandeau qui lui ment.

`ST._revueContactee` est remis a zero lors d une rehabilitation, pour qu un
futur marquage reparte de l etat d alerte et non d un accuse perime.

Rendu mesure a 430 px, les deux etats, aucun debordement horizontal.

Au passage, une erreur de ma part dans une requete donnee a Thibs :
`select public.metanoia_blanchir((select id from profiles where ...))`
echoue en 55006, parce que la sous-requete tient une lecture active sur
`profiles` pendant que la fonction tente `alter table ... disable trigger`.
Il faut passer l identifiant en dur.

## Bouton de fin de saison, 16 octobre

Pour verifier les recompenses sans attendre quatorze jours. `_testFinSaison()`
n avance pas l horloge : elle inscrit le rang choisi sous la saison
PRECEDENTE (`s:<id-1>`) et efface sa cle de versement, ce qui place
`_socCheckPeriodRewards` dans exactement la situation d une bascule reelle,
puisque celle-ci ne verse que pour une cle dont l identifiant differe de la
saison courante. Reserve au mode test, bouton dans le panneau de test.

Bareme verifie par execution sur la vraie table `_SOC_SEASON_PRIZES` :

    rang  1       Champion de la saison   +2000 pts  Boite Rang S   titre leg. 7j
    rang  2 a 3   Podium de saison        +1200 pts  Boite Rang A   titre epique 5j
    rang  4 a 10  Top 10 de saison         +700 pts  Cle du Neant
    rang 11 a 25  Top 25 de saison         +300 pts  Boite Rang C
    rang 26+      aucune recompense

## Trois restes d audit traites, 16 octobre

**Mystere Systemique : la selection du jour n etait pas figee.** Quand une
des quatre cartes etait un Mystere Systemique, `_getDailyPickedRaw` en faisait
une copie pour y ecrire le fragment revele. `_getDailyPicked` memorisait
ensuite la selection par `_DAILY_POOL.indexOf(it)`, qui compare des
references : la copie n etant pas dans le catalogue, l indice valait -1. Au
rechargement `_DAILY_POOL[-1]` etait `undefined`, le compte ne tombait plus
juste, et QUATRE cartes neuves etaient retirees. Un cache memoire masquait le
probleme tant que l application restait ouverte ; il apparaissait au
redemarrage, et les cartes changeaient parce que le pool est refiltre selon l
etat courant (points, deblocages, fragments restants).

Correctif : `_dailyCarteFragment(ix, fragId)` fabrique la carte revelee, et
c est le SEUL endroit qui la fabrique, pour que le tirage et la
reconstruction ne puissent plus diverger. Une entree memorisee est desormais
soit un indice simple, soit `{i:indice, f:fragment}`. Les anciennes
sauvegardes, qui ne contiennent que des indices simples, restent lues.

**Boucliers : prix de reference.** `activate_shield` n est pas dans
`_DAILY_POOL`, la recherche de prix par `effect` echouait donc, et
`_sellInvItem` retombait sur son repli a 100 : TOUT bouclier se revendait
50 pts. Le tarif est maintenant repris de `UTIL_R`, source unique deja
utilisee par la boutique, donc aucun second jeu de prix a maintenir.

**Champs morts du catalogue.** Les 30 entrees de `_DAILY_POOL` portaient
`price` et `discount`. `discount` n etait lu nulle part : les badges de remise
viennent de `pr.discountTag`, calcule a la volee par `_prixItem`. `price` n
etait jamais lu non plus, parce que tous les consommateurs ecrivent
`item.orig || item.price` et que les 30 entrees ont un `orig`. Le piege etait
la : modifier `price` n avait aucun effet. Les deux champs sont supprimes, 759
caracteres, et les `|| item.price` des lecteurs sont conserves comme filet
pour les inventaires deja sauvegardes.

Verifie par execution sur les vraies fonctions extraites du fichier :

    premier tirage        memorise [0, {i:1,f:"f3"}, 2]
    apres redemarrage     memes cartes, aucun nouveau tirage
    sauvegarde ancienne   indices simples toujours lus
    bouclier 1j           orig 80  -> revente 40 pts
    bouclier 3j           orig 200 -> revente 100 pts
    bouclier 5j           orig 350 -> revente 175 pts
    cle du neant          orig 900 -> revente 450 pts (inchange)

## Zones de Flow : seuil d affichage, 16 octobre

Le commentaire annoncait cinq jours de donnees, le code en exigeait trois.

Precision importante, parce que je l avais d abord mal presentee a Thibs : la
FENETRE est bien celle des trente derniers jours, `dayLog.slice(-30)`. Elle
vaut donc neuf journees a J10, quand l ecran Stats se debloque, puis une de
plus chaque jour jusqu a trente ou elle se met a glisser. Le `>= 3` n etait
pas une fenetre de trois jours mais un MINIMUM d affichage, sous lequel le
bloc annonce « En attente » au lieu d un verdict.

Ce minimum ne mord donc que pour un axe peu renseigne : la Discipline, qui
apparait plus tard que Body et Mind, ou un historique troue par des journees
sous bouclier, explicitement exclues par `!d.shield`. Mais dans ce cas precis
le verdict devenait absurde : a trois journees, une seule quete ratee faisait
passer le conseil de « trop facile, augmente la difficulte » a « trop dur,
baisse-la ».

Seuil porte a cinq, dans une constante unique `_FLOW_MIN_JOURS` partagee par
les trois axes, au lieu de trois litteraux a tenir synchronises. Le
commentaire dit maintenant ce que fait le code.

Verifie par execution :

    3 jours, 2 reussis    En attente
    4 jours, 3 reussis    En attente
    5 jours, 3 reussis    60 %  Zone de Flow
    5 jours, 4 reussis    80 %  Zone de Flow
    9 jours, 8 reussis    89 %  trop facile
    30 jours, 20 reussis  67 %  Zone de Flow

## Erreur JS a l ouverture d une boite, 16 octobre

Signalee par Thibs sur l appareil : `Uncaught TypeError: Cannot read
properties of null (reading 'style')` a la ligne 12882, pendant qu une boite
de Rang C affichait son recapitulatif.

Course entre un minuteur et les appuis du joueur. Au premier appui,
`_boxNext` programme `_boxShow(0)` 600 ms plus tard, le temps de l animation
du coffre, mais pose `S.i=0` immediatement. Trois appuis rapides pendant ces
600 ms faisaient donc defiler la sequence sans attendre : objet 2, puis
recapitulatif. Or `_boxRecap` remplace le contenu de l overlay, donc
`box-item` disparait. Le minuteur retombait ensuite sur un noeud absent.
`_boxNext` se protegeait par `if(!pane) return`, `_boxShow` n avait aucune
garde.

Trois correctifs, du plus cible au plus defensif :

- `S.ouverture` ignore les appuis pendant l animation d ouverture. C est la
  cause racine.
- `_boxShow` sort si `box-item` a disparu.
- `_boxClose` annule le minuteur encore en vol.

Reproduit et verifie dans Chromium, sur les vraies fonctions extraites du
fichier, en comparant la version d avant et celle d apres :

    AVANT  trois appuis rapides  objet 2 | RECAP  puis TypeError
    APRES  trois appuis rapides  objet 1         aucune erreur
    APRES  parcours normal       objet 1 | objet 2 | RECAP  aucune erreur

## Fiche de profil reagencee, 16 octobre

D apres un croquis de Thibs. L en-tete ne bouge pas : rond, pseudo, pastille
« C est toi ». Dessous, deux colonnes en `flex:2` et `flex:3`, soit 2/5 et
3/5 de la largeur utile.

A gauche, empilees : Rang, XP, Serie, puis un bloc Classements qui regroupe
Global, Saison et Record en trois lignes au lieu de trois tuiles. Les tuiles
passent du format centre au format libelle au-dessus, valeur en dessous : sur
2/5 de largeur, une valeur centree sous un libelle en capitales devenait
illisible.

A droite, la guilde. Embleme en 150 px, le maximum tenable (3/5 de 394 px a
430 px d ecran, moins les marges, laisse environ 209 px ; a 360 px il reste
167 px). Dessous le nom en Cinzel, la devise en italique entre guillemets, et
le grade du joueur dans sa guilde. Sans guilde : ecu gris et « Aucune
guilde ». L embleme et le nom ouvrent le profil de la guilde.

Le bloc « Chasseur depuis » reste en dessous des deux colonnes. Je l avais
supprime par erreur en remplacant le corps de la fiche ; restaure.

Le grade vient de `u.guild_role`, que `user_public_profile` doit renvoyer.
Tant que le SQL n est pas pose, un repli cherche le role dans `_GUILD.roster`,
ce qui ne marche que pour un membre de MA guilde, la policy de lecture de
`guild_members` n allant pas plus loin.

Rendu verifie dans Chromium sur trois cas : Maitre avec devise a 430 px,
Second avec pseudo long a 430 px, sans guilde a 360 px. Aucun debordement.

## Liste des membres : demi-ligne et chainage, 16 octobre

Deux retours de Thibs sur la liste de guilde.

**La huitieme ligne est maintenant coupee en deux.** A sept lignes pile, la
liste paraissait complete et rien n invitait a la faire defiler. La hauteur
n est pas figee : `_guildAjusterListe()` mesure une VRAIE ligne apres le
rendu, puis pose `maxHeight = 7,5 x hauteur`. Une valeur en dur aurait
coupe au mauvais endroit, les polices Sora et Cinzel ne donnant pas la meme
hauteur que les polices systeme. Sous huit membres, aucune limite n est
posee : il n y a rien a faire defiler.

Un fondu de 34 px, `#gld-fog`, grise le bas de la liste et s eteint des qu on
atteint le dernier membre, pour ne pas promettre une suite qui n existe pas.

**Le chainage de defilement est coupe.** La liste n avait pas
`overscroll-behavior`, donc un dernier glissement vers le bas, une fois
arrive au bout, faisait defiler l ecran entier derriere elle. Meme correctif
que celui deja pose sur les feuilles de profil.

Mesure a 430 px : 7,51 lignes visibles, `overscrollBehaviorY` a `contain`,
fondu opaque en haut de liste et transparent en bas, bas du fondu aligne au
pixel sur le bas de la liste, et aucune limite de hauteur a cinq membres.

Reste non traite, faute d avoir pu le reproduire : le grand vide sous la
carte quand l ecran lui-meme est fait defiler. Il vient probablement de
`.screen.active{min-height:100dvh;overflow-y:auto}`, qui fait de chaque ecran
un second conteneur defilant a l interieur du corps. C est une regle globale
qui touche les cinq ecrans, je n y touche pas sans arbitrage.

## Bandeau reseau refermable, 16 octobre

Demande de Thibs : un joueur qui SAIT etre hors reseau pour plusieurs jours
ne doit pas subir le bandeau rouge en permanence ; et le retour du reseau
doit se voir.

Une croix est posee a droite du message. La fermeture est memorisee dans
`ST._netMasque`, donc elle survit aux redemarrages, ce qui est tout l interet
pour une absence de reseau qui dure. Elle est OUBLIEE des que la connexion
revient : une coupure ulterieure reaffiche l alerte, sinon un joueur ayant
ferme le bandeau une fois ne serait plus jamais prevenu.

Au retour du reseau, le meme element passe en bleu avec « Connexion
retablie » pendant une seconde, puis disparait et reprend sa couleur rouge
pour la fois suivante. Le `toast` qui annoncait deja le retour dans le
gestionnaire `online` est supprime : il faisait doublon.

Machine a etats verifiee par execution, les six transitions :

    coupure                  rouge affiche, croix presente
    fermeture                masque, ST._netMasque enregistre
    toujours hors ligne      reste masque
    retour du reseau         bleu « Connexion retablie », masque oublie
    une seconde plus tard    masque, fond revenu au rouge
    nouvelle coupure         rouge reaffiche

## Le bandeau hors-ligne n apparaissait pas, 16 octobre

Thibs coupe sa connexion, rien ne s affiche. Ce n etait pas le bandeau qui
etait casse : c est l etat reseau qui n etait jamais reevalue.

`_netProbe` n etait appelee qu a quatre endroits : au demarrage, sur l
evenement `online`, au retour d arriere-plan via `visibilitychange`, et avant
une action reseau par `_netGuard`. Aucune sonde periodique. Couper le reseau
en gardant l application au premier plan ne declenchait donc rien, sauf si la
WebView emettait `offline`, ce qu elle ne fait pas toujours : le commentaire
du code le dit lui-meme, `navigator.onLine` signifie « une interface reseau
est active », pas « internet marche ». Wifi associe a une box sans acces, et
l evenement ne part jamais.

Une sonde est posee toutes les 30 s, uniquement quand l ecran est visible.
Avec le cache interne de 15 s de `_netProbe`, cela fait une vraie requete par
demi-minute, vers la racine PostgREST, quelques centaines d octets. Hors
ligne, `_netProbe` sort avant toute requete : la sonde ne coute alors rien.

Verifie par execution avec l intervalle accelere :

    au premier plan        4 sondes en 180 ms (dont la forcee du demarrage)
    en arriere-plan        0 sonde
    retour au premier plan 3 sondes

## Le temps reel du bandeau hors-ligne, 16 octobre

Suite du precedent. Thibs : couper brutalement la radio, mode avion ou wifi
et donnees eteints, n affiche rien ; il faut fermer et rouvrir. Seule une
connexion qui se degrade en douceur declenche le bandeau a vue.

C est coherent avec ce que faisait le code. La WebView d Android garde
`navigator.onLine` a true en mode avion et n emet pas `offline` de facon
fiable, donc le seul signal restant etait la sonde des 30 s. Une degradation
progressive, elle, fait echouer les requetes applicatives, et celles-la
reagissaient plus vite. D ou l asymetrie qu il decrit.

Trois leviers, du plus decisif au moins couteux.

**1. Le greffon natif `@capacitor/network`.** Il ecoute le
`ConnectivityManager` du systeme et previent a l instant de la bascule, sans
la moindre requete. `_NET.natif` memorise son verdict et `_netIsOnline()` le
fait primer sur `navigator.onLine`, precisement parce que celui-ci ment.
Le greffon reste facultatif : `_netPlugin()` renvoie null s il manque et tout
continue par sonde. `npm i` puis `npx cap sync android` ont deja ete passes
ici, le greffon est enregistre dans `capacitor.plugins.json`.

**2. La sonde resserree a 10 s** quand le greffon manque, 25 s quand il est
la. Elle reste indispensable dans les deux cas : un wifi associe a une box
sans acces est « connecte » pour le systeme comme pour le greffon.

**3. Une sonde au premier toucher** apres cinq secondes sans contact. Celui
qui pose le doigt sur l ecran attend une reponse immediate.

Pour rendre cette cadence tenable, la sonde passe de GET a HEAD. La
remarque de la section precedente, « quelques centaines d octets », etait
fausse : un GET sur la racine PostgREST rapatrie tout le schema OpenAPI,
plusieurs dizaines de kilo-octets. En HEAD, il n y a plus de corps. Si un
intermediaire refusait HEAD, un repli GET est tente une fois avant de
conclure que le serveur est muet, et HEAD est alors abandonne pour la
session : aucun faux bandeau possible.

Verifie par execution, vraies fonctions extraites du fichier, requetes vers
la sonde interceptees :

    sans greffon, coupure brutale   bandeau apres 8 514 ms, navigator.onLine
                                    reste a true tout du long
    avec greffon, coupure brutale   bandeau apres 1 ms, _netIsOnline() suit
                                    le natif malgre onLine a true
    avec greffon, retour reseau     bandeau bleu « Connexion retablie »,
                                    efface apres la seconde
    toucher apres coupure           bandeau apres 59 ms
    HEAD refuse                     sequence HEAD puis GET, reseau juge
                                    joignable, aucun bandeau a tort
    connexion saine pendant 12 s    aucun bandeau, 2 sondes

Note relevee au passage : `capacitor.plugins.json` du depot ne listait pas
`@capacitor/local-notifications`, et `capacitor.config.json` n avait pas le
`backgroundColor`. Ces fichiers sont generes, ils etaient simplement
anterieurs a ces deux ajouts ; le `cap sync` les a remis a jour. Rien n
indique un defaut sur l appareil, ou chaque construction les regenere.

## Le claquement de cil survivait au redemarrage, 16 octobre

Thibs : le battement est encore la quand on ferme puis rouvre l application
et qu on retourne sur la Guilde. Question posee : defaut supprimable, ou
limite atteinte ? Supprimable, et la cause etait ailleurs que la transition.

L ecran Social est en `display:none` tant qu il n est pas ouvert, et
`_guildLoad` rend la liste bien avant, au demarrage. Un element non rendu
mesure zero partout : `scrollHeight - scrollTop - clientHeight` valait donc
0, `maj()` en concluait « liste arrivee au bout » et eteignait la brume,
puis armait la transition par-dessus. A l ouverture de l onglet, la huitieme
ligne apparaissait nette avant de se voiler en fondu. Le correctif precedent
posait bien `opacity:1` a la construction, mais l ajustement l ecrasait dans
la seconde qui suivait.

Mesure du defaut, avant correctif, rendu avec le conteneur masque :

    opacite posee a la construction   1
    apres `_guildAjusterListe`        0, transition armee
    a l ouverture de l onglet         0 puis 1, le battement

Deux corrections. `_guildAjusterListe` sort desormais sans rien conclure
quand `clientHeight` vaut 0 : une mesure impossible ne decide plus de rien,
et l etat pose a la construction reste en place. Et l ajustement est rejoue
a l instant ou un ecran devient actif, aux deux endroits qui posent
`classList.add('active')`, la ou `_ajusterPaddingBas()` est deja appele :
l ecran est mesurable des cet instant.

Troisieme point, pour solder la reserve notee plus haut. `_GLD_HLIGNE`
repartait de 49 px a chaque lancement, donc un appareil dont la ligne mesure
autre chose subissait un reajustement a la premiere ouverture, a chaque
session. La valeur mesuree est maintenant conservee dans `ST._gldHLigne`,
relue par `_gldHLigne()`, bornee a 20-120 px pour ecarter une valeur
aberrante lue dans un etat corrompu.

Verifie par execution, vraie fonction extraite du fichier, ligne forcee a
56 px pour simuler un appareil different :

    session 1, ouverture      368 px corriges en 420, valeur mémorisée,
                              une seule ecriture d etat
    session 2, construction   420 px poses d emblee, saut 0
    session 2, opacites       1 sur vingt frames, aucun passage par 0
    valeur aberrante 9999     ignoree, retour a 49 px
    defilement                0,53 a mi-fondu, 0 en bas, 1 au retour en haut
    guilde de 5 membres       aucune brume, aucune hauteur posee

## Audit du systeme de sanction, 16 octobre

Demande de Thibs : verifier que la sanction fonctionne. Audit par execution
de la chaine cliente, vraies fonctions extraites du fichier.

Huit scenarios, resultats avant correctif :

    compte sain                aucun bandeau, aucune activite, present au
                               classement
    marque par le serveur      bandeau orange, une entree d activite,
                               non reinsere au classement
    profil recharge trois fois aucun message en double
    contact assistance         mailto vers l assistance, sujet et
                               identifiant presents, bandeau passe au vert
    rehabilite                 bandeau retire, contact oublie, retour au
                               classement
    recidive                   le bandeau repart de l etat d alerte
    etat client perime         DEFAUT, reinsere au classement
    colonne `suspect` absente  DEFAUT, annonce une rehabilitation

Les deux defauts avaient la meme racine. `_socLoadProfile` avale ses
erreurs : hors ligne, `_socProfile` reste nul, et l absence de marque etait
lue comme une rehabilitation. Un joueur sanctionne qui relancait
l application sans reseau recevait « Ton compte est de nouveau en regle »,
perdait le bandeau et revenait au classement local, alors que le serveur le
tenait toujours a l ecart. Le meme chemin s ouvrait si la colonne `suspect`
venait a manquer de la reponse.

`_fraudeVerifier` ne conclut desormais plus rien d une information qu il n a
pas : profil absent ou `suspect` non booleen, on sort sans toucher a l etat.

Verifie apres correctif :

    redemarrage hors ligne     sanction maintenue, aucun message, bandeau
                               affiche, pas de reinsertion au classement
    colonne absente            etat conserve, derniere entree inchangee
    marquage et rehabilitation reels   inchanges, toujours corrects

Points cote serveur restant a confirmer avec Thibs : l exclusion des
suspects dans la vue `classement`, les seuils de `guard_profile_progress`,
l etat du declencheur `zz_alerte_suspect` et son rang alphabetique, le gel
annonce de l XP publique, les droits de lecture du joueur sur sa propre
colonne `suspect`, et les deux voies de sortie `metanoia_annuler_triche` et
`metanoia_blanchir`.

## Audit de l ecran de sanction, 16 octobre

Thibs : l ecran de sanction doit apparaitre des qu une quete obligatoire
n est pas accomplie, et il ne l a plus vu depuis longtemps. Audit en
chargeant l application reelle dans un navigateur et en pilotant un joueur
au jour 20, quetes du jour generees par `genWeek()`.

Trois chemins menent a la sanction, et ils ne disaient pas la meme chose.

**Le bilan du soir** (`submitReview`) sanctionne des la premiere quete
obligatoire ratee. Mesure : une ratee sur trois, ecran affiche, texte et
contexte poses. Celui-la marchait.

**Le controleur de fin de creneau**, qui marque en echec les quetes restees
sans statut, exigeait DEUX quetes ratees. Mesure avant correctif : une seule
quete ratee, echec bien enregistre, integrite a 75, et `sanctionPending`
reste faux, aucun ecran. La regle s appliquait donc ou non selon que le
joueur faisait son bilan ou non. Seuil ramene a une quete.

Deuxieme defaut du meme bloc : l ecran ne s affichait que si le joueur se
trouvait sur l accueil ou sur le bilan. Ailleurs, la sanction etait posee en
memoire mais il gardait la main sur toute l application jusqu au redemarrage
suivant, alors que cet ecran est precisement celui qu on ne peut pas
contourner. Il s affiche desormais depuis n importe quel ecran, sauf pendant
l integration.

Ce correctif en a cree un autre, vu a la mesure suivante et corrige :
`buildSanction` ne pose rien avant le jour 15, donc l ecran s ouvrait VIDE
pendant la franchise. L ancien code avait le meme defaut, limite a l accueil
et au bilan. L affichage est maintenant conditionne a `ST.sanctionPending`.

Retire au passage : `_lateOpen`, variable lue nulle part et dont le calcul
etait faux, `ST._openedBefore22h||(ST.day||1)` retombant sur le jour courant
quand le marqueur manque, ce qui rendait la negation toujours fausse. C est
`_wasActive` qui fait ce travail. Corrige aussi le commentaire qui annoncait
un auto-echec « a 22h » : le creneau par defaut va de 8 h a minuit, et c est
sa fin qui declenche.

Etat verifie apres correctifs :

    1 ratee, bilan du soir          sanction, ecran affiche
    1 ratee, depuis #Social         sanction, ecran affiche
    1 ratee, depuis #Stats          sanction, ecran affiche
    1 ratee, bouclier actif         aucune sanction, quete non marquee,
                                    integrite intacte a 80
    1 ratee, jour 12                aucune sanction, pas d ecran vide
    1 ratee, joueur absent du jour  aucune sanction (garde volontaire)
    0 ratee                         rien

Les deux trous restants ont ete tranches par Thibs dans la foulee.

**L absence de la journee se sanctionne.** Le garde `_wasActive` exigeait que
le joueur ait ete vu pendant le creneau : ne pas ouvrir l application du tout
ne coutait donc aucune sanction. Il est retire.

**Une seule sanction au retour d une absence de plusieurs jours.** Le
rattrapage comptait les sanctions dues dans `CATCHUP._sanctionsDues`, les
recopiait dans `b.sanctions`, et personne ne lisait jamais ce champ : elles
etaient perdues sans un mot. Les quetes du dernier jour fautif sont
desormais retenues dans `CATCHUP._ratees`, et une sanction unique est posee
au retour, mentionnee dans le recapitulatif d absence. Une par jour manque
ecraserait celui qui revient ; aucune effacait l absence.

Verifie par execution, meme methode :

    absence de 5 jours              J20 vers J25, serie 5 vers 0, integrite
                                    80 vers 5, 5 jours comptes, UNE sanction,
                                    ecran affiche
    absence de 5 jours, bouclier    aucune sanction, serie et integrite
                                    intactes
    joueur absent de la journee     sanction, ecran affiche
    bouclier, jour 12, 0 ratee      inchanges

Note de lecture pour la suite : `todayStr()` produit `annee-mois-jour` avec
un mois indexe a partir de zero et sans zero de tete, `2026-9-16` pour le
16 octobre 2026. Format maison coherent entre producteur et consommateur,
mais il fait trebucher quiconque le lit comme une date ISO.

## Journal du 16 octobre, resume pour une reprise rapide

La seance du 16 octobre a ete longue. Dans l ordre, ce qui a change :

| Sujet | Resultat |
|---|---|
| Grade de Second | hierarchie Maitre, Second, Membre, avec matrice de droits |
| Rond de profil, fiche joueur | fiche en deux colonnes, carte de guilde cliquable |
| Classement de Saison | reparee, faute de frappe `xp_season` vers `season_xp` |
| Compte de Thibs gele | degele, exemption posee pour le mode test |
| Cron fantome | il echouait 96 fois par jour, remis en marche |
| Web Push mort | code retire, inerte sous Capacitor |
| Chaine de courriel | Resend plus pg_net, domaine verifie, code 200 observe |
| Compte en revue | bandeau, entree d activite, courriel, bouton assistance |
| Carte Mystere Systemique | le clone cassait le gel de la carte du jour |
| Boucliers | revente alignee sur la boutique, 40 / 100 / 175 |
| Champs morts du catalogue | 30 `price` et 30 `discount` retires |
| Zones de Flow | seuil porte a 5 jours, puis glissant de 9 a 30 |
| Course a l ouverture des boites | verrou pose, erreur JS supprimee |
| Fiche de profil | reagencee selon le croquis de Thibs |
| Liste de membres | demi-ligne visible, chainage de defilement coupe |
| Bandeau reseau | croix de fermeture, retour bleu, sonde periodique |
| Temps reel du bandeau | greffon natif `@capacitor/network` installe et synchronise |
| Brume de la liste | deux defauts successifs, dont un de mon fait |
| Systeme de sanction client | un defaut grave trouve et corrige |
| Ecran de sanction | seuil incoherent entre chemins, corrige |

Les deux derniers meritent d etre relus en detail plus bas : ce sont les
seuls de la journee qui touchaient a des regles de jeu, et non a l affichage.

## Le vide sous le dernier bloc, 16 octobre

Thibs : on peut encore faire defiler en dehors des blocs, et ca laisse un
espace. Mesure plutot que supposition, sur une reproduction fidele des regles
`body`, `.screen.active`, `.app` et `.bnav`.

La cause n est ni le chainage de defilement ni `min-height:100dvh`, mais la
reserve de place sous le contenu, qui sert a ne pas passer sous la barre de
navigation fixe. Elle etait ecrite en dur : `5,5 rem` par defaut sur `.app`,
et `6 rem` en style en ligne sur le Social. Soit 88 et 96 px, pour une barre
qui en mesure 54.

`_ajusterPaddingBas()` mesure la barre pour de vrai et pose sa hauteur plus
14 px de respiration, sur les `.app` de l ecran actif. Appelee aux deux
endroits qui activent un ecran, et sur `resize`.

Mesure avant et apres, barre de 54 px, defilement pousse jusqu en bas :

    avant   padding 96 px   vide sous la carte 96 px   dont 42 px hors barre
    apres   padding 68 px   vide sous la carte 68 px   dont 14 px hors barre

Les 14 px restants sont voulus : sans eux le dernier bloc collerait a la
barre.

## Le mot « Guilde » en Cinzel

Demande de Thibs, viser l immersion. L etiquette passe de 8,5 px en Sora gris
a 12,5 px en Cinzel dore, interlettrage a 0,20 em, avec un leger relief clair.
Cinzel est deja la serif d apparat des titres d ecran et des noms de guilde :
le mot devient une enseigne gravee au lieu d une etiquette de formulaire.

## La fermeture du bandeau survivait a la reconnexion, 16 octobre

Bug introduit par moi le matin meme. `ST._netMasque` n etait remis a faux que
sur une TRANSITION observee de hors-ligne vers en ligne, dans `_netPaint`. Au
demarrage de l application, `_netEtatPrec` vaut `null` : si le reseau est la,
on passe par la branche qui masque, sans jamais effacer le drapeau. Une
fermeture faite avant un redemarrage survivait donc a la reconnexion, et la
coupure suivante restait muette.

Le drapeau est maintenant efface des que `_netOk()` est vrai, pas seulement
sur une transition, et la sauvegarde n est declenchee que s il valait vrai.

Verifie par execution, le scenario exact :

    coupure                        bandeau affiche
    fermeture                      masque, drapeau pose
    redemarrage, en ligne          drapeau efface
    nouvelle coupure               bandeau reaffiche

Avant le correctif, la derniere etape ne montrait rien.

## Le saut de hauteur de la liste de guilde, 16 octobre

Defaut introduit par moi une heure plus tot. Le gabarit posait
`max-height:340px`, puis `_guildAjusterListe` corrigeait a 368 apres le rendu.
Le bouton « Chat de guilde » descendait donc d un demi-cran sous les yeux du
joueur a chaque ouverture de l onglet.

La hauteur est desormais posee DES la construction du HTML, a partir de
`_GLD_HLIGNE`, la hauteur de ligne mesuree au rendu precedent, initialisee a
49 px. `_guildAjusterListe` ne touche plus a la hauteur que si la mesure
reelle s ecarte du cache d au moins un pixel : sinon elle rejouerait
exactement le saut qu on cherche a supprimer. Elle conserve son role sur le
fondu de bas de liste.

Verifie par execution, hauteur avant et apres l appel a l ajustement :

    17 membres   368 px avant, 368 px apres, saut 0, 7,51 lignes visibles
    5 membres    245 px avant, 245 px apres, aucune limite posee

Reserve : si la hauteur de ligne reelle sur l appareil differe de 49 px, le
tout premier affichage apres installation bougera de cet ecart, puis plus
jamais, le cache etant corrige des le premier rendu.

## Le battement de cil de la brume, 16 octobre

Deuxieme defaut du meme lot, du meme auteur. Le gabarit posait la brume
`#gld-fog` a `opacity:0` avec `transition:opacity .18s`, et c est
`_guildAjusterListe` qui la montait a 1 apres le rendu. En arrivant sur
l onglet Guilde, le joueur voyait donc la huitieme ligne nette une fraction
de seconde avant qu elle soit voilee.

La brume est maintenant posee a son etat final des la construction du HTML,
`opacity:1` quand le roster depasse sept membres, et sans transition. La
transition n est armee qu au `requestAnimationFrame` suivant, de sorte que
le premier affichage est sec et que seules les variations au defilement
restent adoucies.

Verifie par execution, opacites relevees sur vingt-sept frames depuis
l insertion du HTML :

    avant   17 membres   0 puis 1   le battement
    apres   17 membres   1 seulement
    apres    5 membres   0 seulement, aucune brume
    apres   17 membres   transition vide au premier rendu, « opacity 0.18s »
                         au frame suivant, 0,53 a mi-fondu lors du
                         defilement vers le bas, 0 en bas de liste

## Audit de securite du 9 octobre, etat des onze points au 18 octobre

Etat verifie dans le code le 18 octobre, pas recopie du document d audit.

| # | Faille | Etat |
|---|---|---|
| 1 | Cinq tapes ouvrent le panneau de triche | corrige, `ADMIN_UID` renseigne, verrou `_verrouPanneauTest()` |
| 2 | Import sans borne | ferme par retrait de l import, fonctions conservees |
| 3 | `state_blob` lisible par tous | corrige, vue `classement` et `metanoia_pseudo_pris` |
| 4 | Bilan validable en boucle | corrige, garde d idempotence |
| 5 | Revente a 50 pts fixes | corrige, prix par `_DAILY_POOL` et `UTIL_R` pour les boucliers |
| 6 | Mauvais objet vendu sous bouclier | corrige |
| 7 | Journee off rachetable le meme jour | INJOIGNABLE, voir ci-dessous |
| 8 | `trig()` cycle perfect, fail, perfect | corrige, `trig` refuse fail sur perfect, clear et dayoff |
| 9 | `_pickChosenSec` rouvre une secondaire validee | corrige, refus si la secondaire est perfect |
| 10 | `slConfirm` a resolveur unique | corrige, le precedent recoit `false` |
| 11 | Policies de guilde et RPC | NON VERIFIE, question serveur 7 plus bas |

**Point 7.** La branche `if(r.name==='Journee off sans penalite')` existe
toujours dans `buyRew()` (ligne 14400 au 18 octobre) et n a toujours aucune
garde de jour. Mais aucun objet du catalogue ne porte ce nom : le seul autre
resultat d une recherche sur ce libelle est la branche elle-meme, et l objet
`day_off` d inventaire est purge au demarrage. Branche morte, sans risque
aujourd hui. Decision de Thibs le 18 octobre : documenter, ne pas toucher.
Si l objet revient un jour au catalogue, poser d abord un test du type
`ST._dayOffDay === ST.day`, sinon chaque achat reincremente la serie,
remonte l integrite de 3 et ecrit un bilan pour le meme jour.

**Point 10, consequence a connaitre.** L audit signalait que le resolveur
unique neutralisait PAR ACCIDENT cinq doubles depenses, dont
`_openSealedBox` et `_buyPermItem` : la premiere promesse ne se resolvait
jamais, donc la premiere depense n avait pas lieu. Depuis le correctif, la
premiere promesse se resout a `false`, ce qui produit le meme effet,
volontairement cette fois. Le jour ou `slConfirm` gerera une vraie pile de
modales qui laisse les deux confirmations aboutir, ces cinq chemins devront
etre gardes un par un.

## Lot du 18 octobre : vide sous la guilde, balayage entre ecrans

### Le vide sous le dernier bloc, cause reelle

Thibs envoie deux captures de #Social, onglet Guilde : la carte tient dans
l ecran, et pourtant on peut faire defiler vers le haut et faire apparaitre
un vide sous la carte. Il veut un ecran fige.

Retractation de la section « Le vide sous le dernier bloc » du 16 octobre.
J y ecrivais que `_ajusterPaddingBas()` posait la reserve « sur les `.app`
de l ecran actif ». C etait faux : seul le Social possede un `.app`
interieur. Les quatre autres ecrans n en ont aucun, et la mesure d alors
portait sur une reproduction, pas sur l application.

La vraie structure, mesuree dans l application chargee : un
`<div class="app">` ENVELOPPE tous les ecrans, enfant direct de `body`. Il
herite de `.app{padding:.5rem 1rem 5.5rem}`, donc 8 px en haut et 88 px en
bas. Or l ecran actif impose `min-height:100dvh`. Total : 8 + 100dvh + 88,
toujours plus haut que la fenetre, quel que soit le contenu. Sur l appareil
s y ajoute la marge haute du systeme, car `targetSdk 36` impose le bord a
bord et `viewport-fit=cover` rend `env(safe-area-inset-*)` non nul. Le
Social cumulait en plus sa propre reserve interieure.

Correctif :

- le conteneur racine porte desormais `id="app-racine"` et SEUL il reserve
  la place de la barre du bas, `padding-bottom:var(--res-bas,5.5rem)` ;
- `_ajusterPaddingBas()` ne touche plus aux `.app` : il mesure la barre et
  pose `--res-bas` = hauteur + 14 px sur la racine du document ;
- l ecran actif retranche tout ce qui l entoure :
  `min-height:calc(100dvh - .5rem - var(--res-bas) - env(top) - env(bottom))` ;
- le `.app` interieur du Social passe de `padding-bottom:6rem` a `0`.

Les ecrans fixes (`s-ob`, `s-welcome`, `s-sanction`) ne sont pas concernes :
ils ont leur propre `inset` ou `top`/`bottom`.

Mesure avant et apres, application reelle a 430 x 900, `env()` remplace par
40 px en haut et 30 px en bas dans une copie pour simuler un telephone
(Chromium les evalue a 0, forcer le padding du body ne suffit pas) :

    ecran                 defilement en trop   ecart dernier bloc / barre
    Social court   avant  136 px               338 px
                   apres    0 px               202 px
    Social long    avant  bas a 102 px de la barre
                   apres  bas a  14 px de la barre
    Quetes, Boutique      14 px sous le dernier bloc, contre 20 avant
    Identite, Stats       28 et 24 px, marge propre du dernier element

Un ecran dont le contenu tient ne defile donc plus du tout ; un ecran plus
long s arrete 14 px au-dessus de la barre, comme voulu le 16 octobre.

### Balayage horizontal entre les cinq ecrans

Demande de Thibs : changer d onglet d un geste, a gauche ou a droite.

`_swpDebut`, `_swpFin` et `_swpAller`, places juste apres `nav()`. Un geste
d au moins 70 px, deux fois plus horizontal que vertical et de moins de
700 ms clique le bouton voisin dans la barre de l ecran ACTIF. Donc
strictement le meme chemin qu un appui : son, memoire de defilement,
fermeture du chat de guilde, onglets grises. Ordre : Quetes, Identite,
Boutique, Stats, Social ; aucun bouclage aux deux bouts.

Le geste est ignore : a plusieurs doigts, dans un champ ou un canvas, dans
tout element qui defile lui-meme a l horizontale, sur tout element en
position fixe (fenetres superposees, barre du bas, ecran de sanction), sur
un ecran autre que les cinq principaux, pendant le tutoriel et pendant
l integration. Un element peut s exclure avec l attribut `data-noswipe`.
Ecouteurs passifs : ils ne retardent ni ne bloquent aucun defilement.

Verifie par de vrais evenements tactiles (CDP `Input.dispatchTouchEvent`) :

    Quetes > Identite > Boutique > Stats > Social    un geste chacun
    Social vers la gauche                            reste (bout)
    Social vers la droite                            Stats
    geste vertical, 50 px, 1 200 ms                  rien
    depart dans une zone defilante horizontale       rien
    depart sur une fenetre fixe                      rien
    tutoriel actif                                   rien
    jour 1, Quetes vers la gauche                    Identite, comme au doigt

Le dernier cas n est pas une erreur : au jour 1, les onglets verrouilles
gardent `nav()` et sont seulement grises, `renderIdentity()` decide de
l affichage. Un appui fait la meme chose.

Piege de test, a ne pas reprendre pour un defaut : Chromium en emulation
mobile recharge la page sur un glissement vers la droite (navigation
arriere par debordement), avec ou sans ce code. Lancer avec
`--disable-features=OverscrollHistoryNavigation`. La WebView Android n a pas
ce geste.

Non traite : les sous-onglets Guilde et Classements du Social ne se
balaient pas, le geste change d ecran principal.

## Donjons : refonte en cours, et retrait de « Quete en evenement », 18 octobre

### Refonte visuelle : decisions de Thibs (livree, voir section suivante)

Thibs a retenu le parti « tableau de chasse » pour le donjon deplie, et la
variante 4 « anneaux autour des monstres » pour le donjon replie.
Decisions :

- chaque condition est un papier epingle, il n y a pas de papier de boss ;
- tampon vert « ACCOMPLI » pour une condition remplie, rouge « MANQUE »
  pour une condition ratee ;
- coffre scelle : TOUTES les cases en « Scelle », et le texte exact de
  Thibs, a ne pas reformuler : « Coffre scelle. Utilise Eclat du Veilleur
  pour connaitre ses recompenses a l avance » (avec ses accents dans
  l application) ;
- Eclat du Veilleur utilise (`ST._veilRevealed` contient l id du donjon) :
  toutes les recompenses s affichent, donjon commence ou non ;
- les illustrations reutilisent l existant : `_monsterSVG` (7 monstres),
  `_itemSVG` (coffres `box_E` a `box_S`, objets). Le fond clair de ces SVG
  se retire par la regex
  `/<rect(?=[^>]*width="(9[6-9]|100)")(?=[^>]*fill="#F[0-9A-F]{5}")[^>]*>/i`,
  verifiee sur les 33 objets.

Tranche ensuite : illustration de perte « Cendres », regle du tampon
« MANQUE » (des que la condition est impossible), nombre de cases scellees
= vrai nombre de recompenses.

### Les conditions de donjon, telles que le code les compte

Verifie dans `_variantConds`, `_dngTrack`, `_dngFail` et `advDay`. Chaque
donjon a entre 1 et 4 conditions.

| Cle | Libelle | Ce que le code compte reellement | Donjons |
|---|---|---|---|
| body | Quetes Body | quetes body validees, Accomplie ou En partie | 58 |
| mind | Quetes Mind | idem pour mind | 53 |
| water | Eau bue | quetes eau validees | 40 |
| total | Quetes totales | toute quete validee | 32 |
| sec | Quetes secondaires | secondaires validees | 24 |
| noFail | Jours sans fail | jours consecutifs sans quete obligatoire en `fail` | 22 |
| nnStreak | NN Xj d affilee | jours consecutifs ou les 3 obligatoires sont validees | 16 |
| maxFail | Discipline (max X fail) | quetes marquees `fail` pendant le donjon, obligatoires ET secondaires, plus les obligatoires non traitees en fin de journee | 16 |
| integ | Integrite >= X % | integrite courante ; cible = integrite au tirage + 10 a 18, plafond 95 | 10 |
| perfect | Quetes parfaites | quetes validees « Accomplie », pas « En partie » | 8 |
| hardQuest | Quete Hard Mode | une quete Hard Mode validee Accomplie | 8 |

Constat du 18 octobre, REGLE le soir meme : `noFail` et `nnStreak`
comptaient la meme chose, car `advDay` passe en `fail` toute obligatoire non
traitee AVANT de compter les series. `nnStreak` exige desormais les 3
obligatoires en « Accomplie » (bouclier et journee off neutres). Ce tableau
est remplace par celui de la section suivante.

### Retrait de « Quete en evenement »

Decision de Thibs. Quatre points touches :

- `_variantConds` : quand le tirage tombe sur `duringEvent`, il est ecarte
  et un autre candidat est tire. Le candidat reste dans la liste, sinon les
  poids changeaient et le tirage des 98 autres donjons avec. Verifie sur les
  108 : exactement les 10 donjons qui l avaient changent, chacun gagne une
  autre condition, les 98 autres sont identiques. Nouveaux tirages :
  c4 +nnStreak 4, c16 +body 4, b17 +water 5, b18 +nnStreak 5, a4 +perfect 4,
  a9 +noFail 6, a12 +mind 5, a15 +sec 3, a18 +body 6, s5 +water 7.
- `_normalizeConds` force `duringEvent:false`, `_dungeonProgress` ne
  l affiche plus, `_condSummary` ne le cite plus, `_dngTrack` ne pose plus
  `_eventDone`.
- `_evJourNaturel` ne fabrique plus de Double XP pour un donjon. C etait le
  mecanisme qui garantissait un evenement faisable, et dont le correctif du
  « x6 » parlait plus haut : il disparait avec la condition.
- Donjon lance AVANT le patch, sauvegarde avec la condition : verifie par
  execution, la condition disparait de l affichage, le donjon est gagne si le
  reste est rempli, et au jour 10 l evenement du jour passe de `doubleXP`
  fabrique a `null`.

## Donjons : refonte livree, 18 octobre au soir

### Conditions, etat final (18 types, 1 a 4 par donjon)

| Cle | Libelle | Ce que le code compte | Cibles E/D/C/B/A/S |
|---|---|---|---|
| body, mind, disc | Quetes Body / Mind / Discipline | quetes de ce type validees, Accomplie ou En partie | 2..7 (mind 1..6) |
| water | Eau bue | jours avec l eau validee | 2..7 |
| total | Quetes totales | toute quete validee | 4/6/9/12/15/18 |
| sec | Quetes secondaires | secondaires validees | 1/2/2/3/3/4 |
| perfect | Quetes parfaites | quetes en Accomplie | C+ : 2/3/4/5 |
| noFail | Jours sans fail | jours consecutifs sans obligatoire en fail | 2..7 |
| nnStreak | NN d affilee | jours consecutifs, 3 obligatoires en Accomplie | 2/3/3/4/5/6 |
| integ | Integrite | integrite au tirage + 10 a 18, plafond 95 | C+ |
| maxFail | Echecs toleres (ex « Discipline (max X fail) », renomme pour ne pas se confondre avec Quetes Discipline) | quetes ratees pendant le donjon | C+ : 3/2/1/0 |
| hardQuest | Quete Hard Mode | une quete Hard Mode en Accomplie | C+ |
| leveTot | Leve-tot | quetes validees dans les 2 premieres heures du creneau, heure REELLE | 2/3/4/6/8/10 |
| bilans | Bilans du soir | bilans ecrits, 1 par jour au plus | C+ : 4/5/5/6 |
| jourParfait | Journees parfaites | jours ou TOUTES les quetes sont en Accomplie (`_dayIsPerfect`) | D+ : 1/1/2/2/3 |
| sansPartie | Sans demi-mesure | rompue a la premiere « En partie » | C+ |
| ascete | Ascete | rompue au premier achat (`_buyDailyCard`, `_buyPermItem`, `buyRew`) | C+ |
| sansObjet | Sans artifice | rompue au premier objet utilise (`_shopUseItem`, hors boites) | B+ |

Refusees par Thibs : Energie haute, Journees completes, Obligatoires avant
midi. Paires jamais tirees ensemble (`_EXCL` dans `_variantConds`) :
noFail/maxFail, noFail/nnStreak, nnStreak/jourParfait, jourParfait/perfect,
jourParfait/sansPartie. Ajouter des candidats a change le tirage de tous les
donjons, c etait le but ; un donjon en cours garde ses conditions figees.

Mesure sur les 108 : 9 donjons a 1 condition, 36 a 2, 36 a 3, 27 a 4,
aucune paire exclue, aucun « en evenement ».

### Regle de perte du butin

- Une condition est MANQUEE des qu elle ne peut plus etre atteinte dans les
  journees restantes (plafonds par jour : 1 pour body/mind/disc/eau, 2
  secondaires, 6 quetes ; +10 d integrite par jour), ou a la fin pour Hard
  Mode, ou des la rupture pour les conditions « a tenir ». Une fois posee,
  elle est verrouillee (`act._manques`). Une condition atteinte l est aussi
  (`act._acquis`), meme si une serie retombe ensuite.
- Taux conserve = (conditions - manquees) / conditions, applique aux CASES
  (XP et points compris, decision de Thibs). Cases perdues =
  arrondi(cases x manquees / conditions), au moins 1, et au moins une case
  gardee tant qu une condition tient.
- L ordre de perte est tire UNE fois (`L._ordre`, `_dngOrdre`) a la premiere
  condition manquee, puis sauvegarde : rouvrir l application ne change rien,
  et une seconde condition manquee ajoute des cases sans rendre les autres.
- Au bout des 7 journees, le donjon n est plus efface : il passe
  `termine` et reste affiche jusqu a la reclamation (« Reclamer ce qui reste
  (X %) », ou « Clore le donjon » a 0 %). Le choix suivant vient apres.
- Seule une victoire SANS condition manquee compte pour `dungeonWins`,
  `dungeonStreak` et le bonus permanent de serie.
- Les compteurs ne tournent que pendant la fenetre reelle (`_dngEnCours`) :
  avant, ils comptaient aussi la veille d une Porte qui s ouvrait le
  lendemain. Donjon lance dans la journee : ce qui est deja valide ce jour la
  est repris, sans les echecs ni les « En partie ».

### Interface

- Replie : coffre miniature (scelle = assombri et « ? »), rang, nom, barre,
  jours ou « Termine », pile de 4 recompenses au plus puis « +n », et un
  anneau par condition. Le bouton de reclamation apparait aussi replie.
- Deplie : lore, « TABLEAU DE CHASSE », un papier epingle par condition avec
  un (i) en haut a droite. Toucher un papier insere l explication
  (`_dngInfo`) sous SA rangee, une seule a la fois, retoucher referme.
- Tresor : coffre du rang avec rayons, cases scellees, revelees (Eclat du
  Veilleur) ou en cendres, badge « X % conserve », texte de Thibs a ne pas
  reformuler sous un coffre scelle.
- Ecran de victoire : cases perdues barrees avec les cendres, titre
  « Donjon termine · X % du butin » pour une reclamation partielle.

Defaut trouve en route et corrige : la cle de cache de `#boss-zone` ne
suivait que `_body`, `_mind` et `claimed`. Un achat, un objet, l Eclat ou la
fin du donjon ne redessinaient pas la fiche. Elle porte maintenant l etat
complet du donjon actif.

Verifie par execution, vraies fonctions de l application :

    cases perdues   4c 1/4 -> 1 ; 6c 1/3 -> 2 ; 2/3 -> 4 ; 3/3 -> 6 ;
                    3c 1/2 -> 2 ; ordre stable et cumulatif
    fin + reclame   termine pose, choix non retires ; 1 manquee sur 3 :
                    points et fragment perdus, XP, cle, boite, titre verses,
                    dungeonWins inchange, donjon libere
    victoire        butin complet, dungeonWins +1
    fenetre         Porte de demain : rien compte la veille
    advDay          tout Accomplie : NN 1, sans fail 1, parfait 1 ;
                    une En partie : NN 0, sans fail 2 ; un echec : 0 et 0
    impossible      integ 60/95 a 2 jours, bilans 1/4 a 2 jours, serie,
                    echecs depasses : tous MANQUE ; a 6 jours : en cours
    affichage       430 et 360 px, 9 recompenses et 4 conditions : aucun
                    debordement ; (i) ouvre, change, referme
    rattrapage      entree a 10 h : Accomplie et En partie du jour repris,
                    echec non repris, Sans demi-mesure intacte

### Entree dans un donjon en cours de journee (regle de Thibs, 18 octobre)

Le creneau dure 16 h (`CRENEAU_DUREE`). `_dngStartDay` :

- dans les 11 premieres heures du creneau, le donjon commence AUJOURD HUI et
  les quetes deja validees du jour sont reprises (sans echecs ni « En
  partie ») ;
- dans les 5 dernieres heures (`_dngHeuresRestantes(h) <= 5`), il commence
  DEMAIN, et le joueur voit le texte de Thibs, a ne pas reformuler : « Ta
  journee est bien entamee. Pour ne pas te penaliser, le donjon commencera
  demain. » (accents dans l application). Bouton unique « Compris » ;
- hors creneau, demain, comme avant.

Cela remplace l ancien avertissement « Journee deja entamee » et ses deux
boutons « Continuer / Je reviens demain ». `_dngNNToutesTraitees`, qui ne
servait qu a lui, est supprimee.

Verifie : creneau 8 h, de 8 h a 18 h aujourd hui, de 19 h a 23 h demain, 3 h
demain ; creneau 20 h enroule, de 20 h a 6 h aujourd hui, de 7 h a 11 h
demain. Entree a 10 h : aucun dialogue de plus, quete du jour reprise. Entree
a 20 h : le message, puis la confirmation habituelle, et rien de repris.

### Retours de Thibs sur l appareil, 18 octobre au soir

- « Une carte Accomplie alors que le donjon ne commence que demain. » Vrai :
  l Integrite est une valeur vivante, elle etait lue avant l ouverture de la
  Porte. Avant `startDay`, plus rien n est compte, accompli ni manque
  (`avant` dans `_dungeonProgress`), progression a 0 %, et la fiche depliee
  le dit : « La Porte s ouvre demain : rien n est compte aujourd hui ».
- Les quetes « En partie » comptent bien pour Body, Mind, Discipline, Eau,
  Secondaires et Totales. Ce que Thibs voyait venait de la Porte de demain.
- Condition remplie mais reversible (Integrite, flag `vivant`) : jamais
  ACCOMPLI avant la fin. Elle affiche « Tenu », comme les conditions a tenir,
  et redevient « 90/95 » si elle retombe. Jugee a la fin ou a la reclamation.
- Eclat du Veilleur : utilisable sur le donjon EN COURS (`_dngEclat`), depuis
  le sac ou par un bouton sous le coffre scelle, avec le nombre d Eclats.
  Revele 100 % du coffre, cases en cendres barrees. Une seconde utilisation
  est refusee sans consommer d Eclat.
- Message « </b... » au bas de l ecran : c etait le Cristal de focus.
  `toast()` ecrit en `textContent`, donc `<b>En partie</b>` s affichait brut.
  Remplace par des guillemets. Au passage, le Cristal (les deux chemins,
  `_crystalFocusSur` et l objet du sac) compte desormais pour le donjon : il
  rompt Sans artifice, retire l echec de `_fail` et compte la quete en
  « En partie ».
- Hard Mode : il etait force TOUS les jours tant que la quete n etait pas
  faite. Un seul jour force par donjon desormais (`_dngJourHard`), entre le
  2e et le 6e jour, deduit de l identifiant, memorise dans `_hardVu` des
  qu il tombe ; un jour « minimum » le repousse au suivant. Le (i) donne le
  jour. Verifie : sur 7 jours simules, un seul H.

### Incident de fabrication, a ne pas reproduire

Un script de patch a plante PENDANT l ecriture (`UnicodeEncodeError` sur une
paire de substitution d emoji) apres avoir ouvert `index.html` en ecriture :
le fichier est tombe a 0 octet. Restaure depuis l archive livree, verifie
identique a la copie Android. Deux lecons :

- toujours ecrire dans `index.html.tmp` puis `os.replace` ;
- le fichier melange accents en caracteres reels et en sequences `\u`
  selon les zones ; un remplacement doit essayer les deux formes, sans
  decoder les paires de substitution (`\ud83d...`).

### Trois retouches du 19 octobre

- Integrite sans pourcentages : c est un nombre de 0 a 100, et une
  obligatoire ratee retire 5 POINTS (verifie : `ST.integrity-5` partout).
  Le (i) dit « au moins 95 d integrite sur 100 », l ecran de choix
  « integ. >= 95 ».
- Eclat du Veilleur depuis la fiche : confirmation `_dngEclatDemande`
  (« Reveler »), pour qu un toucher de passage ne consomme rien. Le sac a
  deja la sienne. Verifie : un refus ne revele rien et ne consomme rien.
- Toute la fiche deplie et replie (`onclick` sur `.boss-card`). Papiers,
  explication et boutons arretent la propagation. Verifie : toucher les
  anneaux deplie, un papier ou l explication ne replie pas, le texte replie.

Nombre de conditions par rang, rappel : E 1 a 2, D 2, C 2 a 3, B 3, A 3 a 4,
S 4 (`nConds` dans `_variantConds`).

### Economie mesuree le 19 octobre, base de la refonte des recompenses

- Journee parfaite, vraies fonctions : 25 a 31 XP et 10 a 12 pts, quel que
  soit le rang. Semaine simulee par `_testAutoOneDay` : 136 a 195 XP, 58 a
  70 pts. Les rangs Planetaire demandent 4 600 a 6 700 XP chacun.
- Ancien butin, 5 000 tirages par rang avec `_genDungeonLoot` : le nombre de
  cases plafonne a 6,5 du rang C au rang S. Seuls XP et points montent
  (S : 625 XP, 296 pts). Valeur hors XP en prix boutique : C 847, S 1 084,
  soit +28 % seulement pour un donjon bien plus dur.
- Une Boite Scellee ne s ouvre qu avec une Cle du Neant (`_hasKeyFor`).

## Butin de donjon en cases, 19 octobre

Decide par Thibs apres analyse. Le butin n est plus une poignee de champs
fixes mais une liste `L.cases`, une entree par case :
`{k:'xp',n}`, `{k:'pts',n}`, `{k:'item',effect,name,icon,rarity}`,
`{k:'frag',id,name}`, `{k:'cosm',effect,...}`, `{k:'titleEpic'|'titleLeg',id,name}`,
`{k:'shield',days}`, `{k:'cle'}`, `{k:'box',rank}`. `L.v=2`, `L.xpCase`.

Regles (`_genDungeonLoot`) :

| Rang | Cases | Cases XP | Cases points | Budget XP | Budget points |
|---|---|---|---|---|---|
| E | 4 | 1 | 1 | ancien x1,5 (~47) | ancien x0,75 (~12) |
| D | 6 | 1-2 | 1 | ~94 | ~22 |
| C | 8 | 2 | 1-2 | ~172 | ~41 |
| B | 10 | 2-3 | 2 | ~312 | ~74 |
| A | 12 | 3 | 2-3 | ~547 | ~130 |
| S | 14 | 3-4 | 3 | ~937 | ~222 |

- +1 case dans 15 % des donjons. Le budget XP et points est PARTAGE entre
  les cases (`_dngPartage`), pas multiplie par elles.
- Chaque autre case : objet 40, fragment 10, cosmetique 15, bouclier 5,
  cle 15, coffre 15.
- Objet (`_dngTirerObjet`) : consommables seulement. Commun x4, rare x2,
  epique x1 a partir du rang C, et les trois objets a 400 pts et plus
  (Pierre de Renaissance, Reset Integrite, Cristal de focus) a partir du
  rang B, poids 0,5. Decision de Thibs : favoriser les communs, qui se
  revendent peu.
- Fragment : un au plus par donjon (le suivant devient un objet), jamais un
  fragment deja possede ; tous possedes : case d XP.
- Cosmetique : Aura de l Ombre, Bordure Doree, Aura de Feu, Sceau du Monarque
  (60, temporaires, stockables, donc pas de remplacement), titre temporaire
  epique (28) ou legendaire (12) non possede, sinon case d XP. Les titres
  symboliques de la boutique sont EXCLUS (decision de Thibs).
- Bouclier : 1 jour 50 %, 3 jours 35 %, 5 jours 15 %.
- Coffre : rang du donjon 70 %, rang +1 30 %, plafonne a S.
- Revalidation (`_revalideTitresButin`) : un titre ou fragment obtenu entre
  le tirage et la reclamation devient une case d XP de valeur `xpCase`.
- Ancien butin : `_dngNormaliser` le convertit sur place, et traduit l ancien
  ordre de perte par cle (`_ordre`) en ordre par index (`_ordreI`).
- Cases perdues, fiche, ecran de choix, reclamation : tout passe par les
  index de `L.cases`. `_dngNomCase` donne le nom affiche partout.

Mesure, 5 000 butins par rang, valeur hors XP au prix boutique :

    rang  cases  objets  fragment  cles  coffres  valeur  (ancien)
    E     4,1    0,87    0,20      0,33  0,31     312     (286)
    C     8,2    1,94    0,39      0,70  0,68     734     (847)
    S    14,2    3,26    0,55      1,15  1,16    1879    (1084)

Le rang C vaut un peu moins qu avant en prix boutique : moins de fragments
(600 pts chacun) et moins de points, deux choix voulus. La progression E vers
S passe de x3,8 a x6.

Verifie : fragments jamais plus d un ; epiques jamais avant C, objets
premium jamais avant B ; tout possede, 0 fragment et 0 titre sur 2 000
donjons S, convertis en XP ; reclamation partielle 1 manquee sur 3, 8 cases,
3 perdues, les 5 autres versees exactement ; coffre de 15 cases rendu sur
trois lignes sans debordement a 430 px.

## Lot du 19 octobre : popups, abstinences, onglet Tests

### Une popup coupait l ouverture du butin
Cause : `_claimDungeon` et `_claimDailyBoss` appelaient `checkRankUp()` AVANT
d afficher l ecran de victoire, et sortaient par `return` si le rang montait.
L ecran de rang s ouvrait, le butin (deja verse) ne s affichait jamais.
Correctif : la victoire s affiche d abord ; `checkRankUp` est appele a sa
fermeture (donjon : bouton de `dungeon-victory-ov` ; boss du jour : bouton de
`boss-victory-ov`). Seul cas ou le rang passe d abord : donjon clos en
cendres (r >= N), qui n a pas d ecran de victoire.
Enchainement : `trig` sauvegarde avant de sortir sur un rang ou un titre ;
`closeRankUp()` appelle `checkNewTitles()`, pour qu un titre gagne en meme
temps qu un rang ne soit plus perdu.
Teste : rang monte pendant la reclamation, victoire visible et rang absent ;
apres fermeture, ecran de rang affiche.

### Abstinences : Tenu ou Fail
Dans `buildQ`, `isBinaire` : `d4`, `D102` (junk food), `D103` (alcool et
drogue), `D104` et `SD005` (pornographie), ou un nom qui contient
pornographie, alcool ou junk food (via `q._srcId||q.id`). Boutons « Tenu » et
« Fail », plus de « En partie », pas de de du destin ; une fois validee, la
quete affiche « Tenu » au lieu de « Accomplie ». Statut stocke : `perfect`.

### Onglet Tests de #Stats, version 2 (19 octobre)
La version 1 (dix cartes : rebond, paliers, qualite, jour x axe, obstacles et
plan si-alors, SRBAI, regularite, sanctions, resistance, nouveau depart) a ete
retiree : Thibs la jugeait en dessous des trois autres onglets. Les cles
`_planSiAlors` et `_srbai` ne sont plus utilisees.
Principe de la v2 : apprendre a l utilisateur quelque chose sur lui, en
confrontant ce qu il croit (mesure dans l app) a ce que ses donnees montrent.
Retenus par Thibs : 1, 3, 4 et le ressenti du matin. Refuses : pari du matin
(trop d effort quotidien, « on decide pour lui »), test go/no-go (sans rapport).
Bouton `stTab('st-tests',this)`, volet `#st-tests` > `#st-tests-body`, rendu
par `_renderTests()` (ouverture de l onglet, et `renderStats()` si actif).
Fonctions prefixees `_t`, juste avant `stTab`. Chaque carte sous try/catch.
1. Du matin ou du soir : rMEQ (Adan et Almirall 1991), 5 items, score 4-25,
   seuils 22/18/12/8. Stocke `ST._chrono` `{day,score,rep}`. Compare au
   moment reel : mediane de la 1re validation du jour et part des
   validations avant midi (`ST._valHeures`), des 7 jours de donnees.
2. Ta maitrise de toi : Brief Self-Control Scale (Tangney et al. 2004),
   13 items 1-5, inverses 2,3,4,5,7,9,10,12,13, score 13-65. Position par
   loi normale, moyenne 39,5 et ecart-type 8,5 (normes publiees : 606
   etudiants, 95 % entre 22,5 et 56). Compare au taux de quetes Discipline
   tenues sur 60 jours (10 occasions minimum). Remesure conseillee a 90 jours.
   Stocke `ST._bscs`. Traduction libre.
3. Ton ressenti du matin est-il fiable : taux de jours reussis selon
   `dayLog.morningMood` (good/ok/bad, reponse a « Comment te sens-tu ? »),
   120 jours, 3 jours minimum par cote. Verdict selon l ecart.
4. Tes conditions de reussite : 20 jours minimum, 120 jours. Cinq facteurs
   (week-end, lendemain d echec, bilan fait la veille, serie de 7 jours et +,
   1re quete dans les 3 h du creneau), 5 jours minimum de chaque cote ; les
   3 plus marquants affiches, verdict si l ecart atteint 10 points.
Collecte conservee : `ST._valHeures` (via `_tNoterHeure` dans `trig`) et
`_delaiMin` des bilans de sanction (non affiche pour l instant).
Teste a 360 et 430 px : etat vide et donnees fictives, 4 cartes, aucune
erreur, aucun debordement ; scores verifies a la main (rMEQ 18, BSCS 34).

## Donjon invisible apres une journee bouclee, 19 octobre

Bug : toutes les quetes validees, l entree dans un donjon affichait le toast
« la Porte se referme derriere toi » mais la carte ne changeait jamais.
Cause : la vue simplifiee (`renderMainDone`, drapeau `ql-nn.dataset.simplified`)
n est dessinee qu une fois ; ensuite `renderMain` ne faisait que
`_updateSimplifiedCd` et `_updateHeader` puis `return`. Le donjon etait cree
dans `ST._dungeonActive`, jamais redessine. Le mode test sautait cette vue,
d ou un affichage correct en test. Touchait aussi toute action sur la carte
donjon ou boss dans cette vue (Eclat, depli, reclamation).
Correctif : dans cette branche, `boss-zone` est redessinee a chaque
`renderMain` (`_renderDungeonCard` des le jour 7, `_renderDailyBoss` avant).

Regle tranchee par Thibs : si toutes les quetes du jour sont validees
(`allFullDone()`), le donjon commence le lendemain ; les quetes ont ete faites
hors du donjon. `_dngStartDay` renvoie alors jour+1 et `_confirmDungeon`
affiche « Tes quetes du jour sont deja validees, hors du donjon. Le donjon
commencera demain. » La regle des 11 premieres heures reste valable pour une
journee entamee mais pas bouclee.
Teste : quetes toutes validees, entree a 10 h, startDay = jour+1, carte
« Demain » affichee, aucun compteur repris.

Bloc gris « Nouvelles quetes dans ... - A demain. » supprime de la vue
simplifiee (`renderMainDone` et `_updateSimplifiedCd`) ; seul le bandeau vert
reste.

## Bouclier = Accomplie, et fond du curseur de creneau, 19 octobre

Regle (Thibs) : un jour sous bouclier, toutes les quetes comptent comme
« Accomplie » partout (donjon, stats). L affichage « Bouclier » reste sous
les quetes.
Bug : le statut `shield` n etait jamais compte par le donjon (les compteurs ne
montent que via `_dngTrack` a la validation) ; les cibles devenaient
impossibles et passaient « manquee ».
Correctif :
- `_dngBouclier()`, appelee en tete de `_dungeonProgress` : une fois par jour
  (`act._bouclierJour`), credite chaque quete du jour comme Accomplie (total,
  perfect, axe, secondaires, eau, leve-tot) sauf celles deja comptees
  (`act._vus`, liste du jour tenue par `_dngTrack`), puis vide `_manques`
  pour que les manquees soient recalculees. Un donjon deja marque manque a
  cause du bouclier se repare donc a l ouverture suivante.
- `_dayIsPerfect`, `perfCount` du bilan et la condition « Jour parfait »
  acceptent `shield` comme `perfect`.
Teste : bouclier le jour 2, Body et Discipline marques manques ; apres
credit, Body 2/7, Discipline 2/7, Leve-tot 5/10, aucune manquee, credit non
double au second appel.

Parametres, creneau actif : fond du bloc `.cr-bloc` passe de `#F2C75C` a
`var(--gold-bg)`, la couleur de la pastille « Xh restantes aujourd hui ».

## Onglet Tests, premier tri de Thibs (19 octobre, 11 h)
- Retire : « Du matin ou du soir ? » (`_tChrono`, `_T_Q.chrono`). Les
  reponses deja donnees restent dans `ST._chrono`, inutilisees.
- Remis depuis la v1 : « Prochains paliers » (`_tPaliers`) et « Obstacles
  recurrents » avec le plan si-alors (`_tObstacles`, `_T_OBST`,
  `_tPlanEnregistrer`, `ST._planSiAlors`).
- Ordre : paliers, conditions de reussite, ressenti du matin, obstacles,
  maitrise de toi.
- Question ouverte de Thibs : a quoi sert d enregistrer le plan ? Pour
  l instant il n est que conserve et reaffiche dans la carte ; aucune autre
  partie de l app ne s en sert. Pistes proposees : le rappeler dans le bilan
  du soir quand l obstacle ecrit tombe dans la meme categorie, ou dans le
  rappel du matin.
Teste a 360 px : 5 cartes, aucune erreur, aucun debordement.

## Declics et boost, 19 octobre (apres-midi)

Cap fixe par Thibs : les Stats avancees deviendront payantes (version Pro).
Elles doivent creer des declics : visuels, compris en 2 secondes, textes
personnalises tires des habitudes reelles. Pas de module « parce qu il en
faut ». Le paiement (abonnement Google Play) reste un chantier a part.

### Fil de declics (onglet Tests, en tete)
`_renderDeclics()` appelle dix fonctions `_d*`. Chacune renvoie null (rien
de net) ou `{s:score, h:html}` ; le fil trie par score et liste a la fin
ceux qui attendent des donnees. Carte commune `_dCarte` : etiquette, phrase
en gras, visuel, « Ce que ca veut dire ». Les alertes passent toujours en
tete (score 300 pour le seuil, 250 pour le motif actif).
Identite d une quete : `_dKey(nom)` (avant « : », sans chiffres ni unites),
nom affiche `_dNomK` (celui du jour si la quete est au programme).
1. `_dSeuil` : series cassees (bouclier neutre), zone = quartiles 25-75 des
   longueurs, 3 ruptures minimum. Dans la zone : alerte avec le texte de
   Thibs et la quete qui tombe le plus souvent le jour de la rupture.
   Visuel : barres des 11 dernieres series, zone en rouge, serie en cours.
2. `_dDomino` : obligatoires seulement (les secondaires passees noyaient
   l effet). Lien affiche si l ecart atteint 25 points ; 8 occurrences et 3
   echecs minimum. Visuel : la quete au centre, ses liens.
3. `_dMotif` : 5 signaux testes dans les 2 jours avant chaque journee ratee
   (En partie, matin « Pas bien », pas de bilan, secondaire passee, energie
   <= 2). Retenu si present avant 50 % des chutes et 25 points au-dessus des
   jours reussis. S il est present dans les 2 derniers jours : alerte.
4. `_dMoteur` : premiere quete validee du jour (`ST._valHeures`, collecte
   depuis le 19 octobre) et taux de journees bouclees ; 4 jours par type.
5. `_dEvite` : secondaire la plus passee sur 90 jours, 45 % minimum et 20
   points au-dessus des autres.
6. `_dCout` : jours pour retrouver une journee reussie apres un ecart,
   premiere moitie des ecarts contre la seconde ; 30 jours et 6 ecarts.
7. `_dMots` : mots des champs `relapse` et `block` des bilans, jours rates
   contre jours reussis ; 4 bilans rates minimum, 20 points d ecart.
8. `_dEffet` : jours de donjon contre hors donjon. Nouvelle collecte
   `ST._dngJours` (via `_dDngNoterJour` dans `_dungeonProgress`), donc vide
   au depart.
9. `_dProfil` : archetype tire des donnees (Marathonien, Phenix,
   Intermittent, Sprinteur, Batisseur) et 4 axes : endurance, rebond,
   regularite, constance. 30 jours minimum.
10. `_dBoost` : rappel du boost du jour.
Les anciens modules restent dessous, sous « Modules precedents ».

### Boost x4 (idee de Thibs)
`_boostDuJour()` : une fois par jour (`ST._boost`), parmi les obligatoires et
secondaires du jour hors Hard Mode, la quete la plus ratee ou passee sur 90
jours (4 occurrences et 40 % minimum). `_estBooste(q)` : pas de cumul avec
Hard Mode ni De du Destin. Carte : bordure, bandeau « Boost x4 », phrase de
Thibs, XP et points affiches x4. `trig` : XP et points x4 sur Accomplie
seulement (choix a confirmer par Thibs, « En partie » n est pas booste).
Teste : secondaire boostee 3 XP et 1 pt deviennent 12 et 4 ; une autre
quete garde son gain normal.

Teste a 360 et 393 px sur 160 jours fictifs (`pw/gen.js` du scratchpad) :
les dix declics s affichent, aucune erreur, aucun debordement.

## Onglet Tests, version 3 : tri et garde-fous, 19 octobre

Tri de Thibs : restent seuil de rupture, effet domino, quete-moteur, ce qui
marche sur toi (donjon), profil, maitrise de toi (BSCS). Tout le reste est
supprime du code (motif, evitement, mots, cout d un ecart, carte du boost,
paliers, obstacles, ressenti, conditions). Le boost x4 sur les quetes reste.

Critique de Thibs : des constats faux ou absurdes (domino sur « eteindre son
telephone apres 22h30 », quete jouee apres les autres ; « Pas d alcool » donne
comme quete qui casse les series pour 3 ruptures sur 48). Il veut des regles
universelles, pas des cas particuliers. Garde-fous communs (en tete du code) :
1. Minimum de donnees par declic.
2. Ecart reel : test de deux proportions `_dZ`, `_dNet` si |z| >= 1,96.
3. Comparaison a la propre base du joueur, jamais un chiffre brut.
4. Ordre dans la journee : `_dHeuresK()` donne l heure mediane de
   validation par quete (5 validations minimum). Nouvelle collecte : `k`
   (cle de quete) ajoute a `ST._valHeures` par `_tNoterHeure`.
5. Conseil faisable : `_dTardive` (mediane a 11 h ou plus apres le debut du
   creneau) remplace « valide-la tot » par « decide des le matin comment tu
   vas la tenir ».
Changements :
- Seuil : risque de casser par jour de serie (ruptures a L / series ayant
  atteint L), fenetre de 2 a 4 jours ou ce risque est nettement plus haut
  qu ailleurs (z >= 1,96, 3 ruptures et 5 series exposees minimum). La carte
  montre les deux taux. Quete nommee seulement si elle tombe dans 40 % des
  ruptures au moins ET nettement plus que les autres jours ; sinon l alerte
  dit « rater une journee ». Alerte des le jour lo-1 (jamais avant le jour 1).
- Domino : une source ne compte que les obligatoires validees au moins 1 h
  apres elle ; sans heures connues, pas de domino (il apparaitra apres 5
  validations par quete). Ecart de 20 points et z >= 1,96.
- Quete-moteur et effet du donjon : ecart soumis au meme test.
Correctif 14 h : textes du seuil en « apres X a Y jours de serie » (plus de
« le 1e jour ») ; compte a rebours = lo - serie, « demain » a 1 (plus de
« dans 0 jour »). Rappel : la zone porte sur tout l historique ; une longue
serie ne compte qu une fois par jour de serie atteint, elle ne deplace pas
la zone si les ruptures courtes dominent.
Seuil pondere et reglable (19 octobre, 14 h) : `_dZone(R,cur,mode)` calcule
la zone, `_dPoids` donne le poids d une rupture selon `ST._seuilMode` :
'pondere' (defaut, demi-vie 180 jours : moitie a 6 mois, quart a un an),
'6m' (180 derniers jours seulement), 'tout' (historique a egalite). Les
minimums (3 ruptures, 5 series exposees) portent sur les vrais effectifs, le
test z sur les sommes ponderees. Hors mode 'tout', la zone est aussi calculee
sur tout l historique : si elle differe, la carte dit si elle recule (progres)
ou avance. Selecteur de 3 boutons sous la carte (`_dSeuilReglage`,
`_dSeuilMode`) ; si un mode choisi ne donne rien de net, la carte reste
affichee avec le selecteur, pour pouvoir revenir.
Teste : historique ancien 5-6 jours, recent 9-10 jours ; pondere et 6 mois
donnent 9 a 10 jours avec « ta zone recule », tout l historique donne 5 a 6.
Teste a 360 et 393 px sur 160 jours fictifs, dont le cas « Pas d alcool »
(non designee) : seuil, domino, moteur, profil et maitrise s affichent ;
« ce qui marche sur toi » ecarte (91 % contre 77 % sur 33 jours, non
significatif). Boost x4 reverifie.

## Formulation des declics : les quatre pieges, 19 octobre (15 h)

Demande de Thibs : revoir la formulation pour eviter (1) le pourcentage
d echec qui devient une excuse, (2) l effet « au point ou j en suis » apres
une rupture, (3) le retour centre sur la personne plutot que sur l action,
(4) la fatigue d alerte. Pas de recompense pour l instant (decision de Thibs).
Regle : jamais de pourcentage d echec affiche ; toujours une preuve que c est
faisable (tire de l historique du joueur) et une action.
- Seuil : les cases « risque de casser X % / le reste du temps » deviennent
  « jour N, ton cap a franchir (ou cap franchi) » et « deja franchi K fois ».
  Alerte reformulee : « Attention : nous avons analyse tes habitudes. Tu
  entres dans ta zone de rupture, la ou tes series s arretent le plus
  souvent. Sois vigilant, et donne tout pour passer ce seuil ! » (la fin est
  le texte de Thibs ; « predire que tu vas rater X » est retire, c etait le
  piege 1). Quete nommee : « La quete qui fait la difference a ce moment-la »,
  sans pourcentage. Nouvel etat juste apres une rupture dans la zone (jusqu a
  2 jours) : « Ta serie s est arretee au jour N. Ca ne dit rien de la
  prochaine », avec le rebond (« tu repars le lendemain X fois sur 10 ») et
  le rappel du cap deja franchi. Evolution negative tournee vers l action.
- Seuil, calcul : taux ponderes, marge d erreur sur les vrais effectifs (sans
  cela 18 ruptures pesaient comme 10). Choix de la fenetre : la plus forte
  hausse de risque parmi les fenetres nettes. Mode par defaut sans resultat :
  repli sur tout l historique, signale dans la carte.
- Domino : formule en reussite (« Quand tu valides X, tes obligatoires
  suivantes tiennent A %. Quand elle manque : B % »), schema en vert, chaque
  lien montre « tient N % » quand la source est validee.
- Profil devient « Ta dynamique du moment » : 120 derniers jours seulement,
  phrases en « Ces derniers mois, tes series... », conseils « X est acquis.
  Prochaine marche : ... ».
- Maitrise de toi : verdicts sur les quetes, plus « tu te juges plus maitrise
  que tu ne l es ».
Teste : serie juste cassee, 0, 1, 2 et 5 jours ; historiques fictifs ;
domino, dynamique, maitrise ; boost x4 reverifie.

## Stats reorganisees et abonnement Pro, 19 octobre (fin d apres-midi)

### Nouvelle organisation de #Stats
Trois onglets : Vue generale, Automaticite, Insights (PRO). L onglet Tests
n existe plus.
- Automaticite : la courbe de Lally est dans le bloc jaune du score ;
  « Progression par phase » supprime (le rendu ecrit dans un objet vide si
  `#st2-phases` manque) ; « Detail par axe » est dans la carte de la toile
  d araignee ; puis Meilleur jour / Jour faible ; puis Historique des bilans.
- Insights : analyse hebdomadaire, puis les declics et la maitrise de toi
  (`#st-tests-body`, rendu par `_renderTests()` a l ouverture d Insights),
  puis Time Capsule, correlation Energie x Reussite, methodologie.
- Tout le contenu d Insights est dans `#st-insights-contenu`, precede de
  `#st-pro-verrou`.

### Abonnement Metanoia Pro (decisions de Thibs)
RevenueCat ; mensuel 2,99 EUR et annuel 19,99 EUR, 7 jours d essai gratuit ;
Insights reserve aux abonnes ; tout le reste de l app reste gratuit.
Plugin : `@revenuecat/purchases-capacitor` 13.7.4 (Capacitor 8), installe et
synchronise (`npx cap sync android`). Le plugin est appele directement par
`Capacitor.registerPlugin('Purchases')`, sans bundler.
Code (avant `stTab`, prefixe `_pro`) :
- `PRO_CFG` : cle API Android RevenueCat (`goog_A_REMPLIR`), identifiant du
  droit (`pro`), URL des conditions et de la confidentialite, prix de repli.
- `estPro()` : seule fonction a consulter pour savoir si le joueur est Pro.
  Lit le cache `ST._pro` (fin de droit respectee, 3 jours de grace hors
  ligne) ; en mode test, `ST._proTest` (bouton « Pro on/off » du panneau).
- `_proInit()` au chargement : configure RevenueCat, ecoute les changements
  de droit, lit le droit, charge l offre. `_proIdentifier()` relie l achat au
  compte Metanoia (`logIn` avec l id Supabase) a chaque connexion.
- `_proMaj(customerInfo)` : seule ecriture de `ST._pro`. Un import de
  sauvegarde efface `_pro` et `_proTest` : le statut vient de la boutique.
- Ecran `#s-pro` (Parametres > Abonnement) : `_proRendre()`. Non abonne :
  atouts, choix annuel (par defaut, badge -44 %) ou mensuel, prix et essai
  lus dans la boutique (repli sinon), bouton d essai, restauration, mentions
  legales de renouvellement. Abonne : statut, date de renouvellement ou de
  fin, « Voir mes Insights », « Gerer mon abonnement » (page Google Play).
- `_proAcheter()`, `_proRestaurer()`, `_proGerer()`. Annulation par le joueur
  : silencieuse. Echec : message, aucun prelevement. Boutique absente :
  message clair (hors mode test, ou le bouton active Pro sans paiement).
- `_proVerrou()` : Insights floute, carte cadenas avec accroches
  personnalisees (nombre de declics deja calcules, alerte en cours, zone de
  rupture masquee) ; tout tap ouvre l ecran Pro ; pastille PRO sur l onglet.
- Parametres : section « Abonnement » en tete, statut dans `#set-pro-sub`.
Teste a 360 et 393 px : verrou, tap vers l ecran Pro, achat hors boutique
(message), droit RevenueCat simule actif (deverrouillage, statut, date),
puis expire (reverrouillage), parametres.
Non teste ici : le vrai paiement (il faut le compte Google Play et RevenueCat).

### Mise en service de Pro (a faire par Thibs, dans l ordre)
1. Apres avoir dezippe le depot : `npm install` puis `npx cap sync android`
   (le module Android du plugin est dans node_modules, exclu de l archive).
2. Google Play Console : creer le compte developpeur (25 $), creer l app
   `com.metanoia_app`, envoyer un premier AAB signe sur le canal de test
   interne (les abonnements ne se creent qu apres un premier envoi).
3. Play Console > Monetiser > Abonnements : creer `metanoia_pro`, avec deux
   forfaits de base : `mensuel` (P1M, 2,99 EUR, renouvellement auto) et
   `annuel` (P1Y, 19,99 EUR). Sur chacun, une offre « essai gratuit » de
   7 jours (eligibilite : nouveaux clients). Activer.
4. Play Console > Parametres > Profil de paiement (compte marchand) rempli,
   sinon rien ne se vend.
5. RevenueCat (app.revenuecat.com) : creer le projet, ajouter l app Google
   Play (`com.metanoia_app`), et lui donner l acces au compte de service
   Google (guide RevenueCat « Google Play service credentials »).
6. RevenueCat > Product catalog : importer les deux produits ; creer
   l entitlement `pro` et y rattacher les deux ; creer l offering `default`
   (courante) avec les paquets `$rc_monthly` et `$rc_annual`.
7. RevenueCat > API keys : copier la cle publique Google (`goog_...`) dans
   `PRO_CFG.cleAndroid`. Renseigner `PRO_CFG.urlConfidentialite` (exigee par
   Google pour vendre) et `PRO_CFG.urlConditions`.
8. Tester avec un compte « testeur de licence » (Play Console > Parametres >
   Test de licence) : achats gratuits, renouvellements acceleres.

## Seuil de rupture : retour des pourcentages, 19 octobre (15 h 30)
Thibs prefere les pourcentages et les phrases preventives. Les cases
redeviennent « X % risque de casser chaque jour dans la zone / Y % le reste
du temps ». Trois niveaux d alerte :
- serie a 1 ou 2 jours de la zone : « Attention, tu vas rentrer dans une
  phase compliquee pour toi : des demain (ou dans 2 jours), ta serie entre
  dans ta zone de rupture. » (score 290) ;
- dans la zone : « Attention, tu es dans une phase compliquee pour toi :
  c est ici que tes series cassent le plus souvent. Sois vigilant, et donne
  tout pour passer ce seuil ! » (score 300) ;
- plus loin : « Ta prochaine phase compliquee : dans N jours. »
Les textes d explication donnent les deux pourcentages. Conserves : message
de rebond apres une rupture, « deja franchi K fois », quete qui fait la
difference, cap franchi (avec le pourcentage hors zone).

## Analyse de la semaine redigee par IA (option C), 19 octobre (16 h)

Principe : le telephone calcule tous les faits (aucun chiffre laisse a
l IA) ; une IA les met en mots via une fonction Supabase, une fois par
semaine ; sinon le moteur local redige la meme trame. Decision de Thibs :
option C (hybride), modele par defaut Claude Haiku 5.5, fournisseur
interchangeable.

### Cote app (dans `www/index.html`, avant `stTab`, prefixe `_hebdo`)
- Semaine analysee : la derniere semaine de programme close
  (`getWk()-1`, jours (W-1)*7+1 a W*7). Avant la premiere semaine close, les
  anciens constats de la semaine en cours restent affiches.
- `_hebdoFaits(W)` : jours (statut de chaque quete, humeur du matin,
  energie, obstacle et rechute du bilan, 140 caracteres au plus), jours
  reussis, part Accomplie, plus longue suite, moyennes des 4 semaines
  d avant, quete la plus solide et la plus fragile (obligatoire d abord),
  jour faible habituel (test z), declics actifs (seuil, domino, moteur),
  zone de rupture. Environ 5 Ko.
- `_hebdoLocal(F)` : redaction locale en 5 temps (verdict, ce qui a
  marche, ce qui a coince, ce qui change, la semaine qui vient + si/alors).
- `_hebdoObtenir(W)` : cache `ST._hebdo[W]` ({src:'local'|'ia', a, date,
  essai}), 26 semaines gardees ; demande l IA si Pro + consentement +
  session Supabase + en ligne, au plus une tentative toutes les 6 h.
- `_hebdoRendre()` dans `#st2-insights-list` (appele par `_renderTests`) :
  consentement unique en tete (`ST._hebdoIA`), carte de la semaine, mention
  « Redigee par l IA » ou « Redigee sur ton telephone », archive repliable.
  Tout texte (IA comprise) est echappe a l affichage : teste avec une
  balise piegee, rien ne s execute.
- Ecran Abonnement (abonne) : interrupteur « Redigee par l IA ».

### Cote serveur (nouveau dossier `supabase/`)
- `supabase/functions/analyse-hebdo/index.ts` : verifie la session, la
  taille de la demande, renvoie l analyse deja redigee si elle existe,
  verifie l abonnement aupres de RevenueCat (si `REVENUECAT_SECRET`),
  plafonne a 3 analyses par 7 jours et par joueur, appelle l IA, valide le
  JSON (6 cles), retire tirets longs et balises, enregistre, renvoie.
  Fournisseurs : `anthropic` (defaut) ou toute API compatible OpenAI
  (Mistral, Groq, OpenRouter, Ollama...) via `IA_URL`.
- `supabase/migrations/20261019_analyses_hebdo.sql` : table
  `analyses_hebdo` (user_id, semaine, contenu, modele, created_at), RLS en
  lecture sur ses propres lignes, ecriture par la seule cle service,
  suppression avec le compte.
Syntaxe TypeScript verifiee (esbuild). Non execute ici : il faut le projet
Supabase et une cle IA.

### Mise en service de l analyse IA (Thibs)
1. console.anthropic.com : creer une cle API (et un plafond de depense).
2. Supabase > SQL Editor : executer
   `supabase/migrations/20261019_analyses_hebdo.sql`.
3. Installer la CLI Supabase, puis dans le dossier du depot :
   `supabase login`, `supabase link --project-ref <ref du projet>`,
   `supabase functions deploy analyse-hebdo`.
4. `supabase secrets set IA_CLE=sk-ant-...` ; une fois RevenueCat en place :
   `supabase secrets set REVENUECAT_SECRET=sk_...`. Facultatif :
   `IA_MODELE` (ex. `claude-sonnet-5-5` pour un style plus riche),
   ou `IA_FOURNISSEUR=openai` + `IA_URL` + `IA_CLE` pour un autre
   fournisseur (verifier alors ses conditions d usage des donnees : le texte
   de consentement promet qu elles ne servent pas a l entrainement).
5. Cout indicatif (tarifs octobre 2026) : environ 3 000 jetons en entree et
   800 en sortie par analyse ; Haiku 5.5 moins de 0,1 centime, Sonnet 5.5
   environ 1,4 centime.

## Masquage Pro « vicieux », 19 octobre (17 h 30)
Demande de Thibs, pour les joueurs sans abonnement uniquement :
- plus de pastille PRO sur l onglet Insights ; plus de flou ni de carte
  cadenas globale (`#st-pro-verrou` reste vide) ;
- chaque module garde sa forme et son graphe, sans aucune valeur, avec une
  accroche et un bouton « Decouvrir » qui ouvre l abonnement.
Code :
- `_PRO_ACC` : accroche par module (cle = etiquette de la carte). Seuil :
  texte de Thibs « Nous avons analyse ou et quand tu echoues. Decouvre
  pourquoi, et ce que dit la psychologie ! ».
- `_dCarte` renvoie `_proTeaser` si `!estPro()` : etiquette, accroche,
  visuel passe par `_proSansValeurs` (chiffres remplaces par « .. »,
  elements `.pro-val` (noms de quetes du domino, nom du profil) remplaces,
  infobulles retirees), bouton `_proBouton()`.
- Maitrise de toi : courbe de population sans position, accroche, bouton.
- Analyse de la semaine : verdict remplace par une accroche, sections avec
  lignes grises a la place du texte.
- Time Capsule et Correlation : `_proMasquerBloc` efface les chiffres en
  place et ajoute une accroche avec bouton au-dessus (rappele apres le rendu
  synchrone de `renderStats`).
- Tout tap dans Insights ouvre l abonnement (capture inchangee).
Teste a 360 px : 8 boutons, aucun chiffre hors numero de semaine et dates
des references ; clic vers l abonnement ; une fois abonne, tout reapparait.

## Offre annuelle : cout par jour, 19 octobre (18 h)
Choix de Thibs : la carte Annuel affiche le cout par jour, plus par mois.
`_proPrix` renvoie `parJour` : prix boutique / 365, en centimes sous 1 EUR
(arrondi, 1 centime minimum), sinon avec deux decimales et la devise.
Repli `PRO_CFG.repli.annuelParJour` : « 5 centimes ». Teste : repli, boutique
a 19,99 EUR (« soit 5 centimes par jour »), boutique en USD (« 0,08 USD »).

## Onglets de #Stats : Insights au centre et en vedette, 19 octobre (18 h)
Ordre : Vue generale, Insights, Automaticite. Insights (classe `st-vedette`,
contenu `.st-vedette-in`) : pastille doree, police plus grande, reflet qui
passe toutes les 3,2 s (coupe si l appareil demande moins d animations).
Arrivee sur #Stats depuis un autre ecran : toujours la Vue generale (debut de
`nav`). Retour de l ecran Abonnement ouvert depuis Insights : on revient sur
Insights (`_proFermer`). Teste : arrivee, Insights, aller-retour Quetes,
retour d Abonnement.

## Lot du 19 octobre (18 h 10) : masquage, Lally, Insights
- Masquage contourne : `renderStats` remplissait `#st2-insights-list` avec
  les anciens constats en clair apres le masquage. Il rappelle maintenant
  `_hebdoRendre()` juste apres. Teste : Insights ouvert sans abonnement,
  rafraichissement des Stats, aucun constat brut, 8 boutons.
- Lally : la maturation utilisait l index dans `dayLog` (borne a 400
  entrees). Au-dela de 400 jours, la courbe refaisait une fausse montee depuis
  la phase 1 et les etiquettes Phase 1 / Phase 2 se chevauchaient a gauche.
  Maturation et bornes de phases sur le vrai numero de jour ; etiquette
  affichee seulement si sa phase fait 30 px au moins. Mesures : 400 jours
  parfaits finissent a 95, 30 derniers jours rates a 0 (comportement voulu :
  regularite x maturation), 4 jours sur 5 a 76, debutant parfait au jour 40
  a 70.
- Detail par axe : cases Body / Mind / Disc avec bordure de couleur 2 px et
  fond teinte.
- Insights : titre « Tes declics » et sa description supprimes ; message
  « Rien de net pour l instant » supprime.
- Nouveau bloc `#st2-attente` sous la correlation (`_attenteRendre`) :
  sablier anime, « N indicateurs attendent plus de donnees », leurs noms,
  barre de progression (indicateurs disponibles / 5), « Ils se debloquent
  d eux-memes au fil de tes journees ».

## Retour sur Quetes apres deconnexion, 19 octobre (18 h 20)
Signale par Thibs : apres une deconnexion, l app ne rebasculait plus sur
Quetes. Non reproduit en navigateur (ouverture par l engrenage, confirmation,
synchro simulee : retour a 1,2 s, un seul ecran actif, aucune erreur).
Durci quand meme : `settingsLogout` appelle `_versQuetesApresDeco()` a 0,6 s
puis 1,6 s. La fonction ne fait rien si Quetes est deja le seul ecran actif ;
sinon elle tente `nav('s-main')`, puis force l etat a la main (ecrans,
barre du bas, `renderMain`) si `nav` a echoue. Teste avec `nav` volontairement
casse : retour sur Quetes quand meme.

## Retour direct sur Insights, sans flash de la Vue generale, 19 octobre (18 h 25)
Avant : le retour de l abonnement passait par `nav('s-stats')` (qui remettait
la Vue generale) puis cliquait Insights 30 ms plus tard : un battement de cil
de Vue generale visible (captures de Thibs).
Maintenant : `_allerInsights()` pose `window._statsOngletVoulu='st-insights'` ;
`nav` lit cet onglet et l active AVANT d afficher l ecran, puis l oublie.
Utilise par `_proFermer` (origine stats), « Voir mes Insights » (ecran
abonne) et l ecran « Bienvenue dans Pro ». Arrivee normale sur #Stats :
toujours la Vue generale. Teste trame par trame (requestAnimationFrame et
MutationObserver) : 0 trame de Vue generale sur les deux chemins.

## Insights masque, version sobre, 20 octobre
Thibs trouvait la page masquee trop « putaclic / IA ». Changements (joueurs
sans abonnement uniquement) :
- un seul bandeau en tete d Insights (`#st-pro-verrou`, `.pro-bandeau`) :
  « Insights fait partie de Metanoia Pro », essai gratuit, bouton « Voir
  l offre » ;
- plus de boutons dores « Decouvrir » : une puce « Pro » discrete
  (`_proBouton()` rend `.pro-chip`) en haut a droite de chaque carte ;
- carte : nom du module en titre, texte sobre en dessous, graphe sans valeurs ;
- textes de Thibs (orthographe seule corrigee) dans `_PRO_ACC`, l analyse
  de la semaine, Time Capsule et Correlation ; « Ce qui marche sur toi » sans
  description ; « Ta dynamique du moment » : texte factuel (aucun texte fourni) ;
- module renomme « Ton auto-maitrise » partout (carte, test, ecran Pro).
Teste a 360 px : 8 puces, 0 bouton dore, bandeau ; abonne : rien de tout ca.

## Onglet Insights, version sobre, 20 octobre
Thibs trouvait la pastille doree animee trop « putaclic / IA ». L onglet
reprend la forme des deux autres (emoji + texte, soulignement si actif) ;
seuls le texte dore (`#b8862f`) et la graisse 800, meme inactif, le
distinguent. Emoji 💡. Plus de pastille, de reflet ni d animation.

## Analyse de la semaine branchee sur Groq (gratuit), 20 octobre
Decision de Thibs : API gratuite issue du depot public-apis ; l accord de
l utilisateur est donne en prenant Pro.
- Fournisseur par defaut de `supabase/functions/analyse-hebdo` : Groq (API
  compatible OpenAI, `https://api.groq.com/openai/v1`), modele
  `llama-3.3-70b-versatile`. Seul le secret `IA_CLE` est obligatoire.
  Sortie JSON forcee (`response_format: json_object`), redemande sans si le
  fournisseur refuse (400) ; quota gratuit atteint (429) : erreur, l app
  garde la redaction locale et reessaie 6 h plus tard.
- Pourquoi Groq : offre gratuite, ne conserve pas les donnees d inference
  par defaut (journaux possibles 30 jours). Mistral ecarte : son offre
  gratuite « Experiment » peut utiliser les requetes pour entrainer ses
  modeles. Limites gratuites relevees (octobre 2026) pour ce modele : environ
  1 000 requetes et 100 000 jetons par jour, soit une vingtaine d analyses
  par jour ; au-dela, passer sur un modele moins gourmand ou payant (changer
  `IA_MODELE`, ou `IA_FOURNISSEUR=anthropic`).
- App : plus de carte de consentement ; l IA est active par defaut pour les
  abonnes (`ST._hebdoIA!==false`), desactivable dans Abonnement (texte :
  envoi a un service d IA externe). Mention ajoutee aux conditions affichees
  avant la souscription.
Mise en service : console.groq.com > API Keys > creer une cle, puis
`supabase secrets set IA_CLE=gsk_...` et `supabase functions deploy
analyse-hebdo` (plus la table SQL si pas encore faite).
A faire avant publication : ecrire cette sous-traitance dans la politique de
confidentialite (exigee par Google Play).

## Bouton « Pro » du mode test, 20 octobre
Le bouton existait (« Pro on/off ») ; il affiche maintenant son etat
(« Pro : active / desactive », `#test-pro-btn`, `_testProLib`) et
`_testBasculerPro()` force l etat dans les deux sens : en mode test,
`estPro()` renvoie `ST._proTest` des qu il est defini, meme si un vrai
abonnement est actif. Redessine aussitot Insights, Stats, Parametres et
l ecran Abonnement. Hors mode test, `ST._proTest` est ignore.
Teste : 1 clic active (puces et bandeau disparaissent, analyse visible),
2e clic desactive, vrai abonnement coupe par le bouton.

## Analyse IA : chaine de secours et nouvelles consignes, 20 octobre (21 h 30)
Remplace la section « branchee sur Groq » pour la configuration (les
variables `IA_FOURNISSEUR` / `IA_URL` / `IA_MODELE` n existent plus).

### Chaine de secours (`supabase/functions/analyse-hebdo/index.ts`)
Les maillons sont essayes dans l ordre ; un maillon sans cle est saute. On
passe au suivant sur : quota epuise (429), panne (5xx), delai de 25 s
depasse, reponse non JSON, ou chiffre absent des faits.
1. Groq `openai/gpt-oss-120b` (secret `GROQ_CLE`, ou `IA_CLE`)
2. Groq `qwen/qwen3.8-27b` (meme cle, quota separe par modele, preview)
3. Cerebras `gpt-oss-120b` (`CEREBRAS_CLE`)
4. OpenRouter `meta-llama/llama-3.3-70b-instruct:free` (`OPENROUTER_CLE`)
5. Groq `openai/gpt-oss-20b` (dernier recours gratuit, plus faible)
6. Anthropic `claude-haiku-5-5` (`ANTHROPIC_CLE`, payant, facultatif)
Gemini ecarte par defaut : son offre gratuite peut utiliser les requetes
pour ses produits hors UE. `IA_CHAINE` (JSON) remplace l ordre si besoin.
Le modele qui a redige est enregistre dans `analyses_hebdo.modele` ; les
echecs de la chaine sont journalises (`console.warn`) dans les logs de la
fonction. Tous echoues : 502, l app garde sa redaction locale.
Garde-fou anti-invention (`chiffresHonnetes`) : tout pourcentage, decimal
ou nombre superieur a 31 ecrit par l IA doit exister dans les faits ; sinon
maillon suivant. « si_alors » vide s il n a pas la forme « Si ..., alors je ».
Teste sous Node avec des fournisseurs simules : 429, puis texte non JSON,
puis « 87 % » invente, puis reponse correcte retenue (OpenRouter) ;
2e demande servie depuis la base sans appel ; tout en panne : 502.

### Consignes (`supabase/functions/analyse-hebdo/consignes.ts`)
Le jeu en bref (glossaire), ce que le modele recoit, l objectif (« une chose
vraie apprise sur soi + quoi faire la semaine prochaine »), une methode en 5
etapes (fait marquant, explication tiree des faits seulement, suivi de la
priorite precedente, UNE action par ordre de priorite : zone de rupture,
quete obligatoire fragile, jour faible, consolider ; plan si/alors relie a
l obstacle ecrit), regles de fond (chiffres tels quels, pas de cause
inventee, semaine parfaite / difficile, citer ses mots, parler des actes pas
de la personne), regles de forme (60 mots par champ, formules creuses
interdites), exemples bon / mauvais, format JSON, verification finale.

### Cote app
`_hebdoFaits` ajoute `priorite_semaine_precedente` (l action de l analyse
precedente) et `semaine_precedente` (jours reussis), pour que le coach dise
si la priorite a ete tenue.

### Mise en service
Au minimum : `supabase secrets set GROQ_CLE=gsk_...` (console.groq.com).
Pour plus de marge, gratuits aussi : `CEREBRAS_CLE` (cloud.cerebras.ai),
`OPENROUTER_CLE` (openrouter.ai). Puis `supabase functions deploy
analyse-hebdo` (le dossier contient 2 fichiers, deployes ensemble).
Les noms de modeles changent souvent : les verifier dans chaque console en
cas d erreurs 404 dans les logs.

## Analyse de la semaine : 3 mois de recul (20 octobre 2026)

Une semaine seule ne dit presque rien. L analyse lit maintenant la semaine a
la lumiere des 90 derniers jours, et cherche pourquoi chaque echec a eu lieu.

### Les faits (`_hebdo90(W)`, cle `trois_mois` de `_hebdoFaits`)
Absent (null) sous 21 jours d historique. Sinon, calcule sur les 90 jours
qui finissent avec la semaine analysee (boucliers exclus) :
- `reussite_90j_pct` contre `reussite_semaine_pct`, `part_accomplie_90j_pct` ;
- `semaines` : jours reussis des 13 dernieres semaines (tendance) ;
- `par_jour_de_semaine`, `quetes` (8 au plus, 10 occurrences minimum :
  reussite sur 90 jours contre cette semaine), `humeur_du_matin` (5 jours
  minimum par humeur), `energie_du_soir` (basse 2 ou moins contre haute 4
  ou plus, avec `net` = test z) ;
- `mots_des_jours_rates` : mots des bilans (obstacle, rechute) presents
  dans 3 jours rates au moins, avec 20 points d ecart ou plus contre les
  jours reussis (mots vides ecartes, `_H_STOP`) ;
- `patterns_d_echec` (4 au plus) : signaux `_H_SIGNAUX` mesures dans les 2
  jours AVANT chaque journee (quete en partie, matin « Pas bien », soir sans
  bilan, energie 2 ou moins, secondaire passee, echec la veille), plus les
  jours de la semaine. Garde seulement si 5 occasions minimum de chaque
  cote, 15 points d ecart ou plus ET z 1,96 ou plus. Pas de bruit envoye.
- `anatomie_des_echecs_de_la_semaine` : pour chaque jour rate, quetes
  tombees, humeur, energie, obstacle, serie juste avant, dans la zone de
  rupture ou non, signaux des 2 jours avant, et lesquels sont ses patterns.
Taille des faits sur 160 jours fictifs : environ 8 600 caracteres (limite
serveur 24 000).

### Serveur
Nouvelle cle facultative `fond` (« Sur 3 mois »), forcee a vide quand
`trois_mois` est absent. Le garde-fou des chiffres couvre les nouveaux
champs. Consignes : explication des nouveaux champs ; etape 2 = pourquoi
chaque echec, d abord via l anatomie et les patterns ; comparaison a la
norme des 3 mois ; nouvelle priorite d action « couper le pattern le plus
fort » (apres la zone de rupture) ; exemples bon / mauvais « fond ».
Teste sous Node : `fond` garde avec 3 mois, vide sans, chiffre invente
rejete.

### Redaction locale (sans IA)
`coince` dit aussi pourquoi (« Mardi a ete precede d une quete validee
seulement en partie : chez toi, ce signal fait passer l echec de 3 % a
24 % »), ou a defaut signale un echec tombe en zone de rupture. `fond` :
le pattern le plus net, sinon une quete qui decroche, sinon un mot qui
revient, sinon « aucun schema fixe », puis la semaine contre la norme.
L action vise le pattern le plus fort quand la zone de rupture n est pas
proche. Espaces insecables avant « : » et « % ».

### Carte
Nouveau bloc violet « Sur 3 mois » (◷) entre « Ce qui change » et « Ta
semaine qui vient », affiche seulement s il a du contenu. Les analyses
deja en cache gardent leur forme jusqu a la semaine suivante.

## Analyse de la semaine : diagnostic IA (20 octobre 2026)

Sous la carte, pour l admin (ou en mode test) et seulement quand la
redaction est locale, une ligne rouge « Admin, IA : ... » dit pourquoi
l IA n a pas redige (`_hebdoDiag`) : pas Pro, IA desactivee dans
Abonnement, Supabase non initialise, non connecte au compte, hors ligne,
ou la reponse du serveur (« HTTP 502 : redaction », « HTTP 401 : non
connecte », « HTTP 402 : abonnement », « HTTP 429 : limite », 404 si la
fonction n est pas deployee). Bouton « Relancer » (`_hebdoRelancer`) :
redemande tout de suite, sans attendre le delai de 6 h entre deux essais.
Teste : erreur 502 simulee affichee, puis reponse IA acceptee et carte
basculee en « Redigee par l IA ».
Le serveur renvoie aussi, en cas d echec, la liste `essais` (un motif par
maillon : code HTTP du fournisseur, « JSON invalide », « chiffre absent des
faits (12 %) » avec le chiffre fautif, ou « aucune cle IA trouvee »),
affichee dans la ligne admin. `chiffresHonnetes` devient `chiffreInvente`
(renvoie le chiffre rejete). Pour copier-coller la fonction dans le tableau
de bord Supabase : `analyse-hebdo-un-fichier.ts` (consignes integrees).

## Analyse de la semaine : modeles Groq retires (20 octobre 2026)

Premier essai reel : 502, logs « llama-3.3-70b-versatile : 404 »,
« llama-3.1-8b-instant : 404 », « openai/gpt-oss-120b : 429 ». Groq a
retire les deux Llama le 16 aout 2026 (page Deprecations). Nouvelle chaine :
`openai/gpt-oss-120b` (raisonnement `low`), `qwen/qwen3.8-27b`
(raisonnement masque), Cerebras `gpt-oss-120b`, OpenRouter, `openai/gpt-oss-20b`,
Anthropic. Parametres propres au modele dans `extra`, retires si le
fournisseur repond 400. Sur 429 avec `retry-after` de 8 s ou moins : une
seconde tentative apres l attente. `max_tokens` passe de 1200 a 2000 (le
raisonnement des gpt-oss consomme des jetons avant le JSON). La cle Groq
fonctionne (pas de 401).

## Analyse de la semaine, version 2 : la voix du Systeme (20 octobre 2026)

Premier essai IA reel juge « flou, inadapte » : action tautologique (« fais
tes quetes en entier »). Causes : patterns tautologiques envoyes, IA sans
contexte sur l app ni le joueur, consignes de rapport. Refonte :

### Consignes (`consignes.ts`, reecrites)
- L IA parle comme le Systeme de Metanoia (« je »), la « main superieure ».
- « L ame de Metanoia » : texte de Thibs, tel quel (orthographe corrigee).
- Son exemple d analyse sert de modele de ton, avec deux limites : aucune
  statistique exterieure, aucune promesse de recompense.
- Methode : 2 a 4 moments (exploit, echec apres record, echec sur une
  resistance declaree, echec qui suit un schema, accident), puis le fond
  (une chose vraie sur lui, 3 mois), puis UNE action qui change une
  condition (heure, ordre, taille, ce qui precede), avec une liste de
  leviers par schema. Actions qui redisent l objectif interdites.
- Vocabulaire technique interdit (anatomie, pattern, signal, taux...).

### Sortie v2
`{verdict, moments:[{jour, type: exploit|echec|declic, texte}], fond,
action, si_alors, v:2}`. Serveur : 1 a 4 moments obligatoires, type inconnu
ramene a « declic », chiffres controles dans tous les textes.

### Faits ajoutes
- `joueur` (`_hebdoJoueur`) : reponses au questionnaire en clair (age,
  situation, sport, objectif, lecture, sommeil, ecran, resistances
  declarees, mode), jour du programme, boucliers en stock, bouclier actif.
- `trois_mois.exploits_de_la_semaine` : quete tenue cette semaine, reussie
  50 % du temps ou moins sur 90 jours (10 occurrences minimum).
- `trois_mois.rebond` : echecs suivis d un autre echec le lendemain.
- `trois_mois.heures` : heure mediane de validation de chaque obligatoire,
  habituelle contre cette semaine, glissement de 1 h 30 ou plus.
- Anatomie : `record_avant`, `serie_avant_est_un_record` (5 jours ou plus,
  au-dessus du record precedent), `resistance_concernee` (`_H_RESIST` :
  mots cles de la quete ratee croises avec les resistances declarees).
- Signaux : « en partie » et « echec la veille » retires (tautologiques),
  « validees tard » ajoute (mediane des validations obligatoires 11 h ou
  plus apres le debut du creneau).

### Carte
Bande des 7 jours dessinee par l app (✔ ✕ 🛡), puis les moments (★ Exploit,
✕ Chute, ◆ Declic, jour en titre), « Sur 3 mois », « Ta semaine qui
vient ». Les analyses v1 en cache s affichent encore avec l ancien format.
Moteur local reecrit dans le meme format et la meme voix.

### Admin : « Reecrire »
Ligne admin toujours visible pour l admin (modele utilise quand c est
l IA). « Reecrire » regenere la redaction locale puis redemande l IA avec
`forcer:true` : le serveur ignore alors son cache et la limite de 3 par
semaine, et remplace la ligne (upsert), seulement si l utilisateur est
`ADMIN_UID` (secret facultatif, sinon l UID admin de l app).
Teste sous Node : moments filtres, refus sans moment, forcer admin.

## Analyse de la semaine : les bilans du soir (20 octobre 2026)

- Correction du texte de l ame : « rate au moins une quete obligatoire »
  (et non secondaire) declenche la Sanction.
- `jours` : bilan complet (bilan fait ou non, discipline ressentie,
  resistance aux tentations, obstacle et rechute jusqu a 400 caracteres).
  La lettre a soi-meme n est jamais envoyee.
- Anatomie : `quetes_ratees_reussite_habituelle`, `bilan_du_soir` et
  `bilan_de_la_veille` (ce qui a bloque, rechute, tentations, discipline).
- `trois_mois.ses_mots_les_jours_rates_avant_cette_semaine` : les 8
  derniers bilans ecrits les soirs d echec, pour reperer ce qui revient.
- Faits passes par `_hebdoFaits0` puis garde-fou de taille 22 000
  caracteres (retire d abord les vieux bilans, puis raccourcit).
- Consignes : section « Ses bilans d abord » (ses mots priment sur les
  chiffres, les citer et y repondre, reperer une situation qui revient) et
  regle « incident » (quete reussie 75 % du temps ou plus, ratee une fois).
- Moteur local : « Tu as rate « X », que tu reussis 87 % du temps : un
  incident, pas une tendance. Ce soir-la, tu as ecrit : « ... ». »
Taille des faits sur 160 jours fictifs : environ 10 800 caracteres.

## Analyse : deux niveaux et bibliotheque de faits (20 octobre 2026)

### Deux niveaux (decision de Thibs)
- Redigee sur telephone : version allegee. Verdict, bande des 7 jours, 2
  moments au plus (l exploit, puis la chute principale : record, puis
  resistance, puis incident, puis zone, puis schema), une action. Ni « Sur
  3 mois », ni citation des bilans, ni fait exterieur, ni si/alors.
- Redigee par l IA : version complete (tout le reste, plus la bibliotheque).

### Bibliotheque de faits verifies (`bibliotheque.ts`)
29 faits sources (habitudes, plans si/alors, suivi, nouveaux departs,
echec et rechute, series, tentations, soutien social, sommeil, alcool,
ecrans, sport, froid, pornographie), chacun verifie sur sa source le 20
octobre. Fiche lisible : `bibliotheque-faits.md` (livree a part).
`choisirFaits` choisit les 6 plus utiles selon le joueur (resistances
declarees, sommeil, record, resistance touchee, rebond, heures, patterns,
noms des quetes) ; ils sont joints aux faits envoyes. Consignes : un seul
fait au plus, cite fidelement avec sa source courte, jamais d autre chiffre
exterieur. Le controle des chiffres accepte ceux de la bibliotheque (virgule
decimale geree : « 33,4 % »).

### Limite de jetons (Groq gratuit : 8 000 par minute, entree + sortie)
- Faits compacts : par jour, `quetes_accomplies` (nombre) et
  `autres_quetes` (seulement celles non accomplies). `declics` retires
  (redondants avec `trois_mois`). Garde-fou de taille a 9 000 caracteres.
  Sur 160 jours fictifs : environ 8 200 caracteres.
- `max_tokens` 1600 ; bibliotheque limitee a 6 faits.
- Fichier unique pour le tableau de bord : consignes ET bibliotheque
  integrees.

## Mode test : jours de la semaine corriges (20 octobre 2026)

En mode test, les journees avancent sans que la vraie date change : chaque
entree du journal gardait le jour reel (tout « lundi » dans la bande et les
analyses). `_dLog` renvoie desormais, en mode test seulement, une copie de
chaque journee avec le jour de la semaine recalcule depuis le calendrier de
test (`_EV_EPOQUE_TEST`, meme base que `_evDateDecalee`). Les donnees
stockees ne sont pas modifiees. Profite aussi aux declics (jour faible,
etc.) en mode test. Teste : journal force a « lundi », semaine lue mardi a
lundi, coherente avec le calendrier de test. Apres mise a jour, « Reecrire »
pour regenerer l analyse deja en cache.

## Analyse : actions faisables dans le jeu (20 octobre 2026)

Essai reel : « Reduis la quete « Prendre tous ses repas sans telephone » en
ne la faisant qu au dejeuner, en 5 minutes » et un si/alors qui reporte au
dejeuner un soir. Causes : leviers « reduire sa taille » et « version de 5
minutes » dans les consignes, aucune distinction entre quetes d action et
quetes de resistance. Consignes corrigees :
- Le Systeme impose les quetes : l IA ne change jamais une quete (pas de
  reduction, pas de duree inventee). Seul recours du jeu : valider « en
  partie » une quete d action.
- Quetes d ACTION : leviers de moment, d ordre, de preparation. Quetes de
  RESISTANCE (« sans », « pas de », « aucun ») : leviers d environnement et
  de declencheurs seulement (eloigner la tentation avant le moment a risque).
- Si/alors : declencheur concret qui arrive avant le risque, action
  immediate, jamais de report vers un moment passe ; bon et mauvais exemple.
- Un seul moment par jour (regrouper record, resistance, energie).
Moteur local : plus de « version courte » ni « version de 5 minutes » (« en
partie s il le faut ») ; quete fragile de resistance : « eloigne la
tentation avant le moment a risque ».

## Analyse : collecte par jour, contraste, comparaison (20 octobre 2026)

Methode voulue par Thibs : 1. le telephone collecte chaque jour (sac,
bilan, fatigue) ; 2. on relie aux jours rates et reussis ; 3. on compare
les quetes aux 3 mois et a la bibliotheque ; puis une solution.

### Collecte (telephone)
- `_jourInstantane` / `_jourFiger` (appele par `save`) : a la cloture d une
  journee, `dayLog[i].snap = {b: boucliers, c: cristaux de focus, r: pierres
  de renaissance, p: points, f: fatigueScore, g: getGlobalState()}`. Couvre
  toutes les facons de clore une journee. Non retroactif.
- Par jour dans les faits : `fatigue_du_systeme` (epuise, fatigue, normal,
  en forme), `etat_du_systeme`, `sac_en_fin_de_journee` (stock,
  `objets_utilises` par difference avec la veille, et pour un jour rate
  `aurait_pu_sauver_la_journee` : cristal en stock, bouclier en stock la
  veille, ou 80 points pour un bouclier 1j).
- `contraste_jours_reussis_et_rates` : energie, discipline, fatigue,
  matins « pas bien », bilans faits, tentations resistees, par groupe.
- `trois_mois.quetes` : `ecart_points` (semaine moins 90 jours) et
  `cette_semaine` (statuts groupes : « accomplie : sam dim ; ratee : mar »).

### Allegement (8 000 jetons par minute)
Champs vides retires des faits ; anatomie sans doublon avec `jours` ;
semaines limitees a 8. Sur 160 jours fictifs : environ 9 000 caracteres.
Serveur : sur un 413, la meme demande est rejouee en version courte (sans
les champs les moins utiles, 3 faits de bibliotheque).

### Consignes
Nouvelle section « Ta methode, en trois temps » (lis chaque jour, relie
aux resultats, compare), objets du sac expliques (Bouclier, Cristal de
focus, Pierre de Renaissance), etat de forme du Systeme ; un objet qui
aurait pu sauver la journee : le dire une fois, comme un conseil de jeu.
Moteur local : la chute principale mentionne un Cristal de focus ou un
bouclier qui etait dans le sac.

## Analyse : ecrire pour etre compris (20 octobre 2026)

Retour de Thibs sur deux essais reels : phrases floues (« le signal »,
« comme le montre le pattern « une energie du soir a 2 sur 5 ou moins » »),
energie du soir presentee comme cause, faux exploit (quete reussie 92 % du
temps faite « en partie »), declic vide, comparaison inventee aux autres
(« peu de participants »), fond sans direction.

### Faits rediges en clair (telephone)
- Chaque signal a une proposition en clair (`c`). `patterns_d_echec[].en_clair` :
  « Chez toi, quand la veille ou l avant-veille tu as fini la journee avec
  une energie de 2 sur 5 ou moins, la journee qui suit est ratee 36 % du
  temps, contre 13 % le reste du temps. » Le champ `signal` (etiquette) n est
  plus envoye.
- Anatomie : `ce_qui_s_est_passe_les_2_jours_avant` et
  `ce_qui_annonce_souvent_tes_echecs` (phrases completes) remplacent les
  etiquettes. Moteur local adapte.

### Consignes
Nouvelle section « Ecris pour etre compris » (regle la plus importante) :
un ami qui ne connait pas l app comprend chaque phrase ; chaque moment
raconte ce qui s est passe, ce qui l avait precede, ce que ca veut dire ;
reprendre les phrases en clair ; aucune etiquette des donnees entre
guillemets ; energie et fatigue du soir = la journee, pas la cause ;
resistances = reponses au questionnaire, pas des quetes ; exploit
uniquement depuis `exploits_de_la_semaine` ; declic seulement s il apprend
quelque chose ; aucune comparaison aux autres hors bibliotheque ; exemple
mauvais / bon. Fond en trois temps : constat, sens, direction (« Continue
ainsi » autorise s il est relie a une raison). Moments jusqu a 60 mots.
Section « Ce que tu recois » condensee (jetons).

## Analyse : echelles, quetes du lendemain, secondaires (20 octobre 2026)

- Energie du soir envoyee en clair : « 4 sur 5 (bonne) ». Contraste :
  `energie_soir_moyenne_sur_5`. Consignes : echelles sur 5 expliquees, 4 =
  bonne, jamais presentee comme une difficulte.
- Les quetes sont revelees le matin : consignes (jamais preparer une quete
  precise la veille, sauf « Vision d elite » ; preparer un creneau,
  l environnement, le materiel). Levier « jour faible » et action locale :
  bloquer la veille un creneau pour chacune des 3 obligatoires.
- Secondaires facultatives : une secondaire passee qui precede des echecs
  est un signe avant-coureur, pas une cause.
- Mots cles expliques entre parenthese la premiere fois, sans tiret bas.
  Serveur : la cle interne `k` des schemas n est plus envoyee, et
  `nettoyer` remplace un tiret bas entre deux lettres par une espace.
- Serveur : un moment « exploit » dont le jour n est pas dans
  `exploits_de_la_semaine` devient « declic ».

## Analyse : nouvelles API gratuites (21 octobre 2026)

Recherche des offres gratuites (liste communautaire free-llm-api-resources
et pages officielles, 21 octobre 2026) :
- Ajoutes a la chaine : Cloudflare Workers AI `@cf/openai/gpt-oss-120b`
  (10 000 neurones gratuits par jour, environ 34 analyses ; secrets
  `CLOUDFLARE_CLE` = jeton API Workers AI et `CLOUDFLARE_COMPTE` =
  identifiant de compte, l adresse contient `{CLOUDFLARE_COMPTE}`, maillon
  saute si l un manque) et OpenRouter `openai/gpt-oss-120b:free` avant
  Llama (meme quota gratuit de 50 par jour).
- Ecartes : Google Gemini gratuit (conditions : seuls les services payants
  sont autorises pour une app proposee a des utilisateurs de l EEE),
  Mistral gratuit (exige d accepter l entrainement sur les donnees),
  NVIDIA NIM et Cohere (essai, pas de production), Cerebras (plus qu un
  credit unique de 5 dollars avec carte).
- `urlDe` remplace les variables `{NOM}` de l adresse par les secrets.
Teste sous Node : Cloudflare saute sans compte, appele avec la bonne
adresse quand les deux secrets existent.
Export lisible des consignes et d un exemple de donnees envoyees :
`analyse-ia-prompt-et-donnees.md` (livre a part).

## Analyse : consignes reecrites par Thibs (22 octobre 2026)

`consignes.ts` remplace par le texte de Thibs (4 199 jetons avant, 3 155
maintenant), repris tel quel. Retires : le mot « Introduction » et
« [67 jetons] », ajoutes par le document Word d export. Corrections
d orthographe seulement : attends > attend, verouille > verrouille, permets >
permet, mets > met, n' est > n'est, commencer-un > commencer un, leur quetes
> leurs quetes, qu'envoies tu > qu'envoies-tu, n'a vu > n'a pas vu,
Felicites le > Felicite-le (deux fois), encourage le > encourage-le,
reussie > reussit, Ensuites > Ensuite, Utilises > Utilise, echoue > echoue
(accent), restais > restait, cite > citer, double virgule, utilises des
metaphores > utilise, « . LIS » > « 1. LIS ».
Sortie : `max_tokens` 2500 (1400 en repli apres un 413) ; champs coupes a
1200 caracteres au lieu de 600.

## Analyse : bouclier, exploits elargis, « En partie » restants (22 octobre 2026)

Decisions de Thibs :
1. Bouclier = etat a part, « sous bouclier », ni rate ni reussi. Consignes
   corrigees aux deux endroits (« met toutes les quetes « sous bouclier »
   ... ni ratees ni reussies, un etat a part »).
2. Exploits elargis (`_hebdo90`, champ `genre` et phrase `en_clair`) :
   `quete_rare` (comme avant), `record` (le jour ou la serie depasse
   l ancien record, 5 jours minimum), `serie` (semaine finie sur 7 jours
   d affilee ou plus, sans record), `xp` (gain d XP de la semaine au moins
   1,3 fois la moyenne des 4 semaines d avant et au moins 100 de plus ;
   rattache au jour du plus gros gain). 4 au plus. Consignes : la regle
   d exploit cite ces genres.
3. « En partie » restants : l instantane du jour garde `e` =
   `_quotaPartiel()` moins `weeklyPartialCount`. Par jour :
   `en_partie_restants_cette_semaine`, et pour un jour rate,
   `aurait_pu_sauver_la_journee` le propose s il en restait (sauf quete a
   deux boutons). Non retroactif.
4. Regles si/alors et quetes d action ou de resistance non remises.

## Insights, mise a jour par module (22 octobre 2026)

### Ton auto-maitrise
- Banque `_T_BANQUE` : les 36 affirmations de la Self-Control Scale complete
  (Tangney, Baumeister et Boone, 2004), le maximum publie pour cette
  echelle (impossible d aller a 40 sans inventer des questions non
  validees). Traduction libre ; les 13 de la version courte gardent leur
  traduction d avant. 12 directes, 24 inversees (`r:1`).
- `_tTirage` : 13 au hasard a chaque test, 4 directes et 9 inversees (les
  proportions de la version courte), score toujours sur 65. `_T_ITEMS`
  garde le tirage ; chaque mesure enregistre `ids`.
- 6 paliers `_T_PALIERS` (13, 23, 32, 40, 48, 57) avec icone et descriptif,
  textes provisoires a reecrire par Thibs. La comparaison a la population
  d origine (percentile) est retiree : elle ne vaut que pour les 13
  affirmations fixes. Confrontation aux quetes Discipline : note haute a 40
  et plus, basse a 31 et moins.

### Ta dynamique du moment
- Periodes 14 j, 60 j (defaut), 180 j, Tout (`ST._profPer`, `_dProfPer`),
  au lieu de 120 jours fixes. Constance calculee sur la periode. Minimum :
  30 jours d historique pour afficher la carte (7 en « Voir quand meme »),
  puis 10 jours dans la periode pour 14 j, 20 sinon (sinon message et
  puces).
- `_PROFIL_DESC` : un descriptif fixe par type (Marathonien, Phenix,
  Intermittent, Sprinteur, Batisseur), sans IA, a reecrire par Thibs.

### Seuil de rupture
- `_dRatees` : « Tes quetes obligatoires les plus ratees », periodes 7 j,
  21 j (defaut), 60 j, 180 j, Tout (`ST._ratPer`). Quetes obligatoires
  seulement (boucliers et jours off exclus), au moins 2 occurrences (1 sur
  7 j). Affiche jusqu a 5 quetes sous 65 % de reussite, de la plus ratee a
  la moins ratee ; s il n y en a aucune, les 5 plus ratees avec la mention
  « Aucune quete sous 65 % de reussite ». Ajoute sous le reglage de calcul.
- Puces partagees : `_dPuces`, filtre de periode `_dPeriode`.

### « Voir quand meme »
Bouton sous « X indicateurs attendent plus de donnees » (`_dVoirBascule`,
`window._dVoir`). Recalcule chaque indicateur en attente avec `_dForce` :
seuils minimaux abaisses (domino 3 occurrences, 1 de chaque cote ;
moteur 1 jour par type ; donjon 1 jour ; profil 7 jours) et tests
statistiques ignores. Seuil sans zone : carte avec les quetes les plus
ratees. Chaque carte forcee est precedee de « Indicatif : pas encore assez
de donnees pour que ce resultat soit fiable » et placee en fin de liste.
Indicateur sans aucune donnee : nomme dans le bloc d attente. Le bouton
devient « Masquer les indicateurs incomplets ».

### Correlation energie x reussite
- Texte du bouton info reduit a deux phrases.
- Periodes 14 j, 60 j, 180 j, Tout (defaut) au-dessus des batteries
  (`ST._nrjPer`, `_nrjPer`) : seuls les bilans de la periode comptent.
- Chaque batterie se touche (`_nrjVoir`) : encadre `#st2-nrj-detail`
  (`_nrjDetail`) avec, sur les journees de ce niveau d energie : part des
  quetes obligatoires validees (accomplie ou en partie), eau (jours validees
  sur jours avec une quete eau), secondaires (reussies sur proposees, sur
  les seuls jours qui en avaient). Boucliers et jours off exclus. Masque
  sans abonnement Pro (puces et detail vides).
Teste (Playwright 360 px, donnees fictives) : tirage 13 (4 directes),
palier affiche, anciennes mesures sans `ids` lues, periodes du profil et
des quetes ratees, « Voir quand meme » (cartes indicatives), detail energie
et periode 14 j, mode non Pro. Aucune erreur.

## Insights : etat d auto-maitrise, quetes sous 45 % (22 octobre 2026, soir)

### Ton auto-maitrise : un etat, plus un palier
`_T_PALIERS` remplace par `_T_ETATS` (5 etats, exemple de Thibs) :
l ecart entre l image que le joueur a de lui et ses quetes.
- Note percue = (score - 13) / 52 x 100.
- Taux reel = (accomplies + 0,5 x en partie) / quetes obligatoires des 60
  derniers jours (boucliers et jours off exclus), 20 quetes minimum.
- Note reelle = (taux - 40) / 60 x 100, bornee a 0..100.
- Ecart = percue - reelle : 30 et plus Surestime ; 15 a 29 Legerement
  surestime ; -14 a 14 Coherent ; -29 a -15 Legerement sous-estime ; -30 et
  moins Sous-estime. Descriptifs provisoires.
Affichage : etat, une barre 0 a 100 avec les deux reperes (rond or : ta
note ; carre vert : tes quetes), taux brut et nombre de quetes.

### Seuil de rupture : quetes les plus ratees
Seulement les quetes obligatoires sous 45 % de reussite, de la plus ratee
a la moins ratee, 5 au plus, plus de repli. Aucune : « Actuellement, aucune
quete ne dispose d un taux d echec eleve. Felicitations, et continue comme
cela ! » (texte de Thibs, « continues » corrige en « continue »).

## Audit des Insights (22 octobre 2026, soir)

### Collecte (a la source)
1. Detail des quetes efface au-dela de 120 jours (`_trimQuestDetail`) :
   « 180 j » et « Tout » ne voyaient que 120 jours de quetes. Il est
   maintenant garde en version compacte (`{n: cle, s, t}`, `_qc:1`).
   Les jours deja effaces ne reviennent pas.
2. Secondaires encore verrouillees (avant le jour 14) ecrites « fail » au
   bilan alors que le joueur ne les voit pas ; eau et secondaires non
   touchees ecrites « fail » au bilan mais « skip » sans bilan. Exclues
   avant le jour 14 (bilan et `_questDetailOf`), « skip » partout.
3. Jours de donjon notes seulement si l ecran Donjon etait ouvert ce
   jour-la : « Ce qui marche sur toi » sous-comptait. `_dDngNoterJour` est
   appele a chaque cloture de journee (`advDay`).
4. Bilan de journee off marque `dayoff:true`.

### Lecture (`_dLog`, pour tous les modules et l analyse de la semaine)
5. Jour de la semaine faux pour : journees closes sans bilan (ecrites le
   lendemain matin), bilans apres minuit, absences rattrapees (toutes a la
   date du retour). Recalcule depuis le numero de jour (`_dJourSemaine`),
   cale sur la majorite des bilans du soir. Vue generale (meilleur et pire
   jour) et heatmap passent par le meme calcul (`_dowOf`).
6. Absences rattrapees : elles portaient les quetes du jour du retour,
   comptees ratees pour ces quetes. Journee ratee, sans quetes attribuees.
   Auto-maitrise : une absence compte pour 3 obligatoires ratees.
7. Journee off (objet) et jours simules du mode test (obligatoires toutes
   « skip ») comptaient comme reussis ou rates : neutres, comme un bouclier
   (`repos`, `simule`).
8. `_dLog` mis en memoire (cle : taille du journal, dernier jour, jour
   courant, calendrier) : il etait recalcule des dizaines de fois.

### Modules
9. Seuil de rupture et analyse de la semaine : serie en cours prise comme
   le maximum de la serie du journal et de `ST.streak`. Or `ST.streak` ne
   retombe pas a 0 sur un echec (il perd 1) : apres une chute a 20 jours,
   le module annoncait « Cap franchi : 19 jours ». Serie du journal seule.
10. Rebond (Seuil, Dynamique) : « le lendemain » etait l entree suivante
    du tableau, donc parfois plusieurs jours plus tard apres un bouclier.
    Vrai lendemain.
11. Effet domino : les journees abandonnees (aucune obligatoire validee,
    tout tombe a la cloture) fabriquaient un faux domino. Exclues ; un
    statut « passe » compte comme rate. Teste : un faux domino fait
    d abandons n est plus detecte, un vrai l est.
12. Heures de validation : une quete revalidee comptait deux fois
    (`_dValUniques`, premiere validation par quete et par jour).
13. Correlation energie : bilans des jours sous bouclier (toujours
    « reussis », et pris surtout quand on est fatigue), des journees off
    (energie fixee a 3) et des sanctions faussaient les batteries.
    `_dBilans` les exclut, aussi pour l analyse de la semaine. Le detail
    commence par les journees reussies, la base des batteries.
14. Signaux d echec (analyse de la semaine) : un jour sous bouclier dans
    les 2 jours d avant comptait (« soir sans bilan »...). Ignore.
15. Quete-moteur : « meme en version courte » (on ne change pas une quete)
    devient « quitte a la valider en partie ».
16. Time Capsule : « 0 -> XP, 0 -> record » ne disait rien du chemin. Tes
    14 premiers jours face a tes 14 derniers (journees reussies, part
    « Accomplie », energie du soir, automaticite) et « Tes quetes ont
    grandi » (moyenne des 3 premieres fois et des 3 dernieres, 6 fois au
    moins, +10 % minimum).
Tests a reponse connue (Playwright) : jours de semaine recalcules (0
erreur sur 99 jours, dont noReview et bilans apres minuit decales, et
calage sur une derive de 2 jours), absence sans quetes, repos et simule
neutres, serie du journal a 0 malgre `ST.streak` a 19, bilans exclus,
doublons d heures, faux et vrai domino ; plus les tests precedents.

## Insights : la vue ne saute plus, Seuil sans zone explique (22 octobre 2026, nuit)

- `_garderVue(faire)` : a chaque bouton de periode ou de calcul (Seuil,
  quetes ratees, Dynamique, Energie, « Voir quand meme »), la carte touchee
  est reperee (`data-tag` ajoute a chaque carte, ou son id), tout est
  redessine, puis le defilement est corrige pour la remettre exactement au
  meme endroit de l ecran. Avant, les cartes changeaient de hauteur et
  d ordre (triees par importance) et l ecran sautait. Teste : position
  identique avant et apres le clic (Seuil, Dynamique, Energie).
- Seuil de rupture sans zone : la carte s affiche aussi en « Recent
  d abord » (le module passait « en attente » alors qu il avait assez de
  ruptures). Si toutes les series de la periode cassent a 3 jours ou moins
  (3 ruptures au moins) : « Pas de zone de rupture ... : tes series cassent
  toutes avant N jours », avec l explication (c est le demarrage qui coince,
  viser 2 puis 3 jours). Moins de 5 ruptures : le nombre est donne.

## Seuil : zone verifiee, quete a risque du jour (23 octobre 2026)

**Zone de rupture verifiee par permutation.** Avant, le module trouvait une "zone" meme dans des resultats tires au hasard (7 jeux sur 25) et presque toujours quand de bonnes et de mauvaises periodes se melangent (22 sur 25). Maintenant chaque zone est testee : les resultats sont rebattus 100 fois au hasard a l'interieur de chaque semaine, et la zone n'est gardee que si elle ressort nettement mieux que ces tirages (p < 0,05). Mesure sur 25 jeux par cas : hasard pur 1/25, periodes melangees 3/25, vraie fragilite a un jour donne 24/25. Sinon la carte dit "Pas de vraie zone de rupture".

**Quete a risque du jour (Pro).**
- Sur la carte de la quete obligatoire la plus menacee : badge "A risque aujourd'hui : X % (d'habitude Y %)", touche pour voir le pourquoi.
- Dans le Seuil de rupture : bloc "Ta quete a risque aujourd'hui" avec le pourquoi, un conseil, et la fiabilite.
- Calcul : taux d'echec de la quete sur 90 jours, ajuste par le jour de la semaine (de la quete et en general), la tendance des 14 derniers jours et la zone de rupture verifiee.
- Garde-fou : le modele est rejoue sur les 60 derniers jours. L'alerte ne s'affiche que s'il a fait nettement mieux que le hasard (au moins 5 alertes, 3 justes, precision au moins double du taux d'echec moyen). Sinon : rien.

Fichiers : `www/index.html` (et sa copie Android). Fonction et consignes inchangees.

## Carte gratuite, Portail Nocturne revu (24 octobre 2026)

**Carte gratuite (boutique, cartes du jour).**
- Chaque carte a 8 % de chance d'etre gratuite, une seule au plus sur les 4 (environ 28 % des jours en ont une, mesure sur 20 000 jours). Tirage separe : les autres offres du jour ne changent pas.
- Dos vert "Gratuit", face avec bouton vert "Gratuit", sans prix. Meme style que les cosmetiques, en vert.
- Contenu : 65 % des points (15 a 35), 35 % un item parmi les 6 moins chers achetables (Boite Scellee de Rang E, Potion de double points, Eclat du Veilleur, Elixir d'experience, Lettre du futur, Conseil du Sage).
- Pas de confirmation, ne compte pas pour la Faveur du marchand.

**Portail Nocturne.**
- Bandeau bleu et violet, compact, au-dessus du bloc donjon (style du donjon). L'ancien encart dans la zone evenements est retire.
- Utilise pendant le creneau : "Un portail est en approche... Une quete nocturne arrive ! Sois pret..!". La quete apparait dans le bandeau des la sortie du creneau (verification chaque minute).
- Utilise hors creneau : la quete apparait tout de suite dans le bandeau.
- (i) en haut a droite : rappel du fonctionnement, heure de sortie du creneau incluse.
- Recompenses inchangees (+400 % XP, -150 pts, echec automatique au debut du creneau suivant).

Fichiers : `www/index.html` (et sa copie Android).

## Annuler 5 secondes, carte gratuite et Portail Nocturne au design de l'app (24 octobre 2026, apres-midi)

**Bouton Annuler.**
- Des qu'une quete est traitee (Accomplie, En partie, Fail, Skip, Cristal de focus), un bouton "Annuler" apparait a droite du statut pendant 5 secondes, avec une barre qui se vide.
- Annuler remet tout comme avant : XP, points, integrite, quota "En partie", donjon, compteurs.
- Une seule annulation a la fois : traiter une autre quete rend la precedente definitive.
- Les messages a la guilde ("a complete ...") partent seulement apres les 5 secondes, donc jamais pour une action annulee.
- Valable aussi pour la quete du Portail Nocturne.

**Carte gratuite.** Les points ont maintenant leur cadre SVG comme les autres cartes (pile de pieces et piece a croix verte), nom "+N points".

**Portail Nocturne.**
- Scene illustree : ciel etoile anime, lune, collines, portail lumineux a droite.
- En approche : portail pale qui pulse, avec seulement "Un portail est en approche..." et "Une quete nocturne arrive ! Sois pret..!".
- Ouvert : la quete est une vraie carte de quete (icone, ruban "Quete nocturne +400% XP", tag Nocturne, +80 XP, boutons Accomplie et Fail), dans le bloc.
- Apres reponse, la carte reste affichee avec son statut jusqu'a la fin de la journee.

Fichiers : `www/index.html` (et sa copie Android).

## Donjon : alerte si une quete obligatoire est deja en Fail (24 octobre 2026, 15h)

Quand on entre dans un donjon qui commence le jour meme alors qu'une quete obligatoire est deja en Fail, cet echec compte dans le donjon : une cible "7 sur 7" devient impossible et passe en "Manque" des l'entree, avec les recompenses qui vont avec.
- Maintenant, un message previent ("Quete obligatoire en Fail"), nomme la ou les quetes et propose de revenir demain. Boutons "Retour" et "Lancer quand meme".
- Ce message remplace la confirmation habituelle, pour ne pas enchainer deux alertes.
- Pas de message si le donjon commence de toute facon demain (l'alerte "La Porte s'ouvre demain" s'affiche deja dans ce cas).
- Les jours de De du Destin, l'eau et les secondaires en Fail comptent aussi (elles sont obligatoires ce jour-la).

Fichiers : `www/index.html` (et sa copie Android).

## Balayage entre les menus, au doigt (24 octobre 2026, soir)

Avant : un geste franc changeait d'onglet d'un coup, sans transition.

Maintenant, comme les grandes applis :
- L'ecran suit le doigt, l'ecran voisin arrive a cote. Tant que le doigt n'est pas leve, rien n'a change.
- Au lacher : on termine le mouvement si on a depasse 40 % de la largeur, ou sur un geste vif dans ce sens. Sinon l'ecran revient en place. Un geste vif dans l'autre sens annule.
- Animation de fin qui reprend la vitesse du doigt (140 a 320 ms).
- Barre du bas fixe : la pastille doree glisse d'un onglet a l'autre, les icones passent progressivement du gris au blanc.
- Bords (Quetes a gauche, Social a droite) : effet elastique, retour en place.
- Chaque menu garde sa position de defilement ; au lacher, l'ecran arrive exactement a sa place (0 pixel d'ecart mesure).
- Defilement vertical intact : le navigateur le gere seul (touch-action: pan-y), sans attendre le code.
- Ne demarre pas : geste surtout vertical, plusieurs doigts, champ de saisie, zone qui defile elle-meme a l'horizontale, fenetres ouvertes, tutoriel. Appel systeme, deuxieme doigt, appli mise en arriere-plan ou changement d'ecran par le code : remise en place propre.

Performance :
- Pendant le geste, chaque image ne fait que deplacer deux ecrans (translation GPU, sans rendu ni mise en page).
- Les deux ecrans voisins sont prepares a l'avance quand l'appli est au repos, puis mis en veille (content-visibility: hidden) : ils ne coutent rien au repos (aucun dessin, verifie) mais gardent leur mise en page. Demarrer un geste passe de 80 a 150 ms a 15 a 25 ms sur un telephone 4 fois plus lent.
- Mesures (telephone simule 4 fois plus lent) : 60 images par seconde pendant le geste (p95 16,8 ms), quelques images lentes seulement au tout debut. Telephone normal : preparation 3 a 5 ms.

Au passage : la courbe d'XP des Stats devenait vide (erreur NaN) des qu'un seul jour de l'historique n'avait pas de valeur d'XP. Ces jours sont maintenant ignores.

Fichiers : `www/index.html` (et sa copie Android).

## Ce qui reste, etat au 18 octobre 2026

### Avant le depot sur le Play Store

- **Phase 8, le depot lui-meme.** Rien n est commence.
- **Retirer la derogation des comptes de developpement** posee dans
  `garde_partage` le 16 octobre (voir « La garde anti-triche »). A retirer
  avant une ouverture publique, comme `_DEMO_ON`.
- **Politique de confidentialite.** Obligatoire pour la fiche Play Store,
  inexistante. A ecrire avant de soumettre.
- **Questionnaire de classification d age.** Le plan d acquisition vise 12+,
  mais le questionnaire d entree propose « Resister a la pornographie » comme
  difficulte, les sanctions imposent un effort physique reel, et le chat de
  guilde est du contenu genere par les utilisateurs. Recommandation du plan :
  repondre honnetement et accepter le resultat, probablement 16+ ou plus.
  Non verifie contre le questionnaire reel de Google.

### Taches app issues du plan d acquisition, a valider par Thibs

Proposees le 15 octobre dans la conversation marketing, aucune n est
decidee ni commencee :

- **Ecran d avertissement vers le jour 12**, qui previent que la periode
  sans sanction se termine au jour 15. Argument : un joueur qui decouvre
  quarante pompes au jour 15 sans prevenance laisse une note d une etoile.
- **Test silencieux par cinq personnes** de la cible avant le 1er novembre,
  en notant chaque hesitation de plus de cinq secondes dans l entree en jeu.
- **Captures de store** : sept ecrans dans l ordre du plan, quetes du jour,
  rang, sanction, heatmap, guilde, donjon, lettre.
- **Mesure de retention** dans Supabase par `prog_day` et `updated_at`, sans
  outil ajoute.

Contraintes techniques que le plan prend pour acquises et qu il faut
garder en tete : AUCUN projet iOS (pas de dossier `ios/`, pas de
`@capacitor/ios`), et AUCUNE infrastructure de traduction (`lang="fr"`,
libelles en dur). Toute promesse App Store ou anglais est fausse tant que
ces deux chantiers n existent pas. Pour iOS, la mesure du 7 octobre comptait
49 `backdrop-filter` dont 13 prefixes `-webkit` et 44 `background-clip:text`
dont 22 prefixes : sous Safari les non prefixes tombent. Chiffres a
remesurer avant d ouvrir le chantier.
- **Retirer les guildes et chasseurs de demonstration.** Decision de Thibs le
  16 octobre : on les GARDE tant que l application n est pas publique, ils
  servent aux essais. Interrupteur unique `_DEMO_ON`, qui retire du meme coup
  les chasseurs des classements et les membres factices de guilde. C est le
  dernier correctif avant le depot, a ne pas oublier.
- **La cle de PUBLICATION** n existe pas encore et ne devra jamais etre
  versionnee : secrets GitHub.

### Chantiers demandes par Thibs, pas encore commences

- **Reequilibrage des recompenses.** Thibs a demande le 16 octobre la liste
  propre de trois systemes pour les retravailler : completion d un donjon,
  recompense de saison (quoi, et quels rangs concernes), evenement Clear
  (boite scellee offerte en cas de refus d utilisation). La liste lui a ete
  fournie ; les nouvelles valeurs restent a arbitrer PAR LUI. Ne rien
  modifier sans son accord explicite.
- **Le site sur metanoia-app.com.** Domaine achete chez IONOS le 16 octobre
  pour un an, echeance 16/10/2027, contrat 300461449. Hebergement statique
  gratuit prevu, un enregistrement A ou CNAME suffira.
- **La strategie marketing** a ete deplacee dans une autre conversation.

### Questions ouvertes cote serveur

Un audit du systeme de sanction a ete mene le 16 octobre cote client, et six
requetes d audit ont ete remises a Thibs pour la moitie serveur. **Ses
reponses ne sont jamais revenues** : ces points restent donc non verifies et
ne doivent pas etre presentes comme acquis.

1. La vue `classement` ecarte-t-elle reellement `suspect = true` ?
   `pg_get_viewdef('public.classement'::regclass, true)`
2. Les declencheurs sur `profiles` sont-ils actifs, et dans quel ordre
   alphabetique ? Un BEFORE qui `return null` annule l UPDATE en silence.
3. Qui est marque aujourd hui, et que contient `fraude_journal` ?
4. Les courriels de la garde partent-ils ? `net._http_response`, code 200.
5. Le joueur peut-il lire sa propre colonne `suspect` ? Politiques sur
   `profiles`. Si la colonne manque de la reponse, le client conserve
   desormais son etat au lieu de conclure a une rehabilitation.
6. Les definitions de `guard_profile_progress`, `metanoia_annuler_triche` et
   `metanoia_blanchir`.
7. Point 11 de l audit de securite, jamais verifie : le client ecrit en
   direct sur `profiles` et `guild_messages` seulement, tout le reste passe
   par des RPC, donc tout le controle est dans le corps SQL. A trancher :
   `guild_messages` insert (le client fixe `user_id`, `pseudo`,
   `guild_id`), `guild_request_decide` (`p_by` fourni par l appelant),
   `guild_promote` / `guild_kick` / `guild_set_role` (role de l appelant),
   `save_push` (devenu inutile depuis le retrait du Web Push, a supprimer
   cote serveur), `guild_trade_create` (liste blanche de `p_kind`), les
   lectures de guilde bornees par un `guild_id` du navigateur, et le canal
   temps reel. Requete, avec les parentheses qui manquaient dans le document
   d audit (sans elles, le `or` ramenait `save_push` de tout schema) :

   ```sql
   select p.proname, pg_get_functiondef(p.oid)
   from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname = 'public'
     and (p.proname like 'guild%' or p.proname = 'save_push');

   select tablename, policyname, cmd, qual, with_check
   from pg_policies where schemaname = 'public'
     and tablename like 'guild%'
   order by tablename, policyname;
   ```

**Un point me gene particulierement** : un commentaire du client affirme que
l XP publique d un compte marque est GELEE, et je n ai trouve aucun
mecanisme qui le fasse. Soit c est vrai cote serveur, soit le commentaire
ment. Non tranche.

### Points de conception laisses de cote

- Pas de fil d Ariane ni de bouton retour dans l enchainement des profils :
  chaque feuille remplace la precedente. Limite assumee le 16 octobre.
- L ecran de resultat de fin de saison n a jamais ete vu en conditions
  reelles. Un bouton d essai existe dans le panneau de test, mais le vrai
  declenchement sur un changement de saison reste a observer.
- Le commentaire perime qui justifie le filtre `d.disc !== undefined` dans
  les zones de Flow attend toujours une reecriture. Sans consequence.

### Rappel administratif

Le renouvellement automatique de metanoia-app.com chez IONOS n a pas pu etre
desactive le 16 octobre : le domaine etait encore en cours de traitement
chez le registre. A refaire, sur la ligne `metanoia-app.com` et non sur le
contrat conteneur. Et a poser en alerte d agenda vers septembre 2027, un
mois avant l echeance : perdre le nom apres le lancement coute bien plus
cher que le renouvellement.

### Ce qui a ete regle et ne doit plus etre reouvert

Ces points figuraient ici comme ouverts et ont ete traites le 16 octobre :
l envoi d un courriel au joueur marque (chaine Resend plus pg_net, domaine
verifie), les deux chemins de rehabilitation d un compte marque qui
existaient deja (`metanoia_annuler_triche` et `metanoia_blanchir`, j avais
affirme a tort qu il n y en avait aucun), l erreur
`operator does not exist: text = integer` de `user_public_profile`, et le
classement de Saison, casse par une faute de frappe entre `xp_season` et
`season_xp` puis par le gel anti-triche du compte de Thibs.

## Cle de signature

`android/keystore/debug.keystore` est une cle de DEBOGAGE fixe, versionnee
expres : sans elle, chaque machine et chaque run GitHub en genere une au
hasard, donc une empreinte SHA-1 differente a chaque fois, et Google Sign-In
refuse la connexion. Elle ne protege rien (mot de passe « android », comme la
cle de debogage par defaut d'Android, identique chez tout le monde).

    SHA-1 : 4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97

La cle de PUBLICATION, elle, ne doit JAMAIS etre versionnee : elle ira dans
les secrets GitHub a la phase 8.
