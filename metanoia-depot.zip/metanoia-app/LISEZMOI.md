# Metanoia - projet Android (Capacitor)

Phases 1 a 4 du plan de migration. Le projet se compile dans Android Studio ;
il n'a pas pu etre compile ici, faute d'Android SDK (`dl.google.com` inaccessible).

## Pour le lancer

```bash
npm install
npx cap sync android
npx cap open android      # ouvre Android Studio
```

Puis dans Android Studio : Run, ou Build > Build APK(s).

## Ce qui est fait

- **Phase 1** - socle Capacitor, `appId` `com.metanoia_app`, `appName` Metanoia.
- **Phase 2** - polices et Supabase en local. Plus aucune dependance distante
  sauf Google Sign-In (phase 5).
- **Phase 3** - service worker retire, ligne « Version de l'application »
  retiree des parametres.
- **Phase 4** - stockage natif a deux copies, avec migration automatique.
- **Icones** - phenix seul sur fond bordeaux #4D102F, 5 densites, icone
  adaptative + heritee. Le mot METANOIA est retire de l'icone du lanceur
  (il serait rogne par le masque rond) mais reste sur l'icone du store
  et sur l'ecran de lancement.

## Ou se trouve quoi

| Fichier | Role |
|---|---|
| `www/index.html` | l'application, seul fichier modifie par rapport a ta version |
| `www/fonts.css` + `www/fonts/` | les 13 fichiers de police, 239 Ko |
| `www/supabase.js` | la bibliotheque Supabase, version locale |
| `capacitor.config.json` | identifiant, nom, dossier web |
| `android/` | le projet Android genere |
| `store/icone-play-512.png` | l'icone 512x512 pour la fiche Play Store |

## Structure attendue dans le depot

L'archive se decompresse A LA RACINE du depot :

    <ton depot>/
      .github/workflows/android.yml   <- GitHub ne lit les chaines QUE ici
      metanoia-app/                   <- le projet Android
      index.html, manifest.json, ...  <- ta PWA, intacte

La chaine ne se declenche que si `metanoia-app/` change : modifier la PWA a la
racine ne lance aucune compilation.

## Compiler sans ordinateur

Onglet Actions du depot, « APK Android » dans la colonne de gauche, bouton
« Run workflow ». L'APK se telecharge en bas de la page du run, sous Artifacts,
et l'empreinte SHA-1 s'affiche dans le journal de l'etape du meme nom.
Tout se fait depuis un navigateur, telephone compris.

Si le projet est pose a la racine du depot plutot qu'en sous-dossier, changer
`PROJ: metanoia-app` en `PROJ: .` dans le fichier de la chaine.

## Deux index.html desormais

`metanoia-app/www/index.html` est la version native : sans service worker,
polices et Supabase en local, stockage natif. Celui de la racine reste la PWA.
Les deux ont diverge volontairement ; une correction faite dans l'un doit etre
reportee dans l'autre a la main.

## Changer l'identifiant de l'application

`com.metanoia_app` vient du domaine metanoia-app.com : Android refuse les
tirets, la regle Java les remplace par un underscore. Il est **definitif une
fois publie** sur le Play Store, modifiable librement avant. Les cinq endroits :
`capacitor.config.json`, `android/app/build.gradle` (`namespace` et
`applicationId`), `android/app/src/main/res/values/strings.xml`, le chemin
`android/app/src/main/java/com/metanoia_app/` et la ligne `package` de
`MainActivity.java`.

## Ce qui reste

- Phase 5 - Google Sign-In natif
- Phase 6 - notifications locales natives
- Phase 7 - greffon d'horloge monotone
- Phase 8 - depot sur le Play Store
