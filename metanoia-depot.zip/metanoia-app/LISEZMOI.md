# Metanoia - projet Android (Capacitor)

Phases 1 a 4 du plan de migration. Le projet se compile dans Android Studio ;
il n'a pas pu etre compile ici, faute d'Android SDK (`dl.google.com` inaccessible).

## Pour le lancer

```bash
npm install
npx cap sync android
npx cap open android      # ouvre Android Studio
```

Puis dans Android Studio : Run, ou Build > Build APK(s).

## Ce qui est fait

- **Phase 1** - socle Capacitor, `appId` `com.metanoia_app`, `appName` Metanoia.
- **Phase 2** - polices et Supabase en local. Plus aucune dependance distante
  sauf Google Sign-In (phase 5).
- **Phase 3** - service worker retire, ligne « Version de l'application »
  retiree des parametres.
- **Phase 4** - stockage natif a deux copies, avec migration automatique.
- **Icones** - phenix seul sur fond bordeaux #4D102F, 5 densites, icone
  adaptative + heritee. Le mot METANOIA est retire de l'icone du lanceur
  (il serait rogne par le masque rond) mais reste sur l'icone du store
  et sur l'ecran de lancement.

## Ou se trouve quoi

| Fichier | Role |
|---|---|
| `www/index.html` | l'application, seul fichier modifie par rapport a ta version |
| `www/fonts.css` + `www/fonts/` | les 13 fichiers de police, 239 Ko |
| `www/supabase.js` | la bibliotheque Supabase, version locale |
| `capacitor.config.json` | identifiant, nom, dossier web |
| `android/` | le projet Android genere |
| `store/icone-play-512.png` | l'icone 512x512 pour la fiche Play Store |

## Compiler sans ordinateur

Le dossier `.github/workflows/android.yml` compile l'APK sur les serveurs de
GitHub. Depose le projet sur un depot GitHub, puis onglet Actions, « APK
Android », bouton « Run workflow ». L'APK se telecharge en bas de la page du
run, et l'empreinte SHA-1 s'affiche dans le journal de l'etape du meme nom.
Tout se fait depuis un navigateur, telephone compris.

## Changer l'identifiant de l'application

`com.metanoia_app` vient du domaine metanoia-app.com : Android refuse les
tirets, la regle Java les remplace par un underscore. Il est **definitif une
fois publie** sur le Play Store, modifiable librement avant. Les cinq endroits :
`capacitor.config.json`, `android/app/build.gradle` (`namespace` et
`applicationId`), `android/app/src/main/res/values/strings.xml`, le chemin
`android/app/src/main/java/com/metanoia_app/` et la ligne `package` de
`MainActivity.java`.

## Ce qui reste

- Phase 5 - Google Sign-In natif
- Phase 6 - notifications locales natives
- Phase 7 - greffon d'horloge monotone
- Phase 8 - depot sur le Play Store

## Cle de signature

`android/keystore/debug.keystore` est une cle de DEBOGAGE fixe, versionnee
expres : sans elle, chaque machine et chaque run GitHub en genere une au
hasard, donc une empreinte SHA-1 differente a chaque fois, et Google Sign-In
refuse la connexion. Elle ne protege rien (mot de passe « android », comme la
cle de debogage par defaut d'Android, identique chez tout le monde).

    SHA-1 : 4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97

La cle de PUBLICATION, elle, ne doit JAMAIS etre versionnee : elle ira dans
les secrets GitHub a la phase 8.
