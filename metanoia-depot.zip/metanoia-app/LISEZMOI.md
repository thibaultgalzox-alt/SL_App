# Metanoia - projet Android (Capacitor)

Phases 1 a 4 du plan de migration. Le projet se compile dans Android Studio ;
il n'a pas pu etre compile ici, faute d'Android SDK (`dl.google.com` inaccessible).

## Pour le lancer

```bash
npm install
npx cap sync android
npx cap open android      # ouvre Android Studio
```

Puis dans Android Studio : Run, ou Build > Build APK(s).

## Ce qui est fait

- **Phase 1** - socle Capacitor, `appId` `com.metanoia_app`, `appName` Metanoia.
- **Phase 2** - polices et Supabase en local. Plus aucune dependance distante
  sauf Google Sign-In (phase 5).
- **Phase 3** - service worker retire, ligne « Version de l'application »
  retiree des parametres.
- **Phase 4** - stockage natif a deux copies, avec migration automatique.
- **Phase 5** - connexion Google native via @capgo/capacitor-social-login.
  Le script GSI distant n'est plus charge qu'en web. En natif, le selecteur
  de comptes Android renvoie un idToken, passe au meme signInWithIdToken de
  Supabase qu'auparavant. REQUIERT un client OAuth Android dans la console
  Google Cloud (voir ci-dessous).
- **Icones** - phenix seul sur fond bordeaux #4D102F, 5 densites, icone
  adaptative + heritee. Le mot METANOIA est retire de l'icone du lanceur
  (il serait rogne par le masque rond) mais reste sur l'icone du store
  et sur l'ecran de lancement.

## Ou se trouve quoi

| Fichier | Role |
|---|---|
| `www/index.html` | l'application, seul fichier modifie par rapport a ta version |
| `www/fonts.css` + `www/fonts/` | les 13 fichiers de police, 239 Ko |
| `www/supabase.js` | la bibliotheque Supabase, version locale |
| `capacitor.config.json` | identifiant, nom, dossier web |
| `android/` | le projet Android genere |
| `store/icone-play-512.png` | l'icone 512x512 pour la fiche Play Store |

## Compiler sans ordinateur

Le dossier `.github/workflows/android.yml` compile l'APK sur les serveurs de
GitHub. Depose le projet sur un depot GitHub, puis onglet Actions, « APK
Android », bouton « Run workflow ». L'APK se telecharge en bas de la page du
run, et l'empreinte SHA-1 s'affiche dans le journal de l'etape du meme nom.
Tout se fait depuis un navigateur, telephone compris.

## Changer l'identifiant de l'application

`com.metanoia_app` vient du domaine metanoia-app.com : Android refuse les
tirets, la regle Java les remplace par un underscore. Il est **definitif une
fois publie** sur le Play Store, modifiable librement avant. Les cinq endroits :
`capacitor.config.json`, `android/app/build.gradle` (`namespace` et
`applicationId`), `android/app/src/main/res/values/strings.xml`, le chemin
`android/app/src/main/java/com/metanoia_app/` et la ligne `package` de
`MainActivity.java`.

## A faire dans la console Google Cloud

Sans ces deux reglages, la connexion Google echoue en natif :

1. APIs & Services > Credentials > Create credentials > OAuth client ID,
   type **Android**, nom au choix.
   - Package name : `com.metanoia_app`
   - SHA-1 : `4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97`
2. Verifier dans Supabase (Authentication > Providers > Google) que le
   provider est actif et que le Client ID **Web** y figure.

- **Phase 6** - notifications locales natives (@capacitor/local-notifications).
  Les rappels sont desormais programmes par Android et partent application
  fermee, ce que l'ancien setInterval ne faisait pas. Le Web Push, impossible
  sans service worker, est court-circuite en natif.
- **Phase 7** - greffon d'horloge monotone, ecrit sur mesure
  (`android/.../HorlogePlugin.java`, enregistre dans MainActivity).
  Il expose SystemClock.elapsedRealtime(), que l'utilisateur ne peut pas
  regler, et l'instant de demarrage du telephone. Le rattrapage des jours
  borne desormais ce qu'il rejoue par ce temps reellement ecoule.

- **Evenements** - le canal force par Prediction est devenu un vrai second
  canal, strictement equivalent au naturel : volume, points, quete bonus
  Hard Mode et clear de Frenesie, pas seulement l'XP. Avant, deux tirages sur
  six (`double_pts`, `frenzy`) n'avaient aucun effet, et un shadow force ne
  donnait pas son x2 points. Regle ajoutee : Prediction s'adapte a l'evenement
  du jour et ne peut jamais etre le meme que lui. Reelection a trois endroits,
  au tirage (on retire l'evenement calendaire de demain), au passage de jour
  dans advDay(), et en garde-fou a chaque lecture dans _evForce(), parce que
  l'etat du jour bouge encore apres advDay. Plafond d'XP d'une journee ramene
  de 4990 a 3314 pour les quetes seules.
  Donjon : la condition « 1 quete en evenement » (10 donjons sur 108, Rang C+)
  fabriquait un doubleXP d'office les jours sans evenement calendaire, meme
  quand une Prediction etait deja active : les deux se multipliaient et le jour
  passait a x6. Une Prediction active compte desormais comme un evenement, donc
  plus de fabrication, et elle valide la condition par elle-meme.

- **Audit de securite** - quatre correctifs appliques a index.html.
  1. Le panneau de developpement est reserve au compte administrateur.
     Avant : cinq tapes dans le coin haut droit l ouvraient pour n importe quel
     joueur, sur telephone, sans outil (mesure : 25 050 points en cinq clics).
     RENSEIGNE ADMIN_UID OU ADMIN_EMAIL, declares juste avant toggleTestMode() :
     laisses vides, le panneau est desactive pour tout le monde, toi compris.
     Le mode test ne se rallume plus seul au demarrage, la session n etant pas
     encore resolue a cet instant : cinq tapes une fois connecte le rouvrent.
  2. submitReview() a une garde d idempotence. Avant : un double-clic creditait
     deux fois l XP, les points, UN JOUR DE SERIE et ecrivait deux bilans.
  3. _shopAddToInventory conserve price et orig. Avant : la revente retombait
     toujours sur son repli a 100 et rendait 50 pts, donc acheter a 41 puis
     revendre creait 9 pts par cycle.
  4. _sellInvItem ne decale plus l index une seconde fois, et ne vend qu un
     exemplaire d une pile. Avant, sous bouclier : cliquer la 3e case vendait
     le 1er objet, et toute la pile partait pour le prix d un seul.

  Reste a corriger, par ordre de gravite : l import de sauvegarde n a aucune
  borne (ligne 4972), et la policy de lecture de profiles expose le state_blob
  de tous les joueurs a tous les joueurs.

- **Deconnexion** - l interface repond au doigt leve : la ligne « Se
  deconnecter » disparait avant la synchronisation cloud, qui peut prendre six
  secondes, et le message suit. Puis la progression repart a J1 en conservant
  le questionnaire, le pourquoi et la date de mise a jour du formulaire, pour
  qu un changement de compte ne force personne a tout refaire.
  Filet hors ligne : _socLogout prend un instantane « avant-deconnexion » TANT
  QUE le compte est encore connu, donc range dans l anneau de ce compte. Il
  reapparait seul dans Reglages > Sauvegardes locales a la prochaine connexion
  de CE compte, et nulle part ailleurs. La reinitialisation ne purge donc NI
  IndexedDB NI localStorage, contrairement a testReset : ce serait effacer
  l instantane qu on vient de prendre.

- **Import de sauvegarde retire.** Un fichier importe remplacait l etat entier
  du jeu, et sa validation tenait en une ligne : « day est un nombre OU
  onboarded vaut true ». Le borner ne reglait rien, parce que TOUTES les
  valeurs de reference viennent du fichier : plafonner l XP a 5000 par jour n a
  aucun sens quand le nombre de jours est ecrit par celui qui triche. L export
  reste : le RGPD, article 20, ne porte que sur la SORTIE des donnees et
  n oblige a accepter aucun import. Les fonctions rgpdImport,
  _rgpdExtraitEtat et _rgpdImportFichier sont conservees intactes : pour
  reactiver, il suffit de remettre le bloc HTML d origine.
- **Diagnostic Google B5 reserve a l administrateur.** Il n apparait que sur un
  echec de connexion, jamais sur un succes. Son contenu est ecrit pour le
  developpeur : les joueurs recoivent desormais une phrase comprehensible,
  l outil reste entier pour le compte admin.

- **Rappel de sauvegarde dans Activite.** L import retire, un joueur sans
  compte n a plus aucun moyen de transferer sa progression : on le lui dit.
  Deux mecanismes complementaires. Une entree de journal (_actCheckCompte),
  posee a partir de J3 et au plus UNE par semaine de jeu grace a la cle
  « compte-rappel-<semaine> » : c est elle qui allume la pastille et fait
  ouvrir le panneau. Et une banniere CALCULEE a l ouverture, jamais stockee,
  qui porte le bouton « Creer un compte » et disparait a la seconde ou le
  joueur se connecte. Le bouton reutilise ST._socPulse, le clignotement du
  tutoriel, applique par nav() sur l ecran Social.

- **Fuite du state_blob fermee.** profiles porte a la fois les colonnes
  publiques du classement ET state_blob, la sauvegarde personnelle complete.
  L ancienne policy ne filtrait que les LIGNES, donc un GET
  /rest/v1/profiles?select=* rendait l etat de jeu entier de tous les joueurs.
  Correctif en trois temps, fichier metanoia-fuite-state-blob.sql :
  une vue « classement » qui n expose que les colonnes publiques et ecarte les
  suspects ; une fonction metanoia_pseudo_pris qui verifie l unicite sans lire
  la table ; et profiles restreinte a sa propre ligne en lecture.
  Cote client, quatre points : le classement interroge la vue, et les trois
  controles d unicite du pseudo passent par la fonction. Les dix autres acces a
  profiles sont des ecritures, la suppression RGPD, ou la lecture de sa propre
  ligne : tous inchanges.
  LE SQL ET L APPLICATION SE DEPLOIENT ENSEMBLE : une ancienne version du
  client lirait le classement dans profiles et afficherait une liste vide.

- **Greffon d horloge : la detection etait fausse.** HORLOGE_NATIVE ne testait
  que Capacitor.Plugins.Horloge. Or Capacitor.Plugins ne porte pas forcement un
  greffon natif sans pendant JavaScript : la voie documentee est
  registerPlugin(). Resultat, HORLOGE_NATIVE valait faux sur l appareil,
  _ratMonotone renvoyait null, _ratPlafondMonotone aussi, et TOUT le garde-fou
  etait saute EN SILENCE. L heure du telephone redevenait seule maitresse du
  calendrier. Constate en vrai : heure avancee, l application a suivi jusqu au
  jour 975, et le cliquet a ensuite refuse de revenir.
  Correctif : on essaie Capacitor.Plugins.Horloge PUIS registerPlugin.
  Ajout d un ecran de diagnostic reserve a l administrateur, bouton « Horloge »
  du panneau de test : il dit si le greffon repond, ce qu il renvoie, le
  plafond calcule et l etat du cliquet. Il porte aussi « Reparer », qui relache
  le cliquet et retablit un numero de jour saisi a la main, parce que le
  cliquet interdit de reculer par construction.

- Panneau de test ouvert apres la perte de la session. L identite admin n etait
  verifiee qu a l ouverture : au clic, dans toggleTestMode et au demarrage.
  Rien ne la revalidait ensuite, donc quand le jeton Supabase expirait, panneau
  affiche, il restait visible et pleinement utilisable.
  Correctif : `_verrouPanneauTest()`, appele dans le cycle de rendu et dans
  onAuthStateChange juste apres la reaffectation de _socUser. Il ferme le
  panneau, remet _TEST_MODE a faux et persiste. Teste : admin ouvre, session
  perdue, panneau ferme, reouverture refusee, admin revient, panneau rouvert,
  et le verrou ne gene jamais l admin connecte.

- Rappel de compte affiche aux utilisateurs connectes. Supabase restaure la
  session en asynchrone : au demarrage, `_socUser` vaut null pendant une
  seconde alors que le compte existe, et le cycle de rendu tranchait pendant
  ce laps. Deux bannieres posees « a l instant » sur un compte actif.
  Correctif : drapeau `_socAuthPret`, pose par `onAuthStateChange`, par la
  resolution de `getSession` y compris en echec, et tout de suite quand il n y
  a ni SDK ni configuration. Marqueur durable `ST._socDejaConnecte` pour ne
  pas reclamer un compte a un appareil qui en a deja porte un, cas du
  demarrage hors ligne. `_actPurgeCompte()` retire les bannieres deja posees
  des que la session arrive, par la cle `k` desormais retenue sur chaque
  entree, et par le titre pour celles creees avant. Cadence inchangee : un
  rappel par semaine tant qu il n y a pas de compte.

- Confirmation de deconnexion. Le geste partait d un seul appui et remet
  l appareil au jour 1. Une demande de confirmation precede desormais tout,
  et une fois les animations finies l application quitte les reglages pour
  l ecran des Quetes, onglet actif compris.

- Emblemes de guilde. Composition en cinq couches, entierement vectorielle et
  generee a l execution : 32 symboles, 14 cadres, 18 fonds, 10 effets et
  12 palettes, soit 967 680 combinaisons. Rien n est stocke en image, une
  guilde ne retient qu un code de moins de trente caracteres de la forme
  `v1|s<symbole>|f<cadre>|b<fond>|e<effet>|c<palette>`, ecrit dans la colonne
  `emblem` deja existante. Aucune migration SQL : la policy
  `guilds_update_owner` reserve deja l ecriture au proprietaire.
  Les emblemes d avant, qui etaient des emojis, restent affiches tels quels :
  `embSVG` les reconnait et les rend sans conversion.
  A la creation d une guilde, les cinq couches sont tirees au sort. Le Maitre
  les change ensuite dans les reglages de guilde, couche par couche, chaque
  vignette montrant SON embleme avec cette seule couche modifiee. Les autres
  membres y voient l embleme en grand, sans pouvoir le toucher.
  Les effets sont de petites particules posees en couronne, jamais au centre,
  jouees seulement a partir de 40 px et coupees par
  `prefers-reduced-motion`.

- Reglages de guilde : le bouton Enregistrer passait sous le bord de l ecran,
  donc le premier reflexe devenait la croix, qui jetait tout. La boite est
  desormais une colonne, en-tete fixe, corps qui defile, pied colle avec le
  bouton toujours visible. Hauteur bornee a min(80vh, 640px) et marge basse
  calee sur env(safe-area-inset-bottom) : elle ne depasse plus de l ecran.
  La croix previent quand un embleme, une devise ou un mode de recrutement
  n est pas enregistre.

- Effets d embleme refaits : ils se ressemblaient tous, c etaient onze fois
  les memes points. Onze effets distincts par la forme, le sens et le tempo.
  En continu : Comete (une comete et sa queue font le tour), Braises (elles
  montent du bas en vacillant), Neige (des flocons tombent a des vitesses
  differentes), Runes (deux anneaux tournent en sens contraires), Bulles
  (elles montent en ondulant), Poussiere (des motes respirent sur place).
  En salve, deux secondes d activite puis cinq de silence sur un cycle de
  sept : Etincelles (des eclats a quatre branches claquent), Foudre (un
  eclair traverse avec un flash), Onde (deux ondes de choc partent du
  centre), Balayage (une lame de lumiere passe en diagonale).
  Foudre et Balayage passent PAR DESSUS le symbole, les autres dessous.
  Au repos, sans animation, l eclair et le flash sont a opacite nulle : ni
  mouvement reduit ni vieux moteur ne laissent un aplat blanc sur le blason.
  Dans le selecteur seulement, les effets en salve rejouent toutes les
  2,6 s, sinon on choisirait la Foudre sans l avoir jamais vue frapper.
  Le catalogue passe a 32 x 14 x 18 x 11 x 12 = 1 064 448 combinaisons.

- Foudre : la tension vient du clignotement, plus d un deplacement. La chute
  verticale est abandonnee. Pendant le premier quart du cycle, neuf eclats
  nerveux clignotent a des positions et des instants irreguliers, trois fois
  chacun, avec une amplitude qui monte a l approche de la frappe, pendant que
  le voile du blason respire sourdement. Puis l eclair apparait ENTIER et bat
  trois fois en moins de 0,3 s. L impact laisse une onde rasante et quatre
  eclats qui giclent. Trois couches pour la matiere, un halo large, le corps
  dans la palette et un coeur blanc plus etroit, plus deux fourches.
  Cycle de 5 s, deux frappes par cycle.
  Verifie : les 42 balises d animation ont des keyTimes valides, de meme
  longueur que leurs valeurs, partant de 0, finissant a 1 et jamais
  decroissants, un controle qui compte puisqu un keyTimes malforme est
  ignore en silence par le moteur. Puis 24 captures a 75 ms : 24 images
  differentes, precurseurs, frappe, onde, silence.

- Cadrage du symbole par cadre. Une banniere n a pas sa masse au centre du
  carre de 64 : le symbole tombait sur les encoches du bas. Chaque cadre peut
  desormais porter un decalage vertical `dy`, applique au symbole. Pose sur
  Banniere -6, Pointe -5, Blason -2,5, Ecu -2, Gothique -1,5, Creneaux +1.

- Cinq cadres de plus : Rouage, Epines, Soleil, Banniere, Pointe. Le
  catalogue passe a 32 x 19 x 18 x 11 x 12 = 1 444 608 combinaisons.

- Foudre invisible : bug a moi. La base du groupe valait
  `translate(32 32) scale(0)` et `additive="sum"` MULTIPLIE les transformations,
  donc l echelle animee etait annulee par le zero de depart et l eclair ne
  s affichait jamais. Base ramenee a `translate(32 32)` seul, eclair agrandi,
  et deux frappes par cycle au lieu d une.

- Braises redessinees : un point tres clair dans un halo chaud a deux
  couches, une montee en zigzag sur cinq points, et un vacillement sur sept
  pas d echelle au lieu d une simple apparition. Elles ne se confondent plus
  avec les Bulles.

- Changer une valeur dans l editeur relancait toutes les animations : la
  grille entiere etait reconstruite a chaque choix. Or le contenu des
  vignettes voisines ne change pas, seules la selection et l apercu bougent.
  `_embChoisir` ne touche donc plus qu a ces deux la, via `_embMajApercu` et
  `_embMajSelection`. Verifie : apres un choix, les noeuds SVG de la grille
  sont les MEMES objets qu avant, donc SMIL continue sans redemarrer.

## Audit du 10 octobre, huit defauts corriges

Audit mene par un second regard sur le code recent, chaque defaut reproduit
avant correction et reverifie apres.

1. XSS stockee par le nom de guilde. `g.name` etait concatene dans
   `innerHTML` sans `_esc` a quatre endroits : classement, recherche de
   guildes, bandeau de guilde, onglet Guilde. Une guilde nommee
   `<img src=x onerror=...>` executait du code chez tous ceux qui ouvraient
   ces vues. Un cinquieme site, le profil public, echappait correctement :
   c est l oubli qui saute aux yeux. Corrige partout, devise comprise, et
   `_esc` echappe desormais aussi les guillemets puisqu il alimente des
   attributs HTML. Verifie : 0 image injectee, le texte s affiche tel quel.

2. Un mode de recrutement abandonne finissait par partir au serveur.
   `_guildSetMode` ecrivait `_GUILD.info.recruitment` immediatement, donc la
   croix ne detectait aucune modification et un choix abandonne repartait au
   prochain enregistrement de la devise. Le choix ne vit plus que dans
   `_GUILD_MODE_DRAFT`, l affichage et l enregistrement le lisent, et il est
   consomme a l enregistrement. Verifie : etat reel intact a `ask` apres un
   choix `closed`, la croix previent, Revenir conserve, Quitter jette.

3. Le chat se figeait pour de bon si la session tombait pendant qu il etait
   ouvert. `_guildRenderMsgs` lisait `_socUser.id` sans garde, l exception
   partait dans le callback Realtime et le fil ne se redessinait plus jamais.
   Garde ajoutee, et une session perdue referme desormais le chat et coupe
   l abonnement.

4. Un seul code d embleme corrompu vidait tout le classement. Le modulo de JS
   conserve le signe, un index negatif restait negatif, et `embSVG` levait
   dans un `.map()`. Bornage par `((v%n)+n)%n`, plus un repli sur le premier
   element si le catalogue change. Verifie : `v1|s-1|f-9|...` rend sans lever.

5. Deux tapes rapides sur Reglages empilaient deux overlays aux identifiants
   dupliques : l editeur ne remplissait que le premier, la croix n en fermait
   qu un. L ancien overlay est retire avant d en creer un nouveau.

6. Choisir un mode de recrutement renvoyait le panneau tout en haut. La
   position de defilement est desormais relevee puis restauree.

7. Le curseur sautait en fin de champ a chaque frappe dans la recherche de
   guildes, ce qui rendait impossible la correction d un mot au milieu. La
   position est retenue a la frappe et restauree apres le re-rendu. Les DEUX
   branches sont couvertes, celle avec resultats et celle sans, cette
   derniere etant un doublon que le premier correctif avait manque.

8. `_embAppliquerMode` etait du code mort depuis le passage en SMIL : il
   posait des classes qu aucune regle CSS ne ciblait. Le reglage « Jamais »
   n eteignait donc que ce qui etait redessine ensuite. Chaque svg porte
   maintenant son code dans `data-emb`, et le changement de mode les
   redessine tous sur place. Verifie : 20 balises d animation, 0 apres
   Jamais, 20 au retour.

## Passe du 11 octobre

- Fond du bloc Correlation aligne sur celui de la Time Capsule,
  `linear-gradient(135deg,var(--gold-bg),#F8F0E2)`, et bordure adoucie. Le
  vert des jauges et les flammes ressortent nettement mieux dessus.

- Ecran blanc a la reprise de l application, cause trouvee cote ANDROID et
  non cote web. Le theme `AppTheme.NoActionBar` portait
  `android:background = @null` et aucun `windowBackground` : entre la reprise
  de l activite et le premier rendu de la WebView, Android peignait donc du
  blanc. Trois reglages : `android:windowBackground` et
  `android:colorBackground` sur le theme, pointant une couleur
  `metanoiaFond` = #F8F4EE ajoutee dans `colors.xml`, et `backgroundColor`
  dans `capacitor.config.json` pour que la WebView elle-meme parte en beige.
  Le rechargement reste aussi long, mais il ne se voit plus.

- Quatre cosmetiques redessines dans la facture des autres items de la
  boutique, apres les avoir tous rendus cote a cote pour comparer :
  Aura de l Ombre, Bordure Doree, Aura de Feu, Sceau du Monarque. Boite de
  100, fond arrondi, ombre portee au sol, facettes en aplats franches, un
  eclat clair pour le volume, des particules pour la vie. Les quatorze
  autres ne sont pas touches, ils tenaient deja.
  Le croissant de l Aura de l Ombre est obtenu par soustraction de deux
  disques : les arcs de la premiere version debordaient de la sphere et se
  lisaient comme un anneau exterieur.

- Emojis des onglets du classement remplaces par quatre illustrations
  maison, en COULEUR : globe bleu et vert, lames acier a poignees dorees,
  coupe en or a trois tons, flamme a quatre tons. Aplats francs, deux a
  quatre tons par icone, aucun degrade, 15 px.
  Les couleurs sont fixes et ne suivent pas l etat de l onglet : chaque
  icone porte au moins un ton clair, donc le contraste tient aussi bien sur
  la pastille sombre que sur le fond clair.
  Trois partis pris avaient ete rendus cote a cote avant de trancher :
  monochrome en `currentColor`, couleur pleine, et pastille coloree. La
  version monochrome passait par des DECOUPES en masque plutot que des
  accents peints en blanc, parce qu un accent blanc disparait des que le
  fond est clair. Elle n est pas retenue, mais la lecon vaut pour toute
  icone bicolore posee sur deux fonds.

### Incident de fabrication, et ce que j en retiens

En posant ces icones j ai utilise une expression reguliere globale de la
forme `<svg ...>.*?</svg> Libelle</button>`. Appliquee en chaine, chaque
icone fraichement inseree devenait le point de depart du match suivant, qui
avalait alors la fin du bouton precedent : les quatre boutons ont fusionne en
un seul et 2 000 caracteres ont disparu. Restaure depuis la derniere archive
livree, puis rejoue par un remplacement LIGNE PAR LIGNE, borne a la ligne du
bouton vise. A retenir : sur ce fichier, ne jamais faire porter un `.*?` sur
plusieurs lignes quand on remplace en boucle.

## Correlation Energie x Reussite, deuxieme passe

- Bloc reduit d un tiers : 195 px de haut avant, 129 apres, soit 34 % de
  moins. Piste de 78 a 37 px, icone de 32 a 27, valeur de 17 a 15, marges et
  rembourrages resserres partout. La graduation tous les 25 % est conservee,
  c est elle qui permet de distinguer 93 de 98.

- Illustrations redessinees. Les precedentes etaient des traits de 2 px a 20
  ou 32 % d opacite : fines et pales, c est exactement le reproche. Les trois
  nouvelles sont des masses pleines, et forment une progression lisible d un
  seul regard. La braise : une masse basse et trapue qui ne monte plus, une
  seule volute de fumee large, un coeur a peine tiede. La flamme : droite et
  franche, avec un coeur clair et un point blanc au centre. Le brasier : deux
  langues laterales pour la masse, un coeur tres clair, et six eclats qui
  giclent autour. Une seule volute sur la braise et non deux, car a 27 px
  deux traits proches se confondaient en un crochet illisible.

- L etoile des libelles passe a l or de l application, `var(--gold)`, en
  enveloppant le caractere dans un `span` au rendu. Le libelle lui-meme n est
  pas touche.

## La croix des reglages de guilde ne faisait rien

Symptome : on modifie quelque chose, on tape la croix, rien ne se passe ; on
tape ensuite Enregistrer et c est la demande « Quitter sans enregistrer ? »
qui surgit, au mauvais moment.

Cause : `#sl-confirm-overlay` etait a `z-index:9999`, exactement comme
`guild-set-overlay`. A z-index egal, c est l ordre du DOM qui tranche, et le
panneau de reglages est ajoute a la fin du body : il passait donc DEVANT la
confirmation. La croix ouvrait bien le dialogue, mais derriere le panneau,
invisible et injoignable. Il ne reapparaissait qu une fois le panneau retire
par l enregistrement. La confirmation passe a `z-index:99990`, au-dessus de
tous les panneaux de l application.

Au passage, `slConfirm` n avait qu un seul resolveur : ouvrir un dialogue par
dessus un autre laissait le premier en suspens pour toujours, et son
appelant restait bloque. Le precedent recoit desormais `false` avant d etre
remplace.

Verifie : `elementFromPoint` au centre de l ecran renvoie `sl-confirm-box`,
z 99990 contre 9999, le titre est le bon, Quitter referme les deux, et deux
dialogues coup sur coup se resolvent tous les deux au lieu d en bloquer un.
Parcours complet verifie aussi : embleme, mode et devise modifies puis
enregistres partent bien en un `guild_settings` et un `update guilds`, les
brouillons sont consommes, et la reouverture ne declenche plus aucun
avertissement residuel.

## Retouches visuelles du 10 octobre

- Bulle du chat, la sienne : eclaircie de `#d07e45 / #ad5a28` vers
  `#e2995f / #c2743c`, avec une ombre portee sur le texte pour garder la
  lisibilite du blanc sur ce ton plus clair.

- Correlation Energie x Reussite. La piste faisait 54 px de haut sur toute la
  largeur de la colonne : trois dalles, dont une vide qui se lisait comme une
  barre. Elle est desormais etroite, 46 px au plus, haute de 78 px, creusee
  plus franchement et graduee tous les 25 %, si bien qu une piste vide se lit
  comme vide et qu on distingue 93 de 98. La jauge a du volume par un
  degrade de lumiere, la carte prend le grain de papier et l ombre portee du
  reste de l application. Aucune modification du JS, les fonctionnalites et
  le barème de couleur sont intacts.

- Trois listes gardaient encore l animation coupee : l onglet Guilde du
  classement (`_socLoadGuildRanking`), les cartes de la recherche de guildes
  (`_guildBrowseCard`) et l overlay Classement des guildes
  (`_guildShowRanking`). Elles passaient `false` en troisieme argument, un
  reste de l epoque ou les animations coutaient une keyframe CSS par
  particule. Plus aucun appel ne coupe l animation. Verifie : a 22, 26, 28,
  30, 34, 38, 54 et 58 px, 42 balises d animation emises, et 0 en dessous du
  seuil de 20 px.

- Emblemes animes dans le classement Guilde : ils y etaient rendus en 15 px
  avec l animation coupee. Passes a 22 px et animes, et le seuil d animation
  descend de 36 a 20 px.

- Chat de guilde. Treize fois « Thibs a accompli une quete » noyaient les
  vrais messages : les evenements identiques qui se suivent sont desormais
  replies en une seule ligne portant un compteur. Mesure sur un jeu de
  19 messages : 6 lignes affichees, compteurs x13 et x2.
  Matiere et contraste : grain de papier sur la feuille, en-tete sur un
  bandeau soutenu avec l embleme en 34 px anime, evenements reduits a des
  pastilles discretes, bulles detachees par une ombre portee et un filet, la
  sienne en degrade avec reflet et assise, barre de saisie avec champ creuse
  et bouton d envoi en relief. Les messages reposent sur la barre de saisie
  grace a un `margin-top:auto` sur le premier, et non a
  `justify-content:flex-end` qui casse le defilement vers le haut.

- Effets passes en SMIL, et correction de ma lecture precedente du
  diagnostic. J avais conclu que ma regle de mouvement reduit coupait tout :
  c etait faux. Les elements testes par le diagnostic ne portent AUCUNE de
  mes classes, donc cette regle ne les touchait pas, et les trois techniques
  CSS repondaient NON quand meme. La vraie cause : Android met l echelle de
  duree des animations a zero en economie de batterie, et Chromium annule
  alors toutes les animations CSS du document. SMIL est un moteur separe, il
  continue de tourner, ce que le diagnostic montrait deja.
  Les onze effets sont donc reecrits en SMIL, sans une seule keyframe, et
  `embStyles()` n injecte plus rien. Contrainte posee : chaque effet doit
  rester visible par `animateTransform` seul, la seule technique prouvee sur
  l appareil ; les animations d opacite ne sont plus qu un bonus. Les salves
  passent a 6 s, dont environ 1,5 s d activite, et 2,4 s dans le selecteur.
  Le choix Automatique / Toujours / Jamais est desormais tranche en JS avant
  le rendu : en Jamais ou en mouvement reduit, aucune balise d animation n est
  meme emise.
  Verifie par comparaison de pixels sous mouvement reduit emule, 26 captures
  par effet sur 7,3 s, soit un cycle entier : les dix effets produisent
  26 images differentes. Mes deux sondes logicielles precedentes,
  `getComputedStyle` et `transform.animVal`, ne refletent pas SMIL et
  donnaient toutes deux de faux FIGE.

- Verdict du diagnostic d animation, et vrai coupable. Sur l appareil :
  61 images par seconde, donc la WebView peint parfaitement, et
  `prefers-reduced-motion` ACTIF. Les trois techniques CSS repondaient NON et
  SMIL oui, pour une seule raison : ma propre feuille coupait toutes les
  animations CSS sous mouvement reduit, et ne couvrait pas SMIL. Les effets n
  ont jamais ete casses, ils etaient desactives expres sur un telephone en
  economie de batterie. L hypothese d une WebView qui ne repeint pas etait
  fausse, le diagnostic l a tuee.
  Correctif : reglage « Animations des emblemes » dans les Reglages, trois
  etats qui tournent a chaque tape. Automatique suit le telephone, Toujours
  anime meme en economie de batterie, Jamais coupe partout. Le choix pose une
  classe sur la racine du document, et la regle de mouvement reduit ne s
  applique plus que si le joueur n a pas force. Teste sous mouvement reduit
  emule : en Automatique `animationName` vaut `none`, en Toujours `embBrz`,
  en Jamais `none`, et l eclair garde une opacite nulle quand il est coupe.

- Ecran de demarrage. Quand Android recycle la WebView, l application se
  recharge entierement, et comme le document fait 1,5 Mo dont 1,27 Mo de
  script, l utilisateur voyait du blanc plusieurs secondes. Un ecran peint
  AVANT le gros script affiche desormais le nom et une barre de progression
  pilotee a la main, retiree a la fin du boot, avec un filet de securite a
  12 s. Cela ne rend pas le chargement plus rapide, cela supprime le blanc.
  ATTENTION, la reference structurelle change : le document compte desormais
  4 balises `<script` et 3 blocs inline, contre 3 et 2 auparavant.

- Diagnostic d animation, bouton « Animations » du panneau de test, reserve a
  l administrateur. Il mesure, sans rien croire sur parole : les images par
  seconde reellement servies par la WebView, l etat de `prefers-reduced-motion`,
  et quatre techniques testees une par une en comparant une position ou une
  opacite a deux instants, animation CSS d opacite, transform CSS sur un `<g>`
  SVG, transform CSS avec `transform-box`, et SMIL `animateTransform`. Il
  donne aussi la version du moteur et dit si on tourne dans une WebView.
  Raison d etre : « une frame par clic » signale une WebView qui ne repeint
  que sur interaction, et aucune animation ne vaut d etre dessinee avant de
  savoir laquelle de ces quatre techniques fonctionne sur l appareil.

- Effets d embleme invisibles sur telephone. Deux causes mesurees.
  Primo, la taille : une particule de rayon 1 dans le carre de 64 mesure
  0,8 px quand le blason est rendu en 52 px, et un flocon faisait 1,46 px de
  diametre a l ecran. Les effets tournaient, ils etaient simplement trop
  petits pour se voir. Correctif : un facteur d echelle `_ech` passe a chaque
  effet, 2,1 et davantage encore quand le blason est petit, plus le blason du
  bandeau qui passe de 52 a 58 px. Mesure : le flocon passe de 1,46 a
  3,43 px, l apercu de l editeur de 1,46 a 4,25 px.
  Secundo, `prefers-reduced-motion`. Le mode economie de batterie d Android
  et le reglage d accessibilite « Supprimer les animations » le declenchent
  tous les deux, et la feuille coupe alors toutes les animations, ce qui est
  voulu. Verifie par emulation : en `reduce`, `animationName` vaut `none` sur
  tous les elements d effet. Ce n est pas un defaut, mais c est la premiere
  chose a verifier quand un effet ne bouge pas.

- Regression introduite par la passe de matiere, puis corrigee. Pour que le
  grain de papier reste sous le contenu, la feuille posait
  `#s-social > * { position:relative }`. Or chaque ecran porte sa propre
  barre de navigation `.bnav`, qui est un ENFANT DIRECT de l ecran et qui est
  en `position:fixed` : la regle la repassait dans le flux, et elle se
  retrouvait au milieu de l ecran, avec du vide en dessous, uniquement dans
  l onglet Social. Correctif : le grain passe en `z-index:-1`, ce qui le
  peint sous le contenu en flux sans toucher aux enfants, et la regle sur les
  enfants est supprimee. Mesure apres correctif, sur les cinq ecrans :
  `position:fixed`, bord bas a 915 pour une fenetre de 915.

- Matiere et profondeur, onglet Social. Meme palette, mais le grain du papier
  revient en fond, les cartes se detachent par une ombre portee et un filet,
  le bandeau de guilde devient un en-tete sur un ton plus soutenu, la ligne du
  joueur est creusee au lieu d etre simplement teintee, et le bouton de chat
  prend un reflet en haut et une assise en bas.

- Panneau de test deplacable et repliable. Il s etait rempli au point de
  masquer la zone observee. Poignee en haut a gauche, glissement au doigt
  comme a la souris (pointer events avec setPointerCapture), position bornee
  au viewport et retenue dans localStorage (`metanoia_pos_test`), bouton de
  repli qui ne laisse que la barre de titre (`metanoia_repli_test`).
  Boutons reorganises en grille de 3 colonnes, largeur fixee a 338 px.
  Mesure a 430 px de large : ancien 215 x 288, nouveau 338 x 170, soit 41 %
  de hauteur en moins, et 35 px une fois replie. Libelles inchanges.

- Fuseaux horaires. Pas de reglage ajoute, par choix : le greffon monotone
  borne deja tout bond de calendrier au temps reellement ecoule. Mesure : un
  saut de fuseau de +12 h sans vol donne 0 jour rejoue, le meme saut apres
  24 h de vol en donne 1, une horloge avancee de 880 jours en donne 0. Un
  voyage vers l ouest borne l ecart a 0, le jour ne recule jamais.

- Historique des bilans. L affichage demarre a 12 entrees, un bouton « Voir
  plus » en ajoute 30 a chaque appui et disparait quand tout est affiche.
  Compteur `_BILAN_VUS`, pose du bouton par `_stBilanPlus(total)` juste apres
  le rendu. Verifie dans Chromium sur la fonction extraite du fichier, avec
  57 entrees : 12, puis 42, puis 57, bouton retire, jamais duplique. Cas
  limites passes : liste vide (message « Aucun bilan encore. » intact, pas de
  bouton), pile 12 (pas de bouton), 13 (« 1 restant », singulier).

- Cartes Cosmetique. Le violet nuit est remplace par l ambre profond,
  bordure doree double : filet exterieur `2px solid #F6D98A` et lisere
  interieur `inset 0 0 0 1px rgba(255,241,201,.5)`. Fond
  `linear-gradient(155deg,#A8560F,#D9931F)`. Touche les cartes quotidiennes
  (`.dfront.dcosmetic`, `.ddesc.dcosmetic`, `.dback-cosmetic`, coins dores)
  et, pour rester accordee, la grille `.rc.cosmetic` avec son badge et son
  bouton. Encres passees en creme : nom #FFFDF6, libelles #FFE7B0, prix
  #FFF1C9, halo d icone en rgba(255,214,130,.65). Rendu verifie dans Chromium
  sur les regles extraites du fichier, pour les trois faces et pour la grille.
  Piege rencontre : `.ddesc-icon` n heritait d aucune couleur et restait
  sombre sur l ambre, une regle dediee a ete ajoutee.

- Cartes du jour desynchronisees. Symptome : on retourne une carte, elle
  montre un objet, on la retourne encore et c est un autre objet. Cause
  mesuree : le DOM de la grille datait d un jour boutique anterieur. Le flip
  dos vers face avant ne lit rien, il se contente de tourner la carte deja
  presente, mais le flip suivant rappelle `_getDailyPicked()`, qui renvoie le
  tirage du jour courant. Le jour peut avancer sans passer par
  `renderRewards()` : `_testSetJour` (ligne 9012) ne rappelle que
  `renderMain()`, et en mode reel la bascule de 14h change `_shopDayNum()`
  alors que l ecran est deja ouvert. Correctif : la grille porte
  `data-jour`, et `_dailyGrillePerimee()` la reconstruit avant tout
  retournement et avant tout achat. Verifie dans Chromium sur la fonction
  extraite du fichier : meme jour elle laisse passer sans rien faire, jour
  avance elle reconstruit, remarque la grille, previent par un toast et
  annule le retournement, l appel suivant laisse passer, une grille non
  marquee est reconstruite sans toast, une grille absente ne leve rien.

- Reste ouvert, non corrige : `_getDailyPickedRaw` clone l item
  `mystery_fragment` pour y inscrire le nom du fragment, donc
  `_DAILY_POOL.indexOf(clone)` vaut -1 et `ST._shopDailyPickIdx` devient
  irrecuperable. Au redemarrage, le tirage du jour est donc recalcule au lieu
  d etre restaure. Le seed est deterministe, mais `filteredPool` depend de
  `_itemPurchasable`, qui depend des fragments et des titres restants : si
  l un d eux est acquis dans la journee, le pool retrecit et les quatre
  offres changent. Correctif propose : memoriser l index de l item source et
  l id du fragment, puis rederiver le clone a la restauration.

## Audit de l ecran Stats

Cinq defauts corrige, tous verifies par execution.

- `sr7` efface a chaque jour d absence. Ligne 8771, le rattrapage des jours
  manques faisait `if(ST.sr7.length>7) ST.sr7=ST.sr7.slice(-7)`, reste d une
  epoque ou sr7 ne gardait qu une semaine. Les autres points d ecriture (8395,
  8666, 14060) ne tronquent pas. Mesure : 45 jours de suivi, une seule journee
  manquee, sr7 tombe de 45 a 7 valeurs, et le « Taux 30j » de l ecran Stats
  devient un taux sur 7 jours. Borne portee a 400, comme dayLog.

- Gain XP hebdomadaire sous-estime. `_gainXp` prenait `w2[0].xp` comme
  origine, donc le gain du premier jour de la fenetre disparaissait. Mesure :
  sept jours a +30 XP affichaient 180 au lieu de 210, soit un septieme en
  moins. L origine est desormais le dernier releve anterieur a la fenetre, et
  les bornes sont reperees par numero de jour et non par position, le reste du
  bloc supposant dayLog trie. Sept cas verifies, dont un dayLog desordonne,
  un debut d historique, une semaine a trous et un releve sans champ xp.

- Heatmap desalignee des jours de semaine. Les cellules etaient empilees par
  paquets de sept depuis le premier jour affiche (`dow=i%7`), donc les
  libelles L M M J V S D a gauche ne disaient vrai que si J1 tombait un lundi,
  soit un utilisateur sur sept. Mesure : un J1 un jeudi se retrouvait sur la
  ligne « L ». La grille s ancre maintenant sur le premier releve portant un
  `dow`, et les vieilles sauvegardes sans ce champ gardent l ancien calage.
  Verifie sur 365 jours : zero cellule mal placee.

- Etiquette de la sparkline 30j. Elle annoncait toujours J(jour-29) alors que
  la courbe porte `last30.length` points. Elle suit maintenant le nombre reel
  de points, six cas verifies.

- Etiquette de la sparkline XP. « Jour 1 » etait ecrit en dur dans le HTML
  alors que dayLog est borne a 400 entrees. Elle affiche desormais le premier
  jour reellement trace.

Signale, non corrige :

- `d.absent` est lu a six endroits (9500, 9505, 9541, 14844, 14845, 15009)
  mais n est jamais ecrit dans dayLog : la notion de journee d absence n est
  branchee nulle part, tous ces filtres sont donc sans effet.
- Zones de flow : le commentaire annonce « au moins 5 jours de donnees », le
  code teste `>=3`. Le code est le bon, le commentaire trompe le lecteur.
- Fluidite : `renderStats()` reinjecte 48 Ko de SVG pour la heatmap, mesure a
  5,5 ms sur Chromium de bureau, donc de l ordre de 25 ms en WebView. C est
  differe par `requestIdleCallback`, donc invisible a l ouverture, mais
  recalcule a chaque appui sur « Voir plus ». Non corrige : le gain ne
  justifiait pas le risque d un cache.

Hypotheses verifiees puis ecartees, pour ne pas les reprendre :

- Changement d onglet et position de defilement : teste dans Chromium avec
  des panes de hauteurs tres differentes, le defilement retombe a 0 de
  lui-meme. Pas de defaut.
- Double attribut `style` sur une cellule de heatmap : les deux conditions
  (`isToday` et cellule cliquable) sont mutuellement exclusives.
- Correlation energie et bilans de sanction : la condition d entree ne filtre
  pas `isSanction`, mais les bilans de sanction ne portent aucun champ
  `energy`, donc ils sont deja exclus.

## Audit de l ecran Social

Trois defauts corriges, tous verifies par execution.

- XSS stockee par le pseudo, chez le Maitre de guilde. La liste des membres
  transportait le pseudo dans l attribut `onclick` des boutons Promouvoir et
  Exclure, echappe pour la seule apostrophe : un pseudo contenant un guillemet
  double refermait l attribut. `_guildPromote` et `_guildKick` le passaient
  ensuite a `slConfirm`, qui l insere en HTML brut. La validation du pseudo
  est purement cliente (meme regle a l inscription et au changement), et la
  table `profiles` s ecrit en upsert direct : rien n empeche un membre de
  poser un pseudo piege. Mesure avant correction : deux attributs parasites
  injectes et du code execute au simple survol du bouton. Le pseudo est
  desormais relu dans le roster par `_guildPseudoDe(uid)` et echappe par
  `_esc` au seul endroit qui part en HTML. Apres correction : zero attribut
  parasite, zero balise creee, rien d execute.

- XP de saison mesuree sur la mauvaise periode. `_socCalcSeasonXp` renvoyait
  `_socXpGainedLastDays(14)`, une fenetre glissante de quatorze jours DE JEU,
  alors que la saison est une periode calendaire de quatorze jours. Le premier
  jour d une saison, cette fenetre portait encore treize jours de la
  precedente. Mesure : un joueur a +100 XP par jour declarait 1400 XP de
  saison le jour ou il n en avait gagne que 100, et un joueur de trois jours
  declarait tout son cumul. Le classement de saison etait donc decide par l
  activite d avant la saison. On ancre maintenant le total d XP au premier
  contact avec une nouvelle saison (`ST._socSeasonAncre`) et on compte l
  ecart. Neuf cas verifies, dont le changement de saison, la restauration d
  une sauvegarde plus ancienne (pas de gain negatif) et l idempotence (trois
  appels de suite, aucune sauvegarde superflue).

- Icone d evenement de guilde injectee en HTML brut. Dans `_guildRenderMsgs`,
  `m.body` etait echappe mais `m.icon`, pose par un client via le RPC
  `guild_event` et stocke dans le meme enregistrement, ne l etait pas.

Signale, non corrige :

- Les recompenses hebdomadaires ne sont jamais distribuees. `_SOC_TABS` vaut
  `['global','guild','season','streak']` : il n y a pas d onglet `weekly`,
  donc `_socRecordBestRank('weekly', ...)` n est jamais appele, aucune cle
  `w:` ne peut exister, et le bareme `_SOC_WEEKLY_PRIZES` (500 pts et une Cle
  du Neant pour le premier) est du code mort. A trancher : supprimer le
  bareme, ou reintroduire l onglet.
- La recompense de saison depend de la consultation. `ST._socRanks` n est
  alimente que par `_socLoadLeaderboard`, lui-meme appele seulement quand on
  clique sur un onglet, et l onglet par defaut est `global` a chaque
  ouverture. Un joueur premier de sa saison qui n ouvre jamais l onglet
  Saison ne touche rien. De plus c est le MEILLEUR rang vu lors d une
  consultation qui est retenu, pas le rang final. Correctif propose : charger
  le classement saison en arriere-plan a l ouverture de l ecran Social, et
  retenir le dernier rang plutot que le meilleur.
- Au-dela de la cinquantieme place, `myRank` reste a 0 : le joueur ne voit
  pas du tout sa position, la requete etant limitee a 50 lignes.
- Les guildes de demonstration sont concatenees au vrai classement et
  faussent les rangs. Deja marque `[DEMO]` dans le code, a retirer avant le
  Play Store.

## Audit de l ecran Identite

Trois defauts corriges, tous verifies par execution.

- Barre du prochain trait, fausse de bout en bout. Elle comparait le nombre
  TOTAL de fragments possedes a un denominateur `_nextTrait.fragNeeded||5`,
  or `fragNeeded` n existe sur aucun des dix traits et chacun demande trois
  fragments precis. Mesure : un joueur a vingt fragments dont aucun du trait
  vise lisait 5/5, barre pleine, pour une progression reelle de 0/3. On
  compte desormais les fragments DE CE TRAIT sur le nombre qu il demande.
  Sept cas verifies, dont le cas « plus aucun trait » (pas de division par
  zero).

- Total des fragments fige a 40 dans le calcul comme dans l affichage, alors
  qu un commentaire du code prevoit explicitement l ajout de fragments par
  mise a jour. Remplace par `FRAGMENTS.length`.

- Titre temporaire expire : le joueur etait desequipe meme s il avait gagne
  ce titre pour de bon entre-temps. Acheter un titre epique temporaire puis
  le debloquer legitimement le faisait disparaitre de la tete du joueur au
  bout de sept jours. La recherche ignorait aussi `NEW_TITLES_COMMON`, que le
  mode test peut accorder en temporaire. Six cas verifies.

- Titre « Aspirant » accorde trop tot. Il porte `traits:[]`, et
  `[].every()` vaut true : il tombait donc des le premier `checkFragments()`,
  soit des J1, alors qu il doit arriver a J2 avec le deblocage de l ecran
  Identite. Le marqueur `_starterTitle` etait declare mais lu nulle part. La
  boucle des titres communs teste maintenant `_isUnlocked('tab_identity')`,
  la meme condition que l onglet, pour que les deux ne divergent jamais.
  Verifie : rien a J1, accorde et annonce a J2, et un joueur qui le possede
  deja n est pas renotifie.

Signale, non corrige :

- `_buildTraitCard` divise par `tr.frags.length` sans garde. Aucun trait n a
  de liste vide aujourd hui, mais rien ne l empeche.

Verifie puis ecarte :

- Integrite des donnees : aucun id en double parmi les 40 fragments, 10
  traits et 36 titres, aucun nom de titre en double, aucune reference croisee
  cassee, tous les fragments ont une fonction `check`, et aucun id n est
  partage entre l espace des traits et celui des titres (les titres
  legendaires acceptant les deux).
- `RANKS` est strictement croissant, et la couleur du « Rang Planetaire I »,
  absente de la table, est bien rattrapee par le repli sur expression
  reguliere.
- Le rang A : j avais signale a tort qu il n existait pas. L echelle d XP du
  joueur va bien de B a S, mais le rang A est un TIER DE DONJON
  (`_DUNGEON_ORDER`, index 4), obtenable depuis #Quetes par l offset de
  `_rollDungeonChoices` (12 % au rang n+1, 3 % au n+2). Rien a corriger.
- Les dix fragments que ne reference aucun trait sont voulus.
- `_checkedTitles` est amorce au demarrage, aucun titre deja obtenu n est
  reannonce apres un rechargement.

## Audit de la Boutique

Quatre defauts corriges, tous verifies par execution.

- Duplication de boucliers. Deux lignes d une autre branche s etaient glissees
  dans `shield_1/3/5` : un dialogue « Tu t autorises... Reclamer cette
  recompense », pose APRES l activation. L annuler sortait par `return` avant
  le bloc de consommation. Mesure : bouclier 3j actif, quantite toujours a 1.
  Repetable a chaque expiration, donc bouclier gratuit a vie. Lignes retirees.

- Tout se revendait 50 pts. `_shopAddToInventory` stocke `price` et `orig`
  depuis un correctif precedent, mais AUCUN des quatorze appelants ne les
  transmet : ils valaient donc toujours 0 et `_sellInvItem` retombait sur son
  repli a 100. Le commentaire du code annoncait ce bug comme corrige, il ne l
  etait pas. On retrouve desormais les prix dans `_DAILY_POOL` par `effect`,
  ce qui couvre aussi les objets gagnes en donjon, en boite ou en recompense.
  Mesure apres correction : Elixir 30 pts au lieu de 50 (fin de l exploit),
  Reset Integrite 348 au lieu de 50 (fin de la spoliation). Balayage des 14
  objets au prix d achat le plus bas possible : zero revente rentable.

- `_shopUseItem` et `_sellInvItem` supprimaient par l index capture AVANT le
  `await` de confirmation. Si l inventaire avait bouge pendant la modale, c
  est un autre objet qui partait. On retire par la reference, avec garde sur
  -1, `splice(-1,1)` retirant sinon le dernier element.

Signale, non corrige :

- Les remises du marchand sont CONSTANTES. `_shopItemPrice` calcule
  `seed=(ST.day*137+i*31+idx*17)&0x7fffffff` puis `seed/0x7fffffff`, sans
  jamais melanger : pour des jours realistes le quotient vaut ~0,00001, donc
  `Math.round(rng*20)` vaut toujours 0. Mesure sur 2000 jours, 6 positions et
  4 marchands : la remise marchand vaut toujours exactement 10 % et la faveur
  toujours exactement 20 %, contre les 10 a 30 % et 20 a 35 % annonces par le
  code. Il faudrait atteindre le jour 391 877 pour voir le premier cran. Le
  reste du fichier utilise pourtant un vrai generateur
  (`seed*1103515245+12345`) dans `_getDailyPickedRaw`.
  ATTENTION : corriger ce melange seul ROUVRE l achat-revente rentable.
  Mesure avec le generateur corrige : 6,8 % des combinaisons deviennent
  profitables, jusqu a +32 pts par cycle sur le Reset Integrite, parce que le
  prix plancher tombe a 45,5 % du prix d origine alors que la revente est a
  50 %. Les deux corrections vont donc ensemble : melanger le seed ET
  plafonner la revente au prix reellement paye (ou la ramener a 40 %).

- `price` et `discount` des 30 objets du catalogue ne sont lus nulle part :
  tout le code passe par `item.orig||item.price`, donc `orig` gagne toujours.
  Les `-25%` inscrits dans les donnees sont decoratifs.

- `activate_shield` est le seul effet absent de `_DAILY_POOL` : les boucliers
  gardent donc le repli de revente a 50 pts.

## Remises du marchand, nouvelles bornes

Remise marchand ramenee a 5-10 %, faveur a 10-20 %, et le seed est desormais
melange par le generateur deja utilise dans `_getDailyPickedRaw`. Verifie sur
400 jours, 6 positions, 4 marchands et 10 prix : les six valeurs de remise
marchand et les onze de faveur sont toutes parcourues. Le prix plancher vaut
0,90 x 0,80 = 72 % du prix d origine, contre une revente a 50 %, donc zero
combinaison rentable a l achat-revente sur 96 000 testees.

## Audit de l ecran Quetes

Trois defauts corriges, tous verifies par execution.

- Un echec de quete principale comptait DOUBLE pour les donjons. Dans `trig`,
  `if(q2.type==='disc')ST.weeklyBoss.discFail=...;_dngFail();` : le `if` sans
  accolades ne couvrait que l incrementation de `discFail`, donc `_dngFail()`
  tombait pour toute quete principale echouee, en plus de l appel place en
  tete de la branche. Mesure : trois echecs reels donnaient un compteur a 6,
  et un donjon « max 3 fail » etait perdu alors que le plafond etait respecte.
  Les echecs de quetes secondaires, eux, comptaient juste.

- XP et points farmables a l infini. La garde de `trig` bloquait perfect vers
  clear, mais laissait passer perfect vers fail, puis fail vers perfect : le
  cycle creditait a chaque tour sans jamais reprendre. Mesure : dix cycles sur
  une seule quete donnaient 180 XP, et avant le jour 15, ou l echec ne coute
  ni points ni integrite, les points montaient aussi, 220 contre 100 au
  depart. Apres le jour 14 l XP restait farmable, seuls les points devenaient
  perdants. Une quete validee ne peut plus etre repassee en echec ; corriger
  un clic malheureux reste possible dans l autre sens. Matrice des six etats
  verifiee.

- Taux du Top/Flop au-dessus de 100 %. `questLog[].gen` est incremente par
  `advDay` en FIN de journee, `ok` par `trig` PENDANT la journee : un joueur
  parfait avait donc toujours ok = gen+1. Mesure : 200 %, 150 %, 133 %,
  125 %... le premier taux reellement affiche etant 150 % au jour 3. Le
  denominateur est borne par `Math.max(gen, ok)`.

Signale, non corrige :

- Asymetrie de la penalite d echec. Dans `trig`, echouer une quete principale
  apres le jour 14 coute 5 points d integrite ET 15 points. Dans `advDay`, l
  auto-echec d une quete laissee sans reponse ne coute que l integrite. Ne
  rien faire est donc moins punitif que de marquer honnetement son echec. A
  trancher : aligner `advDay` sur `trig`, ou retirer les 15 points de `trig`.

## Arbitrages tranches et bugs du 11 octobre

- Penalite d echec unifiee. Rater une quete obligatoire coute 5 points d
  integrite, et plus aucun point, quel que soit le chemin. Il y en avait
  TROIS, pas deux : `trig` (declare), `advDay` (bascule du jour) et
  `submitReview` (quetes non traitees au bilan). Les deux premiers retiraient
  15 points, le troisieme aussi et sans la franchise des quatorze premiers
  jours. Les trois appliquent maintenant la meme regle.

- Datation et evenements du mode test, meme cause. `_logDate` figeait une
  epoque au premier appel, puis chaque +1j ajoutait un jour a `ST.day` sans
  avancer le calendrier : la date projetee derivait, et le jour courant
  finissait dans le futur (mesure : jour 1033 date au 21/11/2026 alors qu on
  etait le 11/10). Deux consequences : la heatmap affichait des dates fausses,
  et `_evDateDecalee(0)` lit cette date pour choisir l evenement du jour alors
  que hors mode test il lit `new Date()`. Couper le mode test changeait donc
  la source, l evenement disparaissait de l ecran mais ses effets restaient
  acquis. Le jour courant est desormais ancre sur aujourd hui, le jour N-1 sur
  hier, et basculer le mode test ne change plus l evenement. `ST._dayEpoch`
  disparait.

- Notifications. L ecran Parametres ne lisait que l API web `Notification`,
  que la WebView Android n expose pas toujours : la pastille restait eteinte
  et l activer repondait « Notifications non supportees sur cet appareil »
  alors que le greffon `@capacitor/local-notifications` etait present et
  fonctionnel. `toggleNotif` passe maintenant par le greffon quand il existe,
  et une sonde silencieuse au demarrage (`checkPermissions`, qui ne declenche
  aucune demande) renseigne la pastille des le lancement.

- Animations des emblemes : toujours actives, pour tout le monde. La ligne de
  reglage a trois etats est retiree des Parametres, ainsi que son rendu.

- `slConfirm` : un `cancelLabel` vide masque desormais le bouton. La chaine
  vide etant falsy, le `||` remettait « Annuler » : la fiche Confidentialite
  et donnees, qui demandait deja un seul bouton, en affichait deux.

- Plafond monotone. Le `floor` strict comptait des tranches de 24 h et non des
  minuits franchis : fermer a 23h et rouvrir a 13h le lendemain donnait 14 h,
  donc plafond 0, donc passage de jour bloque ET utilisateur marque suspect
  pour un usage normal. On ajoute ce que le jour avait deja consomme a la
  derniere note (`horloge.msJour`), credit borne a moins de 24 h, qui ne peut
  donc jamais offrir plus d un jour. Huit cas verifies, dont la fraude
  classique (montre avancee de 24 h, app fermee a 23h, reouverture une minute
  apres) qui reste bloquee.

- Journal des incidents d horloge. Les cinq points de mise en doute
  consignent desormais un incident date dans `ST._horlogeIncidents` (borne a
  40). L ecran de diagnostic affiche le compte et propose « Signaler a
  l assistance », qui ouvre le client mail prerempli vers
  metanoia.assistance@gmail.com. Aucun envoi automatique n est possible :
  l application n a pas de service d envoi, seul le client mail du telephone
  peut expedier. Le journal part aussi vers Supabase avec le state_blob.

- Recompenses de classement : uniquement en fin de saison. Le bareme
  `_SOC_WEEKLY_PRIZES` est supprime, les vieilles cles « w: » sont
  neutralisees sans rien verser, et `_socRecordBestRank` retient le DERNIER
  rang connu au lieu du meilleur jamais apercu.

- Rang de saison note en arriere-plan. `_socNoterRangSaison()` est appele a
  l ouverture du Social, quel que soit l onglet affiche : un joueur premier
  qui n ouvrait jamais l onglet Saison ne touchait plus rien.

- Rang visible au-dela de la cinquantieme place. `_socRangExact(tab)`
  interroge le serveur en comptage pur (`head:true`, aucune ligne rapatriee,
  donc aucun risque pour le quota) et une ligne « toi » est ajoutee avec le
  numero exact.

- Conseil du Sage. Une secondaire ACCOMPLIE ne peut plus etre remplacee : le
  statut etait efface sans controle, donc on encaissait XP et points, on
  remplacait la quete, et on encaissait de nouveau. En echec ou en partie, le
  remplacement reste permis.

- Instantane « avant-deconnexion ». `_socLogout` le prenait mais rien ne le
  rejouait. `_snapVeillerDeconnexion()` compare au retour et propose la
  restauration quand l instantane est plus avance que la progression en
  place, une seule fois par instantane.

- `_buildTraitCard` : `0/0` donnait `NaN`, donc `width:NaN%`, que le
  navigateur ignore, soit une barre vide sans explication. Garde posee.

## Evenements : regression de mon correctif, puis correction reelle

Ancrer `_logDate` sur aujourd hui reglait la heatmap mais CASSAIT les
evenements en mode test : la date de tirage ne bougeait plus d un jour simule
a l autre, donc meme jour de semaine, meme cle de semaine, donc le meme
evenement en boucle, et aucun si la journee reelle n en portait pas. C est la
regression signalee immediatement apres livraison.

Deux pieces, parce que le probleme etait double.

- La date d AFFICHAGE et la date de TIRAGE sont separees. `_logDate` reste
  ancre sur aujourd hui et sert a l historique et a la heatmap, qui doivent
  montrer des dates passees plausibles. `_evDateDecalee` derive desormais, en
  mode test, une date du NUMERO de jour (`_EV_EPOQUE_TEST`, calee a midi pour
  qu aucun fuseau ne fasse basculer le jour), pour que chaque jour simule tire
  son propre evenement. Cette date n est jamais affichee.

- L evenement du jour est FIGE dans l etat (`ST._evFige = {j, id}`), au
  premier calcul de la journee. Il etait recalcule a chaque affichage, et la
  source de date differait selon que le mode test etait actif : le couper
  faisait disparaitre l evenement de l ecran alors que ses effets etaient deja
  encaisses. Fige, il ne peut plus changer en cours de journee, ni en
  basculant le mode test, ni en changeant de fuseau. Les previsions du
  lendemain (offset non nul) ne sont pas concernees.

Mesures apres correction :

- Mode test, 14 jours simules : huit types d evenements distincts, les jours
  defilent bien avec leurs evenements.
- Un jour simule portant `easyDay` le GARDE apres coupure du mode test, et
  sur trois lectures consecutives.
- Le figeage ne rejoue pas le tirage : trois appels le meme jour, une seule
  sauvegarde.
- Taux de drop sur 730 jours : 62,5 % de jours avec evenement hors mode test,
  58,5 % en mode test, l ecart tenant a l echantillonnage. Repartition
  conforme aux seuils annonces (doubleXP 13 %, easyDay 12 %, hardMode 11 %,
  double_pts 10 %, frenzy 8 %, shadow 5 %, lucky 3 %).
- Garantie de deux evenements par semaine calendaire : minimum observe 2 sur
  52 semaines completes, moyenne 4,16, aucune semaine en dessous.
- Plus longue serie sans evenement : 6 jours, identique dans les deux modes.

## Lot du 14 octobre

- Dates en double dans la heatmap. La date etait HORODATEE au moment de l
  ecriture de l entree : plusieurs jours de jeu enregistres le meme jour reel
  portaient donc la meme date. Cela arrive avec le mode test, mais aussi hors
  mode test, le rattrapage d absence poussant N entrees d un coup avec
  `_logDate`, qui ignore son argument. D ou deux entrees au 12/10 et un jour
  courant date de la veille. `_dateDeJour(n)` compte desormais a rebours
  depuis aujourd hui, a l AFFICHAGE : chaque jour a sa date, le jour courant
  est aujourd hui. La date stockee reste en repli.

- Sanction muette. Deux causes, mesurees sur les trois chemins.
  `window._TEST_MODE` exemptait TOUTE la session : en mode test, aucune
  sanction ne pouvait tomber, meme sur un jour reellement vecu. Seuls les
  jours FABRIQUES par le panneau doivent l etre, et c est ce que porte
  `_testExemptDay` ; les lots +7j et +30j restent proteges autrement, car
  `_testAutoOneDay` pose `reviewDone=true` avant d appeler advDay.
  Seconde cause, plus sournoise : une sanction restee en attente rend muets
  les TROIS chemins a la fois, tous testant `!ST.sanctionPending`. Un etat
  incoherent (texte vide) ou perime bloquait donc le mecanisme entier en
  silence. `ST.sanctionJour` est memorise et une purge au demarrage nettoie,
  verifiee sur six cas (la sanction d hier est conservee, celle de trois jours
  purgee).

- L ecran de sanction nomme les quetes manquees. Il annoncait un nombre sans
  jamais dire lesquelles.

- Plume de Sagesse : nouvel effet, « ton prochain jour rate ne casse pas ta
  serie ». L ancien +10 % XP sur 3 jours doublonnait avec l Elixir
  d experience. La serie est entamee a CINQ endroits (bilan du soir,
  rattrapage, ouverture tardive, deux chemins de cloture) : tous passent
  desormais par `_plumeProtege()`, qui consomme la protection une seule fois.
  Verifie : avec la plume, un jour rate laisse la serie a 12 au lieu de 11 ;
  quatre jours rates la ramenent quand meme a zero.

- Ecran blanc au retour au premier plan. Meme cause que les animations CSS :
  la WebView Android ne repeint que sur interaction. Un voile dedie
  (`#repaint-kick`, z-index -1, sans pointer-events) voit son opacite varier
  de maniere imperceptible pendant quatorze images au retour, ce qui invalide
  la surface. On ne touche NI a `body` NI a `documentElement` : une opacite ou
  une transformation sur l un d eux creerait un contexte d empilement et
  deplacerait tous les `position:fixed`, dont la barre de navigation, qui est
  un enfant direct de chaque ecran - c est la panne deja vue en septembre.
  Branche sur `appStateChange` de Capacitor, `pageshow`, `focus` et
  `visibilitychange`. Verifie dans Chromium : la barre du bas reste collee au
  bas pendant et apres le reveil, le defilement est conserve, les clics
  traversent le voile.

## Audit de l ecran Quetes, second passage

Trois defauts corriges, tous verifies par execution.

- Le melange des jours n en etait pas un. `genWeek` placait les grosses
  seances avec `sort(() => Math.random()-0.5)`, un comparateur incoherent qui
  ne produit PAS une permutation uniforme. Mesure sur 60 000 tirages de six
  jours : le lundi arrivait en premiere position 28,9 % du temps contre 16,7 %
  attendus, et le samedi en seconde position 5,2 %. Les grosses seances
  tombaient donc nettement plus souvent en debut de semaine. Un melange de
  Fisher-Yates (`_melanger`) remplace les QUATRE occurrences du motif : deux
  dans `genWeek`, deux dans l injection des quetes d arc. Apres correction,
  l ecart est de 16,4 a 16,9 % partout.

- Le doublement des points dependait du canal. `ptsV` passait la Potion de
  double points et l evenement NATUREL par un meme OU, mais ajoutait un second
  x2 pour l evenement FORCE par Prediction. Mesure sur une quete body a 2
  points : potion seule 4, potion + evenement naturel 4, potion + evenement
  force 8. Le doublement s applique desormais au plus une fois, quelle que
  soit sa source ; shadow reste cumulable, c est un effet distinct. Huit cas
  verifies, dont la combinaison naturel double_pts + force shadow, inchangee
  a 6.

- Quota « En partie » incoherent entre les quetes. `_enGalere` etait declare
  DANS la branche des quetes non-negociables, mais relu plus bas par le De du
  Destin, qui rend obligatoires AUSSI l eau et les secondaires. Pour ces
  quetes-la, la variable valait `undefined` et le quota retombait a 2 : le
  meme jour, un joueur en difficulte lisait « En partie(3) » sur sa quete body
  et « En partie(2) » sur sa quete eau. Le calcul passe par `_quotaPartiel()`,
  appele aux deux endroits.

Verifie et sain :

- Le creneau horaire, sur les 24 heures de debut possibles : toujours 16
  heures couvertes, y compris quand la fenetre enjambe minuit (20h donne bien
  20h-11h).
- `getToday()` et l indexation du plan hebdomadaire, avec son garde-fou.
- `_claimDungeon` : le drapeau `claimed` est pose apres la distribution, mais
  toute la fonction est synchrone, donc aucune double reclamation possible.
- `_ensureHardModeQuest` : garde contre le doublon effective.
- Les 318 identifiants lus par `getElementById` : 48 ne sont pas declares
  dans le HTML statique, mais ce sont des couches creees dynamiquement ou du
  code mort assume, et AUCUN n est lu sans garde. Aucune exception silencieuse.
- Les compteurs de serie de donjon : un seul chemin actif, protege par
  `_lastCountedDay` ; le bloc du bilan est neutralise par un `if(false &&`
  volontaire.

Signale, non corrige :

- Indicateur de synchronisation du Social : REBRANCHE. `_socUpdateSyncBar`
  existait et etait appelee a dix endroits, mais ses deux elements
  (`soc-sync-dot`, `soc-sync-label`) n avaient jamais ete declares : la
  fonction sortait sur son garde et n affichait rien. La barre est posee sous
  la carte profil. Verifie dans Chromium sur la fonction extraite du fichier :
  les quatre etats donnent la bonne couleur et le bon libelle, gris au repos,
  or pendant la synchronisation, vert au succes, rouge a l erreur, et un etat
  inconnu retombe sur le repos. Un point a noter : les libelles de la fonction
  sont ecrits sans accents (« Sync auto activee », « Synchronise »), sans
  doute parce qu ils n avaient jamais ete relus a l ecran. Je n y touche pas,
  c est du texte.
- Code mort assume, documente dans le fichier : `xp-nxt`, `s-streak`, `slbl`
  et `s-shop` (l ecran boutique s appelle `s-rewards`).

## Classement de Saison casse, 15 octobre

Thibs signale trois symptomes sur l onglet Saison du Social : les comptes de
demonstration affichent tous 0 XP, lui-meme avec plus de cent points de
saison n apparait pas en tete, et il n a jamais vu l ecran de resultat de fin
de saison.

La cause des deux premiers est une faute de frappe a deux endroits.
`_demoMergeRanking` triait sur `xp_season` et `_demoHunters` fabriquait un
champ `xp_season`, alors que la colonne s appelle `season_xp` partout
ailleurs (neuf occurrences). Consequences : `_socRowValue` lit `season_xp`,
donc chaque chasseur de demonstration valait 0 ; et le tri de saison comparait
une cle que personne ne porte, donc il ne triait rien.

Troisieme point, independant : Thibs etait absent des lignes renvoyees par le
serveur (son `season_id` etait perime), et le repli `_socRangExact` que j
avais ajoute affichait alors « #1 » sous la vingt-cinquieme place, ce qui est
incoherent.

Trois corrections, verifiees par execution :

- `xp_season` renomme en `season_xp` aux deux endroits. Apres coup, les
  demonstrations affichent de vraies valeurs (1431, 1404, 1377...) et plus
  aucune ligne a 0.
- Nouvelle fonction `_socAssurerMaLigne(rows, tab)`, appelee juste apres
  `_demoMergeRanking`, qui insere le joueur courant a partir de ses valeurs
  locales quand le serveur ne l a pas renvoye, puis retrie. Thibs apparait
  desormais a la douzieme place dans la liste elle-meme.
- La ligne « hors classement » du bas n est plus affichee que si le rang
  depasse 25.

Structure revue apres coup : 4 balises `<script`, 3 blocs en ligne, `node
--check` passe sur les trois, analyse lxml valide, cadratins a zero.

## Grade de Second, rond de profil dans la guilde, 16 octobre

Trois ajouts demandes par Thibs sur le Social.

**Le grade de Second.** Hierarchie a trois etages : Maitre > Second > Membre,
sans plafond sur le nombre de Seconds. Une seule fonction decide du rang,
`_gldRang`, et tout le reste en decoule : `_gldPeutAgir(role)` exige un rang
strictement superieur, donc un Second ne peut pas exclure un autre Second ni
toucher au Maitre ; `_gldPeutRecruter()` ouvre l etat de recrutement et les
demandes d adhesion au Maitre et au Second. L emblem et la devise restent au
Maitre seul. Matrice verifiee par execution, les neuf combinaisons :

    moi      cible    agir    recruter
    owner    owner    false   true
    owner    second   true    true
    owner    member   true    true
    second   owner    false   true
    second   second   false   true
    second   member   true    true
    member   *        false   false

Changement de comportement a signaler : avant, **n importe quel membre**
pouvait accepter ou refuser une candidature. C est desormais reserve au
Maitre et au Second, sans quoi donner ce pouvoir au Second ne voudrait rien
dire. Le texte du mode « sur demande » a ete corrige en consequence.

**Le rond dans la liste de guilde.** Le meme `.soc-lb-avatar` que les
classements Serie et Global, en 30 px, pose entre le numero et le pseudo. Un
clic dessus ouvre le profil du joueur, avec `event.stopPropagation()` pour ne
pas declencher le menu de la ligne. Le reste de la ligne garde le systeme
actuel : clic sur le pseudo pour promouvoir ou exclure.

**Le profil joueur.** `_openUserProfile` existait deja, ouvert depuis les
classements. Ajoute : la serie, la devise de la guilde sous son nom, et un
blason gris par defaut pour les chasseurs sans guilde (`_blasonGris`, qui
reprend l ecu `EMB.CAD[1]` en pierre grise, sans symbole ni animation).
« Record » devient « Top global », qui est bien ce que mesure `best_rank`.
Tant que `user_public_profile` ne renvoie pas `streak`, la case affiche un
tiret et non un zero : un zero affirmerait une serie cassee.

**Ce qui manque cote serveur.** Les roles vivent dans Supabase et le depot ne
contient aucun SQL. Il faut : autoriser `second` dans la contrainte de
`guild_members.role`, creer `guild_set_role(p_user, p_role)`, et modifier
`guild_kick`, `guild_settings`, `guild_request_decide` et
`user_public_profile`. Je n ai jamais vu le corps de ces quatre fonctions,
donc je ne les ai pas reecrites a l aveugle : Thibs doit d abord executer un
bloc d inspection. Tant que le SQL n est pas pose, le client degrade
proprement (le bouton « Nommer Second » renvoie une erreur, rien d autre ne
casse).

## Retouches du Second, 16 octobre

Retours de Thibs apres installation.

- « Retirer le grade » devient « Retrograder Membre », et la confirmation
  suit : titre « Retrograder en Membre ? », bouton « Retrograder ».
- Le texte vu par un membre simple dans les reglages parle maintenant du
  Maitre « et son ou ses Seconds », puisque leur nombre n est pas plafonne.
- `.gact-pop` debordait. Avec trois boutons, la bulle d actions depassait a
  droite et il fallait faire defiler la liste pour atteindre « Exclure ». Elle
  passe en `flex-wrap:wrap` avec `max-width:calc(100% - 56px)` et
  `white-space:normal`. Mesure apres coup a 430 px : bulle de 334 px de large,
  86 px de haut, deux lignes, `scrollWidth` du document inchange a 430.

Confirme par Thibs sur l appareil : la nomination d un Second fonctionne, et
un Second peut bien changer l etat de recrutement.

## Ce qui reste

- Phase 8 - depot sur le Play Store
- `user_public_profile` echoue avec « operator does not exist: text = integer ».
  La seule comparaison candidate est `season_id = cur_season`, avec
  `cur_season` declare `int` alors que la colonne serait du texte. Correctif
  propose : declarer `cur_season public.profiles.season_id%type`. A confirmer
  par le type reel de la colonne.
- Le classement de Saison lit la vue `classement`, qui ecarte les profils
  suspects. Le compte Thibs, premier en XP de saison, n y apparait pas depuis
  un autre compte. Vue a inspecter avant toute conclusion.
- L ecran de resultat de fin de saison n a toujours pas ete vu en conditions
  reelles : le declenchement reste a verifier sur un vrai changement de saison

## Cle de signature

`android/keystore/debug.keystore` est une cle de DEBOGAGE fixe, versionnee
expres : sans elle, chaque machine et chaque run GitHub en genere une au
hasard, donc une empreinte SHA-1 differente a chaque fois, et Google Sign-In
refuse la connexion. Elle ne protege rien (mot de passe « android », comme la
cle de debogage par defaut d'Android, identique chez tout le monde).

    SHA-1 : 4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97

La cle de PUBLICATION, elle, ne doit JAMAIS etre versionnee : elle ira dans
les secrets GitHub a la phase 8.
