# Metanoia - projet Android (Capacitor)

Phases 1 a 4 du plan de migration. Le projet se compile dans Android Studio ;
il n'a pas pu etre compile ici, faute d'Android SDK (`dl.google.com` inaccessible).

## Pour le lancer

```bash
npm install
npx cap sync android
npx cap open android      # ouvre Android Studio
```

Puis dans Android Studio : Run, ou Build > Build APK(s).

## Ce qui est fait

- **Phase 1** - socle Capacitor, `appId` `com.metanoia_app`, `appName` Metanoia.
- **Phase 2** - polices et Supabase en local. Plus aucune dependance distante
  sauf Google Sign-In (phase 5).
- **Phase 3** - service worker retire, ligne « Version de l'application »
  retiree des parametres.
- **Phase 4** - stockage natif a deux copies, avec migration automatique.
- **Phase 5** - connexion Google native via @capgo/capacitor-social-login.
  Le script GSI distant n'est plus charge qu'en web. En natif, le selecteur
  de comptes Android renvoie un idToken, passe au meme signInWithIdToken de
  Supabase qu'auparavant. REQUIERT un client OAuth Android dans la console
  Google Cloud (voir ci-dessous).
- **Icones** - phenix seul sur fond bordeaux #4D102F, 5 densites, icone
  adaptative + heritee. Le mot METANOIA est retire de l'icone du lanceur
  (il serait rogne par le masque rond) mais reste sur l'icone du store
  et sur l'ecran de lancement.

## Ou se trouve quoi

| Fichier | Role |
|---|---|
| `www/index.html` | l'application, seul fichier modifie par rapport a ta version |
| `www/fonts.css` + `www/fonts/` | les 13 fichiers de police, 239 Ko |
| `www/supabase.js` | la bibliotheque Supabase, version locale |
| `capacitor.config.json` | identifiant, nom, dossier web |
| `android/` | le projet Android genere |
| `store/icone-play-512.png` | l'icone 512x512 pour la fiche Play Store |

## Compiler sans ordinateur

Le dossier `.github/workflows/android.yml` compile l'APK sur les serveurs de
GitHub. Depose le projet sur un depot GitHub, puis onglet Actions, « APK
Android », bouton « Run workflow ». L'APK se telecharge en bas de la page du
run, et l'empreinte SHA-1 s'affiche dans le journal de l'etape du meme nom.
Tout se fait depuis un navigateur, telephone compris.

## Changer l'identifiant de l'application

`com.metanoia_app` vient du domaine metanoia-app.com : Android refuse les
tirets, la regle Java les remplace par un underscore. Il est **definitif une
fois publie** sur le Play Store, modifiable librement avant. Les cinq endroits :
`capacitor.config.json`, `android/app/build.gradle` (`namespace` et
`applicationId`), `android/app/src/main/res/values/strings.xml`, le chemin
`android/app/src/main/java/com/metanoia_app/` et la ligne `package` de
`MainActivity.java`.

## A faire dans la console Google Cloud

Sans ces deux reglages, la connexion Google echoue en natif :

1. APIs & Services > Credentials > Create credentials > OAuth client ID,
   type **Android**, nom au choix.
   - Package name : `com.metanoia_app`
   - SHA-1 : `4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97`
2. Verifier dans Supabase (Authentication > Providers > Google) que le
   provider est actif et que le Client ID **Web** y figure.

- **Phase 6** - notifications locales natives (@capacitor/local-notifications).
  Les rappels sont desormais programmes par Android et partent application
  fermee, ce que l'ancien setInterval ne faisait pas. Le Web Push, impossible
  sans service worker, est court-circuite en natif.
- **Phase 7** - greffon d'horloge monotone, ecrit sur mesure
  (`android/.../HorlogePlugin.java`, enregistre dans MainActivity).
  Il expose SystemClock.elapsedRealtime(), que l'utilisateur ne peut pas
  regler, et l'instant de demarrage du telephone. Le rattrapage des jours
  borne desormais ce qu'il rejoue par ce temps reellement ecoule.

- **Evenements** - le canal force par Prediction est devenu un vrai second
  canal, strictement equivalent au naturel : volume, points, quete bonus
  Hard Mode et clear de Frenesie, pas seulement l'XP. Avant, deux tirages sur
  six (`double_pts`, `frenzy`) n'avaient aucun effet, et un shadow force ne
  donnait pas son x2 points. Regle ajoutee : Prediction s'adapte a l'evenement
  du jour et ne peut jamais etre le meme que lui. Reelection a trois endroits,
  au tirage (on retire l'evenement calendaire de demain), au passage de jour
  dans advDay(), et en garde-fou a chaque lecture dans _evForce(), parce que
  l'etat du jour bouge encore apres advDay. Plafond d'XP d'une journee ramene
  de 4990 a 3314 pour les quetes seules.
  Donjon : la condition « 1 quete en evenement » (10 donjons sur 108, Rang C+)
  fabriquait un doubleXP d'office les jours sans evenement calendaire, meme
  quand une Prediction etait deja active : les deux se multipliaient et le jour
  passait a x6. Une Prediction active compte desormais comme un evenement, donc
  plus de fabrication, et elle valide la condition par elle-meme.

- **Audit de securite** - quatre correctifs appliques a index.html.
  1. Le panneau de developpement est reserve au compte administrateur.
     Avant : cinq tapes dans le coin haut droit l ouvraient pour n importe quel
     joueur, sur telephone, sans outil (mesure : 25 050 points en cinq clics).
     RENSEIGNE ADMIN_UID OU ADMIN_EMAIL, declares juste avant toggleTestMode() :
     laisses vides, le panneau est desactive pour tout le monde, toi compris.
     Le mode test ne se rallume plus seul au demarrage, la session n etant pas
     encore resolue a cet instant : cinq tapes une fois connecte le rouvrent.
  2. submitReview() a une garde d idempotence. Avant : un double-clic creditait
     deux fois l XP, les points, UN JOUR DE SERIE et ecrivait deux bilans.
  3. _shopAddToInventory conserve price et orig. Avant : la revente retombait
     toujours sur son repli a 100 et rendait 50 pts, donc acheter a 41 puis
     revendre creait 9 pts par cycle.
  4. _sellInvItem ne decale plus l index une seconde fois, et ne vend qu un
     exemplaire d une pile. Avant, sous bouclier : cliquer la 3e case vendait
     le 1er objet, et toute la pile partait pour le prix d un seul.

  Reste a corriger, par ordre de gravite : l import de sauvegarde n a aucune
  borne (ligne 4972), et la policy de lecture de profiles expose le state_blob
  de tous les joueurs a tous les joueurs.

- **Deconnexion** - l interface repond au doigt leve : la ligne « Se
  deconnecter » disparait avant la synchronisation cloud, qui peut prendre six
  secondes, et le message suit. Puis la progression repart a J1 en conservant
  le questionnaire, le pourquoi et la date de mise a jour du formulaire, pour
  qu un changement de compte ne force personne a tout refaire.
  Filet hors ligne : _socLogout prend un instantane « avant-deconnexion » TANT
  QUE le compte est encore connu, donc range dans l anneau de ce compte. Il
  reapparait seul dans Reglages > Sauvegardes locales a la prochaine connexion
  de CE compte, et nulle part ailleurs. La reinitialisation ne purge donc NI
  IndexedDB NI localStorage, contrairement a testReset : ce serait effacer
  l instantane qu on vient de prendre.

- **Import de sauvegarde retire.** Un fichier importe remplacait l etat entier
  du jeu, et sa validation tenait en une ligne : « day est un nombre OU
  onboarded vaut true ». Le borner ne reglait rien, parce que TOUTES les
  valeurs de reference viennent du fichier : plafonner l XP a 5000 par jour n a
  aucun sens quand le nombre de jours est ecrit par celui qui triche. L export
  reste : le RGPD, article 20, ne porte que sur la SORTIE des donnees et
  n oblige a accepter aucun import. Les fonctions rgpdImport,
  _rgpdExtraitEtat et _rgpdImportFichier sont conservees intactes : pour
  reactiver, il suffit de remettre le bloc HTML d origine.
- **Diagnostic Google B5 reserve a l administrateur.** Il n apparait que sur un
  echec de connexion, jamais sur un succes. Son contenu est ecrit pour le
  developpeur : les joueurs recoivent desormais une phrase comprehensible,
  l outil reste entier pour le compte admin.

- **Rappel de sauvegarde dans Activite.** L import retire, un joueur sans
  compte n a plus aucun moyen de transferer sa progression : on le lui dit.
  Deux mecanismes complementaires. Une entree de journal (_actCheckCompte),
  posee a partir de J3 et au plus UNE par semaine de jeu grace a la cle
  « compte-rappel-<semaine> » : c est elle qui allume la pastille et fait
  ouvrir le panneau. Et une banniere CALCULEE a l ouverture, jamais stockee,
  qui porte le bouton « Creer un compte » et disparait a la seconde ou le
  joueur se connecte. Le bouton reutilise ST._socPulse, le clignotement du
  tutoriel, applique par nav() sur l ecran Social.

## Ce qui reste

- Phase 8 - depot sur le Play Store

## Cle de signature

`android/keystore/debug.keystore` est une cle de DEBOGAGE fixe, versionnee
expres : sans elle, chaque machine et chaque run GitHub en genere une au
hasard, donc une empreinte SHA-1 differente a chaque fois, et Google Sign-In
refuse la connexion. Elle ne protege rien (mot de passe « android », comme la
cle de debogage par defaut d'Android, identique chez tout le monde).

    SHA-1 : 4E:E9:5D:95:11:37:78:1F:A0:10:27:EC:56:A7:08:14:9A:D4:46:97

La cle de PUBLICATION, elle, ne doit JAMAIS etre versionnee : elle ira dans
les secrets GitHub a la phase 8.
