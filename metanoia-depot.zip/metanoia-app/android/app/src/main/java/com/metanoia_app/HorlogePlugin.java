package com.metanoia_app;

import android.os.SystemClock;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

// Horloge infalsifiable.
//
// SystemClock.elapsedRealtime() compte les millisecondes depuis le demarrage
// du telephone, veille comprise. L'utilisateur ne peut pas la regler : c'est
// la seule mesure de temps ECOULE dont dispose une application Android.
// Elle se remet a zero a chaque redemarrage, d'ou le second champ.
//
// boot = heure murale - temps ecoule, soit l'instant du demarrage exprime
// dans l'heure du telephone. Cette valeur reste constante pendant toute une
// session de demarrage : si elle bouge, c'est que l'heure murale a ete
// modifiee, et de combien.
@CapacitorPlugin(name = "Horloge")
public class HorlogePlugin extends Plugin {

    @PluginMethod
    public void lire(PluginCall call) {
        long ecoule = SystemClock.elapsedRealtime();
        long mur = System.currentTimeMillis();
        JSObject r = new JSObject();
        r.put("ecoule", ecoule);
        r.put("mur", mur);
        r.put("boot", mur - ecoule);
        call.resolve(r);
    }
}
