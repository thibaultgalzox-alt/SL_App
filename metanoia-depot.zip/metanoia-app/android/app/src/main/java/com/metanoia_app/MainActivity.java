package com.metanoia_app;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import androidx.activity.OnBackPressedCallback;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginHandle;
import ee.forgr.capacitor.social.login.GoogleProvider;
import ee.forgr.capacitor.social.login.ModifiedMainActivityForSocialLoginPlugin;
import ee.forgr.capacitor.social.login.SocialLoginPlugin;

// Connexion Google : apres le choix du compte, le greffon lance une interface
// d'autorisation par startIntentSenderForResult (GoogleProvider ligne 653).
// Son resultat revient ici, et doit lui etre transmis : sans ce relais, la
// promesse de login() n'est jamais resolue et l'application reste figee sur
// « Connexion Google... », sans erreur.
public class MainActivity extends BridgeActivity implements ModifiedMainActivityForSocialLoginPlugin {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Le greffon d'horloge vit dans l'application, pas dans un paquet npm :
        // il faut donc l'enregistrer AVANT que le pont ne demarre.
        registerPlugin(HorlogePlugin.class);
        super.onCreate(savedInstanceState);
        // Bouton retour (26 octobre 2026) : c'est d'abord l'appli qui le traite
        // (fenetre ouverte, sous-menu, retour a Quetes), par _retourAndroid().
        // Si elle n'a rien a fermer, l'appli passe en arriere-plan, comme avant.
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                WebView vue = getBridge() != null ? getBridge().getWebView() : null;
                if (vue == null) { moveTaskToBack(true); return; }
                vue.evaluateJavascript(
                    "(function(){try{return !!(window._retourAndroid&&window._retourAndroid());}catch(e){return false;}})()",
                    valeur -> { if (!"true".equals(valeur)) moveTaskToBack(true); });
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode >= GoogleProvider.REQUEST_AUTHORIZE_GOOGLE_MIN && requestCode < GoogleProvider.REQUEST_AUTHORIZE_GOOGLE_MAX) {
            PluginHandle pluginHandle = getBridge().getPlugin("SocialLogin");
            if (pluginHandle == null) {
                android.util.Log.i("Metanoia", "SocialLogin introuvable");
                return;
            }
            Plugin plugin = pluginHandle.getInstance();
            if (!(plugin instanceof SocialLoginPlugin)) {
                android.util.Log.i("Metanoia", "SocialLogin n'est pas du bon type");
                return;
            }
            ((SocialLoginPlugin) plugin).handleGoogleLoginIntent(requestCode, data);
        }
    }

    // Marqueur exige par l'interface du greffon : il verifie que l'activite a
    // bien ete modifiee avant d'autoriser certains flux.
    public void IHaveModifiedTheMainActivityForTheUseWithSocialLoginPlugin() {}
}
