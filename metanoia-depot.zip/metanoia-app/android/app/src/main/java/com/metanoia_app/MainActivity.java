package com.metanoia_app;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginHandle;
import ee.forgr.capacitor.social.login.GoogleProvider;
import ee.forgr.capacitor.social.login.ModifiedMainActivityForSocialLoginPlugin;
import ee.forgr.capacitor.social.login.SocialLoginPlugin;

// Connexion Google : apres le choix du compte, le greffon lance une interface
// d'autorisation par startIntentSenderForResult (GoogleProvider ligne 653).
// Son resultat revient ici, et doit lui etre transmis : sans ce relais, la
// promesse de login() n'est jamais resolue et l'application reste figee sur
// « Connexion Google... », sans erreur.
public class MainActivity extends BridgeActivity implements ModifiedMainActivityForSocialLoginPlugin {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Le greffon d'horloge vit dans l'application, pas dans un paquet npm :
        // il faut donc l'enregistrer AVANT que le pont ne demarre.
        registerPlugin(HorlogePlugin.class);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode >= GoogleProvider.REQUEST_AUTHORIZE_GOOGLE_MIN && requestCode < GoogleProvider.REQUEST_AUTHORIZE_GOOGLE_MAX) {
            PluginHandle pluginHandle = getBridge().getPlugin("SocialLogin");
            if (pluginHandle == null) {
                android.util.Log.i("Metanoia", "SocialLogin introuvable");
                return;
            }
            Plugin plugin = pluginHandle.getInstance();
            if (!(plugin instanceof SocialLoginPlugin)) {
                android.util.Log.i("Metanoia", "SocialLogin n'est pas du bon type");
                return;
            }
            ((SocialLoginPlugin) plugin).handleGoogleLoginIntent(requestCode, data);
        }
    }

    // Marqueur exige par l'interface du greffon : il verifie que l'activite a
    // bien ete modifiee avant d'autoriser certains flux.
    public void IHaveModifiedTheMainActivityForTheUseWithSocialLoginPlugin() {}
}
