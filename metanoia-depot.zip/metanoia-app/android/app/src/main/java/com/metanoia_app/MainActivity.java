package com.metanoia_app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
